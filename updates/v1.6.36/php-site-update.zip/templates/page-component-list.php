<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php if (!$componentItems): ?><p class="hint"><?= $editText('Ничего не найдено.') ?></p><?php endif; ?>
<?php $inlineSchema = site_component_schema(); ?>
<?php foreach ($componentItems as $index => $item): ?>
    <?php $inlineCode = $item['code']; ?>
    <details id="inline-component-<?= $index ?>" class="inline-component-entry">
        <summary><code><?= site_escape(site_search_clip($inlineCode, 145)) ?></code></summary>
        <?php $dataTarget = site_inline_data_target($item, $base, $contentHost, $settings); ?>
        <?php $mediaTarget = $dataTarget && in_array($item['kind'], ['gal', 'fotos', 'files'], true); ?>
        <?php if ($dataTarget && !$mediaTarget): ?>
            <?php $hasDataTarget = true; ?>
            <?php
            $dataLabel = $editDataText;
            if ($item['kind'] === 'banners') {
                $componentHelp = require SITE_ROOT . '/app/help-component-editing.php';
                $dataLabel = ($componentHelp[$editor['language']] ?? $componentHelp['ru'])[0];
            } elseif ($item['kind'] === 'phpModule') {
                $dataLabel = site_edit_layout_labels($editor['language'])[3];
            }
            ?>
            <div class="header-actions component-data-actions">
                <button type="button" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>" data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape($dataLabel) ?></button>
                <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
                <?php if ($item['kind'] === 'banners' && !$editor['edit'] && !$editInAdmin): ?>
                    <a class="button" href="<?= site_escape($editUrl . '#page-components') ?>"><?= $editText('Править компонент') ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ($item['offset'] !== null && ($editor['edit'] || $editInAdmin)): ?>
        <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>" data-inline-editor="<?= site_escape($item['kind']) ?>">
            <?= $editHidden ?>
            <input type="hidden" name="index" value="<?= $index ?>">
            <?php if ($editInAdmin): ?><input type="hidden" name="return_editor" value="1"><?php endif; ?>
            <div class="fields">
                <?php foreach (site_inline_editor_fields($item) as $field => list($label, $value)): ?>
                    <?php if (in_array($item['kind'], ['points', 'maplist'], true) && $field === 'section'):
                        $mapLabelOptions = require SITE_ROOT . '/app/help-maplist.php';
                        $mapLabelOptions = $mapLabelOptions[$editor['language']] ?? $mapLabelOptions['ru']; ?>
                    <label class="field"><?= site_escape($mapLabelOptions[4]) ?>
                        <input data-inline-field="section" value="<?= site_escape($value) ?>" placeholder="/sample/" maxlength="240">
                    </label>
                    <?php continue; endif; ?>
                    <label class="field"><?= $editText($label) ?>
                        <?php if ($item['kind'] === 'route' && $field === 'provider'): ?>
                            <select data-inline-field="provider">
                                <option value=""<?= $value === '' ? ' selected' : '' ?>><?= $editText('По умолчанию') ?></option>
                                <option value="yandex"<?= $value === 'yandex' ? ' selected' : '' ?>><?= $editText('Яндекс Карты') ?></option>
                                <option value="google"<?= $value === 'google' ? ' selected' : '' ?>>Google Maps</option>
                            </select>
                        <?php elseif ($item['kind'] === 'iblock' && $field === 'template'): ?>
                            <?php $viewOptions = site_iblock_views(); ?>
                            <select data-inline-field="template">
                                <?php if (!isset($viewOptions[$value]) && $value !== ''): ?><option value="<?= site_escape($value) ?>" selected disabled><?= site_escape($value) ?></option><?php endif; ?>
                                <?php foreach ($viewOptions as $name => $viewLabel): ?><option value="<?= site_escape($name) ?>"<?= $name === $value ? ' selected' : '' ?>><?= $editText($viewLabel) ?></option><?php endforeach; ?>
                            </select>
                        <?php elseif ($item['kind'] === 'iblock' && $field === 'type'): ?>
                            <?php $chartLabels = site_iblock_chart_text($editor['language']); ?>
                            <select data-inline-field="type">
                                <?php foreach (site_iblock_chart_types() as $chartIndex => $type): ?>
                                    <option value="<?= site_escape($type) ?>"<?= $type === $value ? ' selected' : '' ?>><?= site_escape($chartLabels['types'][$chartIndex]) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input data-inline-field="<?= site_escape($field) ?>" value="<?= site_escape($value) ?>" maxlength="500">
                        <?php endif; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <?php if (isset($inlineSchema[$item['sizeKind']])): ?>
                <?php $selectedOptions = site_shortcode_options($item['options']); ?>
                <?php
                if (isset($selectedOptions['width'])) {
                    $selectedOptions['width'] = rtrim($selectedOptions['width'], '%');
                    if ($selectedOptions['width'] === '100') $selectedOptions['width'] = $item['sizeKind'] === 'banners' ? 'page' : 'parent';
                }
                if (!isset($selectedOptions['mobile-height']) && isset($selectedOptions['height-mobile'])) {
                    $selectedOptions['mobile-height'] = $selectedOptions['height-mobile'];
                }
                ?>
                <div class="fields">
                    <?php foreach ($inlineSchema[$item['sizeKind']]['settings'] as $name => $option): ?>
                        <label class="field"><?= site_escape(site_component_size_text($option['label'], $editor['language'])) ?>
                            <select data-inline-option="<?= site_escape($name) ?>">
                                <option value=""><?= $editText('По умолчанию') ?></option>
                                <?php if (in_array($name, ['height', 'mobile-height'], true) && isset($selectedOptions[$name])
                                    && !isset($option['options'][$selectedOptions[$name]]) && preg_match('/\A[0-9]{2,4}(?:px)?\z/', $selectedOptions[$name])): ?>
                                    <option value="<?= (int) $selectedOptions[$name] ?>" selected><?= (int) $selectedOptions[$name] ?> px</option>
                                <?php endif; ?>
                                <?php foreach ($option['options'] as $value => $label): ?>
                                    <option value="<?= site_escape((string) $value) ?>"<?= (string) $value === ($selectedOptions[$name] ?? null) ? ' selected' : '' ?>><?= site_escape(site_component_size_text($label, $editor['language'])) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <label class="field"><?= $editText('Код вставки') ?>
                <textarea class="inline-component-code" name="code" rows="2" maxlength="4000" spellcheck="false"><?= "\n" . site_escape($inlineCode) ?></textarea>
            </label>
            <div class="header-actions">
                <button class="button-primary" name="action" value="live-component"><?= $editText('Сохранить') ?></button>
                <?php if ($mediaTarget): ?>
                    <?php $hasDataTarget = true; ?>
                    <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>"
                        data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape(site_file_manager_labels($editor['language'])[0]) ?></a>
                <?php endif; ?>
            </div>
        </form>
        <?php elseif ($mediaTarget): ?>
            <?php $hasDataTarget = true; ?>
            <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>" data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape(site_file_manager_labels($editor['language'])[0]) ?></a>
        <?php elseif (!$dataTarget): ?>
            <p class="hint"><code><?= site_escape($inlineCode) ?></code></p>
        <?php endif; ?>
    </details>
<?php endforeach; ?>
