<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_MAPS_FILE = SITE_ROOT . '/admin/.maps.php';

function site_map_providers(): array
{
    return ['off' => 'Выключено', 'yandex' => 'Яндекс Карты', 'google' => 'Google Maps'];
}

function site_map_modes(): array
{
    return ['map' => 'Схема', 'satellite' => 'Спутник', 'hybrid' => 'Гибрид'];
}

function site_map_settings(): array
{
    $default = ['provider' => 'off', 'mode' => 'map', 'zoom' => '12', 'cluster' => '1', 'yandex_key' => '', 'google_key' => '', 'google_map_id' => ''];
    try {
        $stored = site_read_record(SITE_MAPS_FILE);
    } catch (RuntimeException $exception) {
        return $default;
    }
    return array_replace($default, array_intersect_key(array_filter($stored, 'is_string'), $default));
}

function site_map_url(string $url): string
{
    if ($url === '' || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
        return '';
    }
    if ($url[0] === '/' && substr($url, 0, 2) !== '//') {
        return $url;
    }
    return preg_match('~\Ahttps?://~i', $url) && filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
}

function site_map_coordinates(string $lat, string $lng): ?array
{
    if (!preg_match('/\A-?[0-9]{1,3}(?:\.[0-9]{1,10})?\z/', $lat)
        || !preg_match('/\A-?[0-9]{1,3}(?:\.[0-9]{1,10})?\z/', $lng)
        || abs((float) $lat) > 90 || abs((float) $lng) > 180) {
        return null;
    }
    return ['lat' => (float) $lat, 'lng' => (float) $lng];
}

function site_page_map_point(array $page, array $context, array $baseFields = []): ?array
{
    $fields = $page['fields'];
    $coordinates = site_map_coordinates($fields['Lat'] ?? '', $fields['Lng'] ?? '')
        ?? site_map_coordinates($baseFields['Lat'] ?? '', $baseFields['Lng'] ?? '');
    if ($coordinates === null) {
        return null;
    }
    $path = site_page_translation($page['path'])[0];
    $title = site_search_clip(site_expand_text($fields['Title'], $context['snippets']), 500);
    return $coordinates + ['title' => $title, 'url' => site_page_url($context['base'], $path), 'button' => ''];
}

function site_component_map(array $options, array &$context): string
{
    if (!isset($context['mapPoints'])) {
        return '';
    }
    $manual = isset($options['lat']) || isset($options['lng']);
    $page = $context['pageData'];
    $baseFields = !$manual && $page['path'] !== $context['originalPath'] ? (site_read_page($context['originalPath'])['fields'] ?? []) : [];
    $point = $manual ? site_map_coordinates($options['lat'] ?? '', $options['lng'] ?? '') : site_page_map_point($page, $context, $baseFields);
    if ($point === null || ($manual && ($options['title'] ?? '') === '')) {
        return '';
    }
    $url = site_map_url($options['url'] ?? '');
    if ($url !== '' && $url[0] === '/') {
        $url = site_url($context['base'], substr($url, 1));
    }
    $first = !$context['mapPoints'];
    $context['mapPoints'][] = array_replace($point, ['title' => $options['title'] ?? ($point['title'] ?? ''),
        'url' => isset($options['url']) ? $url : ($point['url'] ?? ''), 'button' => $options['button'] ?? '']);
    if (!$first) {
        return '';
    }
    $context['mapOptions'] = $options;
    $context['mapSlot'] = '<!--site-map-' . bin2hex(random_bytes(12)) . '-->';
    return $context['mapSlot'];
}

function site_component_all_maps(array $options, array &$context): string
{
    if (($options['source'] ?? '') !== '') {
        try {
            $block = site_read_iblock($options['source']);
        } catch (RuntimeException $exception) {
            return '';
        }
        $points = [];
        $keys = array_column($block['columns'] ?? [], 'key');
        foreach (array_slice($block['rows'] ?? [], 0, 500) as $row) {
            if (count($keys) !== count($row)) continue;
            $record = array_combine($keys, $row);
            $title = trim($record['title'] ?? '');
            $coordinates = site_map_coordinates(trim($record['lat'] ?? ''), trim($record['lng'] ?? ''));
            if ($coordinates === null || $title === '') continue;
            $url = site_map_url(trim($record['url'] ?? ''));
            if (isset($url[0]) && $url[0] === '/') $url = site_url($context['base'], substr($url, 1));
            $points[] = $coordinates + ['title' => site_search_clip($title, 500), 'url' => $url, 'button' => site_search_clip($record['button'] ?? '', 200)];
        }
        return site_render_map($points, $options, $context['locale'], $context['base']);
    }
    if (!isset($context['allMapPoints'])) {
        $context['allMapPoints'] = [];
        foreach (site_pages() as $basePage) {
            if (!site_page_is_public($basePage['fields'])) {
                continue;
            }
            $page = site_localized_page($basePage['path'], $context['locale']);
            $point = $page === null ? null : site_page_map_point($page, $context, $basePage['fields']);
            if ($point !== null) {
                $context['allMapPoints'][] = $point;
            }
        }
    }
    return site_render_map($context['allMapPoints'], $options, $context['locale'], $context['base']);
}

function site_component_section_map(string $kind, string $directory, array $options, array &$context): string
{
    $path = $context['originalPath'] ?? '';
    $directory = trim($directory);
    if ($directory === '') {
        if ($path === '' || strpos($path, 'error/') === 0) return '';
        $directory = dirname($path) === '.' ? '/' : '/' . dirname($path) . '/';
    }
    if (!preg_match('~\A/(?:[a-z0-9_-]+/)*\z~i', $directory)
        || !site_valid_path(substr($directory, 1) . 'index.php') || stripos($directory, '/error/') === 0) {
        return '';
    }
    $cacheKey = $context['locale'] . '|' . $directory;
    if (!isset($context['sectionMapPoints'][$cacheKey])) {
        $base = $context['base'];
        $prefix = substr($directory, 1);
        $labels = require __DIR__ . '/help-maplist.php';
        $button = ($labels[$context['locale']] ?? $labels['ru'])[1];
        $context['sectionMapPages'] = $context['sectionMapPages'] ?? site_pages();
        $context['sectionMapPoints'][$cacheKey] = [];
        foreach ($context['sectionMapPages'] as $basePage) {
            $target = $basePage['path'];
            if (strpos($target, $prefix) !== 0 || strpos($target, 'error/') === 0) continue;
            $page = site_localized_page($target, $context['locale']);
            if ($page === null) continue;
            $point = site_page_map_point($page, $context, $basePage['fields']);
            if ($point === null) continue;

            $point['url'] = site_page_link($base, $page);
            $image = site_page_media_url($page['fields']['AnnouncementImage'] ?? '', $base);
            $announcement = site_page_announcement($page, $context['snippets']);
            $point['label'] = site_page_menu_label($point['title'], $page, $base);
            $point['card'] = '<article class="map-page-balloon"><strong>' . $point['label'] . '</strong>'
                . ($image === '' ? '' : '<img class="map-page-balloon-image" src="' . site_escape($image) . '" alt="">')
                . ($announcement === '' ? '' : '<div class="map-page-balloon-note">' . $announcement . '</div>')
                . '<a class="button button-primary" href="' . site_escape($point['url']) . '">' . site_escape($button) . '</a></article>';
            $context['sectionMapPoints'][$cacheKey][] = $point;
        }
    }
    $points = $context['sectionMapPoints'][$cacheKey];
    if ($kind === 'maplist') return site_render_map($points, $options, $context['locale'], $context['base']);
    if (!$points) return '';
    $modal = ($options['display'] ?? '') === 'modal';
    $name = 'point-list-' . bin2hex(random_bytes(6));
    $items = '';
    unset($options['center'], $options['center_lat'], $options['center_lng']);
    foreach ($points as $point) {
        $label = $point['label'];
        unset($point['label']);
        $map = '<template>' . site_render_map([$point], $options, $context['locale'], $context['base']) . '</template>';
        $link = '<noscript><a href="' . site_escape($point['url']) . '">' . site_escape($point['title']) . '</a></noscript>';
        $items .= $modal
            ? '<li><button type="button" data-point-map-open aria-haspopup="dialog">' . $label . '</button>' . $map . $link . '</li>'
            : '<li><details name="' . $name . '" data-point-map><summary>' . $label . '</summary>' . $map . $link . '</details></li>';
    }
    $list = '<ul class="page-point-maps">' . $items . '</ul>';
    if (!$modal) return $list;
    $close = site_escape(site_translation('Закрыть', $context['locale']));
    return '<div data-point-map-group>' . $list . '<dialog class="editor-dialog page-point-map-dialog" aria-labelledby="' . $name . '">'
        . '<div class="header-actions editor-dialog-heading"><h2 id="' . $name . '" data-point-map-title></h2>'
        . '<form method="dialog"><button type="submit" aria-label="' . $close . '">×</button></form></div>'
        . '<div data-point-map-body></div></dialog></div>';
}

function site_finish_map(string $html, array &$context): string
{
    if (!$context['mapPoints']) {
        return $html;
    }
    return str_replace($context['mapSlot'], site_render_map($context['mapPoints'], $context['mapOptions'], $context['locale'], $context['base']), $html);
}

function site_render_map(array $points, array $options, string $locale, string $base = ''): string
{
    if (!$points) {
        return '';
    }
    $settings = site_map_settings();
    $provider = $settings['provider'] === 'off' ? 'off' : ($options['provider'] ?? $settings['provider']);
    if (!in_array($provider, ['google', 'yandex'], true)) {
        $provider = $settings['provider'];
    }
    $mode = $options['mode'] ?? $settings['mode'];
    $zoom = $options['zoom'] ?? '';
    $hasZoom = ctype_digit($zoom) && (int) $zoom >= 1 && (int) $zoom <= 20;
    $centerCoordinates = array_map('trim', explode(',', $options['center'] ?? '', 2));
    $center = site_map_coordinates($options['center_lat'] ?? ($centerCoordinates[0] ?? ''), $options['center_lng'] ?? ($centerCoordinates[1] ?? ''));
    $data = [
        'provider' => $provider, 'key' => $settings[$provider . '_key'] ?? '',
        'mapId' => $settings['google_map_id'], 'locale' => $locale,
        'mode' => isset(site_map_modes()[$mode]) ? $mode : 'map',
        'zoom' => $hasZoom ? (int) $zoom : (int) $settings['zoom'], 'center' => $center,
        'fit' => !$hasZoom && $center === null, 'cluster' => $settings['cluster'] === '1', 'points' => $points,
    ];
    ob_start();
    require site_template_file('components/map.php');
    return (string) ob_get_clean();
}
