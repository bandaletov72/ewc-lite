<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
if (!$navigation && $settings['searchMode'] === 'off' && count(site_region_settings()['languages']) < 2) {
    return;
}
$tree = site_page_tree($navigation);
$render = static function (string $parent, string $landing = '') use (&$render, $tree, $base, $originalPath, $snippets) {
    echo '<ul>';
    if ($landing !== '') {
        echo '<li>' . $landing . '</li>';
    }
    foreach ($tree[$parent] ?? [] as $node) {
        $page = $node['page'];
        $folder = $node['folder'];
        $label = $page ? site_expand_text($page['fields']['Menu'] ?: $page['fields']['Title'], $snippets) : basename($folder);
        $label = site_page_menu_label($label, $page, $base);
        $link = $page ? '<a href="' . site_escape(site_page_link($base, $page)) . '"'
            . ($originalPath === $page['path'] ? ' aria-current="page"' : '') . '>' . $label . '</a>' : '';
        echo '<li>';
        if ($folder !== '' && !empty($tree[$folder])) {
            echo '<details><summary>' . $label . '</summary>';
            $render($folder, $link);
            echo '</details>';
        } else {
            echo $link;
        }
        echo '</li>';
    }
    echo '</ul>';
};
?>
<nav class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>public-main-menu" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
    <?php if ($navigation) $render('.'); ?>
    <div class="main-menu-tools">
        <?php if ($settings['searchMode'] !== 'off'): ?>
            <div class="main-menu-search"><?= site_expand_content('[search]', $snippets, $context) ?></div>
        <?php endif; ?>
        <div class="main-menu-language"><?= site_expand_content('[lang]', $snippets, $context) ?></div>
    </div>
</nav>
