<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Управление сайтом | <?= site_escape($siteSettings['name']) ?></title>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, site_brand_settings()['favicon'] ?: 'templates/icons/site.png')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>">
    <?php if ($loggedIn && in_array($section, ['forms', 'iblocks', 'contacts', 'components', 'theme'], true)): ?>
        <script src="<?= site_escape(site_url($base, 'templates/js/admin.js')) ?>" defer></script>
    <?php endif; ?>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <a class="brand" href="<?= site_escape($adminUrl) ?>">Управление сайтом</a>
            <div class="header-actions">
                <a class="button" href="<?= site_escape(site_url($base)) ?>">Открыть сайт</a>
                <?php if ($loggedIn): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>">
                        <input type="hidden" name="action" value="logout">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <button type="submit">Выйти</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main class="container admin-main">
        <?php if ($accessError !== ''): ?>
            <section class="panel login-panel">
                <h1>Настройка входа</h1>
                <p class="notice error" role="alert"><?= site_escape($accessError) ?></p>
            </section>
        <?php elseif (!$configured): ?>
            <section class="panel login-panel">
                <h1>Создать учётную запись</h1>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                <?php endif; ?>
                <?php if ($setupAvailable): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                        <input type="hidden" name="action" value="setup">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <?php if ($needsCode): ?>
                            <div class="field">
                                <label for="setup-code">Одноразовый код установки</label>
                                <input id="setup-code" name="setup_code" autocomplete="off" required>
                            </div>
                        <?php endif; ?>
                        <div class="field">
                            <label for="setup-username">Логин</label>
                            <input id="setup-username" name="username" value="<?= site_escape($username) ?>" placeholder="admin" autocomplete="username" maxlength="64" required>
                        </div>
                        <div class="field">
                            <label for="setup-password">Пароль</label>
                            <input id="setup-password" type="password" name="password" autocomplete="new-password" minlength="8" aria-describedby="password-hint" required>
                            <small class="hint" id="password-hint">От 8 символов, не более 72 байт.</small>
                        </div>
                        <div class="field">
                            <label for="setup-confirmation">Повторите пароль</label>
                            <input id="setup-confirmation" type="password" name="confirmation" autocomplete="new-password" required>
                        </div>
                        <div><button class="button-primary" type="submit">Создать и войти</button></div>
                    </form>
                <?php else: ?>
                    <p>В каталоге сайта выполните <code>php admin/setup.php</code>, затем обновите страницу и введите полученный код.</p>
                <?php endif; ?>
            </section>
        <?php elseif (!$loggedIn): ?>
            <section class="panel login-panel">
                <h1>Вход в админку</h1>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                <?php endif; ?>
                <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                    <input type="hidden" name="action" value="login">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <div class="field">
                        <label for="username">Логин</label>
                        <input id="username" name="username" value="<?= site_escape($username) ?>" autocomplete="username" required>
                    </div>
                    <div class="field">
                        <label for="password">Пароль</label>
                        <input id="password" type="password" name="password" autocomplete="current-password" required>
                    </div>
                    <div><button class="button-primary" type="submit">Войти</button></div>
                </form>
            </section>
        <?php else: ?>
            <nav class="site-menu admin-menu" aria-label="Разделы админки">
                <?php foreach (['pages' => ['Страницы', $adminUrl], 'settings' => ['Настройки', $settingsUrl], 'snippets' => ['Подшаблоны', $snippetsUrl], 'domains' => ['Домены', $domainsUrl], 'iblocks' => ['Инфоблоки', $iblocksUrl], 'forms' => ['Формы', $formsUrl], 'spam' => ['Антиспам', $spamUrl], 'messages' => ['Сообщения', $messagesUrl], 'callbacks' => ['Обратные звонки', $callbacksUrl]] as $key => $item): ?>
                    <a href="<?= site_escape($item[1]) ?>"<?= $section === $key || ($key === 'settings' && in_array($section, ['contacts', 'theme', 'components', 'updates'], true)) ? ' aria-current="page"' : '' ?>><?= site_escape($item[0]) ?></a>
                <?php endforeach; ?>
            </nav>
            <?php if ($section !== 'pages'): ?>
                <?php require __DIR__ . '/config-view.php'; ?>
            <?php else: ?>
            <div class="admin-heading">
                <h1>Страницы</h1>
                <a class="button button-primary" href="<?= site_escape($adminUrl . '?new=1') ?>">Новая страница</a>
            </div>
            <div class="editor-grid">
                <nav class="panel" aria-label="Список страниц">
                    <ul class="page-list">
                        <?php foreach ($pages as $item): ?>
                            <?php
                            $address = site_page_url('', $item['path']);
                            $editUrl = $adminUrl . '?' . http_build_query(['page' => $address]);
                            $hidden = $item['fields']['Hidden'] === '1';
                            ?>
                            <li class="page-list-entry">
                                <a href="<?= site_escape($editUrl) ?>"<?= $page !== null && !$creating && $page['path'] === $item['path'] ? ' aria-current="page"' : '' ?>>
                                    <?= site_escape($item['fields']['Title']) ?><small><?= site_escape($address) ?><?= $hidden ? ' · скрыта' : '' ?></small>
                                </a>
                                <div class="page-list-actions">
                                    <?php if (!$hidden): ?>
                                        <a href="<?= site_escape(site_page_url($base, $item['path'])) ?>" aria-label="<?= site_escape('Перейти на ' . $address) ?>">Перейти</a>
                                    <?php endif; ?>
                                    <a href="<?= site_escape($editUrl . '&confirm=' . ($hidden ? 'show' : 'hide')) ?>"><?= $hidden ? 'Показать' : 'Скрыть' ?></a>
                                    <?php if ($item['path'] !== 'index.php'): ?>
                                        <a href="<?= site_escape($editUrl . '&confirm=delete') ?>">Удалить</a>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
                <section class="panel">
                    <?php if ($error !== ''): ?>
                        <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                    <?php elseif ($notice !== ''): ?>
                        <p class="notice" role="status"><?= site_escape($notice) ?></p>
                    <?php endif; ?>
                    <?php if ($page !== null && !$creating && in_array($pageOperation, ['hide', 'show', 'delete'], true)
                        && ($pageOperation !== 'delete' || $page['path'] !== 'index.php')): ?>
                        <?php
                        $address = site_page_url('', $page['path']);
                        $editUrl = $adminUrl . '?' . http_build_query(['page' => $address]);
                        $operationLabel = ['hide' => 'Скрыть страницу', 'show' => 'Опубликовать страницу', 'delete' => 'Удалить страницу'];
                        ?>
                        <h2><?= $operationLabel[$pageOperation] ?>?</h2>
                        <p><?= site_escape($page['fields']['Title'] . ' · ' . $address) ?></p>
                        <?php if ($pageOperation === 'delete'): ?>
                            <p class="hint">Файл страницы будет удалён. Остальные файлы в её папке останутся.</p>
                        <?php elseif ($pageOperation === 'hide'): ?>
                            <p class="hint">Страница исчезнет из меню и будет недоступна по прямой ссылке, пока вы её не опубликуете.</p>
                        <?php endif; ?>
                        <form class="header-actions" method="post" action="<?= site_escape($editUrl . '&confirm=' . $pageOperation) ?>">
                            <input type="hidden" name="action" value="change-page-status">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="path" value="<?= site_escape($address) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <input type="hidden" name="operation" value="<?= $pageOperation ?>">
                            <button class="<?= $pageOperation === 'delete' ? 'button-danger' : 'button-primary' ?>" type="submit"><?= $operationLabel[$pageOperation] ?></button>
                            <a class="button" href="<?= site_escape($editUrl) ?>">Отмена</a>
                        </form>
                    <?php elseif ($page !== null): ?>
                        <h2><?= $creating ? 'Новая страница' : 'Редактирование страницы' ?></h2>
                        <form method="post" action="<?= site_escape($adminUrl) ?>">
                            <input type="hidden" name="action" value="save">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="new" value="<?= $creating ? '1' : '0' ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <div class="fields">
                                <div class="field field-wide">
                                    <label for="path">Адрес страницы</label>
                                    <input id="path" name="path" value="<?= site_escape($creating ? $page['path'] : site_page_url('', $page['path'])) ?>" placeholder="/services/" maxlength="240" <?= $creating ? 'required aria-describedby="path-hint"' : 'readonly' ?>>
                                    <?php if ($creating): ?>
                                        <small id="path-hint" class="hint">Например, /services/ или /about.php. Используйте строчные латинские буквы, цифры, дефисы и подчёркивания.</small>
                                    <?php endif; ?>
                                </div>
                                <?php
                                $labels = [
                                    'Title' => 'Заголовок вкладки',
                                    'Heading' => 'Заголовок H1',
                                    'Description' => 'Метаописание',
                                    'Menu' => 'Название в меню',
                                    'Order' => 'Порядок в меню',
                                ];
                                ?>
                                <?php foreach ($labels as $name => $label): ?>
                                    <div class="field<?= $name === 'Description' ? ' field-wide' : '' ?>">
                                        <label for="<?= $name ?>"><?= $label ?></label>
                                        <input id="<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($page['fields'][$name]) ?>"
                                            <?= $name === 'Order' ? 'type="number" min="0" max="99999" required' : 'maxlength="375"' ?>
                                            <?= $name === 'Title' ? 'required' : '' ?>
                                            <?= $name === 'Menu' ? 'aria-describedby="menu-hint"' : '' ?>>
                                        <?php if ($name === 'Menu'): ?>
                                            <small id="menu-hint" class="hint">Пустое поле скрывает страницу из меню.</small>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                                <div class="field field-wide">
                                    <label for="html">Содержимое HTML</label>
                                    <textarea id="html" name="html" spellcheck="false" rows="12"><?= "\n" . site_escape($page['html']) ?></textarea>
                                </div>
                            </div>
                            <div class="form-actions">
                                <button class="button-primary" type="submit">Сохранить</button>
                                <?php if (!$creating && ($page['fields']['Hidden'] ?? '0') === '0'): ?>
                                    <a class="button" href="<?= site_escape(site_page_url($base, $page['path'])) ?>">Открыть страницу</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    <?php endif; ?>
                </section>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</body>
</html>
