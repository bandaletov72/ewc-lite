<?php

if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

if (is_file(__DIR__ . '/.update-in-progress')) {
    http_response_code(503);
    header('Retry-After: 10');
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Обновляется движок сайта. Откройте страницу через несколько секунд.');
}

require __DIR__ . '/components.php';
require __DIR__ . '/forms.php';
require __DIR__ . '/spam.php';
require __DIR__ . '/iblocks.php';
require __DIR__ . '/appearance.php';
require __DIR__ . '/component-settings.php';
require __DIR__ . '/callbacks.php';

const SITE_NAME = 'Мой сайт';
const SITE_PAGE_LIMIT = 524288;
const SITE_MAX_INCLUDE_DEPTH = 10;
const SITE_RECORD_HEADER = "<?php http_response_code(404); exit; __halt_compiler();\n";
const SITE_SETTINGS_FILE = SITE_ROOT . '/admin/.site-settings.php';
const SITE_DOMAINS_FILE = SITE_ROOT . '/admin/.domains.php';

/** @return string|null */
function site_read_payload(string $file, int $limit)
{
    if (is_link($file)) {
        throw new RuntimeException('Недопустимый путь к файлу настроек.');
    }
    if (!file_exists($file)) {
        return null;
    }

    $bytes = @file_get_contents($file, false, null, 0, $limit + 1);
    if ($bytes === false || strlen($bytes) > $limit || strpos($bytes, SITE_RECORD_HEADER) !== 0) {
        throw new RuntimeException('Не удалось прочитать файл настроек.');
    }

    return substr($bytes, strlen(SITE_RECORD_HEADER));
}

function site_read_record(string $file, int $limit = 32768): array
{
    $payload = site_read_payload($file, $limit);
    if ($payload === null) {
        return [];
    }
    $record = json_decode($payload, true);
    if (!is_array($record)) {
        throw new RuntimeException('Неверный формат файла настроек.');
    }

    return $record;
}

function site_default_settings(): array
{
    return ['name' => SITE_NAME, 'description' => '', 'footer' => '', 'variables' => []];
}

function site_footer_pattern(string $text): string
{
    if (strpos($text, '[year]') !== false) {
        return $text;
    }
    return preg_replace('/\A(©\s*(?:[0-9]{4}\s*[-–—]\s*)?)[0-9]{4}(?=\s|$)/u', '$1[year]', $text) ?? $text;
}

function site_settings(): array
{
    $settings = site_default_settings();
    try {
        $stored = site_read_record(SITE_SETTINGS_FILE);
    } catch (RuntimeException $exception) {
        return $settings;
    }

    foreach ($settings as $key => $value) {
        if (isset($stored[$key]) && gettype($stored[$key]) === gettype($value)) {
            $settings[$key] = $stored[$key];
        }
    }

    $settings['footer'] = site_footer_pattern($settings['footer']);
    return $settings;
}

function site_valid_snippet(string $name): bool
{
    return preg_match('/\A[a-z][a-z0-9_-]{0,63}\z/', $name) === 1;
}

function site_normalize_domain(string $domain): string
{
    $domain = strtolower($domain);
    if (substr($domain, -1) === '.') {
        $domain = substr($domain, 0, -1);
    }
    if (strlen($domain) > 253) {
        return '';
    }
    foreach (explode('.', $domain) as $label) {
        if (!preg_match('/\A[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\z/', $label)) {
            return '';
        }
    }
    return $domain;
}

function site_host(): string
{
    $header = $_SERVER['HTTP_HOST'] ?? '';
    if (!preg_match('/\A(\[[a-f0-9:.]+\]|[a-z0-9.-]+)(?::[0-9]{1,5})?\z/i', $header, $match)) {
        return '';
    }
    $host = strtolower($match[1]);
    if ($host[0] === '[') {
        return filter_var(substr($host, 1, -1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? $host : '';
    }
    return site_normalize_domain($host);
}

function site_snippet_file(string $host = ''): string
{
    $suffix = $host === '' ? '' : '-' . hash('sha256', $host);
    return SITE_ROOT . '/admin/.snippets' . $suffix . '.php';
}

function site_read_snippets(string $host = ''): array
{
    return site_read_record(site_snippet_file($host));
}

function site_snippet_values(string $host): array
{
    $shared = [];
    try {
        $shared = site_read_snippets();
    } catch (RuntimeException $exception) {
        // Pages remain available if the shared snippets cannot be read.
    }
    if ($host !== '') {
        try {
            $shared = array_replace($shared, site_read_snippets($host));
        } catch (RuntimeException $exception) {
            // Shared values still apply if one domain's data cannot be read.
        }
    }

    $values = [];
    foreach ($shared as $name => $snippet) {
        if (is_array($snippet) && isset($snippet['value']) && is_string($snippet['value'])) {
            $values[$name] = $snippet['value'];
        }
    }
    return $values;
}

const SITE_SNIPPET_TOKEN = '\[(?P<snippet>[a-z][a-z0-9_-]{0,63})\]';

function site_date_snippets(): array
{
    $time = $_SERVER['REQUEST_TIME'] ?? time();
    $date = date('d.m.Y', $time);
    return ['year' => date('Y', $time), 'month' => date('m', $time), 'day' => date('d', $time),
        'time' => date('H:i', $time), 'dmy' => $date, 'date' => $date, 'datetime' => date('d.m.Y H:i', $time)];
}

function site_expand_text(string $text, array $snippets): string
{
    return preg_replace_callback('~' . SITE_SNIPPET_TOKEN . '~i', static function (array $match) use ($snippets): string {
        $name = strtolower($match[1]);
        if (!isset($snippets[$name])) {
            return $match[0];
        }
        return html_entity_decode(strip_tags($snippets[$name]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }, $text) ?? $text;
}

function site_expand_content(string $html, array $snippets, array &$context): string
{
    if (strpos($html, '[') === false) {
        return $html;
    }

    // Keep tags, attributes, and literal HTML regions intact.
    $pattern = <<<'REGEX'
~
  <!-- .*? (?: --> | $ )
  | <(script|style|textarea|pre|code)\b (?: [^>"']++ | "[^"]*" | '[^']*' )* >
    .*? (?: </\1\s*> | $ )
  | </?[a-z][a-z0-9:-]*\b (?: [^>"']++ | "[^"]*" | '[^']*' )* >
  | \[ (?P<galleryTag>gal|fotos) (?P<galleryOptions>(?:[\x20\t]+[a-z0-9_-]+=[a-z0-9_-]+)*) \]
    (?P<gallery>[^\[\]]+) \[/\k<galleryTag>\]
  | \[files (?P<fileOptions>(?:[\x20\t]+[a-z0-9_-]+=[a-z0-9_-]+)*) \] (?P<files>[^\[\]]+) \[/files\]
  | \[include\] (?P<include>[^\[\]]+) \[/include\]
  | \[iblock=(?P<iblockTemplate>[a-z][a-z0-9_-]{0,63})\] (?P<iblock>[^\[\]]+) \[/?iblock\]
  | \[ (?P<callback>callback) (?:=(?P<callbackLabel>[^\[\]\r\n]+))? \]
  | \[ (?P<form>form[1-9][0-9]{0,8}) \]
REGEX;
    $wrapped = [];
    foreach ($context['extensions'] as $name => $extension) {
        if ($extension['kind'] === 'wrapped') {
            $wrapped[] = preg_quote($name, '~');
        }
    }
    if ($wrapped) {
        $pattern .= ' | \[ (?P<extensionTag>' . implode('|', $wrapped) . ') \]'
            . ' (?P<extensionArg>[^\[\]]*) \[/\k<extensionTag>\]';
    }
    $pattern .= ' | ' . SITE_SNIPPET_TOKEN . '~six';

    $expanded = preg_replace_callback($pattern, static function (array $match) use ($snippets, &$context): string {
        if (!empty($match['gallery'])) {
            return site_component_gallery($match['gallery'], $context['base'], strtolower($match['galleryTag']) === 'gal', $match['galleryOptions']);
        }
        if (!empty($match['files'])) {
            return site_component_files($match['files'], $context['base'], $match['fileOptions']);
        }
        if (!empty($match['include'])) {
            return site_component_include($match['include'], $snippets, $context);
        }
        if (!empty($match['iblock'])) {
            return site_component_iblock(strtolower($match['iblockTemplate']), $match['iblock']);
        }
        if (!empty($match['form'])) {
            return site_component_form(strtolower($match['form']), $context);
        }
        if (!empty($match['callback'])) {
            return site_component_callback(trim($match['callbackLabel'] ?? ''), $context);
        }
        if (!empty($match['extensionTag'])) {
            return site_render_extension(strtolower($match['extensionTag']), $match['extensionArg'], $context);
        }
        $name = strtolower($match['snippet'] ?? '');
        if (isset(site_layout_blocks()[$name])) {
            return $context['fragment'] ? '' : site_layout_block($name, $context);
        }
        if (isset($context['extensions'][$name]) && $context['extensions'][$name]['kind'] === 'single') {
            return site_render_extension($name, '', $context);
        }
        if (isset($context['contactTokens'][$name])) {
            if ($context['contacts'] === null) {
                $context['contacts'] = site_contact_settings();
            }
            $markup = site_contact_markup($context['contactTokens'][$name], $context['base'], $context['contacts']);
            return $markup !== '' ? $markup : ($snippets[$name] ?? '');
        }
        return isset($snippets[$name]) && is_string($snippets[$name]) ? $snippets[$name] : $match[0];
    }, $html);

    return $expanded === null ? $html : $expanded;
}

function site_escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function site_base(string $entry): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $suffix = '/' . $entry;
    if (substr($script, -strlen($suffix)) !== $suffix) {
        return '';
    }

    $prefix = substr($script, 0, -strlen($suffix));
    $segments = array_map(static function (string $segment): string {
        return rawurlencode(rawurldecode($segment));
    }, explode('/', $prefix));

    return '/' . ltrim(implode('/', $segments), '/');
}

function site_url(string $base, string $path = ''): string
{
    return rtrim($base, '/') . '/' . $path;
}

function site_template_file(string $name): string
{
    $local = SITE_ROOT . '/templates/local/' . $name;
    return is_file($local) ? $local : SITE_ROOT . '/templates/' . $name;
}

function site_layout_blocks(): array
{
    return ['header' => 'header.php', 'mobile-menu' => 'mobile-menu.php', 'menu' => 'menu.php', 'footer' => 'footer.php'];
}

function site_layout_block(string $name, array &$context): string
{
    $snippets = $context['snippets'];
    if (array_key_exists($name, $snippets)) {
        if (isset($context['activeBlocks'][$name])) {
            return '';
        }
        $context['activeBlocks'][$name] = true;
        try {
            return site_expand_content($snippets[$name], $snippets, $context);
        } finally {
            unset($context['activeBlocks'][$name]);
        }
    }

    $base = $context['base'];
    $page = $context['pageData'];
    $settings = $context['settings'];
    $brand = $context['brand'];
    if ($name !== 'footer' && $context['navigation'] === null) {
        $context['navigation'] = array_filter(site_pages(), static function (array $item): bool {
            return $item['fields']['Menu'] !== '' && $item['fields']['Hidden'] === '0';
        });
    }
    $navigation = $context['navigation'];
    ob_start();
    require site_template_file(site_layout_blocks()[$name]);
    return (string) ob_get_clean();
}

function site_valid_part(string $part): bool
{
    return preg_match('/\A[a-z0-9][a-z0-9_-]{0,63}\z/', $part) === 1
        && preg_match('/\A(?:con|prn|aux|nul|com[1-9]|lpt[1-9])\z/', $part) !== 1;
}

function site_valid_path(string $path): bool
{
    if (strlen($path) > 240 || substr($path, -4) !== '.php') {
        return false;
    }

    $parts = explode('/', substr($path, 0, -4));
    if (in_array($parts[0], ['admin', 'app', 'data', 'extensions', 'maintenance', 'templates', 'form', 'router', 'update'], true)) {
        return false;
    }

    foreach ($parts as $part) {
        if (!site_valid_part($part)) {
            return false;
        }
    }

    return true;
}

function site_page_url(string $base, string $path): string
{
    if (basename($path) === 'index.php') {
        $path = substr($path, 0, -strlen('index.php'));
    }

    return site_url($base, $path);
}

function site_page_header(string $path): string
{
    if ($path === 'index.php') {
        return <<<'PHP'
<?php
define('SITE_ROOT', __DIR__);
require SITE_ROOT . '/app/site.php';
site_render(isset($pageFile) ? $pageFile : __FILE__);
__halt_compiler();
PHP;
    }

    $toRoot = str_repeat('../', substr_count($path, '/'));
    return "<?php\n\$pageFile = __FILE__;\nrequire __DIR__ . '/" . $toRoot
        . "index.php';\n__halt_compiler();";
}

function site_page_fields(): array
{
    return ['Title', 'Heading', 'Description', 'Menu', 'Order'];
}

function site_valid_metadata(array $fields): bool
{
    foreach ($fields as $value) {
        if (strlen($value) > 1500 || preg_match('/[\x00-\x1F\x7F]/', $value)) {
            return false;
        }
    }

    return $fields['Title'] !== '' && preg_match('/\A[0-9]{1,5}\z/', $fields['Order']) === 1
        && in_array($fields['Hidden'] ?? '0', ['0', '1'], true);
}

/** @return array|null */
function site_read_page(string $path)
{
    if (!site_valid_path($path)) {
        return null;
    }

    $file = SITE_ROOT . '/' . $path;
    $resolved = realpath($file);
    $expected = str_replace('/', DIRECTORY_SEPARATOR, $file);
    if ($resolved !== $expected || !is_file($file)) {
        return null;
    }

    $bytes = @file_get_contents($file, false, null, 0, SITE_PAGE_LIMIT + 1);
    if ($bytes === false || strlen($bytes) > SITE_PAGE_LIMIT || preg_match('//u', $bytes) !== 1) {
        return null;
    }

    $header = site_page_header($path);
    $pattern = str_replace("\n", '\r?\n', preg_quote($header, '~'));
    if (!preg_match('~\A' . $pattern . '\r?\n~', $bytes, $match)) {
        return null;
    }

    $sections = preg_split('/\r?\n\r?\n/', substr($bytes, strlen($match[0])), 2);
    if (count($sections) !== 2) {
        return null;
    }

    $fields = ['Title' => '', 'Heading' => '', 'Description' => '', 'Menu' => '', 'Order' => '100', 'Hidden' => '0'];
    $seen = [];
    foreach (preg_split('/\r?\n/', $sections[0]) as $line) {
        $pair = explode(':', $line, 2);
        if (count($pair) !== 2 || !array_key_exists($pair[0], $fields) || isset($seen[$pair[0]])) {
            return null;
        }

        $seen[$pair[0]] = true;
        $fields[$pair[0]] = trim($pair[1], ' ');
    }

    if (!site_valid_metadata($fields)) {
        return null;
    }

    return [
        'path' => $path,
        'fields' => $fields,
        'html' => $sections[1],
        'revision' => hash('sha256', $bytes),
    ];
}

function site_pages(): array
{
    $directory = new RecursiveDirectoryIterator(SITE_ROOT, FilesystemIterator::SKIP_DOTS);
    $filter = new RecursiveCallbackFilterIterator($directory, static function (SplFileInfo $item): bool {
        if ($item->isLink()) {
            return false;
        }

        $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($item->getPathname(), strlen(SITE_ROOT) + 1));
        if ($item->isDir()) {
            return site_valid_path($path . '/index.php')
                && $item->getRealPath() === $item->getPathname();
        }

        return site_valid_path($path);
    });

    $pages = [];
    $files = new RecursiveIteratorIterator($filter, RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD);
    foreach ($files as $file) {
        $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen(SITE_ROOT) + 1));
        $page = site_read_page($path);
        if ($page !== null) {
            $pages[] = ['path' => $path, 'fields' => $page['fields']];
        }
    }

    usort($pages, static function (array $left, array $right): int {
        $order = (int) $left['fields']['Order'] <=> (int) $right['fields']['Order'];
        return $order !== 0 ? $order : strcmp($left['path'], $right['path']);
    });

    return $pages;
}

function site_render(string $file)
{
    $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($file, strlen(SITE_ROOT) + 1));
    $base = site_base($path);
    $settings = site_settings();
    $brand = site_brand_settings();
    $variables = array_filter(array_diff_key($settings['variables'], site_layout_blocks()), 'is_string');
    $snippets = site_date_snippets() + site_snippet_values(site_host()) + array_map('site_escape', $variables);
    $settings['name'] = site_expand_text($settings['name'], $snippets);
    $page = empty($_SERVER['PATH_INFO']) ? site_read_page($path) : null;
    if ($page !== null && $page['fields']['Hidden'] === '1') {
        $page = null;
    }
    if ($page === null) {
        http_response_code(404);
        $page = [
            'path' => '',
            'fields' => ['Title' => 'Страница не найдена', 'Heading' => '', 'Description' => ''],
            'html' => '<p>Проверьте адрес страницы или выберите раздел в меню.</p>',
        ];
    }

    header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    $fragment = ($_GET['ajax'] ?? '') === '1';
    $public = site_public_context($base, $fragment);
    if ($fragment && !$public) {
        http_response_code(403);
        echo 'Доступ к фрагменту разрешён только из сеанса на этом сайте.';
        return;
    }
    $components = [
        'base' => $base, 'page' => $page['path'], 'active' => [$page['path'] => true],
        'forms' => null, 'formSession' => $public,
        'contactTokens' => site_contact_tokens(), 'contacts' => null,
        'extensions' => site_extensions(),
        'pageData' => $page, 'settings' => $settings, 'snippets' => $snippets, 'brand' => $brand,
        'navigation' => null, 'activeBlocks' => [], 'fragment' => $fragment,
    ];
    $content = site_expand_content($page['html'], $snippets, $components);
    $fields = $page['fields'];
    $title = site_expand_text($fields['Title'], $snippets);
    $heading = $fields['Heading'] !== '' ? site_expand_text($fields['Heading'], $snippets) : $title;
    if ($fragment) {
        require site_template_file('content.php');
        return;
    }
    require site_template_file('layout.php');
}
