<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';
require SITE_ROOT . '/admin/files.php';

function form_reply(int $status, string $text, array $fields = [])
{
    http_response_code($status);
    echo json_encode(['ok' => $status === 200, 'message' => $text, 'fields' => (object) $fields], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    form_reply(405, 'Используйте форму на странице сайта.');
}

$base = site_base('form/index.php');
if (!site_public_session($base)) {
    form_reply(503, 'Форма временно недоступна.');
}
$id = $_POST['form'] ?? '';
$pagePath = $_POST['page'] ?? '';
$data = $_POST['fields'] ?? [];
if (!is_string($id) || !site_valid_form_id($id) || !is_string($pagePath) || !is_array($data)) {
    form_reply(400, 'Форма не найдена.');
}
if (!isset($_POST['csrf'], $_SESSION['csrf']) || !is_string($_POST['csrf'])
    || !hash_equals(site_form_signature($_SESSION['csrf'], $id, $pagePath), $_POST['csrf'])) {
    form_reply(403, 'Обновите страницу и попробуйте снова.');
}
$page = site_read_page($pagePath);
if ($page === null || $page['fields']['Hidden'] === '1') {
    form_reply(400, 'Страница с формой не найдена.');
}

try {
    $forms = site_forms();
    $rules = site_spam_rules();
} catch (RuntimeException $exception) {
    form_reply(503, 'Форма временно недоступна.');
}
if (!isset($forms[$id])) {
    form_reply(404, 'Форма не найдена.');
}
$ip = site_normalize_ip($_SERVER['REMOTE_ADDR'] ?? '');
if (in_array($ip, $rules['ips'], true) || ($_POST['website'] ?? '') !== '') {
    form_reply(403, 'Отправка сообщения заблокирована.');
}

$now = time();
$recent = array_filter($_SESSION['submitted'] ?? [], static function (int $submitted) use ($now): bool {
    return $submitted > $now - 60;
});
if (count($recent) >= 5) {
    header('Retry-After: 60');
    form_reply(429, 'Слишком много отправок. Попробуйте через минуту.');
}

$form = $forms[$id];
$submission = site_validate_message($form, $data);
$errors = $submission['errors'] + site_spam_errors($submission['fields'], $rules['words']);
if ($errors) {
    form_reply(422, 'Проверьте отмеченные поля.', $errors);
}

$message = ['time' => gmdate('c'), 'host' => site_host(), 'page' => $pagePath, 'form' => $id, 'fields' => $submission['fields']];
if (strlen(json_encode($message, JSON_UNESCAPED_UNICODE)) > 27000) {
    form_reply(422, 'Сократите сообщение и попробуйте снова.');
}
try {
    site_save_message($message);
} catch (RuntimeException $exception) {
    form_reply(503, 'Не удалось сохранить сообщение. Попробуйте позже.');
}
$recent[] = $now;
$_SESSION['submitted'] = $recent;
session_write_close();
site_notify_message($form['recipient'], $submission['replyTo'], $message);
form_reply(200, 'Сообщение отправлено.');
