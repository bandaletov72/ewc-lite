<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_extensions(): array
{
    static $loaded;
    if ($loaded !== null) {
        return $loaded;
    }
    $extensions = [];
    foreach ([SITE_ROOT . '/app/extensions', SITE_ROOT . '/extensions'] as $folder) {
        foreach (glob($folder . '/*.php') ?: [] as $module) {
            if (is_link($module)) {
                continue;
            }
            $declared = require $module;
            if (!is_array($declared)) {
                continue;
            }
            foreach ($declared as $name => $definition) {
                if (!is_string($name) || !site_valid_snippet($name)
                    || isset(site_contact_tokens()[$name]) || isset(site_layout_blocks()[$name]) || site_valid_form_id($name)
                    || in_array($name, ['gal', 'fotos', 'files', 'include', 'iblock'], true)
                    || !is_array($definition) || !in_array($definition['kind'] ?? '', ['single', 'wrapped'], true)
                    || !is_callable($definition['render'] ?? null)) {
                    continue;
                }
                $extensions[$name] = $definition;
            }
        }
    }
    $loaded = $extensions;
    return $loaded;
}

function site_render_extension(string $name, string $argument, array $context): string
{
    static $settings;
    if ($settings === null) {
        $settings = site_component_settings();
    }
    return (string) $context['extensions'][$name]['render']($argument,
        ['base' => $context['base'], 'page' => $context['page'], 'settings' => $settings[$name] ?? []]);
}

function site_asset_files(string $argument, string $base, string $asset, array $extensions): array
{
    $argument = rtrim(trim($argument), '/');
    if (!preg_match('~\A/((?:templates/)?' . $asset . ')(?:/(.+))?\z~s', $argument, $match)) {
        return [];
    }
    $path = $match[1] . (isset($match[2]) ? '/' . $match[2] : '');
    foreach (explode('/', $path) as $part) {
        if ($part === '' || substr($part, -1) === '.' || substr($part, -1) === ' '
            || preg_match('~[\x00-\x1F\x7F\\\\:<>"|?*]~', $part)) {
            return [];
        }
    }

    $folder = SITE_ROOT . '/' . $path;
    if ($match[1] === $asset && !is_dir($folder)) {
        $path = 'templates/' . $path;
        $folder = SITE_ROOT . '/' . $path;
    }
    $resolved = realpath($folder);
    if ($resolved !== str_replace('/', DIRECTORY_SEPARATOR, $folder) || !is_dir($folder)) {
        return [];
    }

    $files = @scandir($folder, SCANDIR_SORT_NONE);
    if ($files === false) {
        return [];
    }
    $assets = [];
    $url = site_url($base, implode('/', array_map('rawurlencode', explode('/', $path)))) . '/';
    foreach ($files as $file) {
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($extension, $extensions, true)
            || !is_file($folder . '/' . $file) || is_link($folder . '/' . $file)) {
            continue;
        }
        $assets[$file] = [
            'url' => $url . rawurlencode($file), 'name' => $file,
            'alt' => pathinfo($file, PATHINFO_FILENAME), 'extension' => $extension,
        ];
    }
    uksort($assets, 'strnatcasecmp');
    return array_values($assets);
}

function site_component_gallery(string $argument, string $base, bool $carousel, string $overrides = ''): string
{
    $images = site_asset_files($argument, $base, 'images', ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif']);
    if (!$images) {
        return '';
    }
    $options = $carousel ? site_gallery_options($overrides) : [];
    ob_start();
    require site_template_file('components/gallery.php');
    return (string) ob_get_clean();
}

function site_component_files(string $argument, string $base): string
{
    $files = site_asset_files($argument, $base, 'files', ['zip', 'pdf', 'xls', 'xlsx', 'doc', 'docx', 'png', 'gif', 'jpg', 'jpeg', 'mp4', 'mov', 'mp3']);
    if (!$files) {
        return '';
    }
    ob_start();
    require site_template_file('components/files.php');
    return (string) ob_get_clean();
}

function site_component_include(string $argument, array $snippets, array &$context): string
{
    $argument = trim($argument);
    if (substr($argument, 0, 1) !== '/') {
        return '';
    }

    $path = substr($argument, 1);
    if (substr($path, -4) !== '.php') {
        $path = $path === '' ? 'index.php' : rtrim($path, '/') . '/index.php';
    }
    if (isset($context['active'][$path])) {
        return '';
    }
    $page = site_read_page($path);
    if ($page === null || $page['fields']['Hidden'] === '1') {
        return '';
    }
    $context['active'][$path] = true;
    try {
        return site_expand_content($page['html'], $snippets, $context);
    } finally {
        unset($context['active'][$path]);
    }
}

function site_component_form(string $id, array &$context): string
{
    if ($context['forms'] === null) {
        try {
            $context['forms'] = site_forms();
        } catch (RuntimeException $exception) {
            $context['forms'] = [];
            return '<p>Форма временно недоступна.</p>';
        }
    }
    if (!isset($context['forms'][$id])) {
        return '[' . $id . ']';
    }
    $form = $context['forms'][$id];
    $session = $context['formSession'];
    $base = $context['base'];
    $page = $context['page'];
    $instance = 'form-' . bin2hex(random_bytes(6));
    ob_start();
    require site_template_file('components/form.php');
    return (string) ob_get_clean();
}
