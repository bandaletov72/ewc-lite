<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_content_url(string $url, string $base, bool $link = false): string
{
    $base = rtrim($base, '/');
    if ($base === '' || $url === '' || strpos($url, $base . '/') === 0 || $url === $base
        || $url[0] === '#' || $url[0] === '?' || strpos($url, '//') === 0) {
        return $url;
    }
    $path = rawurldecode(substr($url, 0, strcspn($url, '?#')));
    if (preg_match('~[:\\\\\x00-\x1f\x7f]|(?:^|/)\.{1,2}(?:/|$)~', $path)) {
        return $url;
    }
    $path = ltrim($path, '/');
    if (preg_match('~\A(?:(?:images|img|files|media|uploads|assets|icons|static|templates)/|favicon\.(?:ico|png|svg)\z)~i', $path)) {
        return site_url($base, ltrim($url, '/'));
    }
    if ($url[0] === '/' && preg_match('~\.(?:avif|bmp|gif|ico|jpe?g|png|svg|webp)\z~i', $path)
        && is_file(SITE_ROOT . '/' . $path)) {
        return site_url($base, ltrim($url, '/'));
    }
    if (!$link || $url[0] !== '/') {
        return $url;
    }
    $page = preg_match('~\.php\z~i', $path) ? $path : rtrim($path, '/') . '/index.php';
    $page = ltrim($page, '/');
    if (($path === '' || site_valid_path($page)) && is_file(site_content_root() . '/' . $page)) {
        return site_url($base, ltrim($url, '/'));
    }
    return $url;
}

function site_content_css_urls(string $css, string $base): string
{
    return preg_replace_callback('~/\*.*?\*/(*SKIP)(*F)|\burl\(\s*(?:"([^"]*)"|\'([^\']*)\'|&quot;(.*?)&quot;|&#(?:39|x27);(.*?)&#(?:39|x27);|([^\s\x29]*))\s*\)~is',
        static function (array $match) use ($base): string {
            $url = (string) end($match);
            $resolved = site_content_url($url, $base);
            return $resolved === $url ? $match[0] : str_replace($url, $resolved, $match[0]);
        }, $css) ?? $css;
}

function site_content_html_urls(string $html, string $base): string
{
    if ($base === '' || $base === '/') {
        return $html;
    }
    // Skip comments and raw text. Handle style elements separately without reserializing the HTML.
    $tags = <<<'REGEX'
~(?:<!--.*?-->|<(script|textarea|title)\b(?:"[^"]*"|'[^']*'|[^"'<>])*+>.*?</\1\s*>)(*SKIP)(*F)|(<style\b[^>]*>)(.*?)(</style\s*>)|<([a-z][a-z0-9:-]*)\b((?:"[^"]*"|'[^']*'|[^"'<>])*+)>~is
REGEX;
    $attributes = <<<'REGEX'
~\s+([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>\x60]+)))?~
REGEX;
    return preg_replace_callback($tags, static function (array $tag) use ($base, $attributes): string {
        if (($tag[2] ?? '') !== '') {
            return $tag[2] . site_content_css_urls($tag[3], $base) . $tag[4];
        }
        $name = strtolower($tag[5]);
        $result = preg_replace_callback($attributes, static function (array $attribute) use ($base, $name): string {
            $key = strtolower($attribute[1]);
            $value = $attribute[2] ?? '';
            if ($value === '') $value = $attribute[3] ?? '';
            if ($value === '') $value = $attribute[4] ?? '';
            if ($value === '') return $attribute[0];
            if ($key === 'srcset' || $key === 'data-srcset') {
                // A URL token can contain an embedded comma, as in a data URL.
                $resolved = preg_replace_callback('~(?:\A|(?<=,))\s*\K[^\s,][^\s]*~',
                    static function (array $candidate) use ($base): string {
                        return site_content_url($candidate[0], $base);
                    }, $value) ?? $value;
            } elseif ($key === 'style') {
                $resolved = site_content_css_urls($value, $base);
            } elseif (in_array($key, ['src', 'poster', 'data-src', 'data-original'], true)
                || $key === 'href' && in_array($name, ['a', 'area', 'link', 'image', 'use'], true)
                || $key === 'xlink:href' && in_array($name, ['image', 'use'], true)) {
                $resolved = site_content_url($value, $base, $key === 'href' && in_array($name, ['a', 'area'], true));
            } else {
                return $attribute[0];
            }
            return $resolved === $value ? $attribute[0] : str_replace($value, $resolved, $attribute[0]);
        }, $tag[6]);
        return $result === null ? $tag[0] : '<' . $tag[5] . $result . '>';
    }, $html) ?? $html;
}
