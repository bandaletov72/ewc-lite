<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Фильтр иконок', 'Иконки не найдены.', 'Ещё иконки', 'В окне выбора иконок введите название. Например, home находит варианты дома, включая иконки с house в названии.'],
    'en' => ['Filter icons', 'No icons found.', 'More icons', 'Type a name in the icon picker. For example, home also finds icons named house.'],
    'uk' => ['Фільтр іконок', 'Іконок не знайдено.', 'Ще іконки', 'Введіть назву в полі вибору іконок. Наприклад, home знаходить іконки з house у назві.'],
    'de' => ['Symbole filtern', 'Keine Symbole gefunden.', 'Weitere Symbole', 'Geben Sie einen Namen in die Symbolsuche ein. Home findet auch Symbole mit house im Namen.'],
    'fr' => ['Filtrer les icônes', 'Aucune icône trouvée.', 'Plus d’icônes', 'Saisissez un nom dans le sélecteur d’icônes. Par exemple, home trouve aussi les icônes nommées house.'],
    'es' => ['Filtrar iconos', 'No se encontraron iconos.', 'Más iconos', 'Escribe un nombre en el selector de iconos. Por ejemplo, home también encuentra iconos con house en el nombre.'],
    'pt' => ['Filtrar ícones', 'Não foram encontrados ícones.', 'Mais ícones', 'Introduza um nome no seletor de ícones. Por exemplo, home também encontra ícones com house no nome.'],
    'vi' => ['Lọc biểu tượng', 'Không tìm thấy biểu tượng.', 'Thêm biểu tượng', 'Nhập tên trong bộ chọn biểu tượng. Ví dụ, home cũng tìm các biểu tượng có tên chứa house.'],
    'ja' => ['アイコンを絞り込む', 'アイコンが見つかりません。', 'さらに表示', 'アイコン選択欄に名前を入力します。たとえば home と入力すると、house を含む名前のアイコンも表示されます。'],
    'ko' => ['아이콘 필터', '아이콘을 찾을 수 없습니다.', '더보기', '아이콘 선택 창에 이름을 입력하세요. 예를 들어 home은 이름에 house가 포함된 아이콘도 찾습니다.'],
    'zh' => ['筛选图标', '未找到图标。', '更多图标', '在图标选择器中输入名称。例如，home 也会找到名称包含 house 的图标。'],
];
