<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Новый файл…', 'Имя файла', 'Создать файл', 'Выберите существующий файл или пункт «Новый файл…». Введите имя без /data/ и нажмите «Создать файл». Новый пустой инфоблок появится в списке.', 'Файл создан.', 'Как выбрать или создать файл'],
    'en' => ['New file…', 'File name', 'Create file', 'Choose an existing file or New file. Enter its name without /data/ and select Create file. The new empty data block will appear in the list.', 'File created.', 'How to choose or create a file'],
    'uk' => ['Новий файл…', 'Ім’я файлу', 'Створити файл', 'Виберіть наявний файл або «Новий файл…». Введіть ім’я без /data/ і натисніть «Створити файл». Новий порожній інфоблок з’явиться у списку.', 'Файл створено.', 'Як вибрати або створити файл'],
    'de' => ['Neue Datei…', 'Dateiname', 'Datei erstellen', 'Wählen Sie eine vorhandene Datei oder „Neue Datei…“. Geben Sie den Namen ohne /data/ ein und wählen Sie „Datei erstellen“. Der neue leere Datenblock erscheint in der Liste.', 'Datei erstellt.', 'Datei auswählen oder erstellen'],
    'fr' => ['Nouveau fichier…', 'Nom de fichier', 'Créer le fichier', 'Choisissez un fichier existant ou « Nouveau fichier… ». Saisissez le nom sans /data/, puis cliquez sur « Créer le fichier ». Le bloc de données vide apparaîtra dans la liste.', 'Fichier créé.', 'Choisir ou créer un fichier'],
    'es' => ['Nuevo archivo…', 'Nombre de archivo', 'Crear archivo', 'Elige un archivo existente o «Nuevo archivo…». Escribe el nombre sin /data/ y pulsa «Crear archivo». El bloque de datos vacío aparecerá en la lista.', 'Archivo creado.', 'Elegir o crear un archivo'],
    'pt' => ['Novo ficheiro…', 'Nome do ficheiro', 'Criar ficheiro', 'Escolha um ficheiro existente ou «Novo ficheiro…». Escreva o nome sem /data/ e clique em «Criar ficheiro». O bloco de dados vazio aparecerá na lista.', 'Ficheiro criado.', 'Escolher ou criar um ficheiro'],
    'vi' => ['Tệp mới…', 'Tên tệp', 'Tạo tệp', 'Chọn tệp có sẵn hoặc «Tệp mới…». Nhập tên không có /data/ rồi nhấn «Tạo tệp». Khối dữ liệu trống mới sẽ hiện trong danh sách.', 'Đã tạo tệp.', 'Cách chọn hoặc tạo tệp'],
    'ja' => ['新規ファイル…', 'ファイル名', 'ファイルを作成', '既存ファイルまたは「新規ファイル…」を選びます。/data/ を除いた名前を入力し、「ファイルを作成」を押します。新しい空のデータブロックが一覧に表示されます。', 'ファイルを作成しました。', 'ファイルを選択または作成する方法'],
    'ko' => ['새 파일…', '파일 이름', '파일 만들기', '기존 파일이나 새 파일을 선택합니다. /data/를 제외한 이름을 입력하고 파일 만들기를 누릅니다. 빈 데이터 블록이 목록에 추가됩니다.', '파일을 만들었습니다.', '파일을 선택하거나 만드는 방법'],
    'zh' => ['新建文件…', '文件名', '创建文件', '选择现有文件或“新建文件…”。输入不带 /data/ 的名称，然后点击“创建文件”。新的空数据块将出现在列表中。', '文件已创建。', '如何选择或创建文件'],
];
