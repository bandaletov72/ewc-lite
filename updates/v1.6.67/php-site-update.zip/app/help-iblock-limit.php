<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Что означает количество записей', 'Максимум работ для этого блока. Если указано 2, показываются первые две работы из файла. Оставьте поле пустым, чтобы показать все работы.', 'Максимум опубликованных отзывов для этого блока. Если указано 2, показываются первые два. Пустое поле использует стандартный предел в 30 отзывов.'],
    'en' => ['What the record count means', 'Maximum projects to show in this block. Enter 2 to show the first two projects from the file. Leave blank to show all projects.', 'Maximum published reviews to show in this block. Enter 2 to show the first two. Leave blank to use the default limit of 30 reviews.'],
    'uk' => ['Що означає кількість записів', 'Максимум робіт у цьому блоці. Значення 2 показує перші дві роботи з файлу. Порожнє поле показує всі роботи.', 'Максимум опублікованих відгуків у блоці. Значення 2 показує перші два. Порожнє поле використовує типове обмеження у 30 відгуків.'],
    'de' => ['Bedeutung der Anzahl', 'Höchstzahl der Projekte in diesem Block. Mit 2 erscheinen die ersten zwei Projekte aus der Datei. Ein leeres Feld zeigt alle Projekte.', 'Höchstzahl veröffentlichter Bewertungen in diesem Block. Mit 2 erscheinen die ersten zwei. Ein leeres Feld verwendet den Standardwert 30.'],
    'fr' => ['À quoi correspond le nombre de résultats', 'Nombre maximal de projets dans ce bloc. Avec 2, les deux premiers projets du fichier s’affichent. Laissez le champ vide pour afficher tous les projets.', 'Nombre maximal d’avis publiés dans ce bloc. Avec 2, les deux premiers s’affichent. Un champ vide utilise la limite par défaut de 30 avis.'],
    'es' => ['Qué significa el número de registros', 'Máximo de proyectos en este bloque. Con 2 se muestran los dos primeros proyectos del archivo. Deja el campo vacío para mostrarlos todos.', 'Máximo de reseñas publicadas en este bloque. Con 2 se muestran las dos primeras. Si el campo está vacío se usa el límite predeterminado de 30.'],
    'pt' => ['O que significa a quantidade de registros', 'Máximo de projetos neste bloco. Com 2, aparecem os dois primeiros projetos do arquivo. Deixe em branco para mostrar todos.', 'Máximo de avaliações publicadas neste bloco. Com 2, aparecem as duas primeiras. Em branco, aplica-se o limite padrão de 30.'],
    'ja' => ['表示件数について', 'このブロックに表示する作品数の上限です。2 を指定すると、ファイルの先頭から2件の作品が表示されます。空欄なら全件表示されます。', 'このブロックに表示する公開レビューの上限です。2 を指定すると、先頭の2件が表示されます。空欄なら既定の30件が上限になります。'],
    'ko' => ['표시 개수 안내', '이 블록에 표시할 최대 작업 수입니다. 2를 입력하면 파일의 처음 두 작업을 표시합니다. 비워 두면 모두 표시합니다.', '이 블록에 표시할 최대 공개 리뷰 수입니다. 2를 입력하면 처음 두 개를 표시합니다. 비워 두면 기본값인 30개가 적용됩니다.'],
    'vi' => ['Ý nghĩa của số bản ghi', 'Số dự án tối đa trong khối này. Nhập 2 để hiện hai dự án đầu tiên trong tệp. Để trống để hiện tất cả.', 'Số đánh giá đã công bố tối đa trong khối này. Nhập 2 để hiện hai đánh giá đầu. Để trống sẽ dùng giới hạn mặc định là 30.'],
    'zh' => ['记录数量说明', '此区块显示的作品上限。输入 2 会显示文件中的前两项作品。留空会显示所有作品。', '此区块显示的已发布评论上限。输入 2 会显示前两条。留空时默认最多显示 30 条。'],
];
