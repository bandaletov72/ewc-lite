<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

return [
    'ru' => '«Тихий сад» — готовый сайт студии ландшафтного дизайна. Выберите его в «Шаблоны оформления → Темы дизайна» и нажмите «Применить». Для проектов и цен откройте инфоблоки garden-projects и garden-prices. Обложка меняется в наборе баннеров garden-cover. Добавьте свои контакты и укажите получателя у формы [form85].',
    'en' => 'Quiet Garden is a complete landscape design studio site. Select it under Layout templates → Design themes and choose Apply. Edit the garden-projects and garden-prices data blocks, and change the cover in the garden-cover banner set. Add your contact details and set a recipient for [form85].',
    'uk' => '«Тихий сад» — готовий сайт студії ландшафтного дизайну. Виберіть його в «Шаблони оформлення → Теми дизайну» і натисніть «Застосувати». Проєкти й ціни редагуються в інфоблоках garden-projects і garden-prices, обкладинка — у наборі банерів garden-cover. Додайте контакти й одержувача форми [form85].',
    'fr' => '« Тихий сад » est un site complet pour un studio de design paysager. Choisissez-le dans Modèles de mise en page → Thèmes de design, puis appliquez-le. Modifiez les blocs garden-projects et garden-prices et le groupe de bannières garden-cover. Ajoutez vos coordonnées et le destinataire du formulaire [form85].',
    'de' => '„Тихий сад“ ist eine vollständige Website für Landschaftsgestaltung. Wählen Sie das Theme unter Layoutvorlagen → Design-Themes und wenden Sie es an. Bearbeiten Sie garden-projects und garden-prices sowie das Banner-Set garden-cover. Hinterlegen Sie Ihre Kontaktdaten und einen Empfänger für [form85].',
    'es' => '«Тихий сад» es un sitio completo para un estudio de paisajismo. Selecciónalo en Plantillas de diseño → Temas de diseño y pulsa Aplicar. Edita los bloques garden-projects y garden-prices y el conjunto de banners garden-cover. Añade tus datos de contacto y el destinatario de [form85].',
    'pt' => '«Тихий сад» é um site completo para um estúdio de paisagismo. Selecione-o em Modelos de design → Temas de design e clique em Aplicar. Edite os blocos garden-projects e garden-prices e o conjunto de banners garden-cover. Adicione os contactos e o destinatário de [form85].',
    'ja' => '「Тихий сад」はランドスケープデザイン事務所向けの完成サイトです。レイアウトテンプレートからデザインテーマを開き、選択して適用します。作品と価格は garden-projects と garden-prices、表紙は garden-cover のバナーセットで編集します。連絡先と [form85] の送信先を設定してください。',
    'ko' => '«Тихий сад»는 조경 디자인 스튜디오용 완성형 사이트입니다. 레이아웃 템플릿 → 디자인 테마에서 선택한 후 적용합니다. garden-projects 및 garden-prices 데이터 블록과 garden-cover 배너 세트를 편집하세요. 연락처와 [form85]의 수신자를 설정합니다.',
    'vi' => '«Тихий сад» là trang web trọn bộ cho studio thiết kế cảnh quan. Chọn trong Mẫu bố cục → Giao diện thiết kế rồi áp dụng. Sửa hai khối dữ liệu garden-projects và garden-prices và bộ banner garden-cover. Thêm thông tin liên hệ và người nhận cho [form85].',
    'zh' => '“Тихий сад”是景观设计工作室的完整站点。在布局模板 → 设计主题中选择并应用该主题。编辑 garden-projects 和 garden-prices 数据块以及 garden-cover 横幅组，并填写联系信息和表单 [form85] 的收件人。',
];
