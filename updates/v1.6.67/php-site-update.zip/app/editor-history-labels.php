<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['На странице были сделаны изменения. Вы уверены, что не хотите их сохранить?', 'Вернуть отменённое изменение', 'Вернуть последний сохранённый текст'],
    'en' => ['Changes were made to this page. Are you sure you want to leave without saving them?', 'Redo last change', 'Restore last saved text'],
    'uk' => ['На сторінці внесено зміни. Ви впевнені, що хочете вийти без збереження?', 'Повернути скасовану зміну', 'Відновити останній збережений текст'],
    'de' => ['Die Seite wurde geändert. Möchten Sie sie wirklich ohne Speichern verlassen?', 'Letzte Änderung wiederholen', 'Zuletzt gespeicherten Text wiederherstellen'],
    'fr' => ['La page a été modifiée. Voulez-vous vraiment partir sans enregistrer les modifications ?', 'Rétablir la dernière modification', 'Restaurer le dernier texte enregistré'],
    'es' => ['Se ha modificado la página. ¿Quieres salir sin guardar los cambios?', 'Rehacer el último cambio', 'Restaurar el último texto guardado'],
    'pt' => ['A página foi alterada. Tem certeza de que deseja sair sem salvar as alterações?', 'Refazer a última alteração', 'Restaurar o último texto salvo'],
    'ja' => ['ページが変更されています。保存せずに移動しますか？', '最後に取り消した変更をやり直す', '最後に保存したテキストを復元'],
    'ko' => ['페이지가 변경되었습니다. 변경 사항을 저장하지 않고 나가시겠습니까?', '마지막 변경 사항 다시 실행', '마지막으로 저장한 텍스트 복원'],
    'vi' => ['Trang đã được chỉnh sửa. Bạn có chắc muốn rời đi mà không lưu các thay đổi?', 'Làm lại thay đổi vừa hoàn tác', 'Khôi phục văn bản đã lưu gần nhất'],
    'zh' => ['此页面有未保存的更改。确定不保存并离开吗？', '重做上次撤销的更改', '恢复上次保存的文本'],
];
