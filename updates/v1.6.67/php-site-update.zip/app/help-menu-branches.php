<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return [
    'ru' => ['Раскрывать ветку меню', 'Показать подразделы', 'Флажок «Показывать в карте сайта» находится во вкладке SEO и учитывается при генерации sitemap.xml. Во вкладке «Настройки страницы» включите «Раскрывать ветку меню», чтобы рядом с разделом появилась стрелка. Видимые в меню подразделы раскрываются при наведении, а на телефоне — по нажатию на стрелку.'],
    'en' => ['Expand menu branch', 'Show subsections', 'The SEO tab contains Include in sitemap, which applies when generating sitemap.xml. In Page settings, enable Expand menu branch to show an arrow beside the section. Subpages visible in the menu open on hover or when tapping the arrow on mobile.'],
    'uk' => ['Розгортати гілку меню', 'Показати підрозділи', 'Прапорець «Показувати в карті сайту» є у вкладці SEO й враховується під час створення sitemap.xml. У налаштуваннях сторінки увімкніть «Розгортати гілку меню». Видимі підрозділи відкриються при наведенні або натисканні на стрілку на телефоні.'],
    'de' => ['Menüzweig ausklappen', 'Unterseiten anzeigen', 'Die Einstellung zur Sitemap befindet sich im SEO-Tab und gilt bei der Erzeugung von sitemap.xml. Aktivieren Sie in den Seiteneinstellungen „Menüzweig ausklappen“. Im Menü sichtbare Unterseiten öffnen sich beim Überfahren oder durch Tippen auf den Pfeil.'],
    'fr' => ['Déployer la branche du menu', 'Afficher les sous-sections', 'L’option d’inclusion dans sitemap.xml se trouve dans l’onglet SEO. Activez « Déployer la branche du menu » dans les paramètres de la page. Les sous-pages visibles s’affichent au survol ou après un appui sur la flèche sur mobile.'],
    'es' => ['Desplegar la rama del menú', 'Mostrar subsecciones', 'La opción para incluir la página en sitemap.xml está en la pestaña SEO. Activa «Desplegar la rama del menú» en los ajustes de página. Las subpáginas visibles aparecen al pasar el cursor o al pulsar la flecha en el móvil.'],
    'pt' => ['Expandir o ramo do menu', 'Mostrar subsecções', 'A opção de inclusão em sitemap.xml está no separador SEO. Nas definições da página, ative «Expandir o ramo do menu». As subpáginas visíveis abrem ao passar o cursor ou ao tocar na seta no telemóvel.'],
    'vi' => ['Mở rộng nhánh menu', 'Hiện các mục con', 'Tùy chọn đưa trang vào sitemap.xml nằm trong tab SEO. Bật «Mở rộng nhánh menu» trong cài đặt trang. Các trang con hiển thị trong menu sẽ mở khi di chuột hoặc chạm vào mũi tên trên điện thoại.'],
    'ja' => ['メニューの枝を展開', '下位セクションを表示', 'SEO タブで sitemap.xml への掲載を設定できます。ページ設定で「メニューの枝を展開」を有効にすると、メニュー表示対象の下位ページがマウスオーバーまたはスマートフォンで矢印をタップすると開きます。'],
    'ko' => ['메뉴 분기 펼치기', '하위 섹션 표시', 'SEO 탭에서 sitemap.xml에 포함할지 설정합니다. 페이지 설정에서 ‘메뉴 분기 펼치기’를 켜면 메뉴에 표시되는 하위 페이지가 마우스를 올리거나 모바일에서 화살표를 누를 때 열립니다.'],
    'zh' => ['展开菜单分支', '显示子栏目', 'SEO 选项卡可设置页面是否包含在 sitemap.xml 中。在页面设置中启用“展开菜单分支”后，悬停或在手机上点击箭头即可显示菜单中可见的子页面。'],
];
