<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'Изменить ширину столбца',
    'en' => 'Resize column',
    'uk' => 'Змінити ширину стовпця',
    'de' => 'Spaltenbreite ändern',
    'fr' => 'Redimensionner la colonne',
    'es' => 'Cambiar el ancho de la columna',
    'pt' => 'Alterar a largura da coluna',
    'vi' => 'Thay đổi độ rộng cột',
    'ja' => '列幅を変更',
    'ko' => '열 너비 조절',
    'zh' => '调整列宽',
];
