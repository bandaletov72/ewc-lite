<?php
if (!defined('SITE_ROOT')) exit;
return <<<'JS'
const siteIconPicker = (picker, selectIcon) => {
    const search = picker.querySelector('[data-editor-icon-filter]');
    const results = picker.querySelector('[data-editor-icon-results]');
    const shortcodes = picker.querySelector('[data-editor-icon-shortcodes]');
    const more = picker.querySelector('[data-editor-icon-more]');
    const empty = picker.querySelector('[data-editor-icon-empty]');
    const aliases = [
        ['home', 'house', 'дом', 'домик', 'главная'],
        ['phone', 'telephone', 'tel', 'телефон'],
        ['star', 'звезда'],
        ['pin', 'location', 'map', 'карта', 'метка'],
    ];
    let icons;
    let includeShortcodes = false;
    let limit = 48;
    const renderIcon = (item) => {
        const name = item.fa || item.name;
        const button = document.createElement('button');
        button.type = 'button';
        button.title = name;
        button.setAttribute('aria-label', name);
        if (item.fa) {
            const glyph = document.createElement('i');
            const [style, symbol] = item.fa.split(':');
            glyph.classList.add('fa-' + style, 'fa-' + symbol);
            glyph.setAttribute('aria-hidden', 'true');
            button.append(glyph);
        } else if (item.image) {
            const glyph = document.createElement('img');
            glyph.src = item.image;
            glyph.alt = '';
            button.append(glyph);
        } else {
            button.textContent = item.code;
        }
        button.addEventListener('click', () => selectIcon(item, item.fa ? '[fa-icon=' + item.fa + ']' : item.code));
        return button;
    };
    const render = () => {
        icons ??= [...picker.querySelector('[data-editor-icon-catalog]').content.children].map(node => node.dataset);
        const terms = search.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
        const matches = icons.filter(item => {
            if (!includeShortcodes && 'inlineOnly' in item) return false;
            const name = item.fa || item.name;
            const words = name.split(/[:/.-]/);
            return terms.every(term => name.includes(term)
                || aliases.some(group => group.includes(term) && group.some(word => words.includes(word)))
                || (item.name === 'site.png' && aliases[0].includes(term)));
        });
        if (shortcodes) {
            const tokens = matches.filter(item => 'inlineOnly' in item);
            shortcodes.querySelector('[data-editor-icon-token-results]').replaceChildren(...tokens.map(renderIcon));
            shortcodes.hidden = tokens.length === 0;
        }
        const glyphs = matches.filter(item => !('inlineOnly' in item));
        results.replaceChildren(...glyphs.slice(0, limit).map(renderIcon));
        empty.hidden = matches.length !== 0;
        more.hidden = glyphs.length <= limit;
    };
    search.addEventListener('input', () => { limit = 48; render(); });
    more.addEventListener('click', () => { limit += 48; render(); });
    return (withShortcodes = false) => {
        includeShortcodes = withShortcodes;
        render();
    };
};
JS;
