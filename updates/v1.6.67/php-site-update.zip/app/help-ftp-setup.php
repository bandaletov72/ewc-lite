<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => [
        'Скачать утилиту для FTP',
        'Откройте скачанную утилиту и нажмите «Создать код сброса». Скачайте и распакуйте ZIP.',
        'Загрузите файл %1$s в папку %2$s на сервере. Имя начинается с точки.',
        'Обновите эту страницу. Введите одноразовый код из утилиты, логин и пароль.',
    ],
    'en' => [
        'Download FTP utility',
        'Open the downloaded utility and generate a setup code. Download and extract the ZIP.',
        'Upload %1$s to the %2$s folder on the server. The filename starts with a dot.',
        'Reload this page. Enter the one-time code from the utility, a username and a password.',
    ],
    'uk' => [
        'Завантажити утиліту для FTP',
        'Відкрийте завантажену утиліту й створіть код встановлення. Завантажте та розпакуйте ZIP.',
        'Завантажте файл %1$s у папку %2$s на сервері. Ім’я файлу починається з крапки.',
        'Оновіть цю сторінку. Введіть одноразовий код, ім’я користувача та пароль.',
    ],
    'de' => [
        'FTP-Werkzeug herunterladen',
        'Öffnen Sie das Werkzeug und erzeugen Sie einen Installationscode. Laden Sie die ZIP-Datei herunter und entpacken Sie sie.',
        'Laden Sie %1$s in den Ordner %2$s auf dem Server hoch. Der Dateiname beginnt mit einem Punkt.',
        'Laden Sie diese Seite neu. Geben Sie den Einmalcode, einen Benutzernamen und ein Passwort ein.',
    ],
    'es' => [
        'Descargar la herramienta FTP',
        'Abre la herramienta y genera un código de instalación. Descarga y extrae el archivo ZIP.',
        'Sube %1$s a la carpeta %2$s del servidor. El nombre del archivo empieza por un punto.',
        'Recarga esta página. Introduce el código de un solo uso, un nombre de usuario y una contraseña.',
    ],
    'fr' => [
        'Télécharger l’outil FTP',
        'Ouvrez l’outil et générez un code d’installation. Téléchargez et extrayez le ZIP.',
        'Envoyez %1$s dans le dossier %2$s sur le serveur. Le nom du fichier commence par un point.',
        'Actualisez cette page. Saisissez le code à usage unique, un identifiant et un mot de passe.',
    ],
    'pt' => [
        'Baixar o utilitário para FTP',
        'Abra o utilitário e gere um código de instalação. Baixe e extraia o ZIP.',
        'Envie %1$s para a pasta %2$s no servidor. O nome do arquivo começa com um ponto.',
        'Atualize esta página. Informe o código de uso único, um usuário e uma senha.',
    ],
    'vi' => [
        'Tải công cụ FTP',
        'Mở công cụ và tạo mã cài đặt. Tải và giải nén tệp ZIP.',
        'Tải %1$s lên thư mục %2$s trên máy chủ. Tên tệp bắt đầu bằng dấu chấm.',
        'Tải lại trang này. Nhập mã dùng một lần, tên đăng nhập và mật khẩu.',
    ],
    'zh' => [
        '下载 FTP 工具',
        '打开工具并生成安装代码。下载并解压 ZIP 文件。',
        '将 %1$s 上传到服务器上的 %2$s 目录。文件名以点开头。',
        '刷新此页并输入一次性代码、用户名和密码。',
    ],
    'ja' => [
        'FTP ツールをダウンロード',
        'ツールを開き、セットアップコードを生成します。ZIP をダウンロードして展開します。',
        '%1$s をサーバーの %2$s フォルダーへアップロードします。ファイル名はドットで始まります。',
        'このページを再読み込みし、ワンタイムコードとユーザー名、パスワードを入力します。',
    ],
    'ko' => [
        'FTP 도구 다운로드',
        '도구를 열어 설치 코드를 생성합니다. ZIP 파일을 내려받아 압축을 풉니다.',
        '서버의 %2$s 폴더에 %1$s 파일을 업로드합니다. 파일 이름은 점으로 시작합니다.',
        '이 페이지를 새로 고칩니다. 일회용 코드와 사용자 이름, 비밀번호를 입력합니다.',
    ],
];
