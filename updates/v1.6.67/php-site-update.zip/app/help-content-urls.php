<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'Если EWC находится в подпапке, путь /images/photo.jpg строится от папки установки. Например, при установке в /test/ браузер получит /test/images/photo.jpg. Для изображения на другом сайте укажите полный URL.',
    'en' => 'If EWC is installed in a subdirectory, /images/photo.jpg is resolved from that directory. For example, an installation at /test/ serves /test/images/photo.jpg. Use a full URL for an image on another site.',
    'de' => 'Bei einer Installation in einem Unterverzeichnis wird /images/photo.jpg relativ zu diesem Verzeichnis aufgelöst. Für /test/ ergibt sich /test/images/photo.jpg. Verwenden Sie für externe Bilder die vollständige URL.',
    'es' => 'Si EWC está instalado en una subcarpeta, /images/photo.jpg se resuelve desde esa carpeta. En /test/ se convierte en /test/images/photo.jpg. Usa una URL completa para imágenes externas.',
    'fr' => 'Si EWC est installé dans un sous-dossier, /images/photo.jpg part de ce dossier. Dans /test/, le chemin devient /test/images/photo.jpg. Utilisez une URL complète pour les images externes.',
    'pt' => 'Se o EWC estiver numa subpasta, /images/photo.jpg é resolvido a partir dessa pasta. Em /test/, o caminho será /test/images/photo.jpg. Use a URL completa para imagens externas.',
    'uk' => 'Якщо EWC встановлено в підпапці, шлях /images/photo.jpg відраховується від цієї папки. У /test/ він стає /test/images/photo.jpg. Для зображення з іншого сайту вкажіть повну URL-адресу.',
    'vi' => 'Nếu EWC được cài trong thư mục con, /images/photo.jpg được tính từ thư mục đó. Với /test/, đường dẫn trở thành /test/images/photo.jpg. Dùng URL đầy đủ cho ảnh bên ngoài.',
    'zh' => '如果 EWC 安装在子目录中，/images/photo.jpg 将相对于该目录解析。安装在 /test/ 时，路径为 /test/images/photo.jpg。外部图片请使用完整 URL。',
    'ja' => 'EWC をサブディレクトリに設置すると、/images/photo.jpg はそのディレクトリを基準に解決されます。/test/ では /test/images/photo.jpg になります。外部の画像には完全な URL を使います。',
    'ko' => 'EWC를 하위 디렉터리에 설치하면 /images/photo.jpg는 그 디렉터리를 기준으로 해석됩니다. /test/에 설치하면 /test/images/photo.jpg가 됩니다. 외부 이미지는 전체 URL을 사용하세요.',
];
