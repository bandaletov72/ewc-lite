<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PAGE_CUSTOM_SCHEMA = SITE_ROOT . '/admin/.page-custom-fields.php';
const SITE_PAGE_CUSTOM_SCHEMA_LIMIT = 65536;
const SITE_PAGE_CUSTOM_FIELD_COUNT = 64;

function site_page_custom_definitions(bool $strict = false): array
{
    try {
        return site_read_record(SITE_PAGE_CUSTOM_SCHEMA, SITE_PAGE_CUSTOM_SCHEMA_LIMIT);
    } catch (RuntimeException $error) {
        if ($strict) throw $error;
        return [];
    }
}

function site_page_reserved_field_ids(): array
{
    return array_merge(array_keys(array_change_key_case(site_page_metadata_defaults())), ['id', 'path', 'html', 'fields', 'revision', 'url']);
}

function site_decode_page_custom_values(string $encoded): ?array
{
    if ($encoded === '') return [];
    $json = site_asset_decode($encoded);
    if ($json === null) return null;
    $values = json_decode($json, true);
    if (!is_array($values) || count($values) > SITE_PAGE_CUSTOM_FIELD_COUNT) return null;
    foreach ($values as $key => $value) {
        if (!preg_match('/\Af-[a-f0-9]{16}\z/', (string) $key) || !is_string($value)) return null;
    }
    return $values;
}

function site_page_custom_fields(array $page, ?array $definitions = null): array
{
    $values = site_decode_page_custom_values($page['fields']['CustomFields'] ?? '') ?? [];
    $fields = [];
    foreach ($definitions ?? site_page_custom_definitions() as $key => $definition) {
        $fields[$definition['id']] = $definition + ['value' => $values[$key] ?? ''];
    }
    return $fields;
}
