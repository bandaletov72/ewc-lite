<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Оформление текста', 'Размер шрифта', 'Цвет текста', 'Цвет фона текста', 'Шрифт', 'Выделите текст, чтобы применить оформление.'],
    'en' => ['Text styling', 'Font size', 'Text color', 'Text background color', 'Font', 'Select text to apply styling.'],
    'uk' => ['Оформлення тексту', 'Розмір шрифту', 'Колір тексту', 'Колір тла тексту', 'Шрифт', 'Виділіть текст, щоб застосувати оформлення.'],
    'de' => ['Text formatieren', 'Schriftgröße', 'Textfarbe', 'Texthintergrundfarbe', 'Schriftart', 'Wählen Sie den zu formatierenden Text aus.'],
    'fr' => ['Style du texte', 'Taille de police', 'Couleur du texte', 'Couleur de fond du texte', 'Police', 'Sélectionnez le texte à mettre en forme.'],
    'es' => ['Estilo del texto', 'Tamaño de fuente', 'Color del texto', 'Color de fondo del texto', 'Fuente', 'Selecciona el texto al que quieres aplicar el estilo.'],
    'pt' => ['Estilo do texto', 'Tamanho da fonte', 'Cor do texto', 'Cor de fundo do texto', 'Fonte', 'Selecione o texto para aplicar o estilo.'],
    'ja' => ['テキストの書式', '文字サイズ', '文字色', '文字の背景色', 'フォント', '書式を適用するテキストを選択してください。'],
    'ko' => ['텍스트 서식', '글꼴 크기', '텍스트 색', '텍스트 배경색', '글꼴', '서식을 적용할 텍스트를 선택하세요.'],
    'vi' => ['Định dạng văn bản', 'Cỡ chữ', 'Màu chữ', 'Màu nền chữ', 'Phông chữ', 'Chọn văn bản để áp dụng định dạng.'],
    'zh' => ['文本样式', '字号', '文字颜色', '文字背景色', '字体', '请选择要设置样式的文字。'],
];
