<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => [
        'Восстановление доступа в админку',
        'При установке укажите email администратора и полный HTTPS-адрес сайта. Если сайт уже установлен, откройте «Настройки → Основные → Email администратора», введите текущий пароль и запросите письмо. Подтвердите адрес по ссылке. На хостинге должна работать отправка почты из PHP.',
        'На форме входа нажмите «Забыли пароль?» и введите подтверждённый email. Откройте ссылку из письма и дважды введите новый пароль. Ссылка одноразовая и действует 30 минут.',
        'Если почта недоступна, скачайте HTML-утилиту по ссылке ниже и откройте её локально. Через SFTP или FTPS скачайте резервную копию admin/.access.php на компьютер и включите показ скрытых файлов при необходимости. Создайте новый файл утилитой и загрузите его вместо существующего admin/.access.php. Откройте /admin/, введите одноразовый код, логин и новый пароль. На втором шаге выберите «Продолжить с текущими настройками». Подтвердите почту заново.',
    ],
    'en' => [
        'Recovering administrator access',
        'During installation, enter the administrator email and the full HTTPS site address. On an existing site, use Settings → General → Administrator email, enter your current password and request the confirmation email. Confirm the address using the link. PHP mail delivery must work on the host.',
        'Choose Forgot your password? on the sign-in page and enter the confirmed email. Open the link and enter the new password twice. The link is single-use and valid for 30 minutes.',
        'If email is inaccessible, download the HTML utility and open it locally. Use SFTP or FTPS to save a backup of admin/.access.php on your computer. Enable hidden files if needed. Generate a new file and upload it to replace admin/.access.php. Open /admin/ and provide the one-time setup code, username, and new password. In step two choose to continue with current settings. Verify your email again.',
    ],
    'uk' => [
        'Відновлення доступу до адмінки',
        'Під час встановлення вкажіть email адміністратора й повну HTTPS-адресу сайту. На чинному сайті відкрийте «Налаштування → Основні → Email адміністратора», введіть поточний пароль і надішліть лист. Підтвердьте адресу за посиланням. На хостингу має працювати надсилання пошти з PHP.',
        'На сторінці входу натисніть «Забули пароль?» і введіть підтверджений email. Відкрийте посилання й двічі введіть новий пароль. Посилання одноразове й діє 30 хвилин.',
        'Якщо пошта недоступна, завантажте й відкрийте HTML-утиліту локально. Через SFTP або FTPS збережіть копію admin/.access.php. За потреби увімкніть показ прихованих файлів. Замініть файл згенерованим утилітою, відкрийте /admin/, введіть одноразовий код, логін і новий пароль. На другому кроці продовжте з чинними налаштуваннями. Підтвердьте email знову.',
    ],
    'de' => [
        'Administratorzugang wiederherstellen',
        'Geben Sie bei der Installation Ihre Administrator-E-Mail und die vollständige HTTPS-Adresse an. Bei einer vorhandenen Website öffnen Sie Einstellungen → Allgemein → Administrator-E-Mail, geben Ihr aktuelles Passwort ein und bestätigen die Adresse über die E-Mail. PHP muss auf dem Host E-Mails senden können.',
        'Wählen Sie „Passwort vergessen?“ und geben Sie die bestätigte E-Mail ein. Öffnen Sie den Link und geben Sie das neue Passwort zweimal ein. Der Link ist einmalig und 30 Minuten gültig.',
        'Ohne E-Mail-Zugang laden Sie das HTML-Werkzeug herunter und öffnen es lokal. Sichern Sie admin/.access.php per SFTP oder FTPS und zeigen Sie bei Bedarf versteckte Dateien an. Ersetzen Sie die Datei durch die erzeugte Datei. Öffnen Sie /admin/ und geben Sie Einmalcode, Benutzername und neues Passwort ein. Behalten Sie im zweiten Schritt die aktuellen Einstellungen bei. Bestätigen Sie die E-Mail erneut.',
    ],
    'es' => [
        'Recuperar el acceso de administrador',
        'Introduce el correo del administrador y la dirección HTTPS completa al instalar. Si el sitio ya existe, abre Ajustes → Generales → Correo del administrador, introduce la contraseña actual y confirma la dirección con el enlace del correo. El alojamiento debe poder enviar correo desde PHP.',
        'Pulsa «¿Olvidaste tu contraseña?» e introduce el correo confirmado. Abre el enlace e introduce dos veces la nueva contraseña. El enlace es de un solo uso y dura 30 minutos.',
        'Si no tienes acceso al correo, descarga la herramienta HTML y ábrela localmente. Guarda una copia de admin/.access.php mediante SFTP o FTPS. Muestra archivos ocultos si es necesario. Sustituye el archivo por el generado, abre /admin/ e introduce el código de un solo uso, el usuario y la nueva contraseña. En el segundo paso, continúa con los ajustes vigentes. Confirma el correo de nuevo.',
    ],
    'fr' => [
        'Récupérer l’accès à l’administration',
        'Lors de l’installation, saisissez l’adresse e-mail d’administration et l’adresse HTTPS complète du site. Sur un site existant, ouvrez Paramètres → Général → Adresse e-mail de l’administrateur, entrez le mot de passe actuel et confirmez l’adresse via l’e-mail. L’envoi d’e-mails depuis PHP doit fonctionner.',
        'Cliquez sur « Mot de passe oublié ? » et saisissez l’adresse confirmée. Ouvrez le lien et saisissez deux fois le nouveau mot de passe. Le lien est à usage unique et valable 30 minutes.',
        'Sans accès à l’e-mail, téléchargez l’outil HTML et ouvrez-le localement. Sauvegardez admin/.access.php par SFTP ou FTPS, en affichant les fichiers cachés si nécessaire. Remplacez-le par le fichier généré. Ouvrez /admin/ et saisissez le code à usage unique, l’identifiant et le nouveau mot de passe. À la deuxième étape, poursuivez avec les paramètres actuels. Confirmez à nouveau l’adresse e-mail.',
    ],
    'pt' => [
        'Recuperar o acesso à administração',
        'Na instalação, indique o e-mail do administrador e o endereço HTTPS completo. Num site existente, abra Configurações → Gerais → E-mail do administrador, informe a senha atual e confirme o endereço pelo link recebido. O envio de e-mail por PHP deve estar ativo na hospedagem.',
        'Clique em «Esqueceu a senha?» e informe o e-mail confirmado. Abra o link e digite a nova senha duas vezes. O link é de uso único e vale 30 minutos.',
        'Se não tiver acesso ao e-mail, baixe a ferramenta HTML e abra-a localmente. Faça uma cópia de admin/.access.php via SFTP ou FTPS e mostre arquivos ocultos, se necessário. Substitua o arquivo pelo gerado, abra /admin/ e informe o código de uso único, o usuário e a nova senha. Na segunda etapa, continue com as configurações atuais. Confirme o e-mail novamente.',
    ],
    'vi' => [
        'Khôi phục quyền truy cập quản trị',
        'Khi cài đặt, nhập email quản trị viên và địa chỉ HTTPS đầy đủ. Trên trang hiện có, mở Cài đặt → Chung → Email quản trị viên, nhập mật khẩu hiện tại và xác nhận địa chỉ qua thư. Máy chủ phải hỗ trợ gửi thư từ PHP.',
        'Chọn «Quên mật khẩu?» và nhập email đã xác nhận. Mở liên kết và nhập mật khẩu mới hai lần. Liên kết dùng một lần và có hiệu lực 30 phút.',
        'Nếu không thể truy cập email, tải công cụ HTML và mở trên máy của bạn. Dùng SFTP hoặc FTPS để sao lưu admin/.access.php, bật hiển thị tệp ẩn nếu cần. Thay tệp bằng bản đã tạo, mở /admin/ và nhập mã dùng một lần, tên đăng nhập và mật khẩu mới. Ở bước hai, tiếp tục với cài đặt hiện tại. Xác nhận lại email.',
    ],
    'zh' => [
        '恢复后台访问权限',
        '安装时填写管理员邮箱和完整的网站 HTTPS 地址。现有站点可进入「设置 → 常规 → 管理员邮箱」，输入当前密码并通过邮件链接确认。主机必须支持从 PHP 发送邮件。',
        '在登录页点击「忘记密码？」，输入已确认的邮箱。打开邮件中的链接，两次输入新密码。链接仅能使用一次，有效期为 30 分钟。',
        '若无法访问邮箱，请下载 HTML 工具并在本地打开。通过 SFTP 或 FTPS 备份 admin/.access.php，必要时显示隐藏文件。用生成的文件替换该文件。打开 /admin/，输入一次性安装代码、用户名和新密码。第二步选择保留当前设置。重新确认邮箱。',
    ],
    'ja' => [
        '管理画面へのアクセスを復旧する',
        'インストール時に管理者メールアドレスとサイトの完全な HTTPS アドレスを入力します。既存サイトでは「設定 → 基本 → 管理者メールアドレス」を開き、現在のパスワードを入力してメールでアドレスを確認します。ホスティングで PHP からメールを送信できる必要があります。',
        'ログイン画面で「パスワードをお忘れですか？」を選び、確認済みのメールアドレスを入力します。メールのリンクを開き、新しいパスワードを2回入力してください。リンクは30分間有効で、1回のみ使用できます。',
        'メールを利用できない場合は、HTML ツールをダウンロードしてローカルで開きます。SFTP または FTPS で admin/.access.php をバックアップし、必要に応じて隠しファイルを表示します。生成されたファイルで置き換え、/admin/ を開いてワンタイムコード、ユーザー名、新しいパスワードを入力します。手順2では現在の設定のまま続行し、メールアドレスを再確認します。',
    ],
    'ko' => [
        '관리자 접근 복구',
        '설치할 때 관리자 이메일과 사이트의 전체 HTTPS 주소를 입력합니다. 기존 사이트에서는 설정 → 기본 → 관리자 이메일에서 현재 비밀번호를 입력한 후 메일의 링크로 주소를 확인합니다. 호스팅에서 PHP 메일 발송이 가능해야 합니다.',
        '로그인 화면에서 ‘비밀번호를 잊으셨나요?’를 선택하고 확인된 이메일을 입력합니다. 메일의 링크를 열고 새 비밀번호를 두 번 입력합니다. 링크는 30분 동안 유효하며 한 번만 쓸 수 있습니다.',
        '이메일에 접근할 수 없으면 HTML 도구를 내려받아 로컬에서 엽니다. SFTP 또는 FTPS를 통해 admin/.access.php를 백업하고 필요하면 숨김 파일을 표시합니다. 생성한 파일로 교체한 다음 /admin/을 열어 일회용 코드, 사용자 이름, 새 비밀번호를 입력합니다. 두 번째 단계에서 현재 설정을 유지한 뒤 이메일을 다시 확인합니다.',
    ],
];
