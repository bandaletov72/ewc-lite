<?php
header('Content-Type: text/javascript; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
echo <<<'JS'
document.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-copy-code-button]');
    if (!button) return;
    const container = button.closest('[data-copy-code]');
    const code = container.querySelector('[data-copy-code-text]');
    const status = container.querySelector('[data-copy-code-status]');
    try {
        await navigator.clipboard.writeText(code.textContent);
        status.textContent = button.dataset.copyConfirmation;
    } catch {
        const editor = container.querySelector('[data-copy-code-editor]:not([hidden])');
        if (editor) {
            editor.focus();
            editor.select();
        } else {
            const range = document.createRange();
            range.selectNodeContents(code);
            const selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
        }
        status.textContent = document.execCommand('copy') ? button.dataset.copyConfirmation : button.dataset.copyFallback;
    }
});
JS;
