<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php
$navItems = ($name ?? '') === 'footer'
    ? array_map(static function (array $page): array { return ['page' => $page, 'children' => []]; }, $navigation ?? [])
    : site_navigation_menu_tree(site_page_tree($navigation ?? []));
$navLabels = require SITE_ROOT . '/app/help-menu-branches.php';
$navExpandLabel = ($navLabels[$locale] ?? $navLabels['ru'])[1];
$navRender = static function (array $items, bool $list) use (&$navRender, $base, $originalPath, $snippets, $navExpandLabel): void {
    foreach ($items as $item) {
        $page = $item['page'];
        $label = site_expand_text($page['fields']['Menu'] ?: $page['fields']['Title'], $snippets);
        $link = '<a href="' . site_escape(site_page_link($base, $page)) . '"'
            . ($originalPath === $page['path'] ? ' aria-current="page"' : '') . '>'
            . site_page_menu_label($label, $page, $base) . '</a>';
        if ($list) echo '<li>';
        if (!$item['children']) {
            echo $link;
        } else {
            $control = site_escape($navExpandLabel . ' · ' . $label);
            echo '<div class="page-menu-branch" data-page-menu-branch>' . $link
                . '<details><summary aria-label="' . $control . '" title="' . $control . '"></summary><ul class="page-menu-submenu">';
            $navRender($item['children'], true);
            echo '</ul></details></div>';
        }
        if ($list) echo '</li>';
    }
};
$navRender($navItems, !empty($navAsList));
