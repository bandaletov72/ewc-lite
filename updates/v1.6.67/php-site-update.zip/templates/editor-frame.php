<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

$fonts = site_font_assets(site_base('templates/editor-frame.php'));
$remote = strpos($fonts, 'https://fonts.googleapis.com/') !== false;
$fontStyleSource = $remote ? ' https://fonts.googleapis.com' : '';
$fontSource = $remote ? ' https://fonts.gstatic.com' : '';
header('Content-Type: text/html; charset=UTF-8');
header("Content-Security-Policy: default-src 'none'; img-src 'self' https: data:; style-src 'unsafe-inline' 'self'{$fontStyleSource}; font-src 'self'{$fontSource}; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
header('X-Content-Type-Options: nosniff');
?>
<!doctype html>
<html><head><meta charset="UTF-8"><title>Визуальный редактор</title><?= $fonts ?><style>body{margin:.8rem;min-height:calc(100vh - 1.6rem);font-family:var(--site-font,serif)}img{max-width:100%;cursor:move}</style></head><body></body></html>
