<?php
header('Content-Type: image/svg+xml; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <rect x=".75" y=".75" width="22.5" height="22.5" rx="5.25" fill="#24201c"/>
  <path d="M16.8 20.2C10.6 22.3 4 18.5 4 12.5C4 7.5 7.8 4 12.7 4C17 4 20 6.7 20 10.2C20 13.4 17.5 15.7 14.4 15.7C11.9 15.7 10.1 14 10.1 11.9C10.1 10.1 11.5 8.9 13.1 9.1"
        fill="none" stroke="#f2ceaa" stroke-width="2.1" stroke-linecap="round"/>
</svg>
