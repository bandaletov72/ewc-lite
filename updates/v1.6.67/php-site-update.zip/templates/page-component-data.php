<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<dialog class="editor-dialog component-data-dialog" id="page-component-data" aria-labelledby="page-component-data-label">
    <div class="header-actions editor-dialog-heading">
        <h2 id="page-component-data-label"><?= site_escape($editDataText) ?></h2>
        <a class="button" data-component-data-wide target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
        <button class="dialog-close" type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>"></button>
    </div>
    <iframe data-component-data-iframe title="<?= site_escape($editDataText) ?>"></iframe>
</dialog>
