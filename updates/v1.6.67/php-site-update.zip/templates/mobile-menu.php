<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="mobile-header-menu">
    <button class="menu-toggle" type="button" data-mobile-toggle aria-expanded="false" aria-haspopup="dialog"
        aria-label="<?= site_escape(site_translation('Меню', $locale)) ?>" hidden>
        <span class="menu-toggle-icon" aria-hidden="true"></span>
    </button>
    <dialog class="mobile-drawer" data-mobile-drawer aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
        <div class="mobile-drawer-heading">
            <strong><?= site_escape(site_translation('Меню', $locale)) ?></strong>
            <button class="mobile-drawer-close dialog-close" type="button" data-mobile-close aria-label="<?= site_escape(site_translation('Закрыть меню', $locale)) ?>" autofocus></button>
        </div>
        <?= site_expand_content('[search]', $snippets, $context) ?>
        <div class="mobile-city-controls"><?= site_expand_content('[cities][phones]', $snippets, $context) ?></div>
        <nav class="site-menu" data-mobile-navigation aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
            <?php require site_template_file('navigation-links.php'); ?>
        </nav>
        <?php $contactMarkup = site_expand_content('[contacts]', $snippets, $context); ?>
        <?php if (trim($contactMarkup) !== ''): ?>
            <div class="mobile-drawer-contacts"><?= $contactMarkup ?></div>
        <?php endif; ?>
        <div class="mobile-language-selector"><?= site_expand_content('[lang]', $snippets, $context) ?></div>
    </dialog>
    <noscript><nav class="site-menu" aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
        <?php require site_template_file('navigation-links.php'); ?>
    </nav></noscript>
</div>
