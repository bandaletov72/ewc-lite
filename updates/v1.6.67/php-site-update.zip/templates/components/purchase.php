<?php if (!defined('SITE_ROOT')) exit; ?>
<button class="button-primary" type="button" data-action-open="<?= site_escape($id) ?>" aria-haspopup="dialog"><?= site_escape($labels['buy']) ?></button>
<dialog class="editor-dialog" data-action-dialog id="<?= site_escape($id) ?>" aria-labelledby="<?= site_escape($id . '-title') ?>">
    <div class="header-actions editor-dialog-heading">
        <h2 id="<?= site_escape($id . '-title') ?>"><?= site_escape($labels['buy'] . ' · ' . $price) ?></h2>
        <button class="dialog-close" type="button" data-action-close aria-label="<?= site_escape(site_translation('Закрыть', $language)) ?>"></button>
    </div>
    <form class="contact-form form-stack" method="post" action="<?= site_escape(site_url($base, 'form/')) ?>" data-contact-form data-purchase-form
        data-phone-profile="<?= site_escape((string) json_encode(site_phone_profile())) ?>"
        data-phone-error="<?= site_escape(site_translation('Укажите полный номер телефона, включая код страны.', $language)) ?>">
        <input type="hidden" name="form" value="purchase">
        <input type="hidden" name="page" value="<?= site_escape($path) ?>">
        <input type="hidden" name="language" value="<?= site_escape($language) ?>">
        <input type="hidden" name="nonce" value="<?= site_escape($nonce) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($signature) ?>">
        <div hidden><input name="website" type="text" tabindex="-1" autocomplete="off"></div>
        <p class="hint"><?= site_escape($labels['contact']) ?></p>
        <?php foreach (['name' => 'text', 'phone' => 'tel', 'email' => 'email'] as $key => $type): ?>
            <label class="field" data-message-field="<?= $key ?>"><?= site_escape($labels[$key]) ?>
                <input name="fields[<?= $key ?>]" type="<?= $type ?>" maxlength="<?= ['name'=>90,'phone'=>32,'email'=>254][$key] ?>"
                    autocomplete="<?= ['name'=>'name','phone'=>'tel','email'=>'email'][$key] ?>"<?= $key === 'name' ? ' required' : '' ?>>
                <small class="field-error" data-field-error hidden></small>
            </label>
        <?php endforeach; ?>
        <?php if ($captcha['enabled']): ?>
            <div data-form-captcha data-sitekey="<?= site_escape($captcha['sitekey']) ?>"></div>
            <p class="hint" data-captcha-status role="status"></p>
        <?php endif; ?>
        <a href="<?= site_escape(site_url($base, 'privacy/')) ?>"><?= site_escape($labels['privacy']) ?></a>
        <div><button class="button-primary" type="submit" disabled><?= site_escape($labels['checkout']) ?></button></div>
        <p class="notice" role="status" data-form-feedback hidden></p>
    </form>
</dialog>
