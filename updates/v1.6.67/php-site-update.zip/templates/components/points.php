<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$points = $context['pointItems'] ?? [];
if (!$points) return;
?>
<ul class="page-point-list">
    <?php foreach ($points as $point): ?>
        <li>
            <article class="map-page-balloon">
                <strong><?= $point['labelHtml'] ?></strong>
                <?php if ($point['image'] !== ''): ?>
                    <img class="map-page-balloon-image" src="<?= site_escape($point['image']) ?>" alt="" loading="lazy">
                <?php endif; ?>
                <?php if ($point['announcement'] !== ''): ?>
                    <div class="map-page-balloon-note"><?= $point['announcement'] ?></div>
                <?php endif; ?>
                <div class="header-actions">
                    <a class="button button-primary" href="<?= site_escape($point['url']) ?>"><?= site_escape($point['pageButtonLabel']) ?></a>
                    <a class="button" href="<?= site_escape($point['routeUrl']) ?>"><?= site_escape($point['routeLabel']) ?></a>
                </div>
            </article>
        </li>
    <?php endforeach; ?>
</ul>
