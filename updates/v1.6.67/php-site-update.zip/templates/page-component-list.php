<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php if (!$componentItems): ?><p class="hint"><?= $editText('Ничего не найдено.') ?></p><?php endif; ?>
<?php $inlineSchema = site_component_schema(); ?>
<?php
$iblockFiles = array_fill_keys(array_map(static function (string $id): string { return '/data/' . $id . '.txt'; }, site_iblock_names()), []);
$limitLabels = require SITE_ROOT . '/app/help-iblock-limit.php';
$limitHelp = $limitLabels[$editor['language']] ?? $limitLabels['ru'];
?>
<?php foreach ($componentItems as $index => $item): ?>
    <?php $inlineCode = $item['code']; ?>
    <details id="inline-component-<?= $index ?>" class="inline-component-entry">
        <summary><code><?= site_escape(site_search_clip($inlineCode, 145)) ?></code></summary>
        <?php $dataTarget = site_inline_data_target($item, $base, $contentHost, $settings); ?>
        <?php $mediaTarget = $dataTarget && in_array($item['kind'], ['gal', 'fotos', 'files'], true); ?>
        <?php if ($dataTarget && !$mediaTarget): ?>
            <?php $hasDataTarget = true; ?>
            <?php
            $dataLabel = $editDataText;
            if ($item['kind'] === 'banners') {
                $componentHelp = require SITE_ROOT . '/app/help-component-editing.php';
                $dataLabel = ($componentHelp[$editor['language']] ?? $componentHelp['ru'])[0];
            } elseif ($item['kind'] === 'phpModule') {
                $dataLabel = site_edit_layout_labels($editor['language'])[3];
            } elseif ($item['kind'] === 'points') {
                $pointLabels = require SITE_ROOT . '/app/help-page-custom-fields.php';
                $dataLabel = ($pointLabels[$editor['language']] ?? $pointLabels['ru'])[11];
            }
            ?>
            <div class="header-actions component-data-actions"<?= $item['kind'] === 'iblock' ? ' data-iblock-file-links' : '' ?>>
                <button type="button" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>" data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape($dataLabel) ?></button>
                <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
                <?php if ($item['kind'] === 'banners' && !$editor['edit'] && !$editInAdmin): ?>
                    <a class="button" href="<?= site_escape($editUrl . '#page-components') ?>"><?= $editText('Править компонент') ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ($item['offset'] !== null && ($editor['edit'] || $editInAdmin)): ?>
        <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>" data-inline-editor="<?= site_escape($item['kind']) ?>">
            <?= $editHidden ?>
            <input type="hidden" name="index" value="<?= $index ?>">
            <?php if ($editInAdmin): ?><input type="hidden" name="return_editor" value="1"><?php endif; ?>
            <div class="fields">
                <?php $inlineFields = site_inline_editor_fields($item); ?>
                <?php foreach ($inlineFields as $field => list($label, $value)): ?>
                    <?php if (in_array($item['kind'], ['points', 'maplist'], true) && $field === 'section'):
                        $mapLabelOptions = require SITE_ROOT . '/app/help-maplist.php';
                        $mapLabelOptions = $mapLabelOptions[$editor['language']] ?? $mapLabelOptions['ru']; ?>
                    <label class="field"><?= site_escape($mapLabelOptions[4]) ?>
                        <input data-inline-field="section" value="<?= site_escape($value) ?>" placeholder="/sample/" maxlength="240">
                    </label>
                    <?php continue; endif; ?>
                    <?php if ($item['kind'] === 'iblock' && $field === 'limit'): ?>
                        <?php $reviews = strtolower($inlineFields['template'][1]) === 'reviews'; ?>
                        <div class="field">
                            <label for="inline-iblock-limit-<?= $index ?>"><?= $editText($label) ?></label>
                            <div class="inline-limit-control">
                                <input type="number" min="1" max="<?= $reviews ? 100 : 200 ?>" id="inline-iblock-limit-<?= $index ?>"
                                    data-inline-field="limit" value="<?= site_escape($value) ?>">
                                <details>
                                    <summary title="<?= site_escape($limitHelp[0]) ?>" aria-label="<?= site_escape($limitHelp[0]) ?>">?</summary>
                                    <small class="hint"><?= site_escape($limitHelp[$reviews ? 2 : 1]) ?></small>
                                </details>
                            </div>
                        </div>
                    <?php continue; endif; ?>
                    <?php if ($item['kind'] === 'iblock' && $field === 'path'): ?>
                        <?php
                        $filePickerOptions = $iblockFiles;
                        $filePickerSelected = $value;
                        $filePickerMode = 'inline';
                        $filePickerLanguage = $editor['language'];
                        $filePickerCsrf = $editor['csrf'];
                        $filePickerTitle = site_translation($label, $filePickerLanguage);
                        require SITE_ROOT . '/templates/iblock-file-picker.php';
                        ?>
                    <?php continue; endif; ?>
                    <label class="field"><?= $editText($label) ?>
                        <?php if (in_array($item['kind'], ['route', 'map', 'maps', 'maplist'], true) && $field === 'provider'): ?>
                            <select data-inline-field="provider">
                                <option value=""<?= $value === '' ? ' selected' : '' ?>><?= $editText('По умолчанию') ?></option>
                                <option value="yandex"<?= $value === 'yandex' ? ' selected' : '' ?>><?= $editText('Яндекс Карты') ?></option>
                                <option value="google"<?= $value === 'google' ? ' selected' : '' ?>>Google Maps</option>
                            </select>
                        <?php elseif (in_array($item['kind'], ['map', 'maps', 'maplist'], true) && $field === 'mode'): ?>
                            <select data-inline-field="mode">
                                <option value=""<?= $value === '' ? ' selected' : '' ?>><?= $editText('По умолчанию') ?></option>
                                <?php foreach (site_map_modes() as $mode => $modeLabel): ?>
                                    <option value="<?= site_escape($mode) ?>"<?= $value === $mode ? ' selected' : '' ?>><?= $editText($modeLabel) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php elseif ($item['kind'] === 'iblock' && $field === 'template'): ?>
                            <?php $viewOptions = site_iblock_views(); ?>
                            <select data-inline-field="template">
                                <?php if (!isset($viewOptions[$value]) && $value !== ''): ?><option value="<?= site_escape($value) ?>" selected disabled><?= site_escape($value) ?></option><?php endif; ?>
                                <?php foreach ($viewOptions as $name => $viewLabel): ?><option value="<?= site_escape($name) ?>"<?= $name === $value ? ' selected' : '' ?>><?= $editText($viewLabel) ?></option><?php endforeach; ?>
                            </select>
                        <?php elseif ($item['kind'] === 'iblock' && $field === 'type'): ?>
                            <?php $chartLabels = site_iblock_chart_text($editor['language']); ?>
                            <select data-inline-field="type">
                                <?php foreach (site_iblock_chart_types() as $chartIndex => $type): ?>
                                    <option value="<?= site_escape($type) ?>"<?= $type === $value ? ' selected' : '' ?>><?= site_escape($chartLabels['types'][$chartIndex]) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input data-inline-field="<?= site_escape($field) ?>" value="<?= site_escape($value) ?>" maxlength="500"
                                <?= $item['kind'] === 'route' && $field === 'button' ? 'placeholder="' . site_escape(site_route_label($editor['language'])) . '"' : '' ?>>
                        <?php endif; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <?php if (isset($inlineSchema[$item['sizeKind']])): ?>
                <?php $selectedOptions = site_shortcode_options($item['options']); ?>
                <?php
                if (isset($selectedOptions['width'])) {
                    $selectedOptions['width'] = rtrim($selectedOptions['width'], '%');
                    if ($selectedOptions['width'] === '100') $selectedOptions['width'] = $item['sizeKind'] === 'banners' ? 'page' : 'parent';
                }
                if (!isset($selectedOptions['mobile-height']) && isset($selectedOptions['height-mobile'])) {
                    $selectedOptions['mobile-height'] = $selectedOptions['height-mobile'];
                }
                ?>
                <div class="fields">
                    <?php foreach ($inlineSchema[$item['sizeKind']]['settings'] as $name => $option): ?>
                        <label class="field"><?= site_escape(site_component_size_text($option['label'], $editor['language'])) ?>
                            <select data-inline-option="<?= site_escape($name) ?>">
                                <option value=""><?= $editText('По умолчанию') ?></option>
                                <?php if (in_array($name, ['height', 'mobile-height'], true) && isset($selectedOptions[$name])
                                    && !isset($option['options'][$selectedOptions[$name]]) && preg_match('/\A[0-9]{2,4}(?:px)?\z/', $selectedOptions[$name])): ?>
                                    <option value="<?= (int) $selectedOptions[$name] ?>" selected><?= (int) $selectedOptions[$name] ?> px</option>
                                <?php endif; ?>
                                <?php foreach ($option['options'] as $value => $label): ?>
                                    <option value="<?= site_escape((string) $value) ?>"<?= (string) $value === ($selectedOptions[$name] ?? null) ? ' selected' : '' ?>><?= site_escape(site_component_size_text($label, $editor['language'])) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <input type="hidden" name="code" value="<?= site_escape($inlineCode) ?>" data-inline-original="<?= site_escape($inlineCode) ?>">
            <?= site_copy_code($inlineCode, $editor['language'], site_translation('Код вставки', $editor['language']), 'inline-shortcode-' . $index) ?>
            <div class="header-actions">
                <button class="button-primary" name="action" value="live-component"><?= $editText('Сохранить') ?></button>
                <?php if ($mediaTarget): ?>
                    <?php $hasDataTarget = true; ?>
                    <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>"
                        data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape(site_file_manager_labels($editor['language'])[0]) ?></a>
                <?php endif; ?>
            </div>
        </form>
        <?php else: ?>
            <?php if ($mediaTarget): ?>
                <?php $hasDataTarget = true; ?>
                <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>" data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape(site_file_manager_labels($editor['language'])[0]) ?></a>
            <?php endif; ?>
            <?= site_copy_code($inlineCode, $editor['language']) ?>
        <?php endif; ?>
    </details>
<?php endforeach; ?>
