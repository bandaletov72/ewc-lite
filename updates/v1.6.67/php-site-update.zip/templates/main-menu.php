<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
if (!$navigation && $settings['searchMode'] === 'off' && count(site_region_settings()['languages']) < 2) {
    return;
}
?>
<nav class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>public-main-menu" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
    <?php if ($navigation): ?>
        <ul><?php $navAsList = true; require site_template_file('navigation-links.php'); unset($navAsList); ?></ul>
    <?php endif; ?>
    <div class="main-menu-tools">
        <?php if ($settings['searchMode'] !== 'off'): ?>
            <div class="main-menu-search"><?= site_expand_content('[search]', $snippets, $context) ?></div>
        <?php endif; ?>
        <div class="main-menu-language"><?= site_expand_content('[lang]', $snippets, $context) ?></div>
    </div>
</nav>
