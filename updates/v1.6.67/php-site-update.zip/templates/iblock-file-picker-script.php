<?php
header('Content-Type: text/javascript; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
echo <<<'JS'
document.querySelectorAll('[data-iblock-file-picker]').forEach(picker => {
    const select = picker.querySelector('select');
    const fields = picker.querySelector('[data-iblock-file-new]');
    const input = picker.querySelector('[data-iblock-file-name]');
    const create = picker.querySelector('[data-iblock-file-create]');
    const status = picker.querySelector('[data-iblock-file-status]');
    const inline = select.dataset.iblockFileSelect === 'inline';
    const inlineForm = inline ? picker.closest('[data-inline-editor]') : null;
    const report = (message, failed = false) => {
        status.textContent = message;
        status.hidden = !message;
        status.classList.toggle('error', failed);
    };
    const updateLinks = (id) => {
        if (!inlineForm || !id) return;
        const links = inlineForm.closest('.inline-component-entry')?.querySelector('[data-iblock-file-links]');
        links?.querySelectorAll('[data-editor-data-url], a[href]').forEach(link => {
            for (const name of ['data-editor-data-url', 'data-editor-data-wide', 'href']) {
                if (!link.hasAttribute(name)) continue;
                const url = new URL(link.getAttribute(name), location.href);
                url.searchParams.set('id', id);
                link.setAttribute(name, url.pathname + url.search + url.hash);
            }
        });
    };
    const updatePicker = () => {
        const adding = select.value === ':new:';
        fields.hidden = !adding;
        input.disabled = !adding;
        create.disabled = !input.value.trim();
        report('');
        if (adding) input.focus();
        else updateLinks(select.value.match(/^\/data\/([A-Za-z0-9_-]+)\.txt$/)?.[1]);
    };
    const createFile = async () => {
        const name = input.value.trim();
        if (!name || !input.reportValidity()) return;
        const component = picker.closest('[data-editor-picker="component"]');
        const type = component?.querySelector('[data-editor-component]')?.value;
        const view = inline ? inlineForm.querySelector('[data-inline-field="template"]').value
            : type === 'iblock' ? component.querySelector('[data-editor-param="layout"]').value : type;
        const body = new URLSearchParams({action: 'create-iblock-file', csrf: picker.dataset.iblockFileCsrf, name, view});
        select.disabled = create.disabled = input.disabled = true;
        report('');
        try {
            const response = await fetch(picker.dataset.iblockFileUrl, {method: 'POST', body, headers: {Accept: 'application/json'}});
            const data = await response.json();
            if (!response.ok || !data.ok) throw new Error(data.message || picker.dataset.iblockFileError);
            document.querySelectorAll('[data-iblock-file-select]').forEach(field => {
                const pathMode = field.dataset.iblockFileSelect === 'inline';
                const value = pathMode ? data.path : data.id;
                if ([...field.options].some(option => option.value === value)) return;
                const option = new Option(data.id + '.txt', value);
                if (!pathMode) option.dataset.columns = JSON.stringify(data.columns);
                field.add(option, field.options.length - 1);
            });
            select.value = inline ? data.path : data.id;
            input.value = '';
            select.dispatchEvent(new Event('change', {bubbles: true}));
            report(picker.dataset.iblockFileCreated);
        } catch (error) {
            report(error.message || picker.dataset.iblockFileError, true);
        } finally {
            select.disabled = false;
            input.disabled = fields.hidden;
            create.disabled = !input.value.trim();
            (fields.hidden ? select : input).focus();
        }
    };
    select.addEventListener('change', updatePicker);
    input.addEventListener('input', () => { create.disabled = !input.value.trim(); });
    input.addEventListener('keydown', event => {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        if (!create.disabled) createFile();
    });
    create.addEventListener('click', createFile);
});
JS;
