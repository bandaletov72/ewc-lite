<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

if (!$settings['breadcrumbs'] || $searchMode || $page['path'] === '' || ($originalPath === 'index.php' && empty($context['embeddedLayout']))) {
    return;
}
$directory = dirname($originalPath);
$ancestors = [];
while ($directory !== '.') {
    $ancestor = $directory . '/index.php';
    if ($ancestor !== $originalPath) {
        $entry = site_localized_page($ancestor, $locale);
        if ($entry !== null) {
            $ancestors[] = [site_page_link($base, $entry), site_expand_text($entry['fields']['Title'], $snippets), site_page_icon($entry, $base)];
        }
    }
    $directory = dirname($directory);
}
$home = site_localized_page('index.php', $locale);
$homeLabel = $home === null ? 'Главная' : site_expand_text($home['fields']['Title'], $snippets);
$homeUrl = $home === null ? site_page_url($base, 'index.php') : site_page_link($base, $home);
$links = $originalPath === 'index.php' ? [] : array_merge([[$homeUrl, $homeLabel, $home ? site_page_icon($home, $base) : '']], array_reverse($ancestors));
$siblings = [];
if ($originalPath !== 'index.php' && basename($originalPath) === 'index.php') {
    $parent = dirname(dirname($originalPath));
    foreach (site_pages() as $candidate) {
        $path = $candidate['path'];
        if ($path === 'index.php' || $path === $originalPath || basename($path) !== 'index.php' || dirname(dirname($path)) !== $parent) {
            continue;
        }
        $entry = site_localized_page($path, $locale);
        if ($entry !== null) {
            $fields = $entry['fields'];
            $siblings[] = [site_page_link($base, $entry), site_expand_text($fields['Menu'] ?: $fields['Title'], $snippets), site_page_icon($entry, $base)];
        }
    }
}
?>
<nav class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>breadcrumbs" aria-label="<?= site_escape(site_translation('Хлебные крошки', $locale)) ?>">
    <ol>
        <?php foreach ($links as list($url, $label, $icon)): ?>
            <li><a href="<?= site_escape($url) ?>"><?= $icon ?><?= site_escape($label) ?></a></li>
        <?php endforeach; ?>
        <?php if ($siblings): ?>
            <li class="breadcrumb-current">
                <details class="breadcrumb-siblings" data-breadcrumb-siblings>
                    <summary><span aria-current="page"><?= site_page_icon($page, $base) ?><?= site_escape($title) ?></span><span aria-hidden="true" class="breadcrumb-caret"></span></summary>
                    <ul>
                        <?php foreach ($siblings as list($url, $label, $icon)): ?>
                            <li><a href="<?= site_escape($url) ?>"><?= $icon ?><?= site_escape($label) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </details>
            </li>
        <?php else: ?>
            <li aria-current="page"><?= site_page_icon($page, $base) ?><?= site_escape($title) ?></li>
        <?php endif; ?>
    </ol>
</nav>
