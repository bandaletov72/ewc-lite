<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$positions = array_flip(array_column($block['columns'], 'key'));
$reviews = [];
$limit = isset($options['limit']) && ctype_digit($options['limit']) ? max(1, min(100, (int) $options['limit'])) : 30;
foreach ($block['rows'] as $row) {
    if (($row[$positions['published'] ?? -1] ?? '') !== '1') continue;
    $author = trim($row[$positions['author'] ?? -1] ?? '');
    $text = trim($row[$positions['text'] ?? -1] ?? '');
    if ($author === '' || $text === '') continue;
    $rating = $row[$positions['rating'] ?? -1] ?? '';
    $reviews[] = [$author, $text, preg_match('/\A[1-5]\z/', $rating) ? (int) $rating : 0];
    if (count($reviews) >= $limit) break;
}
if (!$reviews) return;
?>
<ul class="customer-reviews">
    <?php foreach ($reviews as list($author, $text, $rating)): ?>
        <li class="customer-review">
            <figure>
                <?php if ($rating): ?><span class="customer-rating" role="img" aria-label="<?= $rating ?> / 5"><?= str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) ?></span><?php endif; ?>
                <blockquote><?= nl2br(site_escape($text)) ?></blockquote>
                <figcaption><?= site_escape($author) ?></figcaption>
            </figure>
        </li>
    <?php endforeach; ?>
</ul>
