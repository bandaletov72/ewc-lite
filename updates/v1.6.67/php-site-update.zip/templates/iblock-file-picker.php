<?php if (!defined('SITE_ROOT')) exit; ?>
<?php
$filePickerTexts = require SITE_ROOT . '/app/help-iblock-file-picker.php';
$filePickerText = $filePickerTexts[$filePickerLanguage] ?? $filePickerTexts['ru'];
$selectedFile = $filePickerSelected ?? '';
$showFileOptions = $filePickerMode === 'insert';
?>
<div class="field iblock-file-picker" data-iblock-file-picker data-iblock-file-url="<?= site_escape(site_url($base, 'admin/')) ?>"
    data-iblock-file-csrf="<?= site_escape($filePickerCsrf) ?>" data-iblock-file-created="<?= site_escape($filePickerText[4]) ?>"
    data-iblock-file-error="<?= site_escape(site_translation('Не удалось выполнить действие.', $filePickerLanguage)) ?>"
    <?= $showFileOptions ? 'data-editor-show="table charts iblock"' : '' ?>>
    <label class="field"><?= site_escape($filePickerTitle) ?>
        <span class="iblock-file-control">
            <code aria-hidden="true">/data/</code>
            <select data-iblock-file-select="<?= $filePickerMode ?>" <?= $showFileOptions ? 'data-editor-param="iblock-data"' : 'data-inline-field="path"' ?>>
                <?php if (!isset($filePickerOptions[$selectedFile])): ?>
                    <option value="<?= site_escape($selectedFile) ?>" selected><?= site_escape($selectedFile === '' ? '—' : basename($selectedFile)) ?></option>
                <?php endif; ?>
                <?php foreach ($filePickerOptions as $value => $columns): ?>
                    <option value="<?= site_escape($value) ?>"<?= $value === $selectedFile ? ' selected' : '' ?>
                        <?= $showFileOptions ? 'data-columns="' . site_escape(json_encode($columns, JSON_INVALID_UTF8_SUBSTITUTE) ?: '[]') . '"' : '' ?>>
                        <?= site_escape($showFileOptions ? $value . '.txt' : basename($value)) ?>
                    </option>
                <?php endforeach; ?>
                <option value=":new:">＋ <?= site_escape($filePickerText[0]) ?></option>
            </select>
        </span>
    </label>
    <div class="header-actions" data-iblock-file-new hidden>
        <label class="field"><?= site_escape($filePickerText[1]) ?>
            <span class="iblock-file-control">
                <code aria-hidden="true">/data/</code>
                <input data-iblock-file-name maxlength="68" placeholder="my-data" pattern="[A-Za-z0-9_\x2D]{1,64}(\.txt)?" disabled>
            </span>
        </label>
        <button type="button" data-iblock-file-create><?= site_escape($filePickerText[2]) ?></button>
    </div>
    <details class="iblock-file-help">
        <summary title="<?= site_escape($filePickerText[5]) ?>" aria-label="<?= site_escape($filePickerText[5]) ?>">?</summary>
        <small class="hint"><?= site_escape($filePickerText[3]) ?></small>
    </details>
    <p class="hint" data-iblock-file-status role="status" hidden></p>
</div>
