<?php
if (!defined('SITE_ROOT')) exit;

const ADMIN_EDITOR_HISTORY_LIMIT = 10;

function admin_handle_editor_history(array $input): void
{
    header('Cache-Control: private, no-store');
    $key = admin_input($input, 'key');
    $request = admin_input($input, 'request');
    $operation = admin_input($input, 'operation');
    $field = admin_input($input, 'field');
    $draft = json_decode(admin_input($input, 'draft'), true, 4);
    $current = $draft['current'] ?? null;
    $pending = $draft['pending'] ?? [];
    $error = ['message' => 'Не удалось выполнить действие.'];
    if (!preg_match('/\A[a-f0-9]{32}\z/', $key) || !preg_match('/\A[1-9][0-9]{0,8}\z/', $request)
        || !in_array($operation, ['undo', 'redo', 'restore'], true) || !in_array($field, ['html', 'announcement'], true)
        || !is_array($pending) || count($pending) > ADMIN_EDITOR_HISTORY_LIMIT) {
        admin_json(400, $error);
    }
    foreach (array_merge($pending, [$current]) as $source) {
        if (!is_string($source) || strlen($source) > SITE_PAGE_LIMIT || preg_match('//u', $source) !== 1 || strpos($source, "\0") !== false) {
            admin_json(400, $error);
        }
    }

    $sessionKey = hash('sha256', site_content_root() . ':' . $field . ':' . $key);
    $histories = $_SESSION['editor_history'] ?? [];
    $history = $histories[$sessionKey] ?? ['undo' => [], 'redo' => [], 'request' => '', 'source' => ''];
    if ($history['request'] === $request) {
        admin_json(200, ['source' => $history['source'], 'undo' => count($history['undo']), 'redo' => count($history['redo'])]);
    }
    if ($pending) {
        $history['undo'] = array_slice(array_merge($history['undo'], array_values($pending)), -ADMIN_EDITOR_HISTORY_LIMIT);
        $history['redo'] = [];
    }
    $source = $current;
    if ($operation === 'restore') {
        $path = admin_page_path(admin_input($input, 'path'));
        $page = site_valid_path($path) ? site_read_page($path) : null;
        if ($page === null) admin_json(404, $error);
        $source = $field === 'html' ? $page['html'] : (site_asset_decode($page['fields']['Announcement'] ?? '') ?? '');
        $source = str_replace(["\r\n", "\r"], "\n", $source);
        if ($source !== $current) {
            $history['undo'] = array_slice(array_merge($history['undo'], [$current]), -ADMIN_EDITOR_HISTORY_LIMIT);
            $history['redo'] = [];
        }
    } elseif ($history[$operation]) {
        $source = array_pop($history[$operation]);
        $history[$operation === 'undo' ? 'redo' : 'undo'][] = $current;
    }

    $history['source'] = $source;
    $history['request'] = $request;
    unset($histories[$sessionKey]);
    $histories[$sessionKey] = $history;
    $_SESSION['editor_history'] = array_slice($histories, -6, null, true);
    session_write_close();
    admin_json(200, ['source' => $source, 'undo' => count($history['undo']), 'redo' => count($history['redo'])]);
}
