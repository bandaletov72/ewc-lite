<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$requesting = $recoveryMode === 'forgot';
$resetting = $recoveryMode === 'reset';
$record = $auth[$resetting ? 'password_reset' : 'email_pending'] ?? null;
$valid = $requesting || admin_recovery_token_valid($record, $recoveryToken);
$formUrl = $requesting ? $forgotUrl : $adminUrl . '?' . $recoveryMode . '=' . rawurlencode($recoveryToken);
?>
<section class="panel login-panel">
    <h1><?= site_escape($recoveryLabels[$requesting ? 'forgot-title' : ($resetting ? 'reset-title' : 'verify-title')]) ?></h1>
    <?php if ($recoveryNotice !== ''): ?>
        <p class="notice" role="status"><?= site_escape($recoveryLabels[$recoveryNotice]) ?></p>
    <?php endif; ?>
    <?php if (!$valid || $recoveryError !== '' || $error !== ''): ?>
        <p class="notice error" role="alert"><?= !$valid ? site_escape($recoveryLabels['invalid-link'])
            : ($recoveryError !== '' ? site_escape($recoveryError) : admin_l($error)) ?></p>
    <?php endif; ?>
    <?php if ($valid): ?>
        <form method="post" action="<?= site_escape($formUrl) ?>" class="form-stack">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="action" value="<?= $requesting ? 'forgot-password' : 'complete-recovery' ?>">
            <?php if ($requesting): ?>
                <label class="field">
                    <?= site_escape($recoveryLabels['email']) ?>
                    <input type="email" name="email" autocomplete="email" maxlength="254" required>
                </label>
            <?php elseif ($resetting): ?>
                <label class="field">
                    <?= site_escape($recoveryLabels['reset-title']) ?>
                    <input type="password" name="password" autocomplete="new-password" minlength="8" required>
                    <small class="hint"><?= admin_l('От 8 символов, не более 72 байт.') ?></small>
                </label>
                <label class="field">
                    <?= admin_l('Повторите пароль') ?>
                    <input type="password" name="confirmation" autocomplete="new-password" minlength="8" required>
                </label>
            <?php endif; ?>
            <div><button class="button-primary" type="submit"><?= site_escape($recoveryLabels[$requesting ? 'send-link' : ($resetting ? 'save-password' : 'verify-title')]) ?></button></div>
        </form>
    <?php elseif ($resetting): ?>
        <p><a href="<?= site_escape($forgotUrl) ?>"><?= site_escape($recoveryLabels['send-link']) ?></a></p>
    <?php endif; ?>
    <p><a href="<?= site_escape($adminUrl) ?>"><?= admin_l('Вход в админку') ?></a></p>
    <?php if ($requesting): ?>
        <p><a href="<?= site_escape($ftpResetUrl) ?>" download><?= site_escape($recoveryLabels['ftp-download']) ?></a></p>
    <?php endif; ?>
</section>
