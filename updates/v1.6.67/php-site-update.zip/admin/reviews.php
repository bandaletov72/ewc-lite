<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

function admin_review_action(string $action, array $input, string $locale)
{
    $labels = site_review_labels($locale);
    $lock = admin_lock();
    try {
        if ($action === 'reviews-settings') {
            $value = trim(admin_input($input, 'review_page'));
            $page = '';
            if ($value !== '') {
                $candidate = site_theme_request_path('', $value);
                if (!site_valid_path($candidate) || site_read_page($candidate) === null) {
                    throw new RuntimeException($labels[15]);
                }
                $page = site_page_translation($candidate)[0];
            }
            admin_write_record(site_content_record(SITE_REVIEWS_SETTINGS), ['page' => $page]);
            return;
        }
        $id = admin_input($input, 'review_id');
        $row = site_review_read($id);
        if (!$row || !hash_equals(hash('sha256', serialize($row)), admin_input($input, 'revision'))) {
            throw new RuntimeException($labels[16]);
        }
        $file = SITE_REVIEW_PREFIX . $id . '.php';
        if ($action === 'review-delete') {
            if (admin_input($input, 'confirm_delete') !== '1') throw new RuntimeException($labels[14]);
            if (!@unlink($file)) throw new RuntimeException($labels[16]);
            return;
        }
        if ($action === 'review-edit') {
            $result = site_validate_message(site_review_form($locale), $input);
            if ($result['errors']) throw new RuntimeException($labels[17]);
            foreach ($result['fields'] as $field => $value) $row[$field] = $value['value'];
        } else {
            $row['status'] = $action === 'review-approve' ? 'approved' : 'rejected';
        }
        admin_write_record($file, $row);
    } finally {
        fclose($lock);
    }
}
