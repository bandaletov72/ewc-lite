<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_page_custom_labels(): array
{
    static $labels;
    $labels = $labels ?? (require SITE_ROOT . '/app/help-page-custom-fields.php');
    return $labels[$GLOBALS['adminLanguage'] ?? 'ru'] ?? $labels['ru'];
}

function admin_page_custom_add_url(string $base, bool $newTab): string
{
    return ($newTab ? site_url($base, 'admin/?page=%2F') : '') . '#page-custom-definitions';
}

function admin_save_page_custom_definitions(array $input)
{
    $labels = admin_page_custom_labels();
    $rows = $input['custom_definitions'] ?? null;
    if (!is_array($rows) || count($rows) > SITE_PAGE_CUSTOM_FIELD_COUNT + 1) throw new RuntimeException($labels[5]);
    $newValue = $input['new_custom_value'] ?? '';
    if (!is_string($newValue)) throw new RuntimeException($labels[6]);
    $lock = admin_lock();
    try {
        $current = site_page_custom_definitions(true);
        if (!hash_equals(admin_settings_revision($current), admin_input($input, 'schema_revision'))) {
            throw new RuntimeException($labels[7]);
        }
        $schema = [];
        $newKey = null;
        $removed = [];
        $used = array_fill_keys(site_page_reserved_field_ids(), true);
        $types = site_iblock_types(false);
        foreach ($rows as $key => $row) {
            if (!is_array($row) || ($key !== 'new' && !isset($current[$key]))) throw new RuntimeException($labels[5]);
            if ($key !== 'new' && admin_input($row, 'delete') === '1') {
                $removed[$key] = true;
                continue;
            }
            $id = trim(admin_input($row, 'id'));
            $description = trim(admin_input($row, 'description'));
            $type = admin_input($row, 'type');
            if ($key === 'new' && $type !== 'textarea') $newValue = trim($newValue);
            if ($key === 'new' && $id === '' && $description === '' && $newValue === '') continue;
            if (!preg_match('/\A' . SITE_IDENTIFIER_PATTERN . '\z/', $id) || isset($used[strtolower($id)])) {
                throw new RuntimeException($labels[5] . ' ' . $id);
            }
            if (!isset($types[$type]) || strlen($description) > 1500 || preg_match('//u', $description) !== 1
                || preg_match('/[\x00-\x1F\x7F]/', $description)) {
                throw new RuntimeException($labels[6] . ' ' . $id);
            }
            $used[strtolower($id)] = true;
            if ($key === 'new') {
                $newKey = $key = 'f-' . bin2hex(random_bytes(8));
            }
            $schema[$key] = ['id' => $id, 'description' => $description, 'type' => $type];
        }
        if (count($schema) > SITE_PAGE_CUSTOM_FIELD_COUNT || array_diff_key($current, $schema, $removed)) throw new RuntimeException($labels[5]);
        if ($newValue === '') {
            admin_write_record(SITE_PAGE_CUSTOM_SCHEMA, $schema, SITE_PAGE_CUSTOM_SCHEMA_LIMIT);
            return;
        }
        if ($newKey === null || !admin_validate_cell($newValue, $schema[$newKey]['type'])) {
            throw new RuntimeException($labels[6] . ($newKey === null ? '' : ' ' . $schema[$newKey]['id']));
        }
        $path = admin_input($input, 'path');
        $revision = admin_input($input, 'page_revision');
        $page = admin_current_page($path, $revision);
        $file = site_content_root() . '/' . $path;
        $previous = @file_get_contents($file);
        if ($previous === false || !hash_equals(hash('sha256', $previous), $revision)) {
            throw new RuntimeException('Файл изменился с момента открытия. Скопируйте правки и откройте страницу заново.');
        }
        $values = array_intersect_key(site_decode_page_custom_values($page['fields']['CustomFields']) ?? [], $schema);
        $values[$newKey] = $newValue;
        $page['fields']['CustomFields'] = admin_pack_page_custom_values($values);
        $bytes = admin_page_bytes($path, $page['fields'], $page['html']);
        if (!admin_replace_file($file, $bytes)) {
            throw new RuntimeException('Не удалось сохранить файл. Проверьте права записи в каталоге страницы.');
        }
        try {
            admin_write_record(SITE_PAGE_CUSTOM_SCHEMA, $schema, SITE_PAGE_CUSTOM_SCHEMA_LIMIT);
        } catch (RuntimeException $error) {
            if (!admin_replace_file($file, $previous)) {
                throw new RuntimeException('Не удалось сохранить файл. Проверьте права записи в каталоге страницы.', 0, $error);
            }
            throw $error;
        }
    } finally {
        fclose($lock);
    }
}

function admin_encode_page_custom_values(array $input, array $previous): string
{
    $labels = admin_page_custom_labels();
    $schema = site_page_custom_definitions(true);
    if (!hash_equals(admin_settings_revision($schema), admin_input($input, 'custom_schema_revision'))) {
        throw new RuntimeException($labels[7]);
    }
    $values = array_intersect_key(site_decode_page_custom_values($previous['CustomFields'] ?? '') ?? [], $schema);
    $submitted = $input['custom_values'] ?? [];
    if (!is_array($submitted) || array_diff_key($schema, $submitted) || array_diff_key($submitted, $schema)) {
        throw new RuntimeException($labels[7]);
    }
    foreach ($schema as $key => $field) {
        if (!is_string($submitted[$key])) throw new RuntimeException($labels[6] . ' ' . $field['id']);
        $value = $field['type'] === 'textarea' ? $submitted[$key] : trim($submitted[$key]);
        if (($values[$key] ?? '') !== $value && !admin_validate_cell($value, $field['type'])) {
            throw new RuntimeException($labels[6] . ' ' . $field['id']);
        }
        if ($value === '') unset($values[$key]);
        else $values[$key] = $value;
    }
    return admin_pack_page_custom_values($values);
}

function admin_pack_page_custom_values(array $values): string
{
    if (!$values) return '';
    $json = json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false || strlen($json) > SITE_ASSET_LIMIT) throw new RuntimeException(admin_page_custom_labels()[6]);
    return base64_encode($json);
}
