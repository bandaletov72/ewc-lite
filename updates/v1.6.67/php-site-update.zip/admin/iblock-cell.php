<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$value = $row[$index] ?? '';
$type = $column['type'];
$attributes = 'name="rows[' . $rowIndex . '][' . $index . ']" aria-label="' . site_escape($column['label']) . '"';
?>
<td data-cell-column="<?= $index ?>">
    <?php if ($type === 'textarea'): ?>
        <textarea rows="3" data-cell-type="textarea" <?= $attributes ?>><?= "\n" . site_escape($value) ?></textarea>
    <?php elseif ($type === 'form'): ?>
        <select data-cell-type="form" <?= $attributes ?>>
            <option value="">—</option>
            <?php if ($value !== '' && !isset($iblockFormOptions[$value])): ?>
                <option value="<?= site_escape($value) ?>" selected><?= site_escape($value) ?></option>
            <?php endif; ?>
            <?php foreach ($iblockFormOptions as $id => $name): ?>
                <option value="<?= site_escape($id) ?>"<?= $id === $value ? ' selected' : '' ?>><?= site_escape($name . ' [' . $id . ']') ?></option>
            <?php endforeach; ?>
        </select>
    <?php elseif ($type === 'bool'): ?>
        <select data-cell-type="bool" <?= $attributes ?>>
            <option value="">—</option>
            <option value="1"<?= $value === '1' ? ' selected' : '' ?>><?= admin_l('Да') ?></option>
            <option value="0"<?= $value === '0' ? ' selected' : '' ?>><?= admin_l('Нет') ?></option>
        </select>
    <?php else: ?>
        <?php
        $inputType = in_array($type, ['date', 'number', 'tel', 'email', 'url'], true) ? $type : 'text';
        if ($type === 'number') {
            $value = str_replace(',', '.', $value);
        }
        ?>
        <input type="<?= $inputType ?>" data-cell-type="<?= site_escape($type) ?>" value="<?= site_escape($value) ?>" <?= $attributes ?>
            <?= $type === 'number' ? 'step="any"' : '' ?> <?= $type === 'price' ? 'inputmode="decimal" pattern="[0-9]{1,15}([.,][0-9]{1,2})?"' : '' ?>>
    <?php endif; ?>
</td>
