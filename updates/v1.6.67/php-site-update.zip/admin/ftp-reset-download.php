<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?><!doctype html>
<html lang="ru">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Одноразовый код EWC для FTP</title>
<style>
  :root { color-scheme: light dark; font: 16px/1.5 system-ui, sans-serif; }
  body { margin: 0; padding: 2rem 1rem; }
  main { max-width: 38rem; margin: auto; }
  h1 { font-size: clamp(1.55rem, 5vw, 2.15rem); line-height: 1.15; }
  button, input { font: inherit; padding: .55rem .75rem; border-radius: .4rem; }
  button { cursor: pointer; }
  label { display: block; margin-top: 1rem; }
  input { display: block; width: 100%; max-width: 25rem; box-sizing: border-box; font-family: monospace; }
  a { display: inline-block; margin-top: .8rem; }
  li { margin: .55rem 0; }
</style>
<main>
  <h1>Одноразовый код EWC для FTP</h1>
  <p>Создайте код для установки или восстановления доступа. Код и ZIP создаются на вашем компьютере.</p>
  <button type="button" id="generate">Создать код сброса</button>
  <div id="result" hidden>
    <label for="code">Одноразовый код для мастера установки</label>
    <input id="code" readonly spellcheck="false" autocomplete="off">
    <a id="download" download="ewc-access.zip">Скачать ZIP с файлом .access.php</a>
  </div>
  <p id="status" role="status"></p>
  <ol>
    <li>Распакуйте ZIP. Внутри лежит <code>.access.php</code>. Если файл скрыт, включите показ скрытых файлов.</li>
    <li>Через FTP загрузите его в папку <code>admin</code> вашего сайта. Если там уже есть <code>.access.php</code>, сначала скачайте его резервную копию на компьютер. Для кода нужен файл <code>.access.php</code> с точкой в начале.</li>
    <li>Откройте <code>/admin/</code> на своём сайте и введите код, логин и новый пароль. На следующем шаге нажмите «Продолжить с текущими настройками».</li>
  </ol>
</main>
<script>
  const generate = document.querySelector('#generate');
  const result = document.querySelector('#result');
  const download = document.querySelector('#download');
  const codeField = document.querySelector('#code');
  const statusMessage = document.querySelector('#status');
  const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  let downloadUrl;

  function zipAccessFile(content) {
    const encoder = new TextEncoder();
    const name = encoder.encode('.access.php');
    const payload = encoder.encode(content);
    let crc = -1;
    for (const byte of payload) {
      crc ^= byte;
      for (let bit = 0; bit < 8; bit++) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
      }
    }
    const checksum = (crc ^ -1) >>> 0;
    // A ZIP with one stored file has a local header, a central entry and an end record.
    const localSize = 30;
    const centralSize = 46 + name.length;
    const central = localSize + name.length + payload.length;
    const end = central + centralSize;
    const bytes = new Uint8Array(end + 22);
    const view = new DataView(bytes.buffer);
    const word = (offset, value) => view.setUint16(offset, value, true);
    const dword = (offset, value) => view.setUint32(offset, value, true);
    dword(0, 0x04034b50);
    word(4, 20);
    word(12, 33);
    dword(14, checksum);
    dword(18, payload.length);
    dword(22, payload.length);
    word(26, name.length);
    bytes.set(name, localSize);
    bytes.set(payload, localSize + name.length);

    dword(central, 0x02014b50);
    word(central + 4, 20);
    word(central + 6, 20);
    word(central + 14, 33);
    dword(central + 16, checksum);
    dword(central + 20, payload.length);
    dword(central + 24, payload.length);
    word(central + 28, name.length);
    bytes.set(name, central + 46);

    dword(end, 0x06054b50);
    word(end + 8, 1);
    word(end + 10, 1);
    dword(end + 12, centralSize);
    dword(end + 16, central);
    return new Blob([bytes], {type: 'application/zip'});
  }

  generate.addEventListener('click', async () => {
    generate.disabled = true;
    statusMessage.textContent = '';
    try {
      const code = hex(crypto.getRandomValues(new Uint8Array(16)));
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(code));
      const header = '<' + '?php http_response_code(404); exit; __halt_compiler();\n';
      const content = header + JSON.stringify({setup: hex(new Uint8Array(digest))}) + '\n';
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
      downloadUrl = URL.createObjectURL(zipAccessFile(content));
      download.href = downloadUrl;
      codeField.value = code;
      result.hidden = false;
      codeField.select();
    } catch {
      statusMessage.textContent = 'Откройте скачанный HTML-файл напрямую в Chrome, Edge или Firefox и повторите попытку.';
    } finally {
      generate.disabled = false;
    }
  });
</script>
</html>
