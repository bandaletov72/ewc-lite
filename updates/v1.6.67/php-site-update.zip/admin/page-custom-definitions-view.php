<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }
$canAddField = count($customDefs) < SITE_PAGE_CUSTOM_FIELD_COUNT;
$renderNewValue = static function (string $type, string $value) use ($customLabels): void {
    $attributes = 'name="new_custom_value" data-new-custom-value aria-label="' . site_escape($customLabels[15]) . '"';
    if ($type === 'textarea'): ?>
        <textarea rows="3" maxlength="12000" <?= $attributes ?>><?= "\n" . site_escape($value) ?></textarea>
    <?php elseif ($type === 'bool' && admin_validate_cell($value, $type)): ?>
        <select <?= $attributes ?>>
            <option value="">—</option>
            <option value="1"<?= $value === '1' ? ' selected' : '' ?>><?= admin_l('Да') ?></option>
            <option value="0"<?= $value === '0' ? ' selected' : '' ?>><?= admin_l('Нет') ?></option>
        </select>
    <?php else:
        $numeric = in_array($type, ['number', 'price'], true);
        $typed = admin_validate_cell($value, $type);
        $inputType = $typed && $numeric ? 'number' : ($typed && in_array($type, ['date', 'tel', 'email', 'url'], true) ? $type : 'text');
        $constraints = $inputType === 'number' ? ($type === 'price' ? ' min="0" step="0.01"' : ' step="any"') : '';
        if ($inputType === 'number') $value = str_replace(',', '.', ltrim($value, '+'));
        ?>
        <input type="<?= $inputType ?>" <?= $attributes ?><?= $constraints ?> value="<?= site_escape($value) ?>">
    <?php endif;
};
?>
<details class="page-code" id="page-custom-definitions" data-page-tab-panel="custom-fields"<?= ($error !== '' && admin_input($_POST, 'action') === 'save-page-custom-definitions') ? ' open' : '' ?>>
    <summary><?= site_escape($customLabels[2]) ?></summary>
    <form class="form-stack" method="post" data-custom-field-definitions
        data-confirm-removal="<?= site_escape($customLabels[14]) ?>"
        action="<?= site_escape(($embeddedEditorUrl ?: admin_page_edit_url($adminUrl, $page['path'])) . '#page-custom-fields') ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="action" value="save-page-custom-definitions">
        <input type="hidden" name="path" value="<?= site_escape($page['path']) ?>">
        <input type="hidden" name="schema_revision" value="<?= site_escape(admin_settings_revision($customDefs)) ?>">
        <input type="hidden" name="page_revision" value="<?= site_escape($page['revision']) ?>">
        <p class="hint"><?= site_escape($customLabels[4]) ?></p>
        <details><summary><?= site_escape($customLabels[3]) ?></summary><p class="hint"><code><?= site_escape(implode(', ', site_page_reserved_field_ids())) ?></code></p></details>
        <div class="iblock-table-wrap">
            <table class="iblock-table iblock-editor-table">
                <thead><tr>
                    <th scope="col">ID</th><th scope="col"><?= site_escape($customLabels[1]) ?></th><th scope="col"><?= admin_l('Тип') ?></th>
                    <?php if ($canAddField): ?><th scope="col"><?= site_escape($customLabels[15]) ?></th><?php endif; ?>
                    <?php if ($customDefs): ?><th scope="col"><?= admin_l('Действия') ?></th><?php endif; ?>
                </tr></thead>
                <tbody>
                <?php foreach ($customDefs + ['new' => ['id' => '', 'description' => '', 'type' => 'text']] as $key => $field): ?>
                    <?php
                    if ($key === 'new' && !$canAddField) continue;
                    $draft = $_POST['custom_definitions'][$key] ?? null;
                    $marked = $error !== '' && $key !== 'new' && is_array($draft) && admin_input($draft, 'delete') === '1';
                    if ($error !== '' && is_array($draft)) {
                        foreach (array_keys($field) as $part) {
                            if (isset($draft[$part])) $field[$part] = admin_input($draft, $part);
                        }
                    }
                    $prefix = 'custom_definitions[' . site_escape($key) . ']';
                    ?>
                    <tr>
                        <td><input name="<?= $prefix ?>[id]" value="<?= site_escape($field['id']) ?>" aria-label="ID"
                            pattern="[A-Za-z0-9_\x2D]{1,64}" maxlength="64"<?= $key === 'new' ? ' placeholder="event-id" data-new-custom-definition' : ' required' ?>></td>
                        <td><input name="<?= $prefix ?>[description]" value="<?= site_escape($field['description']) ?>"
                            aria-label="<?= site_escape($customLabels[1]) ?>" maxlength="375"></td>
                        <td><select name="<?= $prefix ?>[type]" aria-label="<?= admin_l('Тип') ?>"<?= $key === 'new' ? ' data-new-custom-type' : '' ?>>
                            <?php foreach (site_iblock_types(false) as $type => $label): ?>
                                <option value="<?= $type ?>"<?= $field['type'] === $type ? ' selected' : '' ?>><?= admin_l($label) ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <?php if ($canAddField): ?>
                            <td>
                                <?php if ($key === 'new'): ?>
                                    <?php $renderNewValue($field['type'], $error !== '' ? admin_input($_POST, 'new_custom_value') : ''); ?>
                                    <?php foreach (array_keys(site_iblock_types(false)) as $valueType): ?>
                                        <template data-custom-value-type="<?= $valueType ?>"><?php $renderNewValue($valueType, ''); ?></template>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <?php if ($customDefs): ?>
                            <td>
                                <?php if ($key !== 'new'): ?>
                                    <label class="choice"><input type="checkbox" name="<?= $prefix ?>[delete]" value="1"
                                        data-custom-field-delete<?= $marked ? ' checked' : '' ?>> <?= admin_l('Удалить') ?></label>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div><button class="button-primary"><?= site_escape($customLabels[9]) ?></button></div>
    </form>
</details>
