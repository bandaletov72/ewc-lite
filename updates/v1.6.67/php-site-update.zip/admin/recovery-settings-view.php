<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$verifiedContact = $auth['email_verified'] ?? [];
$pendingContact = $auth['email_pending'] ?? [];
$contact = $recoveryDraft ?: ($pendingContact ?: $verifiedContact);
?>
<section class="panel form-stack" id="recovery-email">
    <h2><?= site_escape($recoveryLabels['email']) ?></h2>
    <?php if ($recoveryNotice !== '' || $recoveryError !== ''): ?>
        <p class="notice<?= $recoveryError !== '' ? ' error' : '' ?>" role="<?= $recoveryError !== '' ? 'alert' : 'status' ?>"><?= site_escape($recoveryError !== '' ? $recoveryError : $recoveryLabels[$recoveryNotice]) ?></p>
    <?php endif; ?>
    <?php if ($verifiedContact): ?>
        <p><?= site_escape($recoveryLabels['email-confirmed']) ?> <strong><?= site_escape($verifiedContact['email']) ?></strong></p>
    <?php endif; ?>
    <?php if ($pendingContact): ?>
        <p class="hint"><?= site_escape($recoveryLabels['email-pending']) ?> <strong><?= site_escape($pendingContact['email']) ?></strong></p>
    <?php endif; ?>
    <form class="form-stack" method="post" action="<?= site_escape($settingsUrl . '#recovery-email') ?>">
        <input type="hidden" name="action" value="save-recovery-email">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <label class="field">
            <?= site_escape($recoveryLabels['email']) ?>
            <input type="email" name="email" value="<?= site_escape($contact['email'] ?? '') ?>" maxlength="254" autocomplete="email" required>
        </label>
        <label class="field">
            <?= site_escape($recoveryLabels['url']) ?>
            <input type="url" name="recovery_url" value="<?= site_escape($contact['url'] ?? $settingsDraft['publicUrl']) ?>" maxlength="2048" required>
            <small class="hint"><?= site_escape($recoveryLabels['url-hint']) ?></small>
        </label>
        <label class="field">
            <?= site_escape($recoveryLabels['current-password']) ?>
            <input type="password" name="current_password" autocomplete="current-password" required>
        </label>
        <div><button class="button-primary" type="submit"><?= site_escape($recoveryLabels['send-confirmation']) ?></button></div>
    </form>
</section>
