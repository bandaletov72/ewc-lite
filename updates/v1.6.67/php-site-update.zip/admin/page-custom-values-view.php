<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<section class="form-stack field-wide" id="page-custom-fields" data-page-tab-panel="custom-fields">
    <div class="header-actions page-custom-heading">
        <h3><?= site_escape($customLabels[0]) ?></h3>
        <?php if (count($customDefs) < SITE_PAGE_CUSTOM_FIELD_COUNT): ?>
            <a class="button button-primary" href="<?= site_escape(admin_page_custom_add_url($base, $creating)) ?>"
                <?= $creating ? 'target="_blank" rel="noopener"' : '' ?>><i class="fa-solid fa-plus" aria-hidden="true"></i> <?= admin_l('Добавить поле') ?></a>
        <?php endif; ?>
    </div>
    <?php if (!$customDefs): ?><p><?= site_escape($customLabels[13]) ?></p><?php endif; ?>
    <p class="hint"><?= site_escape($customLabels[8]) ?></p>
    <input type="hidden" name="custom_schema_revision" value="<?= site_escape(admin_settings_revision($customDefs)) ?>">
    <?php if ($customDefs): ?>
        <?php $customValues = $page['customDraft'] ?? site_decode_page_custom_values($page['fields']['CustomFields'] ?? '') ?? []; ?>
        <div class="iblock-table-wrap">
            <table class="iblock-table iblock-editor-table">
                <thead><tr>
                    <th scope="col">ID</th><th scope="col"><?= site_escape($customLabels[1]) ?></th>
                    <th scope="col"><?= admin_l('Тип') ?></th><th scope="col"><?= admin_l('Значение') ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ($customDefs as $key => $custom): ?>
                    <?php
                    $value = admin_input($customValues, $key);
                    $type = $custom['type'];
                    $valid = admin_validate_cell($value, $type);
                    $attributes = 'name="custom_values[' . site_escape($key) . ']" aria-label="' . site_escape($custom['id']) . '"';
                    ?>
                    <tr>
                        <td><code>[u-<?= site_escape($custom['id']) ?>]</code></td>
                        <td><?= site_escape($custom['description']) ?></td>
                        <td><?= admin_l(site_iblock_types(false)[$type] ?? 'Текст') ?></td>
                        <td>
                            <?php if ($type === 'textarea'): ?>
                                <textarea rows="3" <?= $attributes ?>><?= "\n" . site_escape($value) ?></textarea>
                            <?php elseif ($valid && $type === 'bool'): ?>
                                <select <?= $attributes ?>>
                                    <option value="">—</option>
                                    <option value="1"<?= $value === '1' ? ' selected' : '' ?>><?= admin_l('Да') ?></option>
                                    <option value="0"<?= $value === '0' ? ' selected' : '' ?>><?= admin_l('Нет') ?></option>
                                </select>
                            <?php else: ?>
                                <?php $inputType = $valid && in_array($type, ['date', 'tel', 'email', 'url'], true) ? $type : 'text'; ?>
                                <input type="<?= $inputType ?>" <?= $attributes ?> value="<?= site_escape($value) ?>"
                                    <?= in_array($type, ['price', 'number'], true) ? 'inputmode="decimal"' : '' ?>>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
