<?php if (!defined('SITE_ROOT')) exit; ?>
<label class="field"><?= site_escape($iconFilterLabels[0]) ?>
    <input type="search" data-editor-icon-filter placeholder="home, phone, star" autocomplete="off" spellcheck="false">
</label>
<template data-editor-icon-catalog>
    <?php foreach ($iconTokens as $key): ?>
        <span data-code="<?= site_escape('[' . $key . ']') ?>" data-name="<?= site_escape($key) ?>" data-inline-only></span>
    <?php endforeach; ?>
    <?php foreach (site_page_system_icons() as $file): ?>
        <span data-code="<?= site_escape('[site-icon=' . $file . ']') ?>" data-name="<?= site_escape($file) ?>"
            data-image="<?= site_escape(site_url($base, 'templates/icons/' . $file)) ?>"></span>
    <?php endforeach; ?>
    <?php if ($canInsertFA): ?>
        <?php foreach (site_font_awesome_icons() as $style => $names): ?>
            <?php foreach ($names as $name): ?>
                <span data-fa="<?= site_escape($style . ':' . $name) ?>"></span>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endif; ?>
</template>
<p class="hint" data-editor-icon-empty role="status" hidden><?= site_escape($iconFilterLabels[1]) ?></p>
<?php if ($iconTokens !== []): ?>
    <div class="editor-icon-shortcodes" data-editor-icon-shortcodes hidden>
        <p class="hint"><?= admin_l('Подшаблоны') ?></p>
        <div data-editor-icon-token-results></div>
    </div>
<?php endif; ?>
<div class="editor-fa-grid" data-editor-icon-results></div>
<div><button type="button" data-editor-icon-more hidden><?= site_escape($iconFilterLabels[2]) ?></button></div>
