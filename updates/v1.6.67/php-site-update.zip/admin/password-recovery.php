<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_recovery_contact(string $email, string $url): array
{
    $parts = parse_url($url);
    if (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || preg_match('/[\x00-\x20\x7f,]/', $email)) {
        throw new InvalidArgumentException('invalid-email');
    }
    if (strlen($url) > 2048 || !filter_var($url, FILTER_VALIDATE_URL)
        || strcasecmp($parts['scheme'] ?? '', 'https') !== 0
        || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
        || strpos($url, '\\') !== false) {
        throw new InvalidArgumentException('invalid-url');
    }
    return ['email' => $email, 'url' => rtrim($url, '/') . '/'];
}

function admin_recovery_issue(int $lifetime): array
{
    $token = bin2hex(random_bytes(32));
    return [$token, ['hash' => hash('sha256', $token), 'expires' => time() + $lifetime]];
}

function admin_recovery_token_valid($record, string $token): bool
{
    return is_array($record) && ($record['expires'] ?? 0) > time()
        && is_string($record['hash'] ?? null) && preg_match('/\A[a-f0-9]{64}\z/', $token) === 1
        && hash_equals($record['hash'], hash('sha256', $token));
}

function admin_recovery_mail(array $contact, string $action, string $token, array $labels): bool
{
    $link = $contact['url'] . 'admin/?' . $action . '=' . $token;
    return function_exists('mail') && @mail(
        $contact['email'],
        site_mail_encode_subject($labels[$action === 'reset' ? 'reset-title' : 'verify-title'] . ' · ' . SITE_PRODUCT_NAME),
        quoted_printable_encode($labels[$action === 'reset' ? 'reset-mail' : 'verify-mail'] . "\r\n\r\n" . $link . "\r\n"),
        "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable"
    );
}

function admin_prepare_recovery_email(string $email, string $url): array
{
    $contact = admin_recovery_contact($email, $url);
    list($token, $record) = admin_recovery_issue(86400);
    return [$token, ['email_pending' => $contact + $record]];
}

function admin_change_recovery_email(array $auth, string $password, string $email, string $url, array $labels): bool
{
    if (strlen($password) > 72 || strpos($password, "\0") !== false || !password_verify($password, $auth['password'])) {
        usleep(300000);
        throw new InvalidArgumentException('invalid-password');
    }
    list($token, $pending) = admin_prepare_recovery_email($email, $url);
    $lock = admin_lock();
    try {
        $state = admin_auth_state();
        if (!isset($state['password']) || !hash_equals(admin_auth_key($auth), admin_auth_key($state))) {
            throw new InvalidArgumentException('invalid-password');
        }
        admin_write_record(ADMIN_ACCESS_FILE, $pending + $state);
    } finally {
        fclose($lock);
    }
    return admin_recovery_mail($pending['email_pending'], 'verify-email', $token, $labels);
}

function admin_request_password_reset(string $email, array $labels)
{
    if (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return;
    }
    $lock = admin_lock();
    try {
        $state = admin_auth_state();
        $contact = $state['email_verified'] ?? [];
        if (!isset($state['password'], $contact['email'], $contact['url'])
            || strcasecmp($email, $contact['email']) !== 0 || ($state['reset_sent_at'] ?? 0) > time() - 60) {
            return;
        }
        list($token, $state['password_reset']) = admin_recovery_issue(1800);
        $state['reset_sent_at'] = time();
        admin_write_record(ADMIN_ACCESS_FILE, $state);
    } finally {
        fclose($lock);
    }
    admin_recovery_mail($contact, 'reset', $token, $labels);
}

function admin_complete_recovery(string $action, string $token, string $password, string $confirmation)
{
    $lock = admin_lock();
    try {
        $state = admin_auth_state();
        $key = $action === 'reset' ? 'password_reset' : 'email_pending';
        if (!isset($state['password']) || !admin_recovery_token_valid($state[$key] ?? null, $token)) {
            throw new InvalidArgumentException('invalid-link');
        }
        if ($action === 'reset') {
            $state['password'] = admin_password_hash($password, $confirmation);
            unset($state['email_pending']);
        } else {
            $state['email_verified'] = ['email' => $state[$key]['email'], 'url' => $state[$key]['url']];
        }
        unset($state[$key], $state['password_reset'], $state['reset_sent_at']);
        admin_write_record(ADMIN_ACCESS_FILE, $state);
    } finally {
        fclose($lock);
    }
}
