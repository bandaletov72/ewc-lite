<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return 'bandaletov72/ewc-lite';
