<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$footerText = $settings['footer'];
if ($footerText === '') {
    $footerText = '© [year] ' . $settings['name'];
}
$footerText = site_expand_text(str_replace('[year]', date('Y'), $footerText), $snippets ?? []);
?>
<footer class="site-footer">
    <div class="container"><?= site_escape($footerText) ?></div>
</footer>
