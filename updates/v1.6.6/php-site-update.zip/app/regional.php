<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_REGIONAL_FILE = SITE_ROOT . '/admin/.regional.php';
const SITE_LANGUAGE_CODES = 'ru|en|uk|ja|vi|fr|de|es|pt|ko';

function site_languages(): array
{
    return ['ru' => 'Русский', 'en' => 'English', 'uk' => 'Українська', 'ja' => '日本語', 'vi' => 'Tiếng Việt',
        'fr' => 'Français', 'de' => 'Deutsch', 'es' => 'Español', 'pt' => 'Português', 'ko' => '한국어'];
}

function site_language_samples(): array
{
    return ['ru' => 'Съешь еще этих мягких французских булочек да выпей чаю', 'en' => 'The quick brown fox jumps over the lazy dog',
        'uk' => 'Ще не вмерла України і слава, і воля', 'ja' => 'こんにちは、世界', 'vi' => 'Xin chào, thế giới',
        'fr' => 'Portez ce vieux whisky au juge blond qui fume', 'de' => 'Franz jagt im komplett verwahrlosten Taxi quer durch Bayern',
        'es' => 'El veloz murciélago hindú comía feliz cardillo y kiwi', 'pt' => 'Olá, mundo! Como vai você?', 'ko' => '안녕하세요, 세계'];
}

function site_region_options(): array
{
    return [
        'currency' => ['RUB' => 'RUB ₽', 'USD' => 'USD $', 'EUR' => 'EUR €', 'UAH' => 'UAH ₴',
            'JPY' => 'JPY ¥', 'VND' => 'VND ₫', 'GBP' => 'GBP £', 'KZT' => 'KZT ₸', 'BYN' => 'BYN Br',
            'CNY' => 'CNY ¥', 'CHF' => 'CHF', 'KRW' => 'KRW ₩', 'BRL' => 'BRL R$', 'CAD' => 'CAD $'],
        'date' => ['d.m.Y' => '31.12.2026', 'Y-m-d' => '2026-12-31', 'd/m/Y' => '31/12/2026',
            'm/d/Y' => '12/31/2026', 'Y/m/d' => '2026/12/31'],
        'time' => ['H:i' => '23:15', 'H:i:s' => '23:15:00', 'g:i A' => '11:15 PM'],
        'group' => ['space' => '1 234', 'comma' => '1,234', 'dot' => '1.234', 'none' => '1234'],
        'decimal' => ['comma' => '12,50', 'dot' => '12.50'],
    ];
}

function site_region_settings(): array
{
    static $settings;
    if ($settings !== null) {
        return $settings;
    }
    $settings = ['languages' => ['ru'], 'interface' => 'ru', 'public' => 'ru', 'timezone' => 'auto',
        'currency' => 'RUB', 'date' => 'd.m.Y', 'time' => 'H:i', 'group' => 'space', 'decimal' => 'comma'];
    try {
        $record = site_read_record(SITE_REGIONAL_FILE);
    } catch (RuntimeException $exception) {
        return $settings;
    }
    $selected = is_array($record['languages'] ?? null) ? $record['languages'] : [];
    foreach (site_languages() as $code => $label) {
        if ($code !== 'ru' && in_array($code, $selected, true)) {
            $settings['languages'][] = $code;
        }
    }
    foreach (site_region_options() as $key => $options) {
        $value = $record[$key] ?? null;
        if (is_string($value) && isset($options[$value])) {
            $settings[$key] = $value;
        }
    }
    foreach (['interface', 'public'] as $key) {
        $language = $record[$key] ?? '';
        if (in_array($language, $settings['languages'], true)) {
            $settings[$key] = $language;
        }
    }
    $zone = $record['timezone'] ?? '';
    if (is_string($zone) && $zone !== '' && in_array($zone, site_time_zones(), true)) {
        $settings['timezone'] = $zone;
    }
    return $settings;
}

function site_time_zones(): array
{
    return array_values(array_unique(array_merge(['UTC', 'GMT'], DateTimeZone::listIdentifiers(),
        preg_grep('~\AEtc/GMT[+-][0-9]+\z~', DateTimeZone::listIdentifiers(DateTimeZone::ALL_WITH_BC)))));
}

function site_translations(string $language): array
{
    static $catalogs = [];
    if (!isset(site_languages()[$language])) {
        return [];
    }
    if (!isset($catalogs[$language])) {
        $file = SITE_ROOT . '/admin/languages/' . $language . '.php';
        $pack = SITE_ROOT . '/app/language-' . $language . '.php';
        $fallback = is_file($pack) ? require $pack : [];
        $local = is_file($file) ? require $file : [];
        $complete = __DIR__ . '/admin-i18n-' . $language . '.php';
        $complete = is_file($complete) ? require $complete : [];
        $catalogs[$language] = (is_array($local) ? $local : []) + (is_array($fallback) ? $fallback : [])
            + (is_array($complete) ? $complete : []);
    }
    return $catalogs[$language];
}

function site_translation(string $text, string $language): string
{
    $translation = site_translations($language)[$text] ?? null;
    return is_string($translation) && $translation !== '' ? $translation : $text;
}

function site_page_translation(string $path): array
{
    if (preg_match('~\A(.*/)?index_(' . SITE_LANGUAGE_CODES . ')\.php\z~', $path, $match)) {
        return [$match[1] . 'index.php', $match[2]];
    }
    return [$path, ''];
}

function site_language_page_path(string $path, string $language): string
{
    if (basename($path) !== 'index.php' || $language === 'ru') {
        return $path;
    }
    return substr($path, 0, -strlen('index.php')) . 'index_' . $language . '.php';
}

function site_public_language(string $base, string $explicit): string
{
    $enabled = site_region_settings()['languages'];
    $requested = $explicit !== '' ? $explicit : ($_GET['lang'] ?? '');
    if (in_array($requested, $enabled, true)) {
        $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        setcookie('FILE_SITE_LANG', $requested, time() + 31536000, site_url($base), '', $secure, true);
        return $requested;
    }
    $stored = $_COOKIE['FILE_SITE_LANG'] ?? '';
    return in_array($stored, $enabled, true) ? $stored : site_region_settings()['public'];
}

/** @return array|null */
function site_localized_page(string $basePath, string $language)
{
    $original = site_read_page($basePath);
    if ($original === null || $original['fields']['Hidden'] === '1') {
        return null;
    }
    $variant = site_language_page_path($basePath, $language);
    if ($variant !== $basePath) {
        $translated = site_read_page($variant);
        if ($translated !== null && $translated['fields']['Hidden'] !== '1') {
            return $translated + ['language' => $language];
        }
    }
    return $original + ['language' => 'ru'];
}

function site_format_price(string $value): string
{
    $currency = explode(' ', site_region_options()['currency'][site_region_settings()['currency']], 2);
    return site_format_number($value, 2) . "\u{00a0}" . ($currency[1] ?? $currency[0]);
}

function site_format_number(string $value, int $minimumDecimals = 0): string
{
    $settings = site_region_settings();
    $separators = ['space' => ' ', 'dot' => '.', 'comma' => ',', 'none' => ''];
    $negative = $value[0] === '-' ? '-' : '';
    $digits = explode('.', str_replace(',', '.', ltrim($value, '+-')), 2);
    $integer = ltrim($digits[0], '0');
    $grouped = strrev(implode($separators[$settings['group']], str_split(strrev($integer === '' ? '0' : $integer), 3)));
    $fraction = str_pad($digits[1] ?? '', $minimumDecimals, '0');
    return $negative . str_replace(' ', "\u{00a0}", $grouped)
        . ($fraction === '' ? '' : $separators[$settings['decimal']] . $fraction);
}
