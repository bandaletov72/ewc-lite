<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const ADMIN_SERVICE_FILES = ['.htaccess' => 65536, 'robots.txt' => 65536, 'sitemap.xml' => 2097152];
const SITE_SITEMAP_NS = 'http://www.sitemaps.org/schemas/sitemap/0.9';

require_once SITE_ROOT . '/app/redirect-rules.php';

function admin_service_snapshot(string $name): array
{
    $limit = admin_service_file_limit($name);
    if (!$limit) {
        throw new RuntimeException('Укажите служебный файл.');
    }
    $file = SITE_ROOT . '/' . $name;
    if (dirname($name) !== '.' && realpath(dirname($file)) !== str_replace('/', DIRECTORY_SEPARATOR, dirname($file))) {
        throw new RuntimeException('Не удалось открыть служебный файл.');
    }
    if (is_link($file) || (file_exists($file) && !is_file($file))) {
        throw new RuntimeException('Не удалось открыть служебный файл.');
    }
    $exists = is_file($file);
    $content = $exists ? @file_get_contents($file, false, null, 0, $limit + 1) : '';
    if (!is_string($content) || strlen($content) > $limit) {
        throw new RuntimeException('Не удалось открыть служебный файл.');
    }
    return ['content' => $content, 'revision' => hash('sha256', ($exists ? '1' : '0') . $content)];
}

function admin_service_file_limit(string $name): int
{
    if (isset(ADMIN_SERVICE_FILES[$name])) {
        return ADMIN_SERVICE_FILES[$name];
    }
    return preg_match('~\Aerror/([0-9]{3})\.html\z~', $name, $match) && isset(SITE_ERROR_PAGES[(int) $match[1]]) ? 65536 : 0;
}

function admin_ensure_error_pages(string $base)
{
    $marker = SITE_ROOT . '/app/.error-pages-installed.php';
    if (is_file($marker)) {
        return;
    }
    $lock = admin_lock();
    try {
        if (is_file($marker)) {
            return;
        }
        admin_make_page_directory('error/404/index.php');
        $index = SITE_ROOT . '/error/404/index.php';
        if (is_link($index) || (!is_file($index) && !admin_replace_file($index, site_error_404_source() . "\n"))) {
            throw new RuntimeException('Не удалось создать страницу ошибки.');
        }
        $configuration = admin_service_snapshot('.htaccess')['content'];
        $lines = [];
        foreach ([404 => ''] + SITE_ERROR_PAGES as $status => $label) {
            $relative = $status === 404 ? '404/' : $status . '.html';
            if ($status !== 404) {
                $file = SITE_ROOT . '/error/' . $relative;
                if (is_link($file) || (!is_file($file) && !admin_replace_file($file, site_error_static_html($status, $base)))) {
                    throw new RuntimeException('Не удалось создать страницу ошибки.');
                }
            }
            if (!preg_match('~^\s*ErrorDocument\s+' . $status . '\s+~mi', $configuration)) {
                $lines[] = 'ErrorDocument ' . $status . ' ' . site_url($base, 'error/' . $relative);
            } elseif ($base !== '') {
                $configuration = str_replace('ErrorDocument ' . $status . ' /error/' . $relative,
                    'ErrorDocument ' . $status . ' ' . site_url($base, 'error/' . $relative), $configuration);
            }
        }
        $next = $configuration . ($lines ? "\n" . implode("\n", $lines) . "\n" : '');
        $current = admin_service_snapshot('.htaccess')['content'];
        if ($next !== $current) {
            admin_write_payload(SITE_ROOT . '/admin/.htaccess-backup.php', $current, ADMIN_SERVICE_FILES['.htaccess'] + strlen(SITE_RECORD_HEADER));
            if (strlen($next) > ADMIN_SERVICE_FILES['.htaccess'] || !admin_replace_file(SITE_ROOT . '/.htaccess', $next)) {
                throw new RuntimeException('Не удалось сохранить ErrorDocument.');
            }
        }
        admin_replace_file($marker, "<?php http_response_code(404); exit;\n");
    } finally {
        fclose($lock);
    }
}

function admin_sitemap_document(string $base): string
{
    $origin = site_settings()['publicUrl'] ?: site_canonical_url($base, 'index.php');
    if (!preg_match('~\Ahttps?://~i', $origin) || !filter_var($origin, FILTER_VALIDATE_URL)) {
        throw new RuntimeException('Укажите публичный адрес сайта в основных настройках.');
    }
    $lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="' . SITE_SITEMAP_NS . '">'];
    foreach (site_pages() as $page) {
        if ($page['fields']['Hidden'] !== '0' || $page['fields']['Sitemap'] !== '1') {
            continue;
        }
        $url = rtrim($origin, '/') . site_page_url('', $page['path']);
        $lines[] = '    <url><loc>' . htmlspecialchars($url, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc></url>';
    }
    $lines[] = '</urlset>';
    return implode("\n", $lines) . "\n";
}

function admin_valid_sitemap(string $source): bool
{
    if (!class_exists('DOMDocument') || stripos($source, '<!DOCTYPE') !== false) {
        return false;
    }
    $document = new DOMDocument();
    if ($source === '' || !@$document->loadXML($source, LIBXML_NONET) || $document->doctype !== null
        || ($document->encoding !== null && strcasecmp($document->encoding, 'UTF-8') !== 0)) {
        return false;
    }
    $root = $document->documentElement;
    if (!$root || $root->namespaceURI !== SITE_SITEMAP_NS || !in_array($root->localName, ['urlset', 'sitemapindex'], true)) {
        return false;
    }
    $entryName = $root->localName === 'urlset' ? 'url' : 'sitemap';
    foreach ($root->childNodes as $entry) {
        if (!$entry instanceof DOMElement) {
            continue;
        }
        if ($entry->localName !== $entryName || $entry->namespaceURI !== SITE_SITEMAP_NS) {
            return false;
        }
        $locations = $entry->getElementsByTagNameNS(SITE_SITEMAP_NS, 'loc');
        $url = $locations->length === 1 && $locations->item(0)->parentNode->isSameNode($entry) ? trim($locations->item(0)->textContent) : '';
        if (!preg_match('~\Ahttps?://~i', $url) || strlen($url) >= 2048 || !filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
    }
    return true;
}

function admin_save_service_file(string $action, array $posted, string $base)
{
    $name = admin_input($posted, 'file');
    $limit = admin_service_file_limit($name);
    if (!$limit || ($action === 'generate-sitemap' && $name !== 'sitemap.xml')
        || ($action === 'restore-htaccess' && $name !== '.htaccess')) {
        throw new RuntimeException('Укажите служебный файл.');
    }
    $lock = admin_lock();
    try {
        $current = admin_service_snapshot($name);
        if (!hash_equals($current['revision'], admin_input($posted, 'revision'))) {
            throw new RuntimeException('Файл изменился с момента открытия. Скопируйте правки и откройте страницу заново.');
        }
        $backup = SITE_ROOT . '/admin/.htaccess-backup.php';
        $content = admin_input($posted, 'code');
        if ($action === 'generate-sitemap') {
            $content = admin_sitemap_document($base);
        } elseif ($action === 'restore-htaccess') {
            $content = site_read_payload($backup, ADMIN_SERVICE_FILES['.htaccess'] + strlen(SITE_RECORD_HEADER));
            if ($content === null) {
                throw new RuntimeException('Резервная копия недоступна.');
            }
        }
        if (strlen($content) > $limit || preg_match('//u', $content) !== 1 || strpos($content, "\0") !== false) {
            throw new RuntimeException('Используйте UTF-8 и проверьте размер файла.');
        }
        if ($name === 'sitemap.xml' && !admin_valid_sitemap($content)) {
            throw new RuntimeException(admin_maintenance_labels($GLOBALS['adminLanguage'] ?? 'ru')['sitemap-error']);
        }
        if ($name === '.htaccess' && $content !== $current['content']) {
            admin_write_payload($backup, $current['content'], ADMIN_SERVICE_FILES[$name] + strlen(SITE_RECORD_HEADER));
        }
        if (!admin_replace_file(SITE_ROOT . '/' . $name, $content)) {
            throw new RuntimeException('Не удалось записать файл. Проверьте права записи в его каталог.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_save_redirect_rules(array $posted)
{
    $rules = [];
    foreach (preg_split('/\r\n|\n|\r/', admin_input($posted, 'rules')) as $index => $line) {
        if (trim($line) === '') {
            continue;
        }
        list($source, $target) = array_pad(array_map('trim', explode('=>', $line, 2)), 2, '');
        if (!preg_match('~\A/(?:[A-Za-z0-9_-][A-Za-z0-9._-]*(?:/[A-Za-z0-9_-][A-Za-z0-9._-]*)*/?)?\z~', $source)
            || in_array(strtolower(explode('/', $source)[1] ?? ''), ['admin', 'app', 'data', 'extensions', 'error', 'form', 'templates', 'functions.php', 'update.php', 'router.php', 'privacy.php'], true)
            || isset($rules[$source]) || !site_redirect_safe_target($target)) {
            throw new RuntimeException('Проверьте правило перенаправления в строке ' . ($index + 1) . '.');
        }
        $rules[$source] = $target;
    }
    foreach ($rules as $source => $target) {
        $visited = [$source => true];
        while (isset($target[0]) && $target[0] === '/') {
            $path = parse_url($target, PHP_URL_PATH);
            if (isset($visited[$path])) {
                throw new RuntimeException('Правила перенаправления образуют цикл.');
            }
            $visited[$path] = true;
            $target = $rules[$path] ?? '';
        }
    }
    $snapshot = admin_service_snapshot('.htaccess');
    $prefix = '';
    if ($rules) {
        $lines = ['# BEGIN EUROWEBCART REDIRECTS', '# Rules: ' . base64_encode(json_encode($rules, JSON_UNESCAPED_SLASHES)), '<IfModule mod_rewrite.c>', 'RewriteEngine On'];
        foreach ($rules as $source => $target) {
            $lines[] = 'RewriteCond %{REQUEST_METHOD} ^(?:GET|HEAD)$';
            $lines[] = 'RewriteRule ^' . preg_quote(ltrim($source, '/'), '~') . '$ app/redirect.php [END]';
        }
        $lines[] = '</IfModule>';
        $lines[] = '# END EUROWEBCART REDIRECTS';
        $prefix = implode("\n", $lines) . "\n";
    }
    $configuration = $prefix . preg_replace(SITE_REDIRECT_SECTION, '', $snapshot['content'], 1);
    admin_save_service_file('save-service-file', ['file' => '.htaccess', 'revision' => admin_input($posted, 'revision'), 'code' => $configuration], '');
}
