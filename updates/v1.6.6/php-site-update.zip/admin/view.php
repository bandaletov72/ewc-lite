<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<!doctype html>
<html lang="<?= site_escape($adminLanguage) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= site_escape(SITE_PRODUCT_NAME) ?> | <?= site_escape($siteSettings['name']) ?></title>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, site_brand_settings()['favicon'] ?: 'templates/icons/site.png')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_font_awesome_stylesheet($base)) ?>">
    <?php if ($loggedIn || count($regional['languages']) > 1): ?>
        <script src="<?= site_escape(site_url($base, 'templates/search-browser.php') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css') . '?v=' . site_update_version()) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>" data-admin-theme>
    <?php if ($loggedIn && $section === 'libraries'): ?>
        <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/font-previews.php') . '?v=' . site_update_version()) ?>">
    <?php endif; ?>
    <?php if ($loggedIn && ($dataViewSuffix !== '' || in_array($section, ['pages', 'forms', 'iblocks', 'contacts', 'components', 'theme', 'libraries', 'updates', 'layout', 'domains'], true))): ?>
        <?php
        $messages = [];
        foreach (require SITE_ROOT . '/app/admin-js-keys.php' as $key) {
            $messages[$key] = admin_t($key);
        }
        ?>
        <script id="admin-messages" type="application/json"><?= json_encode($messages, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
        <script src="<?= site_escape(site_url($base, 'templates/js/admin.js') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
    <?php if ($loggedIn && site_code_editor_on()): ?>
        <script src="<?= site_escape(site_code_editor_url($base)) ?>" defer></script>
    <?php endif; ?>
</head>
<body data-code-auto="<?= admin_l('Авто') ?>" data-code-syntax="<?= admin_l('Язык подсветки') ?>">
    <?php if ($loggedIn && $dataViewSuffix !== ''): ?>
        <main class="focused-data-editor"<?= $embeddedData ? ' data-component-data-frame' : '' ?>>
            <?php if ($embeddedData && $notice !== ''): ?><span data-component-data-saved hidden></span><?php endif; ?>
            <?php require __DIR__ . '/config-view.php'; ?>
        </main>
        </body></html>
        <?php return; ?>
    <?php endif; ?>
    <header class="site-header admin-header">
        <div class="container header-row">
            <a class="brand" href="<?= site_escape($adminUrl) ?>"><?= site_escape(SITE_PRODUCT_NAME) ?></a>
            <div class="header-actions admin-header-actions">
                <?php if (count($regional['languages']) > 1): ?>
                    <details class="admin-language-picker">
                        <summary class="admin-header-button button" title="<?= admin_l('Язык') ?>">
                            <i class="fa-solid fa-language" aria-hidden="true"></i><span class="admin-nav-label"><?= site_escape(site_languages()[$adminLanguage]) ?></span>
                        </summary>
                        <nav class="site-menu" aria-label="<?= admin_l('Язык') ?>">
                            <?php foreach ($regional['languages'] as $code): ?>
                                <?php $params = ['ui_lang' => $code] + array_diff_key($_GET, ['check' => true]); ?>
                                <a lang="<?= $code ?>" href="<?= site_escape($adminUrl . '?' . http_build_query($params)) ?>"<?= $code === $adminLanguage ? ' aria-current="true"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
                            <?php endforeach; ?>
                        </nav>
                    </details>
                <?php endif; ?>
                <a class="button admin-header-button" href="<?= site_escape(site_url($base)) ?>" title="<?= admin_l('Открыть сайт') ?>">
                    <i class="fa-solid fa-globe" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Открыть сайт') ?></span>
                </a>
                <?php if ($loggedIn): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>">
                        <input type="hidden" name="action" value="logout">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <button class="admin-header-button" type="submit" title="<?= admin_l('Выйти') ?>">
                            <i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Выйти') ?></span>
                        </button>
                    </form>
                    <details class="site-search-compact admin-settings-search"<?= $section === 'find' ? ' open' : '' ?>>
                        <summary class="admin-header-button button" aria-label="<?= admin_l('Поиск настроек') ?>" title="<?= admin_l('Поиск настроек') ?>">
                            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        </summary>
                        <form method="get" action="<?= site_escape($adminUrl) ?>" class="site-search" role="search" data-admin-search>
                            <input type="hidden" name="find" value="1">
                            <input type="search" name="q" aria-label="<?= admin_l('Поиск настроек') ?>" aria-controls="admin-search-suggestions" autocomplete="off"
                                placeholder="<?= admin_l('Поиск настроек') ?>" maxlength="100" required
                                value="<?= $section === 'find' ? site_escape(site_search_query($_GET['q'] ?? '')) : '' ?>">
                            <ul class="site-search-suggestions" id="admin-search-suggestions" hidden></ul>
                        </form>
                    </details>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main class="container admin-main">
        <?php if ($accessError !== ''): ?>
            <section class="panel login-panel">
                <h1><?= admin_l('Настройка входа') ?></h1>
                <p class="notice error" role="alert"><?= admin_l($accessError) ?></p>
            </section>
        <?php elseif (!$configured): ?>
            <section class="panel login-panel">
                <p class="hint"><?= admin_l('Шаг 1 из 2') ?></p>
                <h1><?= admin_l('Мастер установки') ?></h1>
                <h2><?= admin_l('Создать учётную запись') ?></h2>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                <?php endif; ?>
                <?php if ($setupAvailable): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                        <input type="hidden" name="action" value="setup">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <?php if ($needsCode): ?>
                            <div class="field">
                                <label for="setup-code"><?= admin_l('Одноразовый код установки') ?></label>
                                <input id="setup-code" name="setup_code" autocomplete="off" required>
                            </div>
                        <?php endif; ?>
                        <div class="field">
                            <label for="setup-username"><?= admin_l('Логин') ?></label>
                            <input id="setup-username" name="username" value="<?= site_escape($username) ?>" placeholder="admin" autocomplete="username" maxlength="64" required>
                        </div>
                        <div class="field">
                            <label for="setup-password"><?= admin_l('Пароль') ?></label>
                            <input id="setup-password" type="password" name="password" autocomplete="new-password" minlength="8" aria-describedby="password-hint" required>
                            <small class="hint" id="password-hint"><?= admin_l('От 8 символов, не более 72 байт.') ?></small>
                        </div>
                        <div class="field">
                            <label for="setup-confirmation"><?= admin_l('Повторите пароль') ?></label>
                            <input id="setup-confirmation" type="password" name="confirmation" autocomplete="new-password" required>
                        </div>
                        <div><button class="button-primary" type="submit"><?= admin_l('Создать учётную запись и продолжить') ?></button></div>
                    </form>
                <?php else: ?>
                    <p><?= admin_l('В каталоге сайта выполните') ?> <code>php admin/setup.php</code><?= admin_l(', затем обновите страницу и введите полученный код.') ?></p>
                <?php endif; ?>
            </section>
        <?php elseif (!$loggedIn): ?>
            <section class="panel login-panel">
                <h1><?= admin_l('Вход в админку') ?></h1>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                <?php endif; ?>
                <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                    <input type="hidden" name="action" value="login">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <div class="field">
                            <label for="username"><?= admin_l('Логин') ?></label>
                        <input id="username" name="username" value="<?= site_escape($username) ?>" autocomplete="username" required>
                    </div>
                    <div class="field">
                        <label for="password"><?= admin_l('Пароль') ?></label>
                        <input id="password" type="password" name="password" autocomplete="current-password" required>
                    </div>
                    <div><button class="button-primary" type="submit"><?= admin_l('Войти') ?></button></div>
                </form>
            </section>
        <?php elseif ($section === 'install'): ?>
            <?php require __DIR__ . '/installation-view.php'; ?>
        <?php else: ?>
            <?php if ($installationPending): ?>
                <p class="notice"><a href="<?= site_escape($installationUrl) ?>"><?= admin_l('Завершить первичную настройку сайта') ?></a></p>
            <?php endif; ?>
            <?php require __DIR__ . '/navigation-view.php'; ?>
            <?php if ($section !== 'pages'): ?>
                <?php require __DIR__ . '/config-view.php'; ?>
            <?php else: ?>
            <div class="admin-heading">
                <h1><?= admin_l('Страницы') ?></h1>
                <a class="button button-primary" href="<?= site_escape($adminUrl . '?new=1') ?>"><?= admin_l('Новая страница') ?></a>
            </div>
            <p data-page-feedback class="notice" role="status" hidden></p>
            <div class="editor-grid" data-page-admin data-admin-url="<?= site_escape($adminUrl) ?>" data-csrf="<?= site_escape($token) ?>">
                <nav class="panel" aria-label="<?= admin_l('Папки и страницы') ?>">
                    <div data-page-tree>
                        <?= admin_page_tree_html($tree, $creating ? '' : ($page['path'] ?? ''), $base, $adminUrl) ?>
                    </div>
                </nav>
                <section class="panel">
                    <?php if ($error !== ''): ?>
                        <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                    <?php elseif ($notice !== ''): ?>
                        <p class="notice" role="status"><?= admin_l($notice) ?></p>
                    <?php endif; ?>
                    <?php if ($page !== null && !$creating && in_array($pageOperation, ['hide', 'show', 'delete'], true)
                        && ($pageOperation !== 'delete' || $page['path'] !== 'index.php')): ?>
                        <?php
                        $address = site_page_url('', $page['path']);
                        $editUrl = $adminUrl . '?' . http_build_query(['page' => $address]);
                        $operationLabel = ['hide' => admin_t('Скрыть страницу'), 'show' => admin_t('Опубликовать страницу'), 'delete' => admin_t('Удалить страницу')];
                        ?>
                        <h2><?= $operationLabel[$pageOperation] ?>?</h2>
                        <p><?= site_escape($page['fields']['Title'] . ' · ' . $address) ?></p>
                        <?php if ($pageOperation === 'delete'): ?>
                            <p class="hint"><?= admin_l('Файл страницы будет удалён. Остальные файлы в её папке останутся.') ?></p>
                        <?php elseif ($pageOperation === 'hide'): ?>
                            <p class="hint"><?= admin_l('Страница исчезнет из меню и будет недоступна по прямой ссылке, пока вы её не опубликуете.') ?></p>
                        <?php endif; ?>
                        <form class="header-actions" method="post" action="<?= site_escape($editUrl . '&confirm=' . $pageOperation) ?>">
                            <input type="hidden" name="action" value="change-page-status">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="path" value="<?= site_escape($address) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <input type="hidden" name="operation" value="<?= $pageOperation ?>">
                            <button class="<?= $pageOperation === 'delete' ? 'button-danger' : 'button-primary' ?>" type="submit"><?= $operationLabel[$pageOperation] ?></button>
                            <a class="button" href="<?= site_escape($editUrl) ?>"><?= admin_l('Отмена') ?></a>
                        </form>
                    <?php elseif ($page !== null): ?>
                        <div data-page-editor-wrapper>
                        <?php
                        $addressPath = $creating ? admin_page_path($page['path']) : $page['path'];
                        $directory = dirname(site_page_translation($addressPath)[0]);
                        $sectionDirectory = $directory !== '.' && basename(site_page_translation($addressPath)[0]) === 'index.php' ? $directory : '';
                        if ($sectionDirectory !== '' && (!$creating || admin_input($_GET, 'section') === '1')):
                            $nodes = $tree[$sectionDirectory] ?? [];
                        ?>
                            <div class="page-section-summary form-stack">
                                <div class="admin-heading">
                                    <strong><i class="fa-regular fa-folder" aria-hidden="true"></i> <?= site_escape('/' . $sectionDirectory . '/') ?></strong>
                                    <?php if (!$creating): ?><a class="button" href="<?= site_escape($adminUrl . '?' . http_build_query(['new' => '1', 'parent' => $sectionDirectory])) ?>"><?= admin_l('Новая страница') ?></a><?php endif; ?>
                                </div>
                                <?php if ($nodes): ?>
                                    <ul class="page-list page-section-children">
                                        <?php foreach ($nodes as $node): ?>
                                            <?php $child = $node['page']; $folder = $node['folder']; ?>
                                            <li><a href="<?= site_escape($folder !== '' ? admin_folder_edit_url($adminUrl, $folder, $child !== null) : admin_page_edit_url($adminUrl, $child['path'])) ?>">
                                                <?= site_escape($folder !== '' ? basename($folder) . '/' : $child['fields']['Title']) ?>
                                            </a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                                <?php
                                $parentDirectory = dirname($sectionDirectory);
                                $parents = array_keys($tree);
                                sort($parents, SORT_STRING);
                                $parents = array_filter($parents, static function (string $folder) use ($sectionDirectory, $parentDirectory): bool {
                                    return $folder === '.' || ($folder !== $parentDirectory && $folder !== $sectionDirectory && strpos($folder, $sectionDirectory . '/') !== 0);
                                });
                                ?>
                                <?php if ($parents): ?>
                                    <form class="form-stack" data-folder-move-form data-has-page="<?= $creating ? '0' : '1' ?>">
                                        <input type="hidden" name="action" value="folder-move">
                                        <input type="hidden" name="path" value="<?= site_escape($sectionDirectory) ?>">
                                        <label class="field"><?= site_escape(admin_page_menu_labels($adminLanguage)['parent-folder']) ?>
                                            <select name="folder" required>
                                                <option value=""><?= admin_l('Выберите папку') ?></option>
                                                <?php foreach ($parents as $parent): ?>
                                                    <option value="<?= site_escape($parent === '.' ? '/' : '/' . $parent . '/') ?>"<?= $parent === '.' && $parentDirectory === '.' ? ' disabled' : '' ?>><?= $parent === '.' ? site_escape(admin_root_folder_label($adminLanguage)) : site_escape('/' . $parent . '/') ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </label>
                                        <div><button type="submit"><?= admin_l('Переместить папку') ?></button></div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <h2><?= admin_l($creating ? admin_t('Новая страница') : admin_t('Редактирование страницы')) ?></h2>
                        <?php
                        $translationPath = $creating ? admin_page_path($page['path']) : $page['path'];
                        list($basePage, $pageLanguage) = site_page_translation($translationPath);
                        if ((!$creating || ($pageLanguage !== '' && site_read_page($basePage) !== null))
                            && basename($basePage) === 'index.php' && count($regional['languages']) > 1):
                        ?>
                                <nav class="site-menu" aria-label="<?= admin_l('Переводы страницы') ?>">
                                    <?php foreach ($regional['languages'] as $code): ?>
                                        <?php
                                        $candidate = site_language_page_path($basePage, $code);
                                        $target = site_read_page($candidate) !== null ? admin_page_edit_url($adminUrl, $candidate)
                                            : $adminUrl . '?' . http_build_query(['new' => '1', 'translation' => site_page_url('', $candidate)]);
                                        ?>
                                        <a href="<?= site_escape($target) ?>" lang="<?= $code ?>" <?= $candidate === $translationPath ? 'aria-current="page"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
                                    <?php endforeach; ?>
                                </nav>
                        <?php endif; ?>
                        <form method="post" action="<?= site_escape($adminUrl) ?>" data-page-editor
                            data-page-path="<?= site_escape($creating ? '' : $page['path']) ?>">
                            <input type="hidden" name="action" value="save">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="new" value="<?= $creating ? '1' : '0' ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <div class="fields">
                                <div class="field field-wide">
                                    <label for="path"><?= admin_l('Адрес страницы') ?></label>
                                    <input id="path" name="path" value="<?= site_escape($creating ? $page['path'] : site_page_url('', $page['path'])) ?>" placeholder="/Services-1/" maxlength="240"
                                        <?php if ($creating): ?>
                                            required data-address-input aria-describedby="path-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*(/|\.php)?') ?>"
                                        <?php else: ?>readonly<?php endif; ?>>
                                    <?php if ($creating): ?>
                                        <small id="path-hint" class="hint"><?= admin_l('В именах файлов и папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Примеры: /Services-1/ и /Services-1/About_2.php.') ?></small>
                                    <?php endif; ?>
                                </div>
                                <?php
                                $labels = [
                                    'Title' => admin_t('Заголовок вкладки'),
                                    'Heading' => admin_t('Заголовок H1'),
                                    'Description' => admin_t('Метаописание'),
                                    'Menu' => admin_t('Название в меню'),
                                    'Order' => admin_t('Порядок в меню'),
                                ];
                                ?>
                                <?php foreach ($labels as $name => $label): ?>
                                    <div class="field<?= $name === 'Description' ? ' field-wide' : '' ?>">
                                        <label for="<?= $name ?>"><?= admin_l($label) ?></label>
                                        <input id="<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($page['fields'][$name]) ?>"
                                            <?= $name === 'Order' ? 'type="number" min="0" max="99999" required' : 'maxlength="375"' ?>
                                            <?= $name === 'Title' ? 'required' : '' ?>
                                            <?= $name === 'Menu' ? 'aria-describedby="menu-hint"' : '' ?>>
                                        <?php if ($name === 'Menu'): ?>
                                            <small id="menu-hint" class="hint"><?= admin_l('Если поле пустое, в меню используется заголовок вкладки.') ?></small>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                                <label class="choice field-wide">
                                    <input type="hidden" name="menu_visibility" value="1">
                                    <input type="checkbox" name="MenuVisible" value="1"<?= $creating ? '' : ' data-page-menu' ?><?= ($page['fields']['MenuVisible'] ?? '0') === '1' ? ' checked' : '' ?>>
                                    <?= admin_l('Показывать в меню') ?>
                                </label>
                                <?php $discoveryLabels = admin_maintenance_labels($adminLanguage); ?>
                                <?php $pageMenuLabels = admin_page_menu_labels($adminLanguage); ?>
                                <label class="field field-wide"><?= admin_l('Мобильное меню') ?>
                                    <select name="MobileMenu">
                                        <option value=""><?= site_escape($pageMenuLabels['inherit-menu']) ?></option>
                                        <option value="1"<?= ($page['fields']['MobileMenu'] ?? '') === '1' ? ' selected' : '' ?>><?= admin_l('Показывать в меню') ?></option>
                                        <option value="0"<?= ($page['fields']['MobileMenu'] ?? '') === '0' ? ' selected' : '' ?>><?= admin_l('Скрыть') ?></option>
                                    </select>
                                </label>
                                <label class="field field-wide"><?= site_escape($pageMenuLabels['redirect']) ?>
                                    <input name="Redirect" value="<?= site_escape($page['fields']['Redirect'] ?? '') ?>" maxlength="375" placeholder="/contacts/">
                                </label>
                                <label class="choice field-wide">
                                    <input type="hidden" name="page_discovery" value="1">
                                    <input type="checkbox" name="Sitemap" value="1"<?= ($page['fields']['Sitemap'] ?? '1') === '1' ? ' checked' : '' ?>>
                                    <?= site_escape($discoveryLabels['sitemap-page']) ?>
                                </label>
                                <?php foreach (['Lat' => 'latitude', 'Lng' => 'longitude'] as $key => $label): ?>
                                    <label class="field"><?= site_escape($discoveryLabels[$label]) ?>
                                        <input name="<?= $key ?>" inputmode="decimal" maxlength="15" value="<?= site_escape($page['fields'][$key] ?? '') ?>" placeholder="<?= $key === 'Lat' ? '55.7558' : '37.6173' ?>">
                                    </label>
                                <?php endforeach; ?>
                                <?php require __DIR__ . '/editor-view.php'; ?>
                                <details class="field-wide page-code">
                                    <summary><?= admin_l('CSS и JavaScript страницы') ?></summary>
                                    <div class="form-stack">
                                        <?php admin_asset_editors($pageAssets ?? [
                                            'CSS' => site_asset_decode($page['fields']['CSS'] ?? '') ?? '',
                                            'JS' => site_asset_decode($page['fields']['JS'] ?? '') ?? '',
                                        ]); ?>
                                    </div>
                                </details>
                            </div>
                            <div class="form-actions">
                                <button class="button-primary" type="submit"><?= admin_l('Сохранить') ?></button>
                                <?php if (!$creating): ?>
                                    <a class="button" data-page-open href="<?= site_escape(site_page_url($base, $page['path'])) ?>"<?= ($page['fields']['Hidden'] ?? '0') === '1' ? ' hidden' : '' ?>><?= admin_l('Открыть страницу') ?></a>
                                    <?php $operation = $page['fields']['Hidden'] === '1' ? 'show' : 'hide'; $editUrl = admin_page_edit_url($adminUrl, $page['path']); ?>
                                    <a class="button" href="<?= site_escape($editUrl . '&confirm=' . $operation) ?>" data-current-page-action="visibility" data-page-action="<?= $operation ?>" data-show-text="<?= admin_l('Показать') ?>" data-hide-text="<?= admin_l('Скрыть') ?>"><?= admin_l($operation === 'show' ? 'Показать' : 'Скрыть') ?></a>
                                    <?php if ($page['path'] !== 'index.php'): ?><a class="button" href="<?= site_escape($editUrl . '&confirm=delete') ?>" data-current-page-action="delete" data-page-action="delete"><?= admin_l('Удалить') ?></a><?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </form>
                        <?php if (!$creating && $page['path'] !== 'index.php'): ?>
                            <details class="page-code" data-page-move>
                                <summary><?= admin_l('Переместить страницу') ?></summary>
                                <form class="form-stack" method="post" action="<?= site_escape(admin_page_edit_url($adminUrl, $page['path'])) ?>" data-page-move-form>
                                    <input type="hidden" name="action" value="page-move">
                                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                                    <input type="hidden" name="path" value="<?= site_escape($page['path']) ?>">
                                    <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                                    <label class="field">
                                        <?= admin_l('Папка назначения') ?>
                                        <input name="folder" list="page-folders" placeholder="/Services-1/" maxlength="230" required
                                            data-address-input aria-describedby="page-folder-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*/?') ?>">
                                    </label>
                                    <datalist id="page-folders">
                                        <?php $folders = array_keys($tree); sort($folders, SORT_STRING); ?>
                                        <?php foreach ($folders as $folder): ?>
                                            <?php if ($folder !== '.'): ?><option value="<?= site_escape('/' . $folder . '/') ?>"><?php endif; ?>
                                        <?php endforeach; ?>
                                    </datalist>
                                    <small class="hint" id="page-folder-hint"><?= admin_l('В именах папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Можно указать новую папку. Подпапки страницы останутся по прежним адресам.') ?></small>
                                    <div><button type="submit"><?= admin_l('Переместить') ?></button></div>
                                </form>
                            </details>
                        <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
    <footer class="site-footer">
        <div class="container"><?= site_author_credit($adminLanguage) ?> · <?= admin_l('Версия') ?> <?= site_escape(site_update_version()) ?></div>
    </footer>
</body>
</html>
