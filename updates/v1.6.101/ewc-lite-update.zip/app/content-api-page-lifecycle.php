<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_content_api_lifecycle_path(string $path): bool
{
    return site_content_api_page_path($path) && site_page_translation($path)[0] !== 'index.php'
        && stripos($path, 'shop/') !== 0;
}

function site_content_api_page_lifecycle(bool $applying, string $base, string $tokenHash, string $access): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        header('Allow: POST');
        site_content_api_error(405, 'method_not_allowed');
        return;
    }
    if ($access !== 'write') {
        site_content_api_error(403, 'write_access_required');
        return;
    }
    $body = site_content_api_json(SITE_CONTENT_GPT_LIMIT);
    if ($body === null) return;
    $operation = $body->operation ?? null;
    $path = $body->path ?? null;
    $allowed = ['create' => ['changes'], 'move' => ['revision', 'folder'], 'delete' => ['revision']];
    if (!is_string($operation) || !isset($allowed[$operation]) || !is_string($path) || !site_content_api_lifecycle_path($path)
        || array_diff(array_keys(get_object_vars($body)), array_merge(['operation', 'path'], $allowed[$operation], $applying ? ['preview_token'] : []))) {
        site_content_api_error(422, 'invalid_page_operation');
        return;
    }
    if ($applying && (!is_string($body->preview_token ?? null)
        || !preg_match('/\A([0-9]{1,11})\.[a-f0-9]{64}\z/', $body->preview_token, $expiry))) {
        site_content_api_error(428, 'preview_required');
        return;
    }
    $revision = $body->revision ?? '';
    if ($operation !== 'create' && (!is_string($revision) || !preg_match('/\A[a-f0-9]{64}\z/', $revision))) {
        site_content_api_error(422, 'invalid_revision');
        return;
    }
    $changes = [];
    if ($operation === 'create') {
        if (!is_object($body->changes ?? null) || !isset($body->changes->title)) {
            site_content_api_error(422, 'title_required');
            return;
        }
        $changes = site_content_api_changes($body->changes);
        if ($changes === null) return;
    }
    require_once SITE_ROOT . '/admin/files.php';
    require_once SITE_ROOT . '/admin/save.php';
    $lock = $applying ? admin_lock() : null;
    try {
        if ($applying && !site_content_api_write_access($tokenHash, 'gpt')) return;
        $root = site_content_root();
        $file = $root . '/' . $path;
        $target = $path;
        $snapshot = $changes;
        $diff = [];
        if ($operation === 'create') {
            if (file_exists($file) || is_link($file)) {
                site_content_api_error(409, 'page_path_taken');
                return;
            }
            $candidate = site_content_api_candidate(['path' => $path, 'fields' => site_page_metadata_defaults(), 'html' => ''], $changes);
            $bytes = site_content_api_page_bytes($candidate);
            if ($bytes === null) return;
            foreach ($changes as $field => $value) $diff[$field] = ['before' => null, 'after' => $value];
        } else {
            $page = site_read_page($path, $root);
            if ($page === null) {
                site_content_api_error(404, 'page_not_found');
                return;
            }
            if (!hash_equals($page['revision'], $revision)) {
                site_content_api_error(412, 'page_has_changed');
                return;
            }
            $diff['title'] = ['before' => $page['fields']['Title'], 'after' => $operation === 'move' ? $page['fields']['Title'] : null];
            if ($operation === 'move') {
                $folder = is_string($body->folder ?? null) ? trim($body->folder, '/') : '';
                if ($folder === '' || !site_content_api_lifecycle_path($folder . '/index.php')
                    || realpath($root . '/' . $folder) !== str_replace('/', DIRECTORY_SEPARATOR, $root . '/' . $folder)
                    || !is_dir($root . '/' . $folder)) {
                    site_content_api_error(422, 'invalid_destination_folder');
                    return;
                }
                try {
                    $target = admin_move_page_target($path, $folder);
                    $sources = admin_move_page_sources($path, $revision);
                } catch (RuntimeException $exception) {
                    site_content_api_error(422, 'invalid_page_move');
                    return;
                }
                $translations = [];
                foreach ($sources as $source => $variant) {
                    $destination = $source === $path ? $target : site_language_page_path($target, site_page_translation($source)[1]);
                    if (file_exists($root . '/' . $destination) || is_link($root . '/' . $destination)) {
                        site_content_api_error(409, 'page_path_taken');
                        return;
                    }
                    $snapshot[$source] = ['destination' => $destination, 'revision' => $variant['revision']];
                    if ($source !== $path) $translations[$source] = $destination;
                }
                $diff['url'] = ['before' => site_page_url($base, $path), 'after' => site_page_url($base, $target)];
                if ($translations) $diff['translations'] = ['before' => array_keys($translations), 'after' => array_values($translations)];
            }
        }
        $until = $applying ? (int) $expiry[1] : time() + SITE_CONTENT_GPT_PREVIEW_LIFETIME;
        $proof = site_content_gpt_preview_token($until, $tokenHash, $root, 'lifecycle/' . $operation . '/' . $path, $revision, $snapshot);
        if (!$applying) {
            site_content_gpt_response(['path' => $path, 'target' => $target, 'url' => site_page_url($base, $target), 'operation' => $operation,
                'revision' => $revision, 'diff' => $diff, 'preview_token' => $proof, 'expires_at' => gmdate('c', $until)]);
            return;
        }
        if ($until < time() || !hash_equals($proof, $body->preview_token)) {
            site_content_api_error(412, 'preview_expired_or_changed');
            return;
        }
        if ($operation === 'create') {
            admin_make_page_directory($path, $root);
            $saved = site_content_api_write_page($root, $path, $bytes);
        } elseif ($operation === 'move') {
            admin_move_page($path, $revision, $folder, true);
            $saved = site_read_page($target, $root);
            if ($saved === null) throw new RuntimeException('Could not read moved page.');
        } else {
            admin_update_page_status($path, $revision, 'delete', true);
            site_content_api_response(200, ['saved' => true, 'deleted' => true, 'path' => $path]);
            return;
        }
        site_content_api_response($operation === 'create' ? 201 : 200,
            ['saved' => true, 'path' => $target, 'url' => site_page_url($base, $target), 'revision' => $saved['revision']]);
    } finally {
        if ($lock !== null) fclose($lock);
    }
}
