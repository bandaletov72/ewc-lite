<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const ADMIN_AI_FILE = SITE_ROOT . '/admin/.ai-chatgpt.php';
require_once SITE_ROOT . '/app/content-api.php';

function admin_content_api_save(array $auth, string $action, string $access, string $revision, array $features): string
{
    if (!site_content_api_secure() || !in_array($access, ['read', 'write'], true)) {
        throw new RuntimeException('Invalid content API settings.');
    }
    $lock = admin_lock();
    try {
        $current = admin_auth_state();
        if (!isset($current['password']) || !hash_equals(admin_auth_key($current), admin_auth_key($auth))) {
            throw new RuntimeException('Administrator session has changed.');
        }
        $settings = site_content_api_settings();
        if (!hash_equals(admin_settings_revision($settings), $revision)) {
            throw new InvalidArgumentException('revisionError');
        }
        $token = '';
        if ($action === 'content-api-revoke') {
            $settings = [];
        } elseif ($action === 'content-api-issue') {
            $token = 'ewc_' . bin2hex(random_bytes(32));
            $settings = ['hash' => hash('sha256', $token), 'access' => $access, 'preview_key' => bin2hex(random_bytes(32))] + $features;
        } elseif ($settings['hash'] !== '') {
            $settings['access'] = $access;
            $settings = array_replace($settings, $features);
            if ($settings['preview_key'] === '') $settings['preview_key'] = bin2hex(random_bytes(32));
        } else {
            throw new RuntimeException('No content API token.');
        }
        admin_write_record(SITE_CONTENT_API_CONFIG, $settings, SITE_CONTENT_API_CONFIG_LIMIT);
        return $token;
    } finally {
        fclose($lock);
    }
}

function admin_content_api_labels(string $language): array
{
    $labels = require __DIR__ . '/content-api-labels.php';
    $lifecycle = [
        'en' => 'To create, move or delete a page, enable GPT Actions and allow edits. Preview the operation first. The confirmation token expires after ten minutes.',
        'ru' => 'Чтобы создать, перенести или удалить страницу, включите GPT Actions и разрешите правку. Сначала запросите предпросмотр. Токен подтверждения действует десять минут.',
        'uk' => 'Щоб створити, перемістити або видалити сторінку, увімкніть GPT Actions і дозвольте редагування. Спочатку отримайте попередній перегляд. Токен підтвердження дійсний десять хвилин.',
        'de' => 'Aktivieren Sie GPT Actions und erlauben Sie Änderungen, um Seiten zu erstellen, zu verschieben oder zu löschen. Rufen Sie zuerst eine Vorschau ab. Das Bestätigungstoken gilt zehn Minuten.',
        'fr' => 'Activez GPT Actions et autorisez la modification pour créer, déplacer ou supprimer une page. Demandez d’abord un aperçu. Le jeton de confirmation est valable dix minutes.',
        'es' => 'Activa GPT Actions y permite la edición para crear, mover o eliminar páginas. Solicita primero una vista previa. El token de confirmación caduca a los diez minutos.',
        'pt' => 'Ative GPT Actions e permita a edição para criar, mover ou eliminar páginas. Peça primeiro uma pré-visualização. O token de confirmação expira após dez minutos.',
        'ja' => 'ページの作成、移動、削除には GPT Actions と編集権限が必要です。まずプレビューを取得してください。確認トークンの有効期限は 10 分です。',
        'ko' => '페이지를 만들거나 이동 또는 삭제하려면 GPT Actions와 편집 권한을 활성화하세요. 먼저 미리보기를 요청하세요. 확인 토큰은 10분 후에 만료됩니다.',
        'vi' => 'Bật GPT Actions và quyền chỉnh sửa để tạo, di chuyển hoặc xóa trang. Trước tiên hãy yêu cầu bản xem trước. Mã xác nhận hết hạn sau mười phút.',
        'zh' => '如需创建、移动或删除页面，请启用 GPT Actions 并授予编辑权限。请先请求预览。确认令牌在十分钟后失效。',
    ];
    return array_combine(array_keys($labels['en']), $labels[$language] ?? array_values($labels['en']))
        + ['lifecycle' => $lifecycle[$language] ?? $lifecycle['en']];
}

function admin_ai_labels(string $language): array
{
    $labels = require __DIR__ . '/ai-labels.php';
    return $labels[$language] ?? $labels['ru'];
}

/** A canonical display/link base, not an MCP endpoint or a network destination. */
function admin_ai_url(string $value): string
{
    $url = parse_url($value);
    if (strlen($value) > 2048 || preg_match('~[\x00-\x20\x7f\\\\]~', $value)
        || !is_array($url) || !isset($url['scheme'], $url['host'])
        || array_intersect(['user', 'pass', 'query', 'fragment'], array_keys($url))
        || !preg_match('~\A/[A-Za-z0-9_/-]*\z~', $url['path'] ?? '/')
        || (isset($url['port']) && $url['port'] < 1)) {
        throw new InvalidArgumentException('urlError');
    }
    $host = strtolower($url['host']);
    $scheme = strtolower($url['scheme']);
    $local = in_array($host, ['localhost', '127.0.0.1', '[::1]'], true);
    if ((!$local && !preg_match('~\A(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\z~', $host))
        || ($scheme !== 'https' && !($local && $scheme === 'http'))) {
        throw new InvalidArgumentException('urlError');
    }
    return $scheme . '://' . $host . (isset($url['port']) ? ':' . $url['port'] : '')
        . rtrim($url['path'] ?? '/', '/') . '/';
}

function admin_ai_validate(string $url, string $tunnel, string $mode): array
{
    if (!in_array($mode, ['tunnel', 'direct'], true)) {
        throw new InvalidArgumentException('modeError');
    }
    if ($mode === 'tunnel' && !preg_match('/\Atunnel_[a-zA-Z0-9]{16,128}\z/', $tunnel)) {
        throw new InvalidArgumentException('tunnelError');
    }
    return ['url' => admin_ai_url($url), 'tunnel' => $mode === 'tunnel' ? $tunnel : '', 'mode' => $mode];
}

function admin_ai_settings(): array
{
    return site_read_record(ADMIN_AI_FILE, 8192);
}

function admin_ai_save(array $auth, array $config, string $revision, bool $onboarding, bool $skip)
{
    $lock = admin_lock();
    try {
        $current = admin_auth_state();
        if (!isset($current['password']) || !hash_equals(admin_auth_key($current), admin_auth_key($auth))
            || ($onboarding && empty($current['chatgptSetupPending']))) {
            throw new InvalidArgumentException('sessionError');
        }
        if (!$skip) {
            if (!hash_equals(admin_settings_revision(admin_ai_settings()), $revision)) {
                throw new InvalidArgumentException('revisionError');
            }
            admin_write_record(ADMIN_AI_FILE, $config, 8192);
        }
        if ($onboarding) {
            unset($current['chatgptSetupPending']);
            admin_write_record(ADMIN_ACCESS_FILE, $current);
        }
    } finally {
        fclose($lock);
    }
}
