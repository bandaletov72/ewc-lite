<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_page_path(string $input): string
{
    if ($input === '') {
        return '';
    }
    if ($input[0] === '/') {
        $input = substr($input, 1);
    }
    if ($input === '' || substr($input, -1) === '/') {
        return $input . 'index.php';
    }
    return strpos(basename($input), '.') === false ? $input . '/index.php' : $input;
}

function admin_page_bytes(string $path, array $fields, string $html): string
{
    if (!site_valid_path($path)) {
        throw new RuntimeException('Укажите адрес страницы на сайте, например /services/.');
    }

    if (!site_valid_metadata($fields)) {
        throw new RuntimeException('Заполните заголовок вкладки и укажите порядок от 0 до 99999.');
    }

    $headers = [];
    foreach ($fields as $name => $value) {
        if (in_array($name, ['CSS', 'JS', 'Sale', 'Announcement', 'AnnouncementImage', 'AnnouncementIcon', 'CustomFields'], true) && $value === '') {
            continue;
        }
        $headers[] = $name . ': ' . $value;
    }

    $bytes = site_page_header($path) . "\n" . implode("\n", $headers) . "\n\n" . $html;
    if (strlen($bytes) - strlen($fields['CSS'] ?? '') - strlen($fields['JS'] ?? '') - strlen($fields['Announcement'] ?? '')
        - strlen($fields['CustomFields'] ?? '') > SITE_PAGE_LIMIT
        || preg_match('//u', $bytes) !== 1 || strpos($bytes, "\0") !== false) {
        throw new RuntimeException('Используйте текст UTF-8. Размер файла должен быть не больше 512 КиБ.');
    }

    return $bytes;
}

function admin_make_page_directory(string $path, ?string $root = null)
{
    $directory = str_replace('/', DIRECTORY_SEPARATOR, $root ?? SITE_ROOT);
    $parts = explode('/', $path);
    array_pop($parts);
    foreach ($parts as $part) {
        $directory .= DIRECTORY_SEPARATOR . $part;
        if (is_link($directory) || (!is_dir($directory) && !@mkdir($directory, 0755))) {
            throw new RuntimeException('Не удалось создать каталог страницы. Проверьте путь и права записи.');
        }
        if (realpath($directory) !== $directory) {
            throw new RuntimeException('Выберите каталог внутри сайта.');
        }
    }
}

function admin_current_page(string $path, string $revision): array
{
    $current = site_read_page($path);
    if ($current === null || !hash_equals($current['revision'], $revision)) {
        throw new RuntimeException('Файл изменился с момента открытия. Скопируйте правки и откройте страницу заново.');
    }
    return $current;
}

function admin_save_page(string $path, array $fields, string $html, string $revision, bool $creating, ?array $form = null, string $base = '')
{
    if (!site_valid_path($path)) {
        throw new RuntimeException('Укажите адрес в папке контента, например /Services-1/. В именах используйте A–Z, a–z, 0–9, дефис и подчёркивание. Без пробелов. В корне доступна только главная страница.');
    }
    if ((($fields['Lat'] ?? '') !== '' || ($fields['Lng'] ?? '') !== '')
        && site_map_coordinates($fields['Lat'] ?? '', $fields['Lng'] ?? '') === null) {
        throw new RuntimeException(admin_maintenance_labels($GLOBALS['adminLanguage'] ?? 'ru')['coordinates-error']);
    }
    if (($fields['Redirect'] ?? '') !== '' && site_page_redirect_url('', $path, $fields['Redirect']) === '') {
        throw new RuntimeException(admin_page_menu_labels($GLOBALS['adminLanguage'] ?? 'ru')['redirect-error']);
    }
    $lock = admin_lock();

    try {
        $file = site_content_root() . '/' . $path;
        if ($creating) {
            if (file_exists($file) || is_link($file)) {
                throw new RuntimeException('Этот путь уже занят. Выберите другой.');
            }
            $fields['Hidden'] = '0';
        } else {
            $current = admin_current_page($path, $revision);
            $fields['Hidden'] = $current['fields']['Hidden'];
            foreach (['Keywords', 'CSS', 'JS', 'Sitemap', 'Lat', 'Lng', 'MobileMenu', 'MenuExpand', 'Redirect', 'Active', 'ActiveFrom', 'ActiveUntil', 'Sale', 'Announcement', 'AnnouncementImage', 'AnnouncementIcon', 'CustomFields'] as $kind) {
                $fields[$kind] = $fields[$kind] ?? $current['fields'][$kind];
            }
            if ($current['menu_explicit']) {
                $fields['MenuVisible'] = $fields['MenuVisible'] ?? $current['fields']['MenuVisible'];
            }
        }
        if (isset($form['custom_schema_revision'])) $fields['CustomFields'] = admin_encode_page_custom_values($form, $current['fields'] ?? []);
        if (!$creating && is_array($form['inline_changes'] ?? null) && $form['inline_changes']) {
            $html = admin_apply_inline_changes($current['html'], $html, $form['inline_changes'], $base);
        }
        $from = $fields['ActiveFrom'] ?? '';
        $until = $fields['ActiveUntil'] ?? '';
        if (!site_schedule_date_valid($from) || !site_schedule_date_valid($until) || ($from !== '' && $until !== '' && $from >= $until)) {
            $labels = require SITE_ROOT . '/app/help-page-editor.php';
            throw new RuntimeException(($labels[$GLOBALS['adminLanguage'] ?? 'ru'] ?? $labels['ru'])[7]);
        }
        $bytes = admin_page_bytes($path, $fields, $html);

        admin_make_page_directory($path, site_content_root());
        if (!admin_replace_file($file, $bytes)) {
            throw new RuntimeException('Не удалось сохранить файл. Проверьте права записи в каталоге страницы.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_encode_asset(string $code): string
{
    if (strlen($code) > SITE_ASSET_LIMIT || preg_match('//u', $code) !== 1 || strpos($code, "\0") !== false) {
        throw new RuntimeException('Каждое поле CSS и JavaScript должно содержать текст UTF-8 размером до 64 КиБ.');
    }
    return base64_encode($code);
}

function admin_asset_editors(array $code)
{
    foreach (['CSS' => 'CSS', 'JS' => 'JavaScript'] as $key => $label): ?>
        <div class="field field-wide">
            <label for="asset-<?= $key ?>"><?= $label ?></label>
            <textarea id="asset-<?= $key ?>" class="code-editor" data-code-mode="<?= $key === 'CSS' ? 'css' : 'javascript' ?>" name="assets[<?= $key ?>]" rows="10" spellcheck="false"><?= "\n" . site_escape($code[$key] ?? '') ?></textarea>
        </div>
    <?php endforeach;
}

function admin_save_global_assets(array $assets, string $revision)
{
    $lock = admin_lock();
    try {
        if (!hash_equals(admin_settings_revision(site_global_assets()), $revision)) {
            throw new RuntimeException('Стили или скрипты уже изменились. Откройте редактор заново.');
        }
        foreach ($assets as &$code) {
            $code = admin_encode_asset($code);
        }
        admin_write_record(site_content_record(SITE_ASSETS_FILE), $assets, SITE_ASSET_RECORD_LIMIT);
    } finally {
        fclose($lock);
    }
}

function admin_save_header_inserts(array $inserts, string $revision)
{
    foreach ($inserts as $code) {
        if (strlen($code) > SITE_HEADER_INSERT_LIMIT || preg_match('//u', $code) !== 1
            || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $code)) {
            throw new RuntimeException('В каждом поле допускается HTML в UTF-8 размером до 32 КиБ.');
        }
    }
    $lock = admin_lock();
    try {
        if (!hash_equals(admin_settings_revision(site_header_inserts()), $revision)) {
            throw new RuntimeException('Служебные заголовки уже изменились. Откройте редактор заново.');
        }
        admin_write_record(site_content_record(SITE_HEADERS_FILE), $inserts, SITE_HEADERS_RECORD_LIMIT);
    } finally {
        fclose($lock);
    }
}

function admin_update_page_menu(string $path, string $revision, string $visible)
{
    $lock = admin_lock();
    try {
        $page = admin_current_page($path, $revision);
        $page['fields']['MenuVisible'] = $visible;
        if (!admin_replace_file(site_content_root() . '/' . $path, admin_page_bytes($path, $page['fields'], $page['html']))) {
            throw new RuntimeException('Не удалось обновить меню.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_move_page_target(string $path, string $folder): string
{
    $folder = trim($folder, '/');
    if ($path === 'index.php' || $folder === '' || !site_valid_path($folder . '/index.php')) {
        throw new RuntimeException('Выберите папку контента. Корень и служебные папки недоступны для переноса.');
    }
    $sourceFolder = dirname($path);
    if (basename($path) === 'index.php' && ($folder === $sourceFolder || strpos($folder, $sourceFolder . '/') === 0)) {
        throw new RuntimeException('Выберите папку за пределами текущего раздела.');
    }
    $leaf = basename($path) === 'index.php' ? basename($sourceFolder) . '/index.php' : basename($path);
    $target = $folder . '/' . $leaf;
    if (!site_valid_path($target) || $target === $path) {
        throw new RuntimeException('Выберите другую папку назначения.');
    }
    return $target;
}

function admin_move_page_sources(string $path, string $revision): array
{
    $pages = [$path => admin_current_page($path, $revision)];
    if (basename($path) === 'index.php') {
        foreach (array_keys(site_languages()) as $language) {
            $variant = site_language_page_path($path, $language);
            if ($variant === $path || (!file_exists(site_content_root() . '/' . $variant) && !is_link(site_content_root() . '/' . $variant))) {
                continue;
            }
            $pages[$variant] = site_read_page($variant);
            if ($pages[$variant] === null) {
                throw new RuntimeException('Не удалось прочитать файл перевода. Перенос отменён.');
            }
        }
    }
    return $pages;
}

function admin_move_page(string $path, string $revision, string $folder, bool $locked = false): string
{
    $target = admin_move_page_target($path, $folder);
    $lock = $locked ? null : admin_lock();
    try {
        $pages = admin_move_page_sources($path, $revision);
        $writes = [];
        foreach ($pages as $oldPath => $page) {
            $language = site_page_translation($oldPath)[1];
            $newPath = $oldPath === $path ? $target : site_language_page_path($target, $language);
            $destination = site_content_root() . '/' . $newPath;
            if (file_exists($destination) || is_link($destination)) {
                throw new RuntimeException('Адрес страницы или перевода уже занят. Перенос отменён.');
            }
            $writes[$destination] = admin_page_bytes($newPath, $page['fields'], $page['html']);
        }
        admin_make_page_directory($target, site_content_root());
        $backups = [];
        $written = [];
        try {
            foreach (array_keys($pages) as $oldPath) {
                $file = site_content_root() . '/' . $oldPath;
                $backup = dirname($file) . '/.move-' . bin2hex(random_bytes(12)) . '.php';
                if (!@rename($file, $backup)) {
                    throw new RuntimeException('Не удалось переместить исходный файл.');
                }
                $backups[$file] = $backup;
            }
            foreach ($writes as $destination => $bytes) {
                if (!admin_replace_file($destination, $bytes)) {
                    throw new RuntimeException('Не удалось записать страницу или перевод.');
                }
                $written[] = $destination;
            }
        } catch (RuntimeException $exception) {
            $restored = true;
            foreach ($written as $file) {
                $restored = @unlink($file) && $restored;
            }
            foreach ($backups as $file => $backup) {
                $restored = @rename($backup, $file) && $restored;
            }
            throw new RuntimeException($restored ? $exception->getMessage() . ' Перенос отменён.'
                : 'Не удалось полностью отменить перенос. Проверьте обе папки.', 0, $exception);
        }
        foreach ($backups as $file => $backup) {
            @unlink($backup);
            if (function_exists('opcache_invalidate')) {
                @opcache_invalidate($file, true);
            }
        }
        clearstatcache(true);
        return $target;
    } finally {
        if ($lock !== null) fclose($lock);
    }
}

function admin_move_folder(string $source, string $parent): array
{
    if (!site_valid_path($source . '/index.php')
        || ($parent !== '/' && !site_valid_path(trim($parent, '/') . '/index.php'))) {
        throw new RuntimeException('Выберите папки контента. Служебные каталоги недоступны.');
    }
    $parent = trim($parent, '/');
    if ($parent === $source || strpos($parent, $source . '/') === 0) {
        throw new RuntimeException('Выберите папку вне переносимого раздела.');
    }
    $target = ($parent === '' ? '' : $parent . '/') . basename($source);
    if ($target === $source || !site_valid_path($target . '/index.php')) {
        throw new RuntimeException('Выберите другую папку назначения.');
    }

    $lock = admin_lock();
    try {
        $pages = site_pages(true);
        $tree = site_page_tree(array_filter($pages, static function (array $page): bool {
            return site_page_translation($page['path'])[1] === '';
        }));
        if (!isset($tree[$source]) || ($parent !== '' && !isset($tree[$parent]))) {
            throw new RuntimeException('Папка изменилась или отсутствует в дереве страниц.');
        }
        $sourcePath = site_content_root() . '/' . $source;
        $targetPath = site_content_root() . '/' . $target;
        if (file_exists($targetPath) || is_link($targetPath)) {
            throw new RuntimeException('В папке назначения уже есть такой файл или каталог.');
        }
        $written = [];
        $revisions = [];
        $rewrites = [];
        foreach ($pages as $page) {
            $oldPath = $page['path'];
            if (strpos($oldPath, $source . '/') !== 0) {
                continue;
            }
            $newPath = $target . substr($oldPath, strlen($source));
            if (!site_valid_path($newPath)) {
                throw new RuntimeException('После переноса адрес одной из страниц станет слишком длинным.');
            }
            $revisions[$oldPath] = $page['revision'];
            $before = site_page_header($oldPath);
            $after = site_page_header($newPath);
            if ($before !== $after) {
                $bytes = @file_get_contents(site_content_root() . '/' . $oldPath, false, null, 0, SITE_PAGE_RECORD_LIMIT + 1);
                if ($bytes === false || !hash_equals($page['revision'], hash('sha256', $bytes))) {
                    throw new RuntimeException('Одна из страниц изменилась. Обновите список.');
                }
                $end = '__halt_compiler();';
                $offset = strpos($bytes, $end) + strlen($end);
                $rewrites[site_content_root() . '/' . $newPath] = ['before' => $bytes, 'after' => $after . substr($bytes, $offset)];
            }
        }
        if (!@rename($sourcePath, $targetPath)) {
            throw new RuntimeException('Не удалось переместить каталог. Проверьте права записи.');
        }
        clearstatcache(true);
        foreach ($rewrites as $file => $versions) {
            if (!admin_replace_file($file, $versions['after'])) {
                $restored = true;
                foreach (array_reverse($written) as $previous) {
                    $restored = admin_replace_file($previous, $rewrites[$previous]['before']) && $restored;
                }
                $restored = @rename($targetPath, $sourcePath) && $restored;
                throw new RuntimeException($restored ? 'Перенос отменён. Проверьте права записи внутри папки.'
                    : 'Не удалось полностью отменить перенос. Проверьте исходную папку и папку назначения.');
            }
            $written[] = $file;
        }
        if (function_exists('opcache_invalidate')) {
            foreach (array_keys($revisions) as $oldPath) {
                @opcache_invalidate(site_content_root() . '/' . $oldPath, true);
            }
        }
        return ['target' => $target, 'revisions' => $revisions];
    } finally {
        fclose($lock);
    }
}

function admin_reorder_pages(string $folder, array $items)
{
    $lock = admin_lock();
    try {
        $siblings = [];
        $tree = site_page_tree(site_pages());
        foreach ($tree[$folder] ?? [] as $node) {
            if ($node['page'] !== null && $node['page']['path'] !== 'index.php') {
                $siblings[$node['page']['path']] = (int) $node['page']['fields']['Order'];
            }
        }
        if (count($siblings) < 2 || count($siblings) !== count($items) || count($items) > 99999) {
            throw new RuntimeException('Список страниц изменился. Обновите его перед сортировкой.');
        }
        $writes = [];
        $order = 0;
        foreach ($items as $item) {
            $path = is_array($item) ? ($item['path'] ?? null) : null;
            if (!is_string($path) || !isset($siblings[$path]) || !is_string($item['revision'] ?? null)) {
                throw new RuntimeException('Сортировать можно только страницы одного уровня.');
            }
            unset($siblings[$path]);
            $page = admin_current_page($path, $item['revision']);
            $number = (string) ++$order;
            if ($page['fields']['Order'] !== $number) {
                $page['fields']['Order'] = $number;
                $file = site_content_root() . '/' . $path;
                $original = @file_get_contents($file, false, null, 0, SITE_PAGE_RECORD_LIMIT + 1);
                if ($original === false || !hash_equals($page['revision'], hash('sha256', $original))) {
                    throw new RuntimeException('Одна из страниц изменилась. Обновите список.');
                }
                $writes[$file] = ['previous' => $original, 'next' => admin_page_bytes($path, $page['fields'], $page['html'])];
            }
        }
        $written = [];
        foreach ($writes as $file => $write) {
            if (!admin_replace_file($file, $write['next'])) {
                $restored = true;
                foreach (array_reverse($written) as $previous) {
                    $restored = admin_replace_file($previous, $writes[$previous]['previous']) && $restored;
                }
                throw new RuntimeException($restored ? 'Не удалось сохранить порядок страниц.'
                    : 'Не удалось полностью вернуть прежний порядок. Обновите список страниц.');
            }
            $written[] = $file;
        }
    } finally {
        fclose($lock);
    }
}

function admin_update_page_status(string $path, string $revision, string $operation, bool $locked = false): string
{
    if (!in_array($operation, ['hide', 'show', 'delete'], true) || ($path === 'index.php' && $operation === 'delete')) {
        throw new RuntimeException('Это действие недоступно для выбранной страницы.');
    }
    $lock = $locked ? null : admin_lock();
    try {
        $page = admin_current_page($path, $revision);
        $file = site_content_root() . '/' . $path;
        if ($operation === 'delete') {
            if (!@unlink($file)) {
                throw new RuntimeException('Не удалось удалить файл страницы.');
            }
            clearstatcache(true);
            if (function_exists('opcache_invalidate')) {
                @opcache_invalidate($file, true);
            }
            return 'Страница удалена.';
        }

        $page['fields']['Hidden'] = $operation === 'hide' ? '1' : '0';
        if (!admin_replace_file($file, admin_page_bytes($path, $page['fields'], $page['html']))) {
            throw new RuntimeException('Не удалось изменить видимость страницы.');
        }
        return $operation === 'hide' ? 'Страница скрыта.' : 'Страница опубликована.';
    } finally {
        if ($lock !== null) fclose($lock);
    }
}
