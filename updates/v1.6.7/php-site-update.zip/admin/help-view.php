<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$guide = require SITE_ROOT . '/app/template-guide.php';
$faq = require SITE_ROOT . '/app/admin-faq.php';
list($localized, $releaseExamples) = require SITE_ROOT . '/app/help-release.php';
$releaseHelp = $localized[$adminLanguage] ?? $localized['ru'];
$currentHelp = require SITE_ROOT . '/app/help-current.php';
$i18nHelp = require SITE_ROOT . '/app/help-i18n.php';
$functionsHelp = require SITE_ROOT . '/app/help-functions.php';
list($headerHelp, $navigationHelp, $layoutHelp) = require SITE_ROOT . '/app/help-header.php';
list($headerTopic, $headerText) = $headerHelp[$adminLanguage] ?? $headerHelp['ru'];
$maintenanceHelp = require SITE_ROOT . '/app/help-maintenance.php';
$externalHelp = require SITE_ROOT . '/app/help-integrations.php';
$editorHelp = require SITE_ROOT . '/app/help-editor.php';
$routingHelp = require SITE_ROOT . '/app/help-routing.php';
$dataEditorHelp = require SITE_ROOT . '/app/help-data-editor.php';
list($dataHelpTitle, $dataHelpText) = $dataEditorHelp[$adminLanguage] ?? $dataEditorHelp['ru'];
list($maintenanceTopic, $serviceText, $mapsText, $customLayoutsText) = $maintenanceHelp[$adminLanguage] ?? $maintenanceHelp['ru'];
?>
<h1><?= admin_l('Помощь') ?></h1>
<nav class="site-menu scope-menu" aria-label="<?= admin_l('Разделы справки') ?>">
    <a href="#help-data-editor"><?= site_escape($dataHelpTitle) ?></a>
    <a href="#help-service-files"><?= site_escape($maintenanceTopic) ?></a>
    <a href="#help-admin-header"><?= site_escape($headerTopic) ?></a>
    <a href="#help-functions"><?= admin_l('Новое в версии 1.6.3') ?></a>
    <a href="#help-i18n"><?= admin_l('Новое в версии 1.6.2') ?></a>
    <a href="#help-current"><?= admin_l('Новое в версии 1.6.1') ?></a>
    <a href="#help-release"><?= admin_l('Новое в версии 1.6.0') ?></a>
    <a href="#help-admin-faq"><?= admin_l('FAQ по админке') ?></a>
    <?php foreach ($guide as $anchor => $group): ?>
        <a href="#help-<?= site_escape($anchor) ?>"><?= admin_l($group['title']) ?></a>
    <?php endforeach; ?>
</nav>
<div class="form-stack template-guide">
    <section class="panel form-stack">
        <h2><?= admin_l('Мобильное меню') ?> · 1.6.7</h2>
        <ul>
            <?php foreach (admin_page_visibility_labels($adminLanguage) as $visibilityLabel): ?><li><?= site_escape($visibilityLabel) ?></li><?php endforeach; ?>
        </ul>
    </section>
    <section class="panel form-stack" id="help-data-editor">
        <h2><?= site_escape($dataHelpTitle) ?> · 1.6.6</h2>
        <p><?= site_escape($dataHelpText) ?></p>
    </section>
    <section class="panel form-stack" id="help-service-files">
        <h2><?= site_escape($maintenanceTopic) ?> · 1.6.5</h2>
        <p><?= site_escape($serviceText) ?></p>
        <p><?= site_escape($mapsText) ?></p>
        <p><?= site_escape($customLayoutsText) ?></p>
        <p><?= site_escape($externalHelp[$adminLanguage] ?? $externalHelp['ru']) ?></p>
        <p><?= site_escape($editorHelp[$adminLanguage] ?? $editorHelp['ru']) ?></p>
        <p><?= site_escape($routingHelp[$adminLanguage] ?? $routingHelp['ru']) ?></p>
        <pre><code><?= site_escape("[map]\n[maps center=\"55.7558,37.6173\" zoom=11]\n[main-menu]\n[lang]\n[privacy]\n[payment]\n\$var = translit(\"Москва\"); // Moskva") ?></code></pre>
    </section>
    <section class="panel form-stack" id="help-admin-header">
        <h2><?= site_escape($headerTopic) ?> · 1.6.4</h2>
        <p><?= site_escape($headerText) ?></p>
        <p><?= site_escape($navigationHelp[$adminLanguage] ?? $navigationHelp['ru']) ?></p>
        <p><?= site_escape($layoutHelp[$adminLanguage] ?? $layoutHelp['ru']) ?></p>
        <pre><code>[bread-crumbs]
[search]
[privacy]</code></pre>
    </section>
    <section class="panel form-stack" id="help-functions">
        <h2><?= admin_l('Новое в версии 1.6.3') ?></h2>
        <?php foreach ($functionsHelp as $topic => $instructions): ?>
            <div class="help-entry"><h3><?= admin_l($topic) ?></h3><p><?= admin_l($instructions) ?></p></div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack" id="help-i18n">
        <h2><?= admin_l('Новое в версии 1.6.2') ?></h2>
        <?php foreach ($i18nHelp as $topic => $instructions): ?>
            <div class="help-entry"><h3><?= admin_l($topic) ?></h3><p><?= admin_l($instructions) ?></p></div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack" id="help-current">
        <h2><?= admin_l('Новое в версии 1.6.1') ?></h2>
        <?php foreach (($currentHelp[$adminLanguage] ?? $currentHelp['ru']) as $topic => $instructions): ?>
            <div class="help-entry"><h3><?= site_escape($topic) ?></h3><p><?= site_escape($instructions) ?></p></div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack" id="help-release">
        <h2><?= admin_l('Новое в версии 1.6.0') ?></h2>
        <?php foreach ($releaseHelp as $index => list($topic, $instructions)): ?>
            <div class="help-entry">
                <h3><?= site_escape($topic) ?></h3>
                <p><?= site_escape($instructions) ?></p>
                <?php foreach (($releaseExamples[$index] ?? []) as $example): ?>
                    <pre><code><?= site_escape($example) ?></code></pre>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack admin-faq" id="help-admin-faq">
        <h2><?= admin_l('FAQ по админке') ?></h2>
        <?php foreach ($faq as $topic => $questions): ?>
            <section class="faq-topic">
                <h3><?= admin_l($topic) ?></h3>
                <?php foreach ($questions as $question => $answer): ?>
                    <details>
                        <summary><?= admin_l($question) ?></summary>
                        <p><?= admin_l($answer) ?></p>
                    </details>
                <?php endforeach; ?>
            </section>
        <?php endforeach; ?>
    </section>
    <h2><?= admin_l('Помощь по шаблонам и компонентам') ?></h2>
    <?php foreach ($guide as $anchor => $group): ?>
        <section class="panel form-stack" id="help-<?= site_escape($anchor) ?>">
            <h2><?= admin_l($group['title']) ?></h2>
            <?php foreach ($group['entries'] as list($title, $description, $examples)): ?>
                <div class="help-entry">
                    <h3><?= admin_l($title) ?></h3>
                    <p><?= admin_l($description) ?></p>
                    <?php foreach ($examples as $example): ?>
                        <pre><code><?= admin_l($example) ?></code></pre>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endforeach; ?>
</div>
