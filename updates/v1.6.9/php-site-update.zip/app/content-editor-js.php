<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return <<<'JS'
document.querySelectorAll('[data-content-editor]').forEach((editor) => {
    const html = editor.querySelector('[data-editor-source]');
    const frame = editor.querySelector('[data-editor-frame]');
    const form = editor.closest('form');
    const format = editor.querySelector('[data-editor-format]');
    const feedback = editor.querySelector('[data-editor-feedback]');
    const component = editor.querySelector('[data-editor-component]');
    let visual = false;
    let editorDocument = null;
    let range = null;
    let dirty = false;
    let imageTarget = '';

    editor.querySelector('[data-editor-toolbar]').hidden = false;
    format.hidden = false;

    const sync = () => {
        if (editorDocument && dirty) html.value = editorDocument.body.innerHTML;
        dirty = false;
    };
    const updateMode = (next) => {
        visual = next === 'visual';
        if (!visual) sync();
        html.hidden = visual;
        frame.hidden = !visual;
        editor.querySelectorAll('[data-editor-mode]').forEach((button) =>
            button.setAttribute('aria-pressed', String(button.dataset.editorMode === next)));
        if (visual && !frame.hasAttribute('src')) {
            frame.src = frame.dataset.src;
        } else if (visual && editorDocument) {
            range = null;
            editorDocument.body.innerHTML = html.value;
        }
    };
    frame.addEventListener('load', () => {
        if (!frame.hasAttribute('src') || !frame.contentDocument?.body) return;
        editorDocument = frame.contentDocument;
        editorDocument.body.innerHTML = html.value;
        editorDocument.body.contentEditable = 'true';
        editorDocument.addEventListener('input', () => {
            dirty = true;
            editor.dispatchEvent(new CustomEvent('content-source', { detail: editorDocument.body.innerHTML }));
        });
        editorDocument.addEventListener('click', (event) => {
            if (event.target.closest?.('a')) event.preventDefault();
        });
        editorDocument.addEventListener('selectionchange', () => {
            const selection = editorDocument.getSelection();
            if (selection.rangeCount > 0 && editorDocument.body.contains(selection.anchorNode)) {
                range = selection.getRangeAt(0).cloneRange();
            }
        });
    });
    form.addEventListener('submit', sync);
    const visualSelection = () => {
        const selection = editorDocument.getSelection();
        frame.contentWindow.focus();
        editorDocument.body.focus();
        if (range && editorDocument.body.contains(range.startContainer)) {
            selection.removeAllRanges();
            selection.addRange(range);
        }
        return selection;
    };
    const selectParameters = () => {
        if (!component) return;
        const current = component.value.startsWith('extension:') ? 'extension' : component.value;
        editor.querySelectorAll('[data-editor-show]').forEach((field) => {
            field.hidden = !field.dataset.editorShow.split(' ').includes(current)
                || (field.dataset.editorShow === 'extension' && component.selectedOptions[0].dataset.kind !== 'paired');
        });
        feedback.textContent = '';
    };
    selectParameters();
    if (component) component.addEventListener('change', selectParameters);

    const parameter = (key) => editor.querySelector('[data-editor-param="' + key + '"]').value.trim();
    const quote = (value) => '"' + value.replaceAll('"', '”') + '"';
    const build = () => {
        const tag = component.value;
        if (tag === 'banners') {
            const set = parameter('banner-set');
            const folder = parameter('banner-folder');
            if (set && !/^[a-z][a-z0-9_-]{0,63}$/.test(set)) return '';
            if (folder && !/^\/(?:templates\/)?images(?:\/[^\[\]]*)?$/.test(folder)) return '';
            const options = [...editor.querySelectorAll('[data-editor-option]')].filter(input => !input.closest('label').hidden && input.value)
                .map(input => input.dataset.editorOption + '=' + input.value);
            if (set) options.unshift('set=' + set);
            return '[banners' + (options.length ? ' ' + options.join(' ') : '') + ']' + (folder ? folder + '[/banners]' : '');
        }
        if (tag.startsWith('extension:')) {
            const key = tag.slice('extension:'.length);
            const value = parameter('extension-value');
            if (component.selectedOptions[0].dataset.kind !== 'paired') return '[' + key + ']';
            return value && !/[\[\]]/.test(value) ? '[' + key + ']' + value + '[/' + key + ']' : '';
        }
        if (tag === 'php') {
            const name = parameter('module');
            return name ? '[php]' + name + '[/php]' : '';
        }
        if (tag === 'form') {
            const name = parameter('form');
            return /^form[1-9][0-9]{0,8}$/.test(name) ? '[' + name + ']' : '';
        }
        if (tag === 'callback') {
            const fields = ['button', 'title', 'submit', 'placeholder'].filter(parameter)
                .map((field) => field + '=' + quote(parameter(field)));
            return '[callback' + (fields.length ? ' ' + fields.join(' ') : '') + ']';
        }
        if (tag === 'map' || tag === 'maps') {
            const lat = parameter('lat');
            const lng = parameter('lng');
            const fields = [];
            if (tag === 'map' && (lat || lng)) {
                if (!/^-?\d{1,3}(\.\d+)?$/.test(lat) || !/^-?\d{1,3}(\.\d+)?$/.test(lng)
                    || Math.abs(Number(lat)) > 90 || Math.abs(Number(lng)) > 180 || !parameter('title')) return '';
                fields.push('lat=' + lat, 'lng=' + lng);
            }
            const pointOptions = tag === 'map' ? ['title', 'url', 'button'] : [];
            for (const field of ['zoom', 'center', 'provider', 'mode', ...pointOptions]) {
                if (parameter(field)) fields.push(field + '=' + quote(parameter(field)));
            }
            return '[' + tag + (fields.length ? ' ' + fields.join(' ') : '') + ']';
        }
        const path = parameter('path');
        if (!path.startsWith('/') || /[\[\]]/.test(path)) return '';
        if (tag === 'iblock') return '[iblock=' + parameter('layout') + ']' + path + '[/iblock]';
        const params = Array.from(editor.querySelectorAll('[data-editor-option]')).filter((input) => !input.closest('label').hidden && input.value)
            .map((input) => ' ' + input.dataset.editorOption + '=' + input.value).join('');
        return '[' + tag + params + ']' + path + '[/' + tag + ']';
    };
    const escapeMarkup = (value) => value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
    const webUrl = (value) => /^(?:https?:\/\/|\/(?![\/\\]))/i.test(value) && !/[\x00-\x1f\x7f\\]/.test(value);
    const announce = (message) => {
        feedback.textContent = message;
        feedback.hidden = !message;
    };
    const changed = () => {
        if (visual) dirty = true;
        else html.dispatchEvent(new Event('input', {bubbles: true}));
        editor.dispatchEvent(new CustomEvent('content-source', {detail: visual ? editorDocument.body.innerHTML : html.value}));
    };
    const insert = (markup, literal = false) => {
        if (!markup || (visual && !editorDocument)) {
            announce(adminText('Проверьте параметры компонента.'));
            return;
        }
        if (visual) {
            visualSelection();
            editorDocument.execCommand('insertHTML', false, literal ? escapeMarkup(markup) : markup);
        } else {
            html.setRangeText(markup, html.selectionStart, html.selectionEnd, 'end');
            html.focus();
        }
        changed();
        announce(adminText('Код вставлен.'));
    };
    const formatHtml = (command, value) => {
        const start = html.selectionStart;
        const end = html.selectionEnd;
        const selected = html.value.slice(start, end);
        const inlineTags = {bold: 'strong', italic: 'em', underline: 'u', strikeThrough: 's', createLink: 'a'};
        const listTag = {insertUnorderedList: 'ul', insertOrderedList: 'ol'}[command];
        const tag = listTag || (command === 'formatBlock' ? value : inlineTags[command]);
        const opening = command === 'createLink' ? '<a href="' + escapeMarkup(value) + '">' : '<' + tag + '>';
        const inner = listTag ? selected.split(/\r?\n/).map(line => '<li>' + line.trim() + '</li>').join('\n') : selected;
        html.setRangeText(opening + inner + '</' + tag + '>', start, end, 'end');
        if (!selected) html.setSelectionRange(start + opening.length + (listTag ? 4 : 0), start + opening.length + (listTag ? 4 : 0));
        html.focus();
        changed();
    };
    const togglePicker = (button) => {
        const id = button.dataset.editorOpen;
        const expanded = button.getAttribute('aria-expanded') !== 'true';
        editor.querySelectorAll('[data-editor-open]').forEach((item) => item.setAttribute('aria-expanded', String(item === button && expanded)));
        editor.querySelectorAll('[data-editor-picker]').forEach((panel) => { panel.hidden = panel.dataset.editorPicker !== id || !expanded; });
        announce('');
        if (expanded && id === 'image') {
            imageTarget = button.dataset.editorImageTarget || '';
            const imageButton = editor.querySelector('[data-editor-add-image]');
            imageButton.textContent = imageTarget ? imageButton.dataset.useLabel : imageButton.dataset.insertLabel;
            const imageUrl = editor.querySelector('[data-editor-image-url]');
            if (imageTarget) imageUrl.value = document.getElementById(imageTarget).value;
            if (!imageLoaded) browseImages('browse');
        }
        if (expanded) editor.querySelector('[data-editor-picker="' + id + '"] :is(input, select)').focus();
    };
    const imageMarkup = (url, alt) => webUrl(url) ? '<img src="' + escapeMarkup(url) + '" alt="' + escapeMarkup(alt) + '">' : '';
    const library = editor.querySelector('[data-image-library]');
    const imageField = editor.querySelector('[data-editor-image-url]');
    const roots = library.querySelector('[data-image-root]');
    const parentFolder = library.querySelector('[data-image-parent]');
    const pathLabel = library.querySelector('[data-image-path]');
    const imageList = library.querySelector('[data-image-list]');
    const preview = library.querySelector('[data-image-preview]');
    const thumbnail = library.querySelector('[data-image-thumbnail]');
    const dimensions = library.querySelector('[data-image-size]');
    const imageStatus = library.querySelector('[data-image-library-status]');
    const valueIn = (key) => library.querySelector('[data-image-' + key + ']').value;
    let folder = roots.value;
    let activeImage = null;
    let imageLoaded = false;
    let imageBusy = false;

    const imageFeedback = (message) => {
        imageStatus.textContent = message;
        imageStatus.hidden = !message;
    };
    const selectImage = (item) => {
        activeImage = item;
        preview.hidden = !item;
        imageList.querySelectorAll('[aria-pressed]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.name === item?.name)));
        if (!item) return;
        imageField.value = item.url;
        thumbnail.src = item.url;
        dimensions.textContent = '';
        ['width', 'height'].forEach(key => { library.querySelector('[data-image-' + key + ']').value = ''; });
        library.querySelector('[data-image-angle]').value = '0';
    };
    thumbnail.addEventListener('load', () => { dimensions.textContent = thumbnail.naturalWidth + ' × ' + thumbnail.naturalHeight; });
    const renderImages = (result) => {
        folder = result.path;
        pathLabel.textContent = folder + '/';
        parentFolder.disabled = folder === roots.value;
        const selected = result.selected || activeImage?.name;
        imageList.replaceChildren(...result.items.map(item => {
            const row = document.createElement('li');
            const choose = document.createElement('button');
            choose.type = 'button';
            choose.textContent = (item.type === 'directory' ? '▸ ' : '') + item.name;
            choose.dataset.name = item.name;
            if (item.type === 'image') choose.setAttribute('aria-pressed', 'false');
            choose.addEventListener('click', () => {
                if (item.type === 'directory') {
                    selectImage(null);
                    browseImages('browse', {}, folder + '/' + item.name);
                } else selectImage(item);
            });
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.textContent = '×';
            remove.title = adminText('Удалить') + ' ' + item.name;
            remove.setAttribute('aria-label', remove.title);
            remove.addEventListener('click', () => {
                if (window.confirm(library.dataset.deleteTitle + '\n' + item.name)) browseImages('delete', {name:item.name});
            });
            row.append(choose, remove);
            return row;
        }));
        selectImage(result.items.find(item => item.type === 'image' && item.name === selected) || null);
    };
    const requestImages = async (operation, fields, path) => {
        const data = new FormData();
        Object.entries({action:'image-library', csrf:editor.dataset.editorCsrf, operation, path, ...fields})
            .forEach(([key, value]) => data.append(key, value));
        const response = await fetch(editor.dataset.editorAdminUrl, {method:'POST', body:data, headers:{Accept:'application/json'}});
        if (!response.headers.get('Content-Type')?.includes('application/json')) throw new Error(library.dataset.errorText);
        const payload = await response.json();
        if (!response.ok || !payload.ok) throw new Error(payload.message || library.dataset.errorText);
        imageLoaded = true;
        renderImages(payload);
    };
    async function browseImages(operation, fields = {}, path = folder, files = []) {
        if (imageBusy) return;
        imageBusy = true;
        library.setAttribute('aria-busy', 'true');
        try {
            imageFeedback('');
            if (files.length) {
                for (const file of files) await requestImages(operation, {upload:file}, path);
            } else await requestImages(operation, fields, path);
        } catch (error) {
            imageFeedback(error.message || library.dataset.errorText);
        } finally {
            imageBusy = false;
            library.removeAttribute('aria-busy');
        }
    }
    roots.addEventListener('change', () => { selectImage(null); browseImages('browse', {}, roots.value); });
    parentFolder.addEventListener('click', () => { selectImage(null); browseImages('browse', {}, folder.slice(0, folder.lastIndexOf('/'))); });
    library.querySelector('[data-image-mkdir]').addEventListener('click', () => {
        const name = valueIn('folder-name').trim();
        if (name) browseImages('mkdir', {name});
    });
    library.querySelector('[data-image-upload-button]').addEventListener('click', () => {
        const upload = library.querySelector('[data-image-upload]');
        const files = [...upload.files];
        if (files.length) browseImages('upload', {}, folder, files);
    });
    library.querySelector('[data-image-transform]').addEventListener('click', () => {
        if (activeImage) browseImages('transform', {name:activeImage.name, width:valueIn('width'), height:valueIn('height'), rotate:valueIn('angle')});
    });

    const iconPicker = editor.querySelector('[data-editor-fa-picker]');
    const knownIcons = iconPicker ? [...iconPicker.querySelectorAll('[data-editor-fa-catalog] option')].map(option => option.value) : [];
    if (iconPicker) {
        const search = iconPicker.querySelector('[data-editor-fa-icon]');
        const results = iconPicker.querySelector('[data-editor-fa-results]');
        const more = iconPicker.querySelector('[data-editor-fa-more]');
        let limit = 48;
        const show = () => {
            const filter = search.value.toLowerCase().trim();
            const matches = knownIcons.filter(icon => icon.includes(filter));
            results.replaceChildren(...matches.slice(0, limit).map(name => {
                const button = document.createElement('button');
                const glyph = document.createElement('i');
                const [style, icon] = name.split(':');
                button.type = 'button';
                button.dataset.editorFaChoice = name;
                button.title = name;
                button.setAttribute('aria-label', name);
                glyph.classList.add('fa-' + style, 'fa-' + icon);
                glyph.setAttribute('aria-hidden', 'true');
                button.append(glyph);
                return button;
            }));
            more.hidden = matches.length <= limit;
        };
        iconPicker.addEventListener('toggle', () => { if (iconPicker.open) show(); });
        search.addEventListener('input', () => { limit = 48; show(); });
        more.addEventListener('click', () => { limit += 48; show(); });
        results.addEventListener('click', (event) => {
            const icon = event.target.closest('[data-editor-fa-choice]');
            if (icon) { search.value = icon.dataset.editorFaChoice; insert('[fa-icon=' + search.value + ']', true); }
        });
    }
    editor.addEventListener('click', (event) => {
        const mode = event.target.closest('[data-editor-mode]');
        const command = event.target.closest('[data-editor-command]');
        const picker = event.target.closest('[data-editor-open]');
        if (mode) {
            updateMode(mode.dataset.editorMode);
        } else if (picker) {
            togglePicker(picker);
        } else if (event.target.closest('[data-editor-code]')) {
            insert(event.target.closest('[data-editor-code]').dataset.editorCode, true);
        } else if (command && (!visual || editorDocument)) {
            let value = command.dataset.editorValue || null;
            if (command.dataset.editorCommand === 'createLink') {
                value = window.prompt(adminText('Введите адрес ссылки'));
                if (!value || (!webUrl(value) && !/^#[^\s]*$/.test(value))) return;
            }
            if (visual) {
                visualSelection();
                editorDocument.execCommand(command.dataset.editorCommand, false, value);
                changed();
            } else {
                formatHtml(command.dataset.editorCommand, value);
            }
        } else if (event.target.closest('[data-editor-insert-button]')) {
            insert(build(), true);
        } else if (event.target.closest('[data-editor-add-template]')) {
            const value = editor.querySelector('[data-editor-template]').value;
            insert(value ? '[' + value + ']' : '', true);
        } else if (event.target.closest('[data-editor-add-image]')) {
            const url = imageField.value.trim();
            if (imageTarget && webUrl(url)) {
                const prefix = editor.dataset.editorBase;
                document.getElementById(imageTarget).value = prefix && url.startsWith(prefix + '/') ? url.slice(prefix.length) : url;
                announce(adminText('Код вставлен.'));
            } else insert(imageMarkup(url, editor.querySelector('[data-editor-image-alt]').value));
        } else if (event.target.closest('[data-editor-add-system-icon]')) {
            const value = editor.querySelector('[data-editor-system-icon]').value;
            if (value.startsWith('/')) insert(imageMarkup(value, ''));
            else insert(value ? '[' + value + ']' : '', true);
        } else if (event.target.closest('[data-editor-add-fa]')) {
            const icon = editor.querySelector('[data-editor-fa-icon]');
            const selected = knownIcons.includes(icon.value.trim());
            insert(selected ? '[fa-icon=' + icon.value.trim() + ']' : '', true);
        }
    });
});
JS;
