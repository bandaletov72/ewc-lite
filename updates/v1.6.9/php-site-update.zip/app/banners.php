<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_BANNERS_FILE = SITE_ROOT . '/admin/.banners.php';
const SITE_BANNERS_LIMIT = 2097152;

function site_banner_sets(): array
{
    return site_read_record(SITE_BANNERS_FILE, SITE_BANNERS_LIMIT);
}

function site_banner_id(string $name, string $folder): string
{
    return $name !== '' ? $name : ($folder === '' ? 'main' : 'folder-' . substr(hash('sha256', site_asset_path($folder, 'images')), 0, 20));
}

function site_banner_fonts(): array
{
    return ['site' => '', 'sans' => 'system-ui, sans-serif', 'serif' => 'Georgia, serif', 'mono' => 'Consolas, monospace'];
}

function site_banner_slide_defaults(): array
{
    return ['image' => '', 'color' => '#263440', 'textColor' => '#ffffff', 'title' => '', 'caption' => '', 'font' => 'site',
        'align' => 'left', 'url' => '', 'button' => '', 'action' => 'none', 'buttonUrl' => '', 'form' => '',
        'active' => true, 'from' => '', 'until' => '', 'excluded' => false];
}

function site_banner_slides(array $set, string $folder): array
{
    $slides = [];
    $defaults = site_banner_slide_defaults();
    $stored = $set['slides'] ?? [];
    if ($folder !== '') {
        $path = site_asset_path($folder, 'images');
        if ($path !== '') {
            foreach (site_asset_files($folder, '', 'images', site_component_asset_extensions('gal')) as $image) {
                $key = 'f-' . substr(hash('sha256', $path . '/' . $image['name']), 0, 20);
                $slides[$key] = array_replace($defaults, ['image' => $image['url']], $stored[$key] ?? []);
            }
        }
    }
    foreach ($stored as $key => $slide) {
        if (strpos($key, 's-') === 0) {
            $slides[$key] = array_replace($defaults, $slide);
        }
    }
    $ordered = [];
    foreach ($set['order'] ?? [] as $key) {
        if (isset($slides[$key])) {
            $ordered[$key] = $slides[$key];
        }
    }
    return $ordered + $slides;
}

function site_banner_visible(array $slide, string $now): bool
{
    return $slide['active'] && !$slide['excluded'] && ($slide['from'] === '' || $slide['from'] <= $now)
        && ($slide['until'] === '' || $now < $slide['until']);
}

function site_banner_url(string $base, string $url): string
{
    return $url !== '' && $url[0] === '/' ? site_url($base, substr($url, 1)) : $url;
}

function site_banner_admin_url(string $base, string $set, string $folder = '', array $extra = []): string
{
    $query = ['components' => '1', 'banner' => $set] + ($folder !== '' ? ['folder' => $folder] : []) + $extra;
    return site_url($base, 'admin/') . '?' . http_build_query($query);
}

function site_component_banners(string $argument, string $folder, array &$context): string
{
    $params = site_shortcode_options($argument);
    $name = $params['set'] ?? '';
    $folder = trim($folder);
    if (($name !== '' && !site_valid_snippet($name)) || ($folder !== '' && site_asset_path($folder, 'images') === '')) {
        return '';
    }
    $setId = site_banner_id($name, $folder);
    if (!empty($context['activeBanners'][$setId]) || count($context['activeBanners'] ?? []) >= SITE_MAX_INCLUDE_DEPTH) {
        return '';
    }
    try {
        if (!isset($context['bannerSets'])) {
            $context['bannerSets'] = site_banner_sets();
        }
    } catch (RuntimeException $exception) {
        return '';
    }
    $set = $context['bannerSets'][$setId] ?? [];
    $folder = $folder !== '' ? $folder : ($set['folder'] ?? '');
    $now = date('Y-m-d\TH:i');
    $slides = array_filter(site_banner_slides($set, $folder), static function (array $slide) use ($now): bool { return site_banner_visible($slide, $now); });
    $editing = !empty($context['bannerEdit']);
    if (!$slides && !$editing) {
        return '';
    }
    $context['activeBanners'][$setId] = true;
    $options = site_component_options('banners', $argument);
    $base = $context['base'];
    $locale = $context['locale'];
    $instance = 'banners-' . bin2hex(random_bytes(6));
    $bufferLevel = ob_get_level();
    ob_start();
    try {
        require site_template_file('components/banners.php');
        return (string) ob_get_clean();
    } finally {
        while (ob_get_level() > $bufferLevel) ob_end_clean();
        unset($context['activeBanners'][$setId]);
    }
}
