<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

if (!$settings['breadcrumbs'] || $searchMode || $page['path'] === '' || ($originalPath === 'index.php' && empty($context['embeddedLayout']))) {
    return;
}
$directory = dirname($originalPath);
$ancestors = [];
while ($directory !== '.') {
    $ancestor = $directory . '/index.php';
    if ($ancestor !== $originalPath) {
        $entry = site_localized_page($ancestor, $locale);
        if ($entry !== null) {
            $ancestors[$ancestor] = site_expand_text($entry['fields']['Title'], $snippets);
        }
    }
    $directory = dirname($directory);
}
$home = site_localized_page('index.php', $locale);
$homeLabel = $home === null ? 'Главная' : site_expand_text($home['fields']['Title'], $snippets);
$links = $originalPath === 'index.php' ? [] : ['index.php' => $homeLabel] + array_reverse($ancestors, true);
?>
<nav class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>breadcrumbs" aria-label="<?= site_escape(site_translation('Хлебные крошки', $locale)) ?>">
    <ol>
        <?php foreach ($links as $ancestor => $label): ?>
            <li><a href="<?= site_escape(site_page_url($base, $ancestor)) ?>"><?= site_escape($label) ?></a></li>
        <?php endforeach; ?>
        <li aria-current="page"><?= site_escape($title) ?></li>
    </ol>
</nav>
