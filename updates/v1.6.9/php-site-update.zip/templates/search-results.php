<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if (!isset($searchIndex['built'])): ?>
    <p><?= site_escape(site_translation('Поиск пока недоступен.', $locale)) ?></p>
<?php elseif ($searchQuery === ''): ?>
    <p><?= site_escape(site_translation('Введите запрос.', $locale)) ?></p>
<?php elseif (!$searchResults): ?>
    <p><?= site_escape(site_translation('Ничего не найдено.', $locale)) ?></p>
<?php else: ?>
    <ol class="site-search-results" start="<?= $searchOffset + 1 ?>">
        <?php foreach ($searchResults as $result): ?>
            <li>
                <a href="<?= site_escape(site_page_url($base, $result['path'])) ?>"><?= site_escape($result['title']) ?></a>
                <?php if ($result['description'] !== ''): ?><p><?= site_escape($result['description']) ?></p><?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ol>
<?php endif; ?>
<?php if (isset($searchIndex['built']) && $searchQuery !== '' && ($searchPage > 1 || $searchHasNext)): ?>
    <?php $searchLink = static function (int $number) use ($base, $searchQuery): string {
        return site_escape(site_url($base) . '?' . http_build_query(['search' => $searchQuery, 'search_page' => $number]));
    }; ?>
    <nav class="site-menu search-pagination" aria-label="<?= site_escape(site_translation('Страницы результатов поиска', $locale)) ?>">
        <?php if ($searchPage > 1): ?>
            <a rel="prev" href="<?= $searchLink($searchPage - 1) ?>"><?= site_escape(site_translation('Назад', $locale)) ?></a>
        <?php endif; ?>
        <span aria-current="page"><?= site_escape(str_replace('{page}', (string) $searchPage, site_translation('Страница {page}', $locale))) ?></span>
        <?php if ($searchHasNext): ?>
            <a rel="next" href="<?= $searchLink($searchPage + 1) ?>"><?= site_escape(site_translation('Далее', $locale)) ?></a>
        <?php endif; ?>
    </nav>
<?php endif; ?>
