<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
if (!$navigation) {
    return;
}
$tree = site_page_tree($navigation);
$render = static function (string $parent, string $landing = '') use (&$render, $tree, $base, $originalPath, $snippets) {
    echo '<ul>';
    if ($landing !== '') {
        echo '<li>' . $landing . '</li>';
    }
    foreach ($tree[$parent] ?? [] as $node) {
        $page = $node['page'];
        $folder = $node['folder'];
        $label = $page ? site_expand_text($page['fields']['Menu'] ?: $page['fields']['Title'], $snippets) : basename($folder);
        $link = $page ? '<a href="' . site_escape(site_page_url($base, $page['path'])) . '"'
            . ($originalPath === $page['path'] ? ' aria-current="page"' : '') . '>' . site_escape($label) . '</a>' : '';
        echo '<li>';
        if ($folder !== '' && !empty($tree[$folder])) {
            echo '<details><summary>' . site_escape($label) . '</summary>';
            $render($folder, $link);
            echo '</details>';
        } else {
            echo $link;
        }
        echo '</li>';
    }
    echo '</ul>';
};
?>
<nav class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>public-main-menu" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
    <?php $render('.'); ?>
</nav>
