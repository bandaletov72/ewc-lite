<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_save_maps(array $draft, string $revision)
{
    if (!isset(site_map_providers()[$draft['provider']], site_map_modes()[$draft['mode']])
        || !preg_match('/\A(?:[1-9]|1[0-9]|20)\z/', $draft['zoom'])) {
        throw new RuntimeException('Проверьте провайдера, режим и масштаб карты.');
    }
    foreach (['yandex_key', 'google_key', 'google_map_id'] as $key) {
        if ($draft[$key] !== '' && !preg_match('/\A[A-Za-z0-9_-]{1,256}\z/', $draft[$key])) {
            throw new RuntimeException('Проверьте ключ карты или Google Map ID.');
        }
    }
    if (($draft['provider'] === 'yandex' && $draft['yandex_key'] === '')
        || ($draft['provider'] === 'google' && ($draft['google_key'] === '' || $draft['google_map_id'] === ''))) {
        throw new RuntimeException('Укажите API-ключ выбранного провайдера. Для Google Maps также нужен Map ID.');
    }
    $lock = admin_lock();
    try {
        site_read_record(SITE_MAPS_FILE);
        if (!hash_equals(admin_settings_revision(site_map_settings()), $revision)) {
            throw new RuntimeException('Настройки карт изменились. Откройте раздел заново.');
        }
        admin_write_record(SITE_MAPS_FILE, $draft);
    } finally {
        fclose($lock);
    }
}

function admin_save_integrations(array $input, string $revision)
{
    $lock = admin_lock();
    try {
        $settings = site_read_record(SITE_INTEGRATIONS_FILE, 65536);
        if (!hash_equals(admin_settings_revision($settings), $revision)) {
            throw new RuntimeException('Интеграции изменились. Откройте раздел заново.');
        }
        foreach (site_integration_catalog() as $key => $service) {
            if (!array_key_exists($key . '_id', $input)) {
                continue;
            }
            $id = trim(admin_input($input, $key . '_id'));
            $enabled = admin_input($input, $key . '_enabled') === '1';
            if (($enabled || $id !== '') && !preg_match($service[2], $id)) {
                throw new RuntimeException('Проверьте идентификатор сервиса «' . $service[0] . '».');
            }
            $settings[$key] = ['enabled' => $enabled, 'id' => $id];
        }
        if (isset($input['botfaqtor_code'])) {
            $code = trim(admin_input($input, 'botfaqtor_code'));
            $enabled = admin_input($input, 'botfaqtor_enabled') === '1';
            if (($enabled || $code !== '') && !site_valid_botfaqtor_code($code)) {
                throw new RuntimeException('Вставьте код счётчика Botfaqtor из личного кабинета.');
            }
            $settings['botfaqtor'] = ['enabled' => $enabled, 'code' => $code];
        }
        if (isset($input['slack_url'])) {
            $url = trim(admin_input($input, 'slack_url'));
            $enabled = admin_input($input, 'slack_enabled') === '1';
            if (admin_input($input, 'slack_clear') === '1') {
                unset($settings['slack_url']);
                $enabled = false;
            } elseif ($url !== '') {
                if (!site_slack_webhook($url)) {
                    throw new RuntimeException('Проверьте URL Slack Incoming Webhook.');
                }
                $settings['slack_url'] = $url;
            }
            if ($enabled && empty($settings['slack_url'])) {
                throw new RuntimeException('Укажите URL Slack Incoming Webhook.');
            }
            $settings['slack_enabled'] = $enabled;
        }
        if (is_array($input['payments'] ?? null)) {
            foreach (site_payment_methods() as $key => list($label, $hosts)) {
                $url = trim(admin_input($input['payments'], $key));
                if ($url !== '' && !site_valid_payment_url($url, $hosts)) {
                    throw new RuntimeException('Проверьте платёжную ссылку ' . $label . '.');
                }
                $settings['payments'][$key] = $url;
            }
        }
        foreach (['zadarma_key', 'zadarma_secret', 'telegram_token'] as $key) {
            $value = trim(admin_input($input, $key));
            if ($value !== '') {
                $pattern = $key === 'telegram_token' ? '/\A[0-9]+:[A-Za-z0-9_-]{16,100}\z/' : '/\A[A-Za-z0-9_+\/=.-]{1,256}\z/';
                if (!preg_match($pattern, $value) || ($key === 'zadarma_key' && !preg_match('/\A[A-Za-z0-9_-]+\z/', $value))) {
                    throw new RuntimeException('Проверьте формат ключа или токена.');
                }
                $settings[$key] = $value;
            }
        }
        if (isset($input['webhook_url'])) {
            $url = trim(admin_input($input, 'webhook_url'));
            $parts = $url !== '' ? parse_url($url) : [];
            if ($url !== '' && (strlen($url) > 2048 || !filter_var($url, FILTER_VALIDATE_URL) || ($parts['scheme'] ?? '') !== 'https'
                || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment']))) {
                throw new RuntimeException('Укажите HTTPS-адрес HTTP API без пароля или фрагмента URL.');
            }
            $settings['webhook_url'] = $url;
            $token = trim(admin_input($input, 'webhook_token'));
            if ($token !== '' && (strlen($token) > 512 || preg_match('/[\x00-\x20\x7f]/', $token))) {
                throw new RuntimeException('Проверьте токен HTTP API.');
            }
            if (admin_input($input, 'webhook_clear_token') === '1') {
                unset($settings['webhook_token']);
            } elseif ($token !== '') {
                $settings['webhook_token'] = $token;
            }
        }
        $settings['telegram_chat'] = trim(admin_input($input, 'telegram_chat'));
        $settings['telegram_enabled'] = admin_input($input, 'telegram_enabled') === '1';
        if (($settings['telegram_enabled'] || $settings['telegram_chat'] !== '')
            && !preg_match('/\A(?:-?[0-9]{1,20}|@[A-Za-z0-9_]{5,32})\z/', $settings['telegram_chat'])) {
            throw new RuntimeException('Укажите ID чата или публичное имя канала Telegram.');
        }
        if ($settings['telegram_enabled'] && empty($settings['telegram_token'])) {
            throw new RuntimeException('Для Telegram укажите токен бота.');
        }
        admin_write_record(SITE_INTEGRATIONS_FILE, $settings, 65536);
    } finally {
        fclose($lock);
    }
}

function admin_test_zadarma(array $input, callable $transport = null): string
{
    $operation = admin_input($input, 'operation');
    if ($operation === 'balance') {
        $request = site_zadarma_request('/v1/info/balance/');
    } elseif (in_array($operation, ['sms', 'call'], true)) {
        $phone = preg_replace('/[ ().-]/', '', trim(admin_input($input, 'number')));
        if (!preg_match('/\A\+?[1-9][0-9]{6,14}\z/', $phone) || admin_input($input, 'confirm_send') !== '1') {
            throw new RuntimeException('Укажите международный номер и подтвердите отправку теста.');
        }
        $phone = ltrim($phone, '+');
        if ($operation === 'sms') {
            $message = trim(admin_input($input, 'sms_text')) ?: 'Test message from Eurowebcart CMS Light';
            $sender = trim(admin_input($input, 'sms_sender'));
            if (strlen($message) > 160 || preg_match('//u', $message) !== 1 || preg_match('/[\x00-\x1F\x7F]/', $message)
                || ($sender !== '' && !preg_match('/\A\+?[A-Za-z0-9 ._-]{1,32}\z/', $sender))) {
                throw new RuntimeException('Проверьте текст и отправителя SMS.');
            }
            $parameters = ['number' => $phone, 'message' => $message];
            if ($sender !== '') {
                $parameters['sender'] = $sender;
            }
            $request = site_zadarma_request('/v1/sms/send/', $parameters, 'POST');
        } else {
            $from = site_callback_settings()['from'];
            if ($from === '') {
                throw new RuntimeException('Проверьте ключи Zadarma и номер или добавочный оператора.');
            }
            $request = site_zadarma_request('/v1/request/callback/', ['from' => $from, 'to' => $phone]);
        }
    } else {
        throw new RuntimeException('Выберите тест Zadarma.');
    }

    list($http, $body) = ($transport ?? 'site_callback_transport')($request);
    $response = is_string($body) ? json_decode($body, true) : null;
    if ($http < 200 || $http >= 300 || ($response['status'] ?? '') !== 'success'
        || ($operation === 'sms' && ((int) ($response['messages'] ?? 0) < 1 || !empty($response['denied_numbers'])))) {
        throw new RuntimeException($http ? 'Zadarma · HTTP ' . $http . ' · ' . admin_t('Запрос отклонён.') : admin_t('Телефония не ответила вовремя.'));
    }
    if ($operation === 'balance' && is_numeric($response['balance'] ?? null) && is_string($response['currency'] ?? null)
        && preg_match('/\A[A-Z]{3}\z/', $response['currency'])) {
        return 'Zadarma · ' . $response['balance'] . ' ' . $response['currency'];
    }
    return 'Zadarma · ' . ($operation === 'sms' ? 'SMS' : ($operation === 'call' ? 'Call' : 'Balance')) . ' · ' . ($operation === 'balance' ? '—' : 'OK');
}
