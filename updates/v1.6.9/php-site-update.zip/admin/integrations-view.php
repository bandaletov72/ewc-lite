<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$maps = $mapsDraft ?? site_map_settings();
$services = site_integration_settings();
$credentialGuides = [
    'metrica' => ['https://yandex.ru/support/metrica/ru/general/creating-counter', admin_t('Создать счётчик Яндекс Метрики')],
    'analytics' => ['https://support.google.com/analytics/answer/12270356?hl=ru', admin_t('Найти идентификатор G-…')],
    'pixel' => ['https://developers.facebook.com/documentation/meta-pixel/get-started', admin_t('Получить ID Meta Pixel')],
    'cloudflare' => ['https://developers.cloudflare.com/web-analytics/get-started/', admin_t('Найти токен Web Analytics')],
    'jivo' => ['https://www.jivochat.com/help/installation/find-code.html', 'JivoSite · Widget ID'],
    'clarity' => ['https://learn.microsoft.com/en-us/clarity/setup-and-installation/clarity-setup', 'Clarity · Project ID'],
    'umami' => ['https://docs.umami.is/docs/collect-data', 'Umami · Website ID'],
];
?>
<h1><?= admin_l('Интеграции') ?></h1>
<div class="form-stack">
    <section class="panel form-stack" id="maps">
        <h2><?= admin_l('Яндекс Карты и Google Maps') ?></h2>
        <form class="form-stack" method="post" action="<?= site_escape($integrationsUrl) ?>#maps">
            <input type="hidden" name="action" value="save-maps">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($mapsRevision ?? admin_settings_revision($maps)) ?>">
            <div class="fields">
                <?php foreach (['provider' => [admin_t('Провайдер'), site_map_providers()], 'mode' => [admin_t('Режим'), site_map_modes()]] as $key => $select): ?>
                    <label class="field"><?= admin_l($select[0]) ?>
                        <select name="<?= $key ?>">
                            <?php foreach ($select[1] as $value => $label): ?>
                                <option value="<?= $value ?>"<?= $maps[$key] === $value ? ' selected' : '' ?>><?= admin_l($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
                <label class="field"><?= admin_l('Масштаб') ?> <input type="number" name="zoom" min="1" max="20" value="<?= site_escape($maps['zoom']) ?>" required></label>
                <label class="choice"><input type="checkbox" name="cluster" value="1"<?= $maps['cluster'] === '1' ? ' checked' : '' ?>> <?= admin_l('Кластеризация точек') ?></label>
                <?php foreach (['yandex_key' => admin_t('API-ключ Яндекс Карт'), 'google_key' => admin_t('API-ключ Google Maps'), 'google_map_id' => 'Google Map ID'] as $key => $label): ?>
                    <label class="field"><?= $label ?><input name="<?= $key ?>" value="<?= site_escape($maps[$key]) ?>" maxlength="256" autocomplete="off"></label>
                <?php endforeach; ?>
            </div>
            <code>[map lat=55.7558 lng=37.6173 title="Офис" zoom=13 provider=yandex mode=map url="/contacts/" button="Связаться"]</code>
            <code>[map]</code>
            <code>[maps center="55.7558,37.6173" zoom=11]</code>
            <small class="hint"><?= admin_l('Все точки страницы выводятся на карте в месте первой вставки. Первой точкой задаются общий режим, провайдер и масштаб. Ключи карт используются в браузере. Ограничьте их доменами в кабинете провайдера.') ?></small>
            <div class="header-actions">
                <a href="https://yandex.ru/maps-api/console" target="_blank" rel="noopener noreferrer"><?= admin_l('Получить ключ Яндекс Карт') ?></a>
                <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank" rel="noopener noreferrer"><?= admin_l('Получить ключ Google Maps') ?></a>
                <a href="https://developers.google.com/maps/documentation/javascript/map-ids/get-map-id" target="_blank" rel="noopener noreferrer"><?= admin_l('Создать Google Map ID') ?></a>
            </div>
            <div><button class="button-primary" type="submit"><?= admin_l('Сохранить настройки карт') ?></button></div>
        </form>
    </section>
    <form class="panel form-stack" method="post" action="<?= site_escape($integrationsUrl) ?>#services" id="services">
        <h2><?= admin_l('Внешние сервисы') ?></h2>
        <input type="hidden" name="action" value="save-integrations">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($services)) ?>">
        <div class="fields">
            <?php foreach (site_integration_catalog() as $key => $item): ?>
                <fieldset class="field-config form-stack">
                    <legend><?= admin_l($item[0]) ?></legend>
                    <label class="choice"><input type="checkbox" name="<?= $key ?>_enabled" value="1"<?= !empty($services[$key]['enabled']) ? ' checked' : '' ?>> <?= admin_l('Подключить') ?></label>
                    <label class="field"><?= admin_l($item[1]) ?>
                        <input name="<?= $key ?>_id" value="<?= site_escape($services[$key]['id'] ?? '') ?>" maxlength="96">
                    </label>
                    <a href="<?= site_escape($credentialGuides[$key][0]) ?>" target="_blank" rel="noopener noreferrer"><?= admin_l($credentialGuides[$key][1]) ?></a>
                </fieldset>
            <?php endforeach; ?>
            <fieldset class="field-config form-stack">
                <legend>Botfaqtor</legend>
                <label class="choice"><input type="checkbox" name="botfaqtor_enabled" value="1"<?= !empty($services['botfaqtor']['enabled']) ? ' checked' : '' ?>> <?= admin_l('Подключить') ?></label>
                <label class="field">Botfaqtor <?= admin_l('Код') ?>
                    <textarea name="botfaqtor_code" class="short-editor" maxlength="16384" spellcheck="false" rows="4"><?= "\n" . site_escape($services['botfaqtor']['code'] ?? '') ?></textarea>
                </label>
                <a href="https://botfaqtor.ru/blog/docs/add-counter/" target="_blank" rel="noopener noreferrer">Botfaqtor · Setup</a>
            </fieldset>
            <fieldset class="field-config form-stack">
                <legend>Slack</legend>
                <label class="choice"><input type="checkbox" name="slack_enabled" value="1"<?= !empty($services['slack_enabled']) ? ' checked' : '' ?>> <?= admin_l('Уведомлять о новых заявках') ?></label>
                <label class="field">Incoming Webhook URL <input type="password" name="slack_url" maxlength="300" autocomplete="new-password"></label>
                <?php if (!empty($services['slack_url'])): ?>
                    <label class="choice"><input type="checkbox" name="slack_clear" value="1"> <?= admin_l('Удалить сохранённый токен') ?></label>
                <?php endif; ?>
                <small class="hint"><?= admin_l('Сообщение содержит код формы и адрес страницы. Содержимое заявки остаётся в админке.') ?></small>
                <a href="https://api.slack.com/messaging/webhooks" target="_blank" rel="noopener noreferrer">Slack · Incoming Webhooks</a>
            </fieldset>
            <fieldset class="field-config form-stack">
                <legend>Zadarma</legend>
                <label class="field"><?= admin_l('API-ключ') ?> <input type="password" name="zadarma_key" maxlength="256" autocomplete="new-password"></label>
                <label class="field"><?= admin_l('Секретный ключ') ?> <input type="password" name="zadarma_secret" maxlength="256" autocomplete="new-password"></label>
                <small class="hint"><?= admin_l('Пустое поле сохраняет ключ. Можно также задать ключи через переменные окружения.') ?></small>
                <a href="https://my.zadarma.com/" target="_blank" rel="noopener noreferrer"><?= admin_l('Кабинет Zadarma → Настройки → Ключи и API') ?></a>
            </fieldset>
            <fieldset class="field-config form-stack">
                <legend><?= admin_l('HTTP API обратного звонка') ?></legend>
                <label class="field"><?= admin_l('HTTPS-адрес') ?> <input type="url" name="webhook_url" value="<?= site_escape($services['webhook_url'] ?? '') ?>" maxlength="2048"></label>
                <label class="field"><?= admin_l('Токен') ?> <input type="password" name="webhook_token" maxlength="512" autocomplete="new-password"></label>
                <label class="choice"><input type="checkbox" name="webhook_clear_token" value="1"> <?= admin_l('Удалить сохранённый токен') ?></label>
                <small class="hint"><?= admin_l('Пустое поле токена сохраняет введённое значение. При отсутствии сохранённого значения используется переменная окружения.') ?></small>
            </fieldset>
            <fieldset class="field-config form-stack">
                <legend>Telegram</legend>
                <label class="choice"><input type="checkbox" name="telegram_enabled" value="1"<?= !empty($services['telegram_enabled']) ? ' checked' : '' ?>> <?= admin_l('Уведомлять о новых заявках') ?></label>
                <label class="field"><?= admin_l('Токен бота') ?> <input type="password" name="telegram_token" maxlength="128" autocomplete="new-password"></label>
                <label class="field"><?= admin_l('ID чата или @канал') ?> <input name="telegram_chat" maxlength="36" value="<?= site_escape($services['telegram_chat'] ?? '') ?>"></label>
                <small class="hint"><?= admin_l('Сообщение содержит код формы и адрес страницы. Содержимое заявки остаётся в админке.') ?></small>
                <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer"><?= admin_l('Получить токен у BotFather') ?></a>
                <a href="https://core.telegram.org/bots/features#botfather" target="_blank" rel="noopener noreferrer"><?= admin_l('Инструкция Telegram') ?></a>
            </fieldset>
        </div>
        <fieldset class="field-config form-stack" id="payments">
            <legend><?= admin_l('Оплата') ?> <code>[payment]</code></legend>
            <?php foreach (site_payment_methods() as $key => list($name, $hosts, $guide)): ?>
                <label class="field"><?= site_escape($name) ?>
                    <input type="url" name="payments[<?= $key ?>]" maxlength="2048" value="<?= site_escape($services['payments'][$key] ?? '') ?>" placeholder="https://<?= site_escape($hosts[0]) ?>/…">
                </label>
                <a href="<?= site_escape($guide) ?>" target="_blank" rel="noopener noreferrer"><?= site_escape($name) ?> · <?= admin_l('Инструкция') ?></a>
            <?php endforeach; ?>
        </fieldset>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить внешние сервисы') ?></button></div>
    </form>
    <form class="panel form-stack" id="zadarma-tests" method="post" action="<?= site_escape($integrationsUrl) ?>#zadarma-tests">
        <h2>Zadarma · <?= admin_l('Тестирование') ?></h2>
        <input type="hidden" name="action" value="zadarma-test">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <div class="fields">
            <label class="field"><?= admin_l('Телефон') ?><input type="tel" name="number" maxlength="32" autocomplete="off" placeholder="+79001234567"></label>
            <label class="field">SMS Sender ID <input name="sms_sender" maxlength="33" autocomplete="off"></label>
            <label class="field field-wide">SMS <input name="sms_text" maxlength="160" placeholder="Test message from Eurowebcart CMS Light"></label>
            <label class="choice field-wide"><input type="checkbox" name="confirm_send" value="1"> <?= admin_l('Подтверждаю тестовую отправку SMS или звонок. Операция может быть платной.') ?></label>
        </div>
        <div class="header-actions">
            <button class="button-primary" type="submit" name="operation" value="balance" formnovalidate><?= admin_l('Получить баланс') ?></button>
            <button type="submit" name="operation" value="sms"><?= admin_l('Тест SMS') ?></button>
            <button type="submit" name="operation" value="call"><?= admin_l('Тест звонка') ?></button>
        </div>
        <a href="https://zadarma.com/ru/support/api/" target="_blank" rel="noopener noreferrer">Zadarma API</a>
    </form>
    <?php $callbackSettingsUrl = $integrationsUrl; require __DIR__ . '/callback-settings-view.php'; ?>
    <section class="panel">
        <h2><?= admin_l('Остальные подключения') ?></h2>
        <ul>
            <li><a href="<?= site_escape($captchaUrl) ?>">Google reCAPTCHA v2</a> · <a href="<?= site_escape($formsUrl) ?>"><?= admin_l('Почтовые уведомления') ?></a></li>
            <li><a href="<?= site_escape($librariesUrl) ?>"><?= admin_l('Google Fonts и CDN-библиотеки') ?></a></li>
            <li><a href="<?= site_escape($updatesUrl) ?>"><?= admin_l('GitHub — обновления движка') ?></a></li>
        </ul>
    </section>
</div>
