<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

return [
    'ru' => 'Тема «Дезинфекторы» включает 32 услуги, заявки [form86] и форму отзыва [form87]. В разделе «Сообщения» откройте отзыв. Если автор согласился на публикацию, перенесите имя, текст и оценку в инфоблок dez-reviews и включите «Показывать на сайте».',
    'en' => 'The Dezinfektori theme includes 32 services, the inquiry form [form86], and the feedback form [form87]. Open the submission in Messages. With consent, copy the name, text, and rating to dez-reviews and enable publication.',
    'uk' => 'Тема «Дезинфекторы» містить 32 послуги, форму заявки [form86] та форму відгуку [form87]. Відкрийте відгук у повідомленнях. За згодою автора перенесіть ім’я, текст та оцінку в dez-reviews і ввімкніть публікацію.',
    'fr' => 'Le thème Dezinfektori comprend 32 services, le formulaire [form86] et le formulaire d’avis [form87]. Ouvrez l’avis dans Messages. Avec l’accord de l’auteur, copiez le nom, le texte et la note dans dez-reviews, puis activez la publication.',
    'de' => 'Das Theme Dezinfektori umfasst 32 Leistungen, die Anfrage [form86] und das Bewertungsformular [form87]. Öffnen Sie die Nachricht. Mit Einwilligung übernehmen Sie Name, Text und Bewertung in dez-reviews und schalten den Eintrag frei.',
    'es' => 'El tema Dezinfektori incluye 32 servicios, solicitudes [form86] y un formulario de reseña [form87]. Abre la reseña en Mensajes. Con permiso, copia el nombre, texto y puntuación a dez-reviews y activa la publicación.',
    'pt' => 'O tema Dezinfektori inclui 32 serviços, pedidos [form86] e o formulário de avaliação [form87]. Abra a mensagem recebida. Com a autorização do autor, copie o nome, o texto e a avaliação para dez-reviews e ative a publicação.',
    'ja' => 'Dezinfektori テーマには 32 のサービス、依頼フォーム [form86]、レビューフォーム [form87] が含まれます。メッセージで投稿を開き、投稿者の同意があれば名前・本文・評価を dez-reviews に登録して公開します。',
    'ko' => 'Dezinfektori 테마에는 32개 서비스, 문의 양식 [form86], 후기 양식 [form87]이 있습니다. 메시지에서 후기를 열고 작성자의 동의를 받은 경우 이름, 본문, 평점을 dez-reviews에 기록한 뒤 게시합니다.',
    'vi' => 'Giao diện Dezinfektori có 32 dịch vụ, biểu mẫu yêu cầu [form86] và đánh giá [form87]. Mở phản hồi trong Tin nhắn. Nếu được tác giả đồng ý, chép tên, nội dung và điểm vào dez-reviews rồi bật xuất bản.',
    'zh' => 'Dezinfektori 主题提供 32 项服务、咨询表单 [form86] 与评价表单 [form87]。在消息中打开评价。经作者同意后，将姓名、内容和评分复制到 dez-reviews，并启用发布。',
];
