<?php if (!defined('SITE_ROOT')) exit;
$cleanupLabels = require SITE_ROOT . '/app/help-media-cleanup.php';
$cleanupLabels = $cleanupLabels[$adminLanguage] ?? $cleanupLabels['ru'];
?>
<section class="panel form-stack" id="unused-media">
    <h2><?= site_escape($cleanupLabels[0]) ?></h2>
    <p class="hint"><?= site_escape($cleanupLabels[4]) ?></p>
    <div><a class="button" href="<?= site_escape($maintenanceUrl . '&scan_media=1#unused-media') ?>"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> <?= site_escape($cleanupLabels[1]) ?></a></div>
    <?php if (admin_input($_GET, 'scan_media') === '1'):
        try { $unusedMedia = admin_media_usage(admin_backup_files()); } catch (RuntimeException $exception) {
            $unusedMedia = null;
            echo '<p class="notice error">' . admin_l($exception->getMessage()) . '</p>';
        }
        if ($unusedMedia === []): ?>
            <p class="hint"><?= site_escape($cleanupLabels[5]) ?></p>
        <?php elseif ($unusedMedia): ?>
            <p><?= count($unusedMedia) ?></p>
            <form class="form-stack" method="post" action="<?= site_escape($maintenanceUrl . '&scan_media=1#unused-media') ?>">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <?php foreach (array_slice(array_keys($unusedMedia), 0, 100) as $path): ?>
                    <label class="choice"><input type="checkbox" name="media[]" value="<?= site_escape($path) ?>"><code><?= site_escape('/' . $path) ?></code></label>
                <?php endforeach; ?>
                <label class="choice"><input type="checkbox" name="confirm" value="1" required> <?= site_escape($cleanupLabels[3]) ?></label>
                <div><button class="button-danger" name="action" value="remove-unused-media"><?= site_escape($cleanupLabels[2]) ?></button></div>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</section>
