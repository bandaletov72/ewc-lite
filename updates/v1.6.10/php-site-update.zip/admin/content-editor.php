<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$layouts = array_diff(array_keys(site_layout_blocks()), ['conf-policy']);
$layouts = array_merge($layouts, ['page-content', 'privacy-content']);
$tokens = array_values(array_diff(array_unique(array_merge(['payment', 'sections', 'list-pages', 'author', 'site-name', 'site-url'], array_keys(site_date_snippets()), ['dmY'],
    array_keys(site_snippet_values($currentHost)), array_keys($siteSettings['variables']), array_keys(site_contact_tokens()))), $layouts, ['conf-policy']));
$iconTokens = array_keys(site_contact_tokens());
try { $editorForms = site_forms(); } catch (RuntimeException $exception) { $editorForms = site_default_forms(); }
try { $editorLibraries = site_library_settings(site_read_record(SITE_LIBRARIES_FILE)); } catch (RuntimeException $exception) { $editorLibraries = site_library_settings(); }
$canInsertFA = $editorLibraries['enabled']['fontawesome'];
$editorLabels = admin_editor_labels($adminLanguage);
$workflow = require SITE_ROOT . '/app/help-workflow.php';
$workflow = $workflow[$adminLanguage] ?? $workflow['ru'];
$toolsLabel = $workflow['tools'];
list($bannerName, $bannerSetLabel, $bannerSetHint) = site_banner_editor_labels($adminLanguage);
?>
<div class="field field-wide" data-content-editor data-editor-admin-url="<?= site_escape(site_url($base, 'admin/')) ?>"
    data-editor-csrf="<?= site_escape($token) ?>" data-editor-base="<?= site_escape($base) ?>">
    <label for="<?= site_escape($editorId) ?>"><?= site_escape($editorTitle) ?></label>
    <div class="header-actions editor-mode-tabs" data-editor-toolbar hidden>
        <button type="button" data-editor-mode="html" aria-pressed="true">HTML</button>
        <button type="button" data-editor-mode="visual" aria-pressed="false"><?= admin_l('Визуальный редактор') ?></button>
    </div>
    <div class="header-actions" data-editor-format hidden>
        <?php foreach (['bold' => ['bold', admin_t('Жирный')], 'italic' => ['italic', admin_t('Курсив')],
            'underline' => ['underline', $editorLabels['underline']], 'strikeThrough' => ['strikethrough', $editorLabels['strike']],
            'superscript' => ['superscript', 'Superscript · SUP'], 'subscript' => ['subscript', 'Subscript · SUB'],
            'insertUnorderedList' => ['list-ul', admin_t('Маркированный список')], 'insertOrderedList' => ['list-ol', $editorLabels['numbered']]] as $command => list($icon, $label)): ?>
            <button class="editor-tool" type="button" data-editor-command="<?= $command ?>" title="<?= site_escape($label) ?>" aria-label="<?= site_escape($label) ?>"><i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i></button>
        <?php endforeach; ?>
        <span class="editor-tool-group" data-editor-visual-controls hidden>
            <?php
            foreach (['Left' => 'left', 'Center' => 'center', 'Right' => 'right'] as $command => $icon):
                $alignLabel = $workflow['align'][$icon];
            ?>
                <button class="editor-tool" type="button" data-editor-command="justify<?= $command ?>" title="<?= site_escape($alignLabel) ?>" aria-label="<?= site_escape($alignLabel) ?>"><i class="fa-solid fa-align-<?= $icon ?>" aria-hidden="true"></i></button>
            <?php endforeach; ?>
            <button class="editor-tool" type="button" data-editor-command="removeFormat" title="<?= site_escape($workflow['align']['clear']) ?>" aria-label="<?= site_escape($workflow['align']['clear']) ?>"><i class="fa-solid fa-eraser" aria-hidden="true"></i></button>
        </span>
        <button class="editor-tool" type="button" data-editor-command="formatBlock" data-editor-value="p" title="<?= admin_l('Параграф') ?>" aria-label="<?= admin_l('Параграф') ?>"><i class="fa-solid fa-paragraph" aria-hidden="true"></i></button>
        <?php for ($level = 1; $level <= 5; $level++): ?>
            <?php $headingLabel = $editorLabels['heading'] . ' H' . $level; ?>
            <button class="editor-tool" type="button" data-editor-command="formatBlock" data-editor-value="h<?= $level ?>" title="<?= site_escape($headingLabel) ?>" aria-label="<?= site_escape($headingLabel) ?>">H<?= $level ?></button>
        <?php endfor; ?>
        <?php foreach (['link' => 'link', 'button' => 'square-plus'] as $key => $icon): ?>
            <button class="editor-tool" type="button" data-editor-dialog-trigger="<?= $key ?>" aria-haspopup="dialog" title="<?= site_escape($toolsLabel[$key]) ?>" aria-label="<?= site_escape($toolsLabel[$key]) ?>"><i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i></button>
        <?php endforeach; ?>
        <?php foreach (['template' => ['layer-group', $editorLabels['template']], 'component' => ['puzzle-piece', $editorLabels['component']],
            'image' => ['image', $editorLabels['image']], 'icon' => ['icons', $editorLabels['icon']]] as $picker => list($icon, $label)): ?>
            <?php if ($picker === 'component' && !$editorWithComponents) continue; ?>
            <button class="editor-tool" type="button" data-editor-open="<?= $picker ?>" title="<?= site_escape($label) ?>" aria-label="<?= site_escape($label) ?>" aria-controls="<?= site_escape($editorId) ?>-picker-<?= $picker ?>" aria-expanded="false"><i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i></button>
        <?php endforeach; ?>
        <?php if (!empty($editorImageTarget)): ?>
            <button type="button" data-editor-open="image" data-editor-image-target="<?= site_escape($editorImageTarget) ?>" aria-expanded="false"><?= $adminLanguage === 'ru' ? 'Выбрать подложку' : 'Choose background' ?></button>
        <?php endif; ?>
        <?php if (($sectionDirectory ?? '') !== ''): ?>
            <button class="editor-tool" type="button" data-editor-code="[list-pages]" title="<?= admin_l('Вставить в текст') ?> [list-pages]" aria-label="<?= admin_l('Вставить в текст') ?> [list-pages]"><i class="fa-solid fa-list" aria-hidden="true"></i></button>
        <?php endif; ?>
    </div>
    <textarea id="<?= site_escape($editorId) ?>" name="<?= site_escape($editorName) ?>" data-editor-source data-code-mode="html" spellcheck="false" rows="<?= $editorWithComponents ? 12 : 6 ?>"><?= "\n" . site_escape($editorValue) ?></textarea>
    <div class="editor-visual-surface" data-editor-surface hidden>
        <iframe data-editor-frame hidden sandbox="allow-same-origin"
            data-src="<?= site_escape(site_url($base, 'templates/editor-frame.php')) ?>" title="<?= admin_l('Визуальный редактор страницы') ?>"></iframe>
        <div class="editor-image-selection" data-editor-image-selection hidden>
            <span data-editor-image-resize title="<?= admin_l('Изменить размер') ?>" aria-hidden="true"></span>
        </div>
    </div>
    <?php require __DIR__ . '/content-editor-tools.php'; ?>
    <div class="panel form-stack" id="<?= site_escape($editorId) ?>-picker-template" data-editor-picker="template" hidden>
        <h3><?= site_escape($editorLabels['template']) ?></h3>
        <label class="field"><?= admin_l('Шаблоны') ?>
            <select data-editor-template>
                <?php foreach ([admin_t('Шаблоны') => $layouts, admin_t('Подшаблоны') => $tokens] as $label => $options): ?>
                    <optgroup label="<?= site_escape($label) ?>">
                        <?php foreach ($options as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                    </optgroup>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button type="button" data-editor-add-template><?= admin_l('Вставить в текст') ?></button></div>
    </div>
    <?php if ($editorWithComponents): ?>
    <div class="panel form-stack" id="<?= site_escape($editorId) ?>-picker-component" data-editor-picker="component" hidden>
        <h3><?= site_escape($editorLabels['component']) ?></h3>
        <div class="fields">
            <label class="field"><?= admin_l('Компонент') ?>
                <select data-editor-component>
                    <?php $componentCodes = ['gal' => '[gal]', 'fotos' => '[fotos]', 'files' => '[files]', 'include' => '[include]',
                        'form' => '[form1]', 'callback' => '[callback]', 'iblock' => '[iblock=table]', 'map' => '[map]',
                        'maps' => '[maps]', 'php' => '[php]', 'banners' => '[banners]']; ?>
                    <?php foreach (['gal' => admin_t('Карусель'), 'fotos' => admin_t('Фотогалерея'), 'files' => admin_t('Список файлов'),
                        'include' => admin_t('Другая страница'), 'form' => admin_t('Форма'), 'callback' => admin_t('Обратный звонок'),
                        'iblock' => admin_t('Инфоблок'), 'map' => admin_t('Точка на карте'), 'maps' => $discoveryLabels['all-maps'], 'php' => admin_t('PHP-модули'), 'banners' => $bannerName] as $key => $label): ?>
                        <option value="<?= $key ?>"><?= site_escape($label . ' ' . $componentCodes[$key]) ?></option>
                    <?php endforeach; ?>
                    <?php foreach (site_extensions() as $tag => $definition): ?>
                        <?php if (isset(site_php_module_settings()[$tag]) || site_php_module_source($tag)[1] !== '') continue; ?>
                        <option value="extension:<?= site_escape($tag) ?>" data-kind="<?= site_escape($definition['kind']) ?>"><?= site_escape($definition['label'] ?? $tag) ?> [<?= site_escape($tag) ?>]</option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="extension"><?= admin_l('Значение') ?><input data-editor-param="extension-value"></label>
            <label class="field" data-editor-show="php"><?= site_escape(admin_l('PHP-модули')) ?>
                <select data-editor-param="module">
                    <?php foreach (site_extensions() as $name => $definition): ?>
                        <?php if (!site_php_module_enabled($name)) continue; ?>
                        <option value="<?= site_escape($name) ?>"><?= site_escape(site_php_module_settings()[$name]['label'] ?? admin_t($definition['label'] ?? $name)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="form"><?= admin_l('Форма') ?>
                <select data-editor-param="form">
                    <?php foreach ($editorForms as $id => $definition): ?>
                        <?php if (!site_valid_form_id($id)) continue; ?>
                        <option value="<?= site_escape($id) ?>">[<?= site_escape($id) ?>] · <?= site_escape($definition['title'] ?? $definition['button'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <?php foreach ([
                'path' => [admin_t('Путь'), 'gal fotos files include iblock', '/images/myfotos/'],
                'banner-set' => [$bannerSetLabel, 'banners', 'main'],
                'banner-folder' => [admin_t('Папка компонента'), 'banners', '/images/myfotos/'],
                'title' => [admin_t('Название точки или заголовок формы'), 'map callback', admin_t('Офис')],
                'lat' => [admin_t('Широта'), 'map', '55.7558'],
                'lng' => [admin_t('Долгота'), 'map', '37.6173'],
                'zoom' => [admin_t('Масштаб'), 'map maps', '13'],
                'center' => [$discoveryLabels['map-center'], 'map maps', '55.7558,37.6173'],
                'url' => [admin_t('URL кнопки'), 'map', '/contacts/'],
                'button' => [admin_t('Текст кнопки'), 'map callback', admin_t('Подробнее')],
                'submit' => [admin_t('Текст кнопки отправки'), 'callback', admin_t('Отправить номер')],
                'placeholder' => [admin_t('Подсказка в поле телефона'), 'callback', '+7(900)123-45-67'],
            ] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <input data-editor-param="<?= $key ?>" placeholder="<?= site_escape($field[2]) ?>">
                    <?php if ($key === 'banner-set'): ?><small class="hint"><?= site_escape($bannerSetHint) ?></small><?php endif; ?>
                    <?php if (in_array($key, ['path', 'banner-folder'], true)): ?>
                        <small class="hint" data-editor-show="<?= $key === 'path' ? 'gal fotos files' : 'banners' ?>"><?= site_escape($adminLanguage === 'ru'
                            ? 'Имена папок: A–Z, a–z, 0–9, дефис и подчёркивание. Слэш разделяет уровни.'
                            : 'Folder names allow A–Z, a–z, 0–9, hyphens and underscores. Use slashes between folders.') ?></small>
                    <?php endif; ?>
                </label>
            <?php endforeach; ?>
            <?php foreach (['layout' => [admin_t('Вид инфоблока'), 'iblock', site_iblock_views()],
                'provider' => [admin_t('Карты'), 'map maps', ['' => admin_t('По умолчанию'), 'yandex' => admin_t('Яндекс Карты'), 'google' => 'Google Maps']],
                'mode' => [admin_t('Режим'), 'map maps', ['' => admin_t('По умолчанию')] + site_map_modes()]] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <select data-editor-param="<?= $key ?>">
                        <?php foreach ($field[2] as $value => $label): ?><option value="<?= $value ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                    </select>
                </label>
            <?php endforeach; ?>
            <?php foreach (site_component_schema() as $kind => $definition): ?>
                <?php foreach ($definition['settings'] as $name => $field): ?>
                    <label class="field" data-editor-show="<?= site_escape($kind) ?>"><?= admin_l($field['label']) ?>
                        <select data-editor-option="<?= site_escape($name) ?>">
                            <option value=""><?= admin_l('По умолчанию') ?></option>
                            <?php foreach ($field['options'] as $option => $label): ?><option value="<?= site_escape($option) ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <div class="header-actions">
            <button type="button" data-editor-insert-button><?= admin_l('Вставить в текст') ?></button>
            <small class="notice error" data-editor-component-error role="alert" hidden
                data-banner-error="<?= site_escape($adminLanguage === 'ru' ? 'Имя набора начните с латинской буквы. Для папки укажите путь, например /images/myfotos/.' : 'Start the set name with a Latin letter. Use a folder path such as /images/myfotos/.') ?>"
                data-files-error="<?= site_escape($adminLanguage === 'ru' ? 'Укажите путь вроде /files/myfiles/. В именах папок допустимы A–Z, a–z, 0–9, дефис и подчёркивание.' : 'Use a folder path such as /files/myfiles/. Names allow A–Z, a–z, 0–9, hyphens and underscores.') ?>"
                data-images-error="<?= site_escape($adminLanguage === 'ru' ? 'Укажите путь вроде /images/myfotos/. В именах папок допустимы A–Z, a–z, 0–9, дефис и подчёркивание.' : 'Use a folder path such as /images/myfotos/. Names allow A–Z, a–z, 0–9, hyphens and underscores.') ?>"></small>
        </div>
    </div>
    <?php endif; ?>
    <div class="panel form-stack" id="<?= site_escape($editorId) ?>-picker-image" data-editor-picker="image" hidden>
        <h3><?= site_escape($editorLabels['image']) ?></h3>
        <?php $imageLabel = static function (string $ru, string $en) use ($adminLanguage): string { return site_escape($adminLanguage === 'ru' ? $ru : $en); }; ?>
        <div class="editor-image-library form-stack" data-image-library
            data-delete-title="<?= $imageLabel('Удалить выбранный файл или папку вместе с вложенными изображениями?', 'Delete this file or folder and its images?') ?>"
            data-error-text="<?= $imageLabel('Не удалось выполнить действие с изображениями.', 'The image operation failed.') ?>">
            <div class="header-actions">
                <select data-image-root aria-label="<?= $imageLabel('Каталог изображений', 'Image directory') ?>"><option>/templates/images</option><option>/images</option></select>
                <button type="button" data-image-parent hidden title="<?= $imageLabel('На уровень выше', 'Parent folder') ?>" aria-label="<?= $imageLabel('На уровень выше', 'Parent folder') ?>">↑</button>
                <code data-image-path aria-live="polite"></code>
            </div>
            <div class="fields">
                <div class="field">
                    <label class="field"><?= $imageLabel('Загрузить фото', 'Upload photos') ?><input type="file" data-image-upload accept="image/jpeg,image/png,image/webp,image/gif,image/avif" multiple></label>
                    <div><button type="button" data-image-upload-button><?= admin_l('Загрузить файлы') ?></button></div>
                </div>
                <div class="field">
                    <label class="field"><?= $imageLabel('Новая папка', 'New folder') ?><input data-image-folder-name maxlength="64"></label>
                    <div><button type="button" data-image-mkdir><?= $imageLabel('Создать папку', 'Create folder') ?></button></div>
                </div>
            </div>
            <div class="fields">
                <ul class="editor-image-list" data-image-list></ul>
                <div class="editor-image-preview form-stack" data-image-preview hidden>
                    <img data-image-thumbnail alt="">
                    <p class="hint" data-image-size></p>
                    <div class="fields">
                        <label class="field"><?= $imageLabel('Ширина', 'Width') ?><input type="number" min="1" max="6000" data-image-width></label>
                        <label class="field"><?= $imageLabel('Высота', 'Height') ?><input type="number" min="1" max="6000" data-image-height></label>
                    </div>
                    <label class="field"><?= $imageLabel('Поворот по часовой стрелке', 'Clockwise rotation') ?>
                        <select data-image-angle><option value="0">0°</option><option value="90">90°</option><option value="180">180°</option><option value="270">270°</option></select>
                    </label>
                    <div><button type="button" data-image-transform><?= $imageLabel('Сохранить копию', 'Save a copy') ?></button></div>
                </div>
            </div>
            <p class="hint" data-image-library-status role="status" hidden></p>
        </div>
        <label class="field">URL <input data-editor-image-url placeholder="/images/photo.jpg"></label>
        <label class="field"><?= site_escape($editorLabels['alt']) ?><input data-editor-image-alt></label>
        <div><button type="button" data-editor-add-image data-insert-label="<?= admin_l('Вставить в текст') ?>" data-use-label="<?= $imageLabel('Использовать изображение', 'Use image') ?>"><?= admin_l('Вставить в текст') ?></button></div>
    </div>
    <div class="panel form-stack" id="<?= site_escape($editorId) ?>-picker-icon" data-editor-picker="icon" hidden>
        <h3><?= site_escape($editorLabels['icon']) ?></h3>
        <label class="field"><?= site_escape($editorLabels['system-icons']) ?>
            <select data-editor-system-icon>
                <?php foreach ($iconTokens as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                <?php foreach (['site.png', 'contact/phone.png', 'contact/tg.png', 'contact/vk.png', 'contact/whatsapp.png', 'contact/youtube.png', 'contact/instagram.png', 'contact/max.png'] as $file): ?>
                    <option value="<?= site_escape(site_url($base, 'templates/icons/' . $file)) ?>"><?= site_escape($file) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button type="button" data-editor-add-system-icon><?= admin_l('Вставить в текст') ?></button></div>
        <?php if ($canInsertFA): ?>
            <details data-editor-fa-picker>
            <summary>Font Awesome</summary>
            <label class="field">Font Awesome
                <input type="search" data-editor-fa-icon placeholder="solid:house" autocomplete="off">
                <datalist data-editor-fa-catalog>
                    <?php foreach ((require SITE_ROOT . '/app/editor-icons.php') as $style => $names): ?>
                        <?php foreach ($names as $name): ?><option value="<?= $style ?>:<?= site_escape($name) ?>"></option><?php endforeach; ?>
                    <?php endforeach; ?>
                </datalist>
            </label>
            <div class="editor-fa-grid" data-editor-fa-results></div>
            <button type="button" data-editor-fa-more hidden><?= $imageLabel('Ещё иконки', 'More icons') ?></button>
            <div><button type="button" data-editor-add-fa><?= admin_l('Вставить в текст') ?> Font Awesome</button></div>
            </details>
        <?php endif; ?>
    </div>
    <p class="hint" data-editor-feedback role="status" hidden></p>
    <?php if ($editorWithMedia): ?>
    <details data-editor-media hidden data-media-kinds="<?= site_escape((string) json_encode(['gal' => admin_t('Карусель'), 'fotos' => admin_t('Фотогалерея'),
        'files' => admin_t('Список файлов'), 'banners' => $bannerName], JSON_UNESCAPED_UNICODE)) ?>">
        <summary><?= site_escape($adminLanguage === 'ru' ? 'Файлы и фото для вставленных компонентов' : 'Files and photos for inserted components') ?></summary>
        <p class="hint"><?= site_escape($adminLanguage === 'ru' ? 'Выберите папку компонента для загрузки, удаления и сортировки файлов.' : 'Select a component’s folder to upload, remove or sort files.') ?></p>
        <label class="field"><?= admin_l('Папка компонента') ?> <select data-media-folder></select></label>
        <div class="header-actions">
            <input type="file" multiple data-media-upload aria-label="<?= admin_l('Выберите файлы для загрузки') ?>">
            <button type="button" data-media-upload-button><?= admin_l('Загрузить файлы') ?></button>
        </div>
        <p class="hint" role="status" data-media-feedback></p>
        <ol class="media-list" data-media-list></ol>
    </details>
    <?php endif; ?>
</div>
