<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_live_edit(string $action, array $input, string $base)
{
    $path = admin_input($input, 'path');
    $returnPath = $path === '' ? '' : $path;
    if ($returnPath !== '' && !site_valid_path($returnPath)) {
        throw new RuntimeException('Страница не найдена.');
    }
    if ($action === 'public-edit-mode') {
        $_SESSION['public_edit'] = admin_input($input, 'enabled') === '1';
    } else {
        $revision = admin_input($input, 'revision');
        $page = admin_current_page($path, $revision);
        if ($action === 'live-page-menu') {
            admin_update_page_menu($path, $revision, admin_input($input, 'visible') === '1' ? '1' : '0');
        } else {
            if ($action === 'live-component' && empty($_SESSION['public_edit'])) {
                throw new RuntimeException('Включите режим правки.');
            }
            $fields = $page['fields'];
            $html = $page['html'];
            if ($action === 'live-page-asset') {
                $asset = admin_input($input, 'asset');
                if (!in_array($asset, ['CSS', 'JS'], true)) {
                    throw new RuntimeException('Выберите CSS или JS.');
                }
                $fields[$asset] = admin_encode_asset(admin_input($input, 'code'));
            } else {
                if (!preg_match('/\A[0-9]{1,6}\z/', admin_input($input, 'index'))) {
                    throw new RuntimeException('Не удалось выбрать вставку.');
                }
                $extensions = site_extensions();
                $settings = site_settings();
                $snippets = ['author' => site_author_credit($GLOBALS['adminLanguage'] ?? 'ru')] + site_date_snippets()
                    + site_snippet_values(site_content_host($base)) + array_map('site_escape', $settings['variables']);
                $index = (int) admin_input($input, 'index');
                $component = site_inline_components($html, $extensions, $snippets)[$index] ?? null;
                $replacement = trim(admin_input($input, 'code'));
                $new = strlen($replacement) <= 4000 && preg_match('//u', $replacement) === 1
                    ? site_inline_components($replacement, $extensions, $snippets) : [];
                if ($component === null || count($new) !== 1 || $new[0]['code'] !== $replacement || $new[0]['kind'] !== $component['kind']) {
                    throw new RuntimeException('Введите один код вставки того же компонента.');
                }
                $html = substr_replace($html, $replacement, $component['offset'], strlen($component['code']));
            }
            admin_save_page($path, $fields, $html, $revision, false);
        }
    }
    header('Location: ' . site_page_url($base, $returnPath), true, 303);
    exit;
}
