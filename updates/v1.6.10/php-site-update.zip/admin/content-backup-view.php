<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$backupLocale = require SITE_ROOT . '/app/help-workflow.php';
$backupLocale = ($backupLocale[$adminLanguage] ?? $backupLocale['ru'])['backup'];
$archives = admin_backup_list();
?>
<section class="panel form-stack" id="content-backups">
    <h2><?= site_escape($backupLocale[0]) ?></h2>
    <p class="hint"><?= site_escape($backupLocale[5]) ?></p>
    <form method="post" action="<?= site_escape($maintenanceUrl) ?>#content-backups">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <button class="button-primary" name="action" value="create-content-backup"><i class="fa-solid fa-box-archive" aria-hidden="true"></i> <?= site_escape($backupLocale[1]) ?></button>
    </form>
    <form class="header-actions" method="post" action="<?= site_escape($maintenanceUrl) ?>#content-backups" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="file" name="archive" accept=".zip,application/zip" aria-label="<?= site_escape($backupLocale[2]) ?>" required>
        <button name="action" value="import-content-backup"><?= site_escape($backupLocale[2]) ?></button>
    </form>
    <?php foreach ($archives as $name => $size): ?>
        <details data-content-backup>
            <summary><code><?= site_escape($name) ?></code> <small class="hint"><?= site_escape(number_format($size / 1048576, 2)) ?> MiB</small></summary>
            <form class="form-stack" method="post" action="<?= site_escape($maintenanceUrl) ?>#content-backups">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <input type="hidden" name="backup" value="<?= site_escape($name) ?>">
                <label class="choice"><input type="checkbox" name="confirm" value="1" required> <?= site_escape($backupLocale[6]) ?></label>
                <div class="header-actions">
                    <a class="button" href="<?= site_escape($maintenanceUrl . '&download_backup=' . rawurlencode($name)) ?>"><?= site_escape($backupLocale[3]) ?></a>
                    <button class="button-danger" name="action" value="restore-content-backup"><?= site_escape($backupLocale[4]) ?></button>
                </div>
            </form>
        </details>
    <?php endforeach; ?>
</section>
