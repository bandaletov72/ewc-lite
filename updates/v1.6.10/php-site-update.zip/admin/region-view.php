<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$labels = ['currency' => admin_t('Валюта'), 'date' => admin_t('Формат даты'), 'time' => admin_t('Формат времени'),
    'group' => admin_t('Разделитель разрядов'), 'decimal' => admin_t('Дробный разделитель')];
?>
<h1><?= admin_l('Региональные настройки') ?></h1>
<form class="panel form-stack" method="post" action="<?= site_escape($regionUrl) ?>">
    <input type="hidden" name="action" value="save-region">
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <input type="hidden" name="revision" value="<?= site_escape($regionRevision) ?>">
    <fieldset class="field-config form-stack" id="site-languages">
        <legend><?= admin_l('Доступные языки') ?></legend>
        <div class="fields">
            <?php foreach (site_languages() as $code => $label): ?>
                <label class="choice">
                    <input type="checkbox" name="languages[]" value="<?= $code ?>"<?= in_array($code, $regionDraft['languages'], true) ? ' checked' : '' ?><?= $code === 'ru' ? ' disabled' : '' ?>>
                    <span lang="<?= $code ?>"><?= site_escape($label) ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    </fieldset>
    <div class="fields">
        <?php foreach (['interface' => admin_t('Язык админки по умолчанию'), 'public' => admin_t('Язык сайта по умолчанию')] as $setting => $label): ?>
            <label class="field"><?= admin_l($label) ?>
                <select name="<?= $setting ?>">
                    <?php foreach (site_languages() as $code => $language): ?>
                        <option value="<?= $code ?>"<?= $regionDraft[$setting] === $code ? ' selected' : '' ?>><?= site_escape($language) ?></option>
                    <?php endforeach; ?>
                </select>
                <small class="hint"><?= admin_l('Добавьте выбранный язык в список доступных.') ?></small>
            </label>
        <?php endforeach; ?>
        <label class="field"><?= admin_l('Часовой пояс') ?>
            <select name="timezone">
                <option value="auto"><?= admin_l('Авто — часовой пояс PHP') ?></option>
                <?php $instant = new DateTimeImmutable('now'); ?>
                <?php foreach (site_time_zones() as $zone): ?>
                    <?php $offset = $instant->setTimezone(new DateTimeZone($zone))->format('P'); ?>
                    <option value="<?= site_escape($zone) ?>"<?= $regionDraft['timezone'] === $zone ? ' selected' : '' ?>><?= site_escape('UTC' . $offset . ' · ' . $zone) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php foreach (site_region_options() as $key => $options): ?>
            <label class="field"><?= admin_l($labels[$key]) ?>
                <select name="<?= $key ?>">
                    <?php foreach ($options as $value => $label): ?>
                        <option value="<?= site_escape($value) ?>"<?= $regionDraft[$key] === $value ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endforeach; ?>
    </div>
    <div><button class="button-primary" type="submit"><?= admin_l('Сохранить') ?></button></div>
</form>
