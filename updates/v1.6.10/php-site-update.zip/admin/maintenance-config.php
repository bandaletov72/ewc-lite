<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_rebuild_search(): int
{
    $paths = [];
    foreach (site_pages(true) as $page) {
        if ($page['fields']['Hidden'] !== '1') {
            $paths[$page['path']] = true;
        }
    }
    $index = ['built' => time(), 'pages' => []];
    $languages = array_keys(site_languages());
    $settings = site_settings();
    $snippets = site_snippet_values('') + array_map('site_escape', array_filter($settings['variables'], 'is_string'));
    foreach (array_keys($paths) as $path) {
        if (site_page_translation($path)[1] !== '') {
            continue;
        }
        foreach ($languages as $language) {
            $variant = site_language_page_path($path, $language);
            if (($variant === $path && $language !== 'ru') || !isset($paths[$variant])) {
                continue;
            }
            $page = site_read_page($variant);
            if ($page === null || $page['fields']['Hidden'] === '1') {
                continue;
            }
            $fields = $page['fields'];
            $title = $fields['Heading'] !== '' ? $fields['Heading'] : $fields['Title'];
            $context = ['searching' => true, 'fragment' => true, 'base' => '', 'locale' => $language,
                'active' => [$path => true], 'extensions' => [], 'contactTokens' => site_contact_tokens(), 'contacts' => null];
            $html = site_expand_content($page['html'], $snippets, $context);
            $index['pages'][$path][$language] = [
                'title' => site_search_text(site_expand_text($title, $snippets), 500) ?: site_page_url('', $path),
                'description' => site_search_text(site_expand_text($fields['Description'], $snippets), 700),
                'text' => site_search_text($html),
                'revision' => $page['revision'],
                'availability' => array_intersect_key($fields, array_flip(['Active', 'ActiveFrom', 'ActiveUntil'])),
            ];
        }
    }
    $json = json_encode($index, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Не удалось подготовить индекс поиска.');
    }
    admin_write_payload(SITE_SEARCH_FILE, $json, SITE_SEARCH_LIMIT);
    return count($index['pages']);
}

function admin_refresh_index_after_edit(string $action)
{
    if (!in_array($action, ['save', 'page-menu', 'page-order', 'page-move', 'folder-move', 'change-page-status',
        'live-component', 'live-page-asset', 'live-page-menu', 'save-iblock', 'save-iblock-text',
        'upload-media', 'delete-media', 'order-media', 'save-settings', 'save-region', 'save-contacts',
        'save-snippet', 'delete-snippet', 'restore-content-backup'], true)) {
        return;
    }
    register_shutdown_function(static function () {
        if (http_response_code() >= 400 || !empty($GLOBALS['error'])) {
            return;
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        try {
            $lock = admin_lock();
            try {
                admin_rebuild_search();
            } finally {
                fclose($lock);
            }
        } catch (Throwable $exception) {
            error_log('Search index: ' . $exception->getMessage());
        }
    });
}

function admin_maintenance(string $action, array $submitted): string
{
    $lock = admin_lock();
    try {
        if ($action === 'index-pages') {
            return admin_l('Страниц в индексе') . ' — ' . admin_rebuild_search();
        }
        $settings = site_performance_settings();
        if ($action === 'save-cache') {
            $settings['cache'] = admin_input($submitted, 'cache') === '1';
        }
        $settings['generation'] = bin2hex(random_bytes(12));
        admin_write_record(SITE_PERFORMANCE_FILE, $settings);
        foreach (glob(SITE_ROOT . '/data/.page-cache-*.php') ?: [] as $file) {
            if (preg_match('/\A\.page-cache-[a-f0-9]{64}\.php\z/', basename($file)) && !is_link($file)) {
                @unlink($file);
            }
        }
        return $action === 'clear-cache' ? admin_l('Кеш очищен.') : admin_l('Настройки сохранены.');
    } finally {
        fclose($lock);
    }
}
