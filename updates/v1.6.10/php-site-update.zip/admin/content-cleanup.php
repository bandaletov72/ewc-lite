<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_media_cleanup_candidate(string $path): bool
{
    return preg_match('~\A(?:images|files|templates/images|templates/files)/~', $path)
        && strpos($path, 'templates/images/branding/') !== 0
        && basename($path) !== '.asset-order.php';
}

function admin_media_usage(array $files): array
{
    $media = array_filter($files, static function (string $path): bool {
        return admin_media_cleanup_candidate($path);
    }, ARRAY_FILTER_USE_KEY);
    if (!$media) return [];

    $folders = [];
    $addFolder = static function (string $path) use (&$folders) {
        $path = trim($path, '/');
        $folders[$path] = true;
        if (strpos($path, 'templates/') === 0) $folders[substr($path, 10)] = true;
        else $folders['templates/' . $path] = true;
    };
    $read = static function (string $text) use (&$media, $addFolder) {
        $text = html_entity_decode(rawurldecode(str_replace('\/', '/', $text)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        foreach ($media as $path => $file) {
            if (stripos($text, basename($path)) !== false) unset($media[$path]);
        }
        if (preg_match_all('~\[(gal|fotos|files|banners)(?:[\t ][^\]\r\n]*)?\]\s*(/[^\[\]\r\n]+)\[/\1\]~i', $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $path = site_asset_path(trim($match[2]), strtolower($match[1]) === 'files' ? 'files' : 'images');
                if ($path !== '') $addFolder($path);
            }
        }
    };
    foreach (site_banner_sets() as $set) {
        $folder = site_asset_path($set['folder'] ?? '', 'images');
        if ($folder !== '') $addFolder($folder);
    }
    foreach (array_diff_key($files, $media) as $path => $file) {
        if (basename($path) === '.asset-order.php') continue;
        $text = @file_get_contents($file, false, null, 0, 8388609);
        if (!is_string($text) || strlen($text) > 8388608) {
            throw new RuntimeException('Не удалось полностью проверить ссылки на медиа. Очистка недоступна.');
        }
        $read($text);
        if (site_valid_path($path)) {
            $page = site_read_page($path);
            foreach (['CSS','JS'] as $asset) {
                $code = site_asset_decode($page['fields'][$asset] ?? '');
                if ($code !== null && $code !== '') $read($code);
            }
        }
    }
    foreach (site_global_assets() as $asset) {
        $code = site_asset_decode($asset);
        if ($code !== null && $code !== '') $read($code);
    }
    foreach ($media as $path => $file) {
        $folder = dirname($path);
        while ($folder !== '.') {
            if (isset($folders[$folder])) {
                unset($media[$path]);
                continue 2;
            }
            $folder = dirname($folder);
        }
    }
    return $media;
}

function admin_remove_unused_media(array $input): int
{
    $selected = $input['media'] ?? null;
    if (!is_array($selected) || !$selected || count($selected) > 100 || admin_input($input, 'confirm') !== '1') {
        throw new RuntimeException('Выберите файлы и подтвердите очистку.');
    }
    $lock = admin_lock();
    $staged = [];
    $directory = '';
    $keepFiles = false;
    try {
        $files = admin_backup_files();
        $unused = admin_media_usage($files);
        foreach ($selected as $path) {
            if (!is_string($path) || !isset($unused[$path])) {
                throw new RuntimeException('Список неиспользуемых файлов изменился. Повторите поиск.');
            }
        }
        admin_backup_capture($files);
        $directory = admin_backup_directory() . '/.cleanup-' . bin2hex(random_bytes(8));
        if (!@mkdir($directory, 0700)) throw new RuntimeException('Не удалось подготовить папку очистки.');
        foreach (array_unique($selected) as $path) {
            $file = $unused[$path];
            $temporary = $directory . '/' . count($staged);
            if (!@rename($file, $temporary)) throw new RuntimeException('Не удалось убрать один из выбранных файлов.');
            $staged[$file] = $temporary;
        }
        return count($staged);
    } catch (Throwable $exception) {
        foreach (array_reverse($staged, true) as $file => $temporary) {
            if (!@rename($temporary, $file)) $keepFiles = true;
        }
        if ($keepFiles) throw new RuntimeException('Очистка прервана. Файлы сохранены в закрытой папке резервных копий.', 0, $exception);
        throw $exception;
    } finally {
        if ($directory !== '' && !$keepFiles) {
            foreach ($staged as $temporary) {
                if (is_file($temporary)) @unlink($temporary);
            }
            @rmdir($directory);
        }
        fclose($lock);
    }
}
