<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_inline_data_target(array $item, string $base, string $host, array $settings): array
{
    $type = $item['kind'];
    $args = $item['arguments'];
    $query = [];
    $anchor = '';
    if ($type === 'iblock' && ($id = site_iblock_id_from_argument($args['iblock'])) !== '') {
        $query = ['iblocks' => '1', 'id' => $id];
    } elseif ($type === 'form' && site_valid_form_id(strtolower($args['form']))) {
        $query = ['forms' => '1', 'id' => strtolower($args['form'])];
    } elseif ($type === 'callback') {
        $query = ['callbacks' => '1'];
    } elseif ($type === 'map' || $type === 'maps') {
        $query = ['integrations' => '1'];
        $anchor = '#maps';
    } elseif ($type === 'snippet') {
        $name = strtolower($args['snippet']);
        if (isset(site_contact_tokens()[$name])) {
            $query = ['contacts' => '1'];
        } elseif (site_valid_snippet($name) && !isset(site_layout_blocks()[$name])) {
            try {
                $own = $host !== '' && isset(site_read_snippets($host)[$name]);
                if ($own || isset(site_read_snippets()[$name])) {
                    $query = ['snippets' => '1', 'snippet' => $name] + ($own ? ['domain' => $host] : ['scope' => 'shared']);
                } elseif (isset($settings['variables'][$name])) {
                    $query = ['settings' => '1'];
                    $anchor = '#variables';
                }
            } catch (RuntimeException $exception) {
                return [];
            }
        }
    }
    if (!$query) {
        return [];
    }
    $url = site_url($base, 'admin/') . '?' . http_build_query($query);
    return ['modal' => $url . '&embed=1' . $anchor, 'wide' => $url . '&wide=1' . $anchor];
}

function site_data_editor_labels(string $locale): array
{
    $options = [
        'ru' => ['Данные', 'На весь экран'], 'en' => ['Data', 'Full screen'], 'uk' => ['Дані', 'На весь екран'],
        'ja' => ['データ', '全画面'], 'vi' => ['Dữ liệu', 'Toàn màn hình'], 'fr' => ['Données', 'Plein écran'],
        'de' => ['Daten', 'Vollbild'], 'es' => ['Datos', 'Pantalla completa'], 'pt' => ['Dados', 'Ecrã inteiro'], 'ko' => ['데이터', '전체 화면'],
    ];
    return $options[$locale] ?? $options['ru'];
}
