<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Выбор точки на карте', 'В кабинете Яндекс Карт создайте ключ для продукта «JavaScript API» в разделе «Карты». Ограничьте ключ доменом по HTTP Referer. При включённом провайдере на вкладке «Карты» страницы нажмите «Выбрать на карте», поставьте точку и перенесите её координаты в поля.'],
    'en' => ['Pick a point on a map', 'In the Yandex Maps console create a key for the «JavaScript API» product and restrict it by HTTP Referer. With a provider enabled, open the page’s Maps tab, choose a point and apply its coordinates.'],
    'uk' => ['Вибір точки на карті', 'У кабінеті Яндекс Карт створіть ключ продукту «JavaScript API» та обмежте його доменом через HTTP Referer. У вкладці «Карти» сторінки виберіть точку й застосуйте координати.'],
    'de' => ['Punkt auf der Karte wählen', 'Erstellen Sie in der Yandex-Konsole einen Schlüssel für „JavaScript API“ und begrenzen Sie ihn per HTTP-Referrer. Wählen Sie in der Karten-Registerkarte der Seite einen Punkt und übernehmen Sie seine Koordinaten.'],
    'fr' => ['Choisir un point sur la carte', 'Dans la console Yandex Maps, créez une clé pour « JavaScript API » et limitez-la par référent HTTP. Dans l’onglet Cartes de la page, choisissez un point puis appliquez ses coordonnées.'],
    'es' => ['Elegir un punto en el mapa', 'Crea una clave para «JavaScript API» en la consola de Yandex Maps y restríngela por referente HTTP. En la pestaña Mapas de la página, elige un punto y aplica sus coordenadas.'],
    'pt' => ['Escolher um ponto no mapa', 'Crie uma chave para «JavaScript API» no console do Yandex Maps e restrinja-a por referência HTTP. Na aba Mapas da página, escolha um ponto e aplique as coordenadas.'],
    'ja' => ['地図で地点を選択する', 'Yandex Maps のコンソールで「JavaScript API」のキーを作成し、HTTP Referer で制限してください。ページの「地図」タブで地点を選択し、座標を適用します。'],
    'ko' => ['지도에서 지점 선택', 'Yandex Maps 콘솔에서 «JavaScript API» 키를 만들고 HTTP Referer로 제한하세요. 페이지의 지도 탭에서 지점을 선택한 뒤 좌표를 적용하세요.'],
    'vi' => ['Chọn một điểm trên bản đồ', 'Tạo khóa «JavaScript API» trong bảng điều khiển Yandex Maps và giới hạn theo HTTP Referer. Trong thẻ Bản đồ của trang, hãy chọn điểm và áp dụng tọa độ.'],
];
