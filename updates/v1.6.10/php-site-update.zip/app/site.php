<?php

if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

if (is_file(__DIR__ . '/.update-in-progress')) {
    http_response_code(503);
    header('Retry-After: 10');
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Обновляется движок сайта. Откройте страницу через несколько секунд.');
}

require __DIR__ . '/components.php';
require __DIR__ . '/banners.php';
require __DIR__ . '/forms.php';
require __DIR__ . '/form-mail.php';
require __DIR__ . '/regional.php';
require __DIR__ . '/maps.php';
require __DIR__ . '/integrations.php';
require __DIR__ . '/php-modules.php';
require __DIR__ . '/captcha.php';
require __DIR__ . '/performance.php';
require __DIR__ . '/page-editor.php';
require __DIR__ . '/data-editor.php';
require __DIR__ . '/privacy.php';
require __DIR__ . '/layout-placement.php';
require __DIR__ . '/error-pages.php';
require __DIR__ . '/functions.php';
require __DIR__ . '/libraries.php';
require __DIR__ . '/spam.php';
require __DIR__ . '/iblocks.php';
require __DIR__ . '/appearance.php';
require __DIR__ . '/component-settings.php';
require __DIR__ . '/callbacks.php';

const SITE_NAME = 'Мой сайт';
const SITE_PRODUCT_NAME = 'Eurowebcart CMS Light';
const SITE_PRODUCT_AUTHOR = 'Бандалетов Павел';
const SITE_PRODUCT_REPOSITORY = 'https://github.com/bandaletov72/php-site-updates';
const SITE_PAGE_LIMIT = 524288;
const SITE_IDENTIFIER_PATTERN = '[A-Za-z0-9_\-]{1,64}';
const SITE_ASSET_LIMIT = 65536;
const SITE_ASSET_RECORD_LIMIT = 180000;
const SITE_ASSETS_FILE = SITE_ROOT . '/admin/.site-assets.php';
const SITE_HEADERS_FILE = SITE_ROOT . '/admin/.site-headers.php';
const SITE_HEADER_INSERT_LIMIT = 32768;
const SITE_HEADERS_RECORD_LIMIT = 100000;
const SITE_MAX_INCLUDE_DEPTH = 10;
const SITE_RECORD_HEADER = "<?php http_response_code(404); exit; __halt_compiler();\n";
const SITE_SETTINGS_FILE = SITE_ROOT . '/admin/.site-settings.php';
const SITE_DOMAINS_FILE = SITE_ROOT . '/admin/.domains.php';
const SITE_SNIPPET_RECORD_LIMIT = 4194304;

/** @return string|null */
function site_read_payload(string $file, int $limit)
{
    if (is_link($file)) {
        throw new RuntimeException('Недопустимый путь к файлу настроек.');
    }
    if (!file_exists($file)) {
        return null;
    }

    $bytes = @file_get_contents($file, false, null, 0, $limit + 1);
    if ($bytes === false || strlen($bytes) > $limit || strpos($bytes, SITE_RECORD_HEADER) !== 0) {
        throw new RuntimeException('Не удалось прочитать файл настроек.');
    }

    return substr($bytes, strlen(SITE_RECORD_HEADER));
}

function site_read_record(string $file, int $limit = 32768): array
{
    $payload = site_read_payload($file, $limit);
    if ($payload === null) {
        return [];
    }
    $record = json_decode($payload, true);
    if (!is_array($record)) {
        throw new RuntimeException('Неверный формат файла настроек.');
    }

    return $record;
}

function site_default_settings(): array
{
    return ['name' => SITE_NAME, 'description' => '', 'footer' => '', 'variables' => [], 'breadcrumbs' => true,
        'searchMode' => 'expanded', 'publicUrl' => ''];
}

function site_footer_pattern(string $text): string
{
    if (strpos($text, '[year]') !== false) {
        return $text;
    }
    return preg_replace('/\A(©\s*(?:[0-9]{4}\s*[-–—]\s*)?)[0-9]{4}(?=\s|$)/u', '$1[year]', $text) ?? $text;
}

function site_settings(): array
{
    $settings = site_default_settings();
    try {
        $stored = site_read_record(SITE_SETTINGS_FILE);
    } catch (RuntimeException $exception) {
        return $settings;
    }

    foreach ($settings as $key => $value) {
        if (isset($stored[$key]) && gettype($stored[$key]) === gettype($value)) {
            $settings[$key] = $stored[$key];
        }
    }

    $settings['footer'] = site_footer_pattern($settings['footer']);
    if (!in_array($settings['searchMode'], ['off', 'compact', 'expanded'], true)) {
        $settings['searchMode'] = 'expanded';
    }
    return $settings;
}

function site_valid_snippet(string $name): bool
{
    return preg_match('/\A[a-z][a-z0-9_-]{0,63}\z/', $name) === 1;
}

function site_normalize_domain(string $domain): string
{
    $domain = strtolower($domain);
    if (substr($domain, -1) === '.') {
        $domain = substr($domain, 0, -1);
    }
    if (strlen($domain) > 253) {
        return '';
    }
    foreach (explode('.', $domain) as $label) {
        if (!preg_match('/\A[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\z/', $label)) {
            return '';
        }
    }
    return $domain;
}

function site_host(): string
{
    $header = $_SERVER['HTTP_HOST'] ?? '';
    if (!preg_match('/\A(\[[a-f0-9:.]+\]|[a-z0-9.-]+)(?::[0-9]{1,5})?\z/i', $header, $match)) {
        return '';
    }
    $host = strtolower($match[1]);
    if ($host[0] === '[') {
        return filter_var(substr($host, 1, -1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? $host : '';
    }
    return site_normalize_domain($host);
}

function site_snippet_file(string $host = ''): string
{
    $suffix = $host === '' ? '' : '-' . hash('sha256', $host);
    return SITE_ROOT . '/admin/.snippets' . $suffix . '.php';
}

function site_content_host(string $base, bool $remember = false): string
{
    $host = site_host();
    try {
        $domains = site_read_record(SITE_DOMAINS_FILE);
    } catch (RuntimeException $exception) {
        return $host;
    }
    if ($host === '' || in_array($host, $domains, true)) {
        return $host;
    }
    $root = strpos($host, 'www.') === 0 ? substr($host, 4) : $host;
    $suffix = '.' . $root;
    $valid = static function (string $source) use ($domains, $suffix): bool {
        return substr($source, -strlen($suffix)) === $suffix && in_array($source, $domains, true);
    };
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $source = strlen($referer) < 4096 ? parse_url($referer) : false;
    if (is_array($source) && in_array($source['scheme'] ?? '', ['http', 'https'], true)) {
        $name = site_normalize_domain($source['host'] ?? '');
        if ($valid($name)) {
            if ($remember) {
                setcookie('FILE_SITE_REGION_HOST', $name, time() + 86400, site_url($base), '',
                    !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', true);
            }
            return $name;
        }
    }
    $saved = $_COOKIE['FILE_SITE_REGION_HOST'] ?? '';
    return is_string($saved) && $valid($saved) ? $saved : $host;
}

function site_read_snippets(string $host = ''): array
{
    return site_read_record(site_snippet_file($host), SITE_SNIPPET_RECORD_LIMIT);
}

function site_snippet_values(string $host, ?array &$stock = null, ?array &$php = null, ?array &$visibility = null): array
{
    $shared = [];
    try {
        $shared = site_read_snippets();
    } catch (RuntimeException $exception) {
        // Pages remain available if the shared snippets cannot be read.
    }
    $visibility = is_array($shared['_layoutVisibility'] ?? null) ? $shared['_layoutVisibility'] : [];
    if ($host !== '') {
        try {
            $own = site_read_snippets($host);
            $shared = array_replace($shared, $own);
            if (is_array($own['_layoutVisibility'] ?? null)) {
                $visibility = array_replace($visibility, $own['_layoutVisibility']);
            }
        } catch (RuntimeException $exception) {
            // Shared values still apply if one domain's data cannot be read.
        }
    }

    $values = [];
    $layoutNames = site_layout_blocks();
    foreach ($shared as $name => $snippet) {
        if (isset($layoutNames[$name])) {
            if (($snippet['mode'] ?? '') === 'stock') {
                $stock[$name] = true;
                continue;
            }
            if (($snippet['mode'] ?? '') === 'php' && is_string($snippet['value'] ?? null)) {
                $php[$name] = $snippet['value'];
                continue;
            }
        }
        if (is_array($snippet) && isset($snippet['value']) && is_string($snippet['value'])) {
            $values[$name] = $snippet['value'];
        }
    }
    return $values;
}

const SITE_SNIPPET_TOKEN = '\[(?P<snippet>[a-z][a-z0-9_-]{0,63})\]';

function site_date_snippets(): array
{
    $time = $_SERVER['REQUEST_TIME'] ?? time();
    $regional = site_region_settings();
    $date = date($regional['date'], $time);
    return ['year' => date('Y', $time), 'month' => date('m', $time), 'day' => date('d', $time),
        'time' => date($regional['time'], $time), 'dmy' => date('d.m.Y', $time), 'date' => $date,
        'datetime' => date($regional['date'] . ' ' . $regional['time'], $time)];
}

function site_expand_text(string $text, array $snippets): string
{
    return preg_replace_callback('~' . SITE_SNIPPET_TOKEN . '~i', static function (array $match) use ($snippets): string {
        $name = strtolower($match[1]);
        if (!isset($snippets[$name])) {
            return $match[0];
        }
        return html_entity_decode(strip_tags($snippets[$name]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }, $text) ?? $text;
}

function site_content_pattern(array $extensions): string
{
    // Keep tags, attributes, and literal HTML regions intact.
    $pattern = <<<'REGEX'
~
  <!-- .*? (?: --> | $ )
  | <(script|style|textarea|pre|code)\b (?: [^>"']++ | "[^"]*" | '[^']*' )* >
    .*? (?: </\1\s*> | $ )
  | </?[a-z][a-z0-9:-]*\b (?: [^>"']++ | "[^"]*" | '[^']*' )* >
  | \[ (?P<galleryTag>gal|fotos) (?P<galleryOptions>(?:[\x20\t]+[a-z0-9_-]+=[a-z0-9_-]+%?)*) \]
    (?P<gallery>[^\[\]]+) \[/\k<galleryTag>\]
  | \[(?P<banners>banners)(?P<bannerOptions>(?:[\x20\t]+[a-z0-9_-]+=[a-z0-9_-]+%?)*)\]
    (?:(?P<bannerFolder>\s*/[^\[\]]+)\[/banners\])?
  | \[files (?P<fileOptions>(?:[\x20\t]+[a-z0-9_-]+=[a-z0-9_-]+%?)*) \] (?P<files>[^\[\]]+) \[/files\]
  | \[include\] (?P<include>[^\[\]]+) \[/include\]
  | \[iblock=(?P<iblockTemplate>[a-z][a-z0-9_-]{0,63})\] (?P<iblock>[^\[\]]+) \[/?iblock\]
  | \[ (?P<callback>callback) (?:=(?P<callbackLabel>[^\[\]\r\n]+)|[\x20\t]+(?P<callbackOptions>(?:[^"\]\r\n]++|"[^"\r\n]*")+))? \]
  | \[php\]\s*(?P<phpModule>[a-z][a-z0-9_-]{0,63})\s*\[/php\]
  | \[func=(?P<functionName>[a-z][a-z0-9_-]{0,63})(?:[\x20\t]+value="(?P<functionArg>[^"\]\r\n]{0,500})")?\]
  | \[ (?P<form>form[1-9][0-9]{0,8}) \]
  | \[(?P<map>maps?)(?:[\x20\t]+(?P<mapOptions>(?:[^"\]\r\n]++|"[^"\r\n]*")+))?\]
  | \[(?P<actionButton>button)[\x20\t]+(?P<actionButtonOptions>(?:[^"\]\r\n]++|"[^"\r\n]*")+)\]
  | \[fa-icon=(?:(?P<iconStyle>solid|regular|brands):)?(?P<iconName>[a-z0-9][a-z0-9-]{0,63})\]
REGEX;
    $wrapped = [];
    foreach ($extensions as $name => $extension) {
        if ($extension['kind'] === 'wrapped') {
            $wrapped[] = preg_quote($name, '~');
        }
    }
    if ($wrapped) {
        $pattern .= ' | \[ (?P<extensionTag>' . implode('|', $wrapped) . ') \]'
            . ' (?P<extensionArg>[^\[\]]*) \[/\k<extensionTag>\]';
    }
    return $pattern . ' | ' . SITE_SNIPPET_TOKEN . '~six';
}

function site_expand_content(string $html, array $snippets, array &$context, bool $inline = false): string
{
    if (strpos($html, '[') === false) {
        return $html;
    }
    $index = 0;
    $expanded = preg_replace_callback(site_content_pattern($context['extensions']), static function (array $match) use ($snippets, &$context, $inline, &$index): string {
        $rendered = site_render_content_match($match, $snippets, $context);
        $kind = $inline ? site_inline_component_type($match, $context['extensions'], $snippets) : '';
        if ($kind === '') {
            return $rendered;
        }
        $label = site_translation('Править компонент', $context['editorLocale'] ?? $context['locale']);
        $id = 'inline-component-' . $index++;
        return '<a class="inline-component-link" data-inline-component href="#' . $id . '" data-inline-kind="'
            . site_escape($kind) . '">' . site_escape($label) . '</a>' . $rendered
            . '<span hidden id="' . $id . '-preview-end"></span>';
    }, $html);
    return $expanded === null ? $html : $expanded;
}

function site_render_content_match(array $match, array $snippets, array &$context): string
{
    $searching = !empty($context['searching']);
    if (!empty($match['actionButton'])) {
        return $searching ? '' : site_component_action_button($match['actionButtonOptions'], $context);
    }
    if (!empty($match['banners'])) {
        return $searching ? '' : site_component_banners($match['bannerOptions'], $match['bannerFolder'] ?? '', $context);
    }
    if ($searching && (!empty($match['form']) || !empty($match['callback']) || !empty($match['phpModule'])
        || !empty($match['extensionTag']) || !empty($match['iconName']) || !empty($match['functionName']))) {
        return '';
    }
    if (!empty($match['gallery'])) {
        return site_component_gallery($match['gallery'], $context['base'], strtolower($match['galleryTag']) === 'gal', $match['galleryOptions']);
    }
    if (!empty($match['files'])) {
        return site_component_files($match['files'], $context['base'], $match['fileOptions']);
    }
    if (!empty($match['include'])) {
        return site_component_include($match['include'], $snippets, $context);
    }
    if (!empty($match['iblock'])) {
        return site_component_iblock(strtolower($match['iblockTemplate']), $match['iblock']);
    }
    if (!empty($match['form'])) {
        return site_component_form(strtolower($match['form']), $context);
    }
    if (!empty($match['map'])) {
        $options = site_shortcode_options($match['mapOptions'] ?? '');
        if ($searching) {
            return ' ' . site_escape(($options['title'] ?? '') . ' ' . ($options['button'] ?? '')) . ' ';
        }
        return strtolower($match['map']) === 'maps' ? site_component_all_maps($options, $context) : site_component_map($options, $context);
    }
    if (isset($match['iconName']) && $match['iconName'] !== '') {
        $style = strtolower($match['iconStyle'] ?: 'solid');
        return '<i class="fa-icon fa-' . $style . ' fa-' . strtolower($match['iconName']) . '" aria-hidden="true"></i>';
    }
    if (!empty($match['callback'])) {
        return site_component_callback(trim($match['callbackLabel'] ?? ''), $context, $match['callbackOptions'] ?? '');
    }
    if (!empty($match['phpModule'])) {
        $module = strtolower($match['phpModule']);
        return isset($context['extensions'][$module]) && site_php_module_enabled($module)
            ? site_render_extension($module, '', $context) : '';
    }
    if (!empty($match['functionName'])) {
        $args = isset($match['functionArg']) ? [html_entity_decode($match['functionArg'], ENT_QUOTES | ENT_HTML5, 'UTF-8')] : [];
        try {
            $result = ew_call(strtolower($match['functionName']), ...$args);
            return is_scalar($result) ? site_escape((string) $result) : '';
        } catch (Throwable $exception) {
            error_log('functions.php: ' . $exception->getMessage());
            return '';
        }
    }
    if (!empty($match['extensionTag'])) {
        return site_render_extension(strtolower($match['extensionTag']), $match['extensionArg'], $context);
    }
    $name = strtolower($match['snippet'] ?? '');
    if ($name === 'conf-policy') {
        return '';
    }
    if ($name === 'payment') {
        return $searching ? '' : site_payment_markup();
    }
    if ($name === 'sections' || $name === 'list-pages') {
        return $searching ? '' : site_section_list($context, $name === 'list-pages');
    }
    if (isset(SITE_MOVABLE_LAYOUTS[$name])) {
        return $searching || $context['fragment'] || isset($context['embeddedLayout']) ? '' : site_layout_placeholder($name);
    }
    if ($name === 'privacy-content') {
        return $searching ? '' : site_layout_block('privacy', $context);
    }
    if ($name === 'privacy') {
        $name = 'conf-policy';
    }
    if (isset(site_layout_blocks()[$name])) {
        return $searching || $context['fragment'] ? '' : site_layout_block($name, $context);
    }
    if (isset($context['extensions'][$name]) && $context['extensions'][$name]['kind'] === 'single') {
        return $searching ? '' : site_render_extension($name, '', $context);
    }
    if (isset($context['contactTokens'][$name])) {
        if ($context['contacts'] === null) {
            $context['contacts'] = site_contact_settings();
        }
        $markup = site_contact_markup($context['contactTokens'][$name], $context['base'], $context['contacts']);
        return $markup !== '' ? $markup : ($snippets[$name] ?? '');
    }
    return isset($snippets[$name]) && is_string($snippets[$name]) ? $snippets[$name] : $match[0];
}

function site_escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function site_author_credit(string $locale): string
{
    $link = '<a href="' . site_escape(SITE_PRODUCT_REPOSITORY) . '">' . site_escape(SITE_PRODUCT_NAME) . '</a>';
    $label = site_escape(site_translation('Сделано на %s. Автор — Бандалетов Павел.', $locale));
    return strpos($label, '%s') !== false ? str_replace('%s', $link, $label)
        : $link . ' · ' . site_escape(SITE_PRODUCT_AUTHOR);
}

function site_base(string $entry): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $suffix = '/' . $entry;
    if (substr($script, -strlen($suffix)) !== $suffix) {
        return '';
    }

    $prefix = substr($script, 0, -strlen($suffix));
    $segments = array_map(static function (string $segment): string {
        return rawurlencode(rawurldecode($segment));
    }, explode('/', $prefix));

    return '/' . ltrim(implode('/', $segments), '/');
}

function site_url(string $base, string $path = ''): string
{
    return rtrim($base, '/') . '/' . $path;
}

function site_font_awesome_stylesheet(string $base): string
{
    return site_url($base, 'templates/font-awesome.php') . '?asset=all.min.css&v=7.3.1';
}

function site_template_file(string $name): string
{
    $local = SITE_ROOT . '/templates/local/' . $name;
    return is_file($local) ? $local : SITE_ROOT . '/templates/' . $name;
}

function site_layout_blocks(): array
{
    return ['header' => 'header.php', 'mobile-menu' => 'mobile-menu.php', 'menu' => 'menu.php', 'footer' => 'footer.php',
        'home' => 'home.php', 'privacy' => 'privacy.php', 'conf-policy' => 'conf-policy.php',
        'top' => 'top.php', 'cookies' => 'cookies.php'] + SITE_MOVABLE_LAYOUTS + array_fill_keys(array_keys(site_custom_layouts()), '');
}

function site_layout_block(string $name, array &$context): string
{
    $visibility = $context['layoutVisibility'][$name] ?? site_layout_visibility_default($name);
    if ($visibility === 0 || isset($context['activeBlocks'][$name])) {
        return '';
    }
    $context['activeBlocks'][$name] = true;
    try {
        $markup = site_render_layout_block($name, $context);
        if (trim($markup) !== '' && ($visibility === 1 || $visibility === 2)) {
            return '<div class="' . ($visibility === 1 ? 'layout-mobile-only' : 'layout-desktop-only') . '">' . $markup . '</div>';
        }
        return $markup;
    } finally {
        unset($context['activeBlocks'][$name]);
    }
}

function site_render_layout_block(string $name, array &$context): string
{
    if (($name === 'search' && $context['settings']['searchMode'] === 'off')
        || ($name === 'bread-crumbs' && (!$context['settings']['breadcrumbs'] || !empty($context['searchMode'])
            || $context['pageData']['path'] === '' || ($context['originalPath'] === 'index.php' && empty($context['embeddedLayout']))))) {
        return '';
    }
    $snippets = $context['snippets'];
    if (array_key_exists($name, $snippets)) {
        return site_expand_content($snippets[$name], $snippets, $context);
    }

    $base = $context['base'];
    $page = $context['pageData'];
    $settings = $context['settings'];
    $brand = $context['brand'];
    $locale = $context['locale'] ?? 'ru';
    $originalPath = $context['originalPath'] ?? $page['path'];
    $searchMode = $context['searchMode'] ?? false;
    $searchQuery = $context['searchQuery'] ?? '';
    $title = $context['title'] ?? '';
    $navKey = $name === 'mobile-menu' ? 'mobileNavigation' : 'navigation';
    if (in_array($name, ['header', 'mobile-menu', 'main-menu'], true) && !isset($context[$navKey])) {
        $context[$navKey] = site_navigation_pages($name === 'mobile-menu');
        if ($locale !== 'ru') {
            foreach ($context[$navKey] as &$item) {
                $translation = site_read_page(site_language_page_path($item['path'], $locale));
                if ($translation !== null && site_page_is_public($translation['fields'])) {
                    $item['fields'] = $translation['fields'];
                }
            }
            unset($item);
        }
    }
    $navigation = $context[$navKey] ?? null;
    $layoutFile = site_layout_blocks()[$name];
    if (isset($context['phpLayouts'][$name])) {
        $level = ob_get_level();
        ob_start();
        try {
            // Executable source saved through the authenticated, syntax-checked layout editor.
            (static function (string $source) use ($name, &$context, $snippets, $base, $page, $settings, $brand, $locale, $originalPath, $navigation, $layoutFile, $searchMode, $searchQuery, $title) {
                eval('?>' . $source);
            })($context['phpLayouts'][$name]);
            return site_expand_content((string) ob_get_clean(), $snippets, $context);
        } catch (Throwable $exception) {
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
            error_log('Layout ' . $name . ': ' . $exception->getMessage());
        }
    }
    if ($layoutFile === '') {
        return '';
    }
    ob_start();
    require !empty($context['stockLayouts'][$name]) ? SITE_ROOT . '/templates/' . $layoutFile : site_template_file($layoutFile);
    return (string) ob_get_clean();
}

function site_valid_part(string $part): bool
{
    return preg_match('/\A' . SITE_IDENTIFIER_PATTERN . '\z/', $part) === 1
        && preg_match('/\A(?:con|prn|aux|nul|com[1-9]|lpt[1-9])\z/i', $part) !== 1;
}

function site_valid_path(string $path): bool
{
    if (strlen($path) > 240 || substr($path, -4) !== '.php') {
        return false;
    }

    $parts = explode('/', substr($path, 0, -4));
    if (strtolower($parts[0]) === 'error') {
        return preg_match('~\Aerror/404/index(?:_[a-z]{2})?\.php\z~', $path) === 1;
    }
    if (count($parts) === 1 && site_page_translation($path)[0] !== 'index.php') {
        return false;
    }
    if (in_array(strtolower($parts[0]), ['admin', 'app', 'assets', 'css', 'data', 'docs', 'extensions', 'files', 'fonts', 'form', 'icons',
        'images', 'img', 'js', 'maintenance', 'media', 'router', 'scripts', 'static', 'styles', 'templates', 'update', 'uploads', 'vendor'], true)) {
        return false;
    }

    foreach ($parts as $part) {
        if (!site_valid_part($part)) {
            return false;
        }
    }

    return true;
}

function site_page_url(string $base, string $path): string
{
    if (basename($path) === 'index.php') {
        $path = substr($path, 0, -strlen('index.php'));
    }

    return site_url($base, $path);
}

function site_canonical_url(string $base, string $path): string
{
    $host = site_host();
    if ($path === '' || $host === '') {
        return '';
    }
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $scheme = $https ? 'https' : 'http';
    $port = preg_match('/:([0-9]{1,5})\z/', $_SERVER['HTTP_HOST'] ?? '', $match) === 1 ? (int) $match[1] : 0;
    if ($port > 65535) {
        return '';
    }
    $suffix = $port !== 0 && $port !== ($https ? 443 : 80) ? ':' . $port : '';
    return $scheme . '://' . $host . $suffix . site_page_url($base, $path);
}

function site_header_inserts(): array
{
    $record = site_read_record(SITE_HEADERS_FILE, SITE_HEADERS_RECORD_LIMIT);
    $inserts = ['head' => '', 'bodyEnd' => ''];
    foreach ($inserts as $key => $default) {
        $value = $record[$key] ?? $default;
        if (!is_string($value) || strlen($value) > SITE_HEADER_INSERT_LIMIT) {
            throw new RuntimeException('Не удалось прочитать служебные заголовки.');
        }
        $inserts[$key] = $value;
    }
    return $inserts;
}

function site_page_header(string $path): string
{
    if ($path === 'index.php') {
        return <<<'PHP'
<?php
define('SITE_ROOT', __DIR__);
require SITE_ROOT . '/app/site.php';
site_render(isset($pageFile) ? $pageFile : __FILE__);
__halt_compiler();
PHP;
    }

    $toRoot = str_repeat('../', substr_count($path, '/'));
    return "<?php\n\$pageFile = __FILE__;\nrequire __DIR__ . '/" . $toRoot
        . "index.php';\n__halt_compiler();";
}

function site_page_fields(): array
{
    return ['Title', 'Heading', 'Description', 'Keywords', 'Menu', 'Order'];
}

function site_schedule_date_valid(string $value): bool
{
    if ($value === '') {
        return true;
    }
    if (!preg_match('/\A[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}\z/', $value)) {
        return false;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value);
    return $date !== false && $date->format('Y-m-d\TH:i') === $value;
}

function site_page_is_public(array $fields): bool
{
    static $now;
    if ($now === null) {
        $now = date('Y-m-d\TH:i');
    }
    $from = $fields['ActiveFrom'] ?? '';
    $until = $fields['ActiveUntil'] ?? '';
    return ($fields['Hidden'] ?? '0') === '0' && ($fields['Active'] ?? '1') === '1'
        && ($from === '' || $from <= $now) && ($until === '' || $now < $until);
}

function site_valid_metadata(array $fields): bool
{
    foreach (array_diff_key($fields, ['CSS' => true, 'JS' => true]) as $value) {
        if (strlen($value) > 1500 || preg_match('/[\x00-\x1F\x7F]/', $value)) {
            return false;
        }
    }

    foreach (['CSS', 'JS'] as $name) {
        if (site_asset_decode($fields[$name] ?? '') === null) {
            return false;
        }
    }
    return $fields['Title'] !== '' && preg_match('/\A[0-9]{1,5}\z/', $fields['Order']) === 1
        && in_array($fields['MenuVisible'] ?? '0', ['0', '1'], true)
        && in_array($fields['MobileMenu'] ?? '', ['', '0', '1'], true)
        && in_array($fields['Sitemap'] ?? '1', ['0', '1'], true)
        && in_array($fields['Active'] ?? '1', ['0', '1'], true)
        && in_array($fields['Hidden'] ?? '0', ['0', '1'], true);
}

/** @return array|null */
function site_read_page(string $path)
{
    if (!site_valid_path($path)) {
        return null;
    }

    $file = SITE_ROOT . '/' . $path;
    $resolved = realpath($file);
    $expected = str_replace('/', DIRECTORY_SEPARATOR, $file);
    if ($resolved !== $expected || !is_file($file)) {
        return null;
    }

    $limit = SITE_PAGE_LIMIT + SITE_ASSET_RECORD_LIMIT;
    $bytes = @file_get_contents($file, false, null, 0, $limit + 1);
    if ($bytes === false || strlen($bytes) > $limit) {
        return null;
    }

    $revision = hash('sha256', $bytes);
    static $memo = [];
    if (isset($memo[$path]) && $memo[$path]['revision'] === $revision) {
        return $memo[$path];
    }
    $cache = site_performance_settings();
    if ($cache['cache']) {
        $cacheKey = 'file-site:' . hash('sha256', $file . ':' . $revision . ':' . $cache['generation'] . ':' . (require __DIR__ . '/version.php'));
        $inMemory = function_exists('apcu_enabled') && apcu_enabled();
        if ($inMemory) {
            $stored = apcu_fetch($cacheKey);
        } else {
            try {
                $record = site_read_record(site_page_cache_file($path), 2 * $limit + 65536);
                $stored = ($record['key'] ?? '') === $cacheKey ? ($record['page'] ?? null) : null;
            } catch (RuntimeException $exception) {
                $stored = null;
            }
        }
        if (is_array($stored) && $stored['path'] === $path && $stored['revision'] === $revision) {
            return $memo[$path] = $stored;
        }
    }
    if (preg_match('//u', $bytes) !== 1) {
        return null;
    }

    $header = site_page_header($path);
    $pattern = str_replace("\n", '\r?\n', preg_quote($header, '~'));
    if (!preg_match('~\A' . $pattern . '\r?\n~', $bytes, $match)) {
        return null;
    }

    $sections = preg_split('/\r?\n\r?\n/', substr($bytes, strlen($match[0])), 2);
    if (count($sections) !== 2) {
        return null;
    }

    $fields = ['Title' => '', 'Heading' => '', 'Description' => '', 'Keywords' => '', 'Menu' => '', 'Order' => '100', 'Hidden' => '0',
        'MenuVisible' => '0', 'MobileMenu' => '', 'Sitemap' => '1', 'Lat' => '', 'Lng' => '', 'Redirect' => '', 'CSS' => '', 'JS' => '',
        'Active' => '1', 'ActiveFrom' => '', 'ActiveUntil' => ''];
    $seen = [];
    foreach (preg_split('/\r?\n/', $sections[0]) as $line) {
        $pair = explode(':', $line, 2);
        if (count($pair) !== 2 || !array_key_exists($pair[0], $fields) || isset($seen[$pair[0]])) {
            return null;
        }

        $seen[$pair[0]] = true;
        $fields[$pair[0]] = trim($pair[1], ' ');
    }

    if (!isset($seen['MenuVisible'])) {
        $fields['MenuVisible'] = $fields['Menu'] === '' ? '0' : '1';
    }
    if (!site_valid_metadata($fields) || !site_schedule_date_valid($fields['ActiveFrom']) || !site_schedule_date_valid($fields['ActiveUntil'])
        || ($fields['ActiveFrom'] !== '' && $fields['ActiveUntil'] !== '' && $fields['ActiveFrom'] >= $fields['ActiveUntil'])) {
        return null;
    }

    $parsed = [
        'path' => $path,
        'fields' => $fields,
        'html' => $sections[1],
        'revision' => $revision,
        'menu_explicit' => isset($seen['MenuVisible']),
    ];
    if ($cache['cache']) {
        if ($inMemory) {
            apcu_store($cacheKey, $parsed, 3600);
        } else {
            site_page_cache_write(site_page_cache_file($path), ['key' => $cacheKey, 'page' => $parsed]);
        }
    }
    return $memo[$path] = $parsed;
}

function site_pages(bool $includeTranslations = false): array
{
    $directory = new RecursiveDirectoryIterator(SITE_ROOT, FilesystemIterator::SKIP_DOTS);
    $filter = new RecursiveCallbackFilterIterator($directory, static function (SplFileInfo $item): bool {
        if ($item->isLink()) {
            return false;
        }

        $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($item->getPathname(), strlen(SITE_ROOT) + 1));
        if ($item->isDir()) {
            return site_valid_path($path . '/index.php')
                && $item->getRealPath() === $item->getPathname();
        }

        return site_valid_path($path);
    });

    $pages = [];
    $files = new RecursiveIteratorIterator($filter, RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD);
    foreach ($files as $file) {
        $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen(SITE_ROOT) + 1));
        if (!$includeTranslations && site_page_translation($path)[1] !== '') {
            continue;
        }
        $page = site_read_page($path);
        if ($page !== null) {
            $pages[] = ['path' => $path, 'fields' => array_diff_key($page['fields'], ['CSS' => true, 'JS' => true]), 'revision' => $page['revision']];
        }
    }

    usort($pages, static function (array $left, array $right): int {
        $order = (int) $left['fields']['Order'] <=> (int) $right['fields']['Order'];
        return $order !== 0 ? $order : strcmp($left['path'], $right['path']);
    });

    return $pages;
}

function site_asset_decode(string $encoded)
{
    if (strlen($encoded) > (int) ceil(SITE_ASSET_LIMIT / 3) * 4) {
        return null;
    }
    $code = base64_decode($encoded, true);
    return $code !== false && strlen($code) <= SITE_ASSET_LIMIT && preg_match('//u', $code) === 1
        && strpos($code, "\0") === false && base64_encode($code) === $encoded ? $code : null;
}

function site_global_assets(): array
{
    $record = site_read_record(SITE_ASSETS_FILE, SITE_ASSET_RECORD_LIMIT);
    $assets = ['CSS' => '', 'JS' => ''];
    foreach ($assets as $kind => $empty) {
        $encoded = $record[$kind] ?? '';
        if (!is_string($encoded) || site_asset_decode($encoded) === null) {
            throw new RuntimeException('Неверный формат файла со стилями и скриптами.');
        }
        $assets[$kind] = $encoded;
    }
    return $assets;
}

function site_asset_urls(string $base, array $page): array
{
    try {
        $global = site_global_assets();
    } catch (RuntimeException $exception) {
        $global = [];
    }
    $urls = ['CSS' => [], 'JS' => []];
    foreach (['' => $global, 'page' => $page['fields']] as $scope => $assets) {
        foreach ($urls as $kind => $items) {
            if (!empty($assets[$kind])) {
                $params = ['type' => strtolower($kind)];
                if ($scope === 'page') {
                    $params['page'] = $page['path'];
                }
                $urls[$kind][] = site_url($base, 'templates/custom-assets.php') . '?' . http_build_query($params);
            }
        }
    }
    return $urls;
}

function site_page_menu_visible(array $fields, bool $mobile): bool
{
    $mobileChoice = $fields['MobileMenu'] ?? '';
    return ($mobile && $mobileChoice !== '' ? $mobileChoice : $fields['MenuVisible']) === '1';
}

function site_navigation_pages(bool $mobile = false): array
{
    $pages = site_pages();
    $excluded = [];
    foreach ($pages as $page) {
        if ((!site_page_is_public($page['fields']) || !site_page_menu_visible($page['fields'], $mobile)) && basename($page['path']) === 'index.php') {
            $excluded[dirname($page['path'])] = true;
        }
    }

    $visible = array_filter($pages, static function (array $page) use ($excluded, $mobile): bool {
        if (!site_page_is_public($page['fields']) || !site_page_menu_visible($page['fields'], $mobile)) {
            return false;
        }
        $folder = dirname($page['path']);
        while ($folder !== '.') {
            if (isset($excluded[$folder])) {
                return false;
            }
            $folder = dirname($folder);
        }
        return !isset($excluded['.']);
    });
    $byPath = array_column($visible, null, 'path');
    return site_navigation_branch(site_page_tree($pages), $byPath);
}

function site_section_list(array $context, bool $recursive = false): string
{
    $path = $context['originalPath'] ?? '';
    if ($path === '' || (!$recursive && basename($path) !== 'index.php')) {
        return '';
    }
    $tree = site_page_tree(site_pages());
    $links = [];
    $visit = static function (string $folder) use (&$visit, $tree, $path, $context, $recursive, &$links) {
        foreach ($tree[$folder] ?? [] as $node) {
            $entry = $node['page'];
            if ($entry !== null && $entry['path'] !== $path && site_page_is_public($entry['fields'])) {
                $localized = site_localized_page($entry['path'], $context['locale']) ?? $entry;
                $label = site_expand_text($localized['fields']['Menu'] ?: $localized['fields']['Title'], $context['snippets']);
                $links[] = '<li><a href="' . site_escape(site_page_link($context['base'], $localized)) . '">' . site_escape($label) . '</a></li>';
            }
            if ($recursive && $node['folder'] !== '') {
                $visit($node['folder']);
            }
        }
    };
    $visit(dirname($path));
    return $links ? '<ul class="section-links">' . implode('', $links) . '</ul>' : '';
}

function site_page_redirect_url(string $base, string $path, string $value): string
{
    $url = site_map_url($value);
    if ($url === '') {
        return '';
    }
    if ($url[0] === '/') {
        $target = parse_url($url, PHP_URL_PATH);
        $original = site_page_translation($path)[0];
        if (in_array($target, [site_page_url('', $original), '/' . $original, '/' . $path], true)) {
            return '';
        }
        return site_url($base, substr($url, 1));
    }
    $target = parse_url($url);
    if (strtolower($target['host'] ?? '') === site_host()
        && in_array($target['path'] ?? '/', [site_page_url($base, site_page_translation($path)[0]), site_url($base, $path)], true)) {
        return '';
    }
    return !isset($target['user']) && !isset($target['pass']) ? $url : '';
}

function site_page_link(string $base, array $page): string
{
    $path = $page['path'];
    return site_page_redirect_url($base, $path, $page['fields']['Redirect'] ?? '')
        ?: site_page_url($base, site_page_translation($path)[0]);
}

function site_page_tree(array $pages): array
{
    $groups = ['.' => []];
    foreach ($pages as $page) {
        $path = $page['path'];
        $folder = dirname($path);
        $order = (int) $page['fields']['Order'];
        for ($current = $folder; $current !== '.'; $current = dirname($current)) {
            $groups[$current] = $groups[$current] ?? [];
            $parent = dirname($current);
            if (!isset($groups[$parent][$current])) {
                $groups[$parent][$current] = ['folder' => $current, 'page' => null, 'order' => $order];
            }
        }
        if ($folder !== '.' && basename($path) === 'index.php') {
            $groups[dirname($folder)][$folder]['page'] = $page;
            $groups[dirname($folder)][$folder]['order'] = $order;
        } else {
            $groups[$folder][$path] = ['folder' => '', 'page' => $page, 'order' => $path === 'index.php' ? -1 : $order];
        }
    }
    foreach ($groups as &$group) {
        uasort($group, static function (array $left, array $right): int {
            $order = $left['order'] <=> $right['order'];
            $leftPath = $left['folder'] ?: $left['page']['path'];
            $rightPath = $right['folder'] ?: $right['page']['path'];
            return $order ?: strcmp($leftPath, $rightPath);
        });
    }
    return $groups;
}

function site_navigation_branch(array $tree, array $byPath, string $folder = '.'): array
{
    $links = [];
    foreach ($tree[$folder] ?? [] as $node) {
        $path = $node['page']['path'] ?? '';
        if (isset($byPath[$path])) {
            $links[] = $byPath[$path];
        }
        if ($node['folder'] !== '') {
            foreach (site_navigation_branch($tree, $byPath, $node['folder']) as $child) {
                $links[] = $child;
            }
        }
    }
    return $links;
}

function site_render(string $file, ?string $routeBase = null)
{
    ew_functions();
    $path = str_replace(DIRECTORY_SEPARATOR, '/', substr($file, strlen(SITE_ROOT) + 1));
    $base = $routeBase ?? site_base($path);
    if ($path === 'privacy.php') {
        http_response_code(404);
        return;
    }
    list($originalPath, $explicit) = site_page_translation($path);
    $enabled = site_region_settings()['languages'];
    $locale = site_public_language($base, $explicit);
    $settings = site_settings();
    $searchMode = $originalPath === 'index.php' && empty($_SERVER['PATH_INFO']) && array_key_exists('search', $_GET)
        && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET';
    if ($searchMode && $settings['searchMode'] === 'off') {
        http_response_code(404);
        return;
    }
    $searchQuery = $searchMode ? site_search_query($_GET['search']) : '';
    $searchIndex = $searchMode ? site_search_index() : [];
    if ($searchMode && ($_GET['suggest'] ?? '') === '1' && !isset($_GET['ajax'])) {
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');
        $results = site_search_find($searchIndex, $searchQuery, $locale, 6, 0, $base);
        foreach ($results as &$result) {
            $result = ['title' => $result['title'], 'url' => $result['url']];
        }
        unset($result);
        echo json_encode($results, JSON_UNESCAPED_UNICODE);
        return;
    }
    $brand = site_brand_settings();
    $variables = array_filter(array_diff_key($settings['variables'], site_layout_blocks()), 'is_string');
    $contentHost = site_content_host($base, !$searchMode && ($_GET['ajax'] ?? '') !== '1');
    $stockLayouts = [];
    $phpLayouts = [];
    $layoutVisibility = [];
    $snippets = ['author' => site_author_credit($locale)] + site_date_snippets()
        + site_snippet_values($contentHost, $stockLayouts, $phpLayouts, $layoutVisibility) + array_map('site_escape', $variables);
    $settings['name'] = site_expand_text($settings['name'], $snippets);
    $sitePublicUrl = $settings['publicUrl'] ?: site_canonical_url($base, 'index.php');
    $snippets = ['site-name' => site_escape($settings['name']), 'site-url' => site_escape($sitePublicUrl)] + $snippets;
    $page = empty($_SERVER['PATH_INFO']) && ($explicit === '' || in_array($explicit, $enabled, true))
        ? site_localized_page($originalPath, $locale) : null;
    if ($originalPath === 'error/404/index.php') {
        http_response_code(404);
    }
    if ($page === null) {
        http_response_code(404);
        $page = site_localized_page('error/404/index.php', $locale) ?? [
            'path' => '',
            'language' => $locale,
            'fields' => ['Title' => site_translation('Страница не найдена', $locale), 'Heading' => '', 'Description' => ''],
            'html' => '<p>' . site_escape(site_translation('Проверьте адрес страницы или выберите раздел в меню.', $locale)) . '</p>',
        ];
        $page['path'] = '';
    }

    header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    $fragment = ($_GET['ajax'] ?? '') === '1';
    if (!$fragment && !$searchMode && $page['path'] !== '' && $originalPath !== 'error/404/index.php'
        && in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
        $redirect = site_page_redirect_url($base, $page['path'], $page['fields']['Redirect']);
        if ($redirect !== '') {
            header('Location: ' . $redirect, true, 302);
            return;
        }
    }
    $editor = $fragment ? [] : site_editor_session($base);
    $public = site_public_context($base, $fragment);
    if ($fragment && !$public) {
        http_response_code(403);
        echo site_translation('Доступ к фрагменту разрешён только из сеанса на этом сайте.', $locale);
        return;
    }
    $components = [
        'base' => $base, 'page' => $page['path'], 'active' => [$originalPath => true],
        'forms' => null, 'formSession' => $public,
        'contactTokens' => site_contact_tokens(), 'contacts' => null,
        'extensions' => site_extensions(),
        'pageData' => $page, 'settings' => $settings, 'snippets' => $snippets, 'brand' => $brand,
        'navigation' => null, 'activeBlocks' => [], 'fragment' => $fragment, 'stockLayouts' => $stockLayouts, 'phpLayouts' => $phpLayouts,
        'layoutVisibility' => $layoutVisibility,
        'locale' => $locale, 'editorLocale' => $editor['language'] ?? $locale, 'originalPath' => $originalPath, 'mapPoints' => [],
    ];
    $inline = !$searchMode && $page['path'] !== '' && ($editor['edit'] ?? false);
    $components['bannerEdit'] = $inline;
    $content = $searchMode && !$fragment ? '' : site_finish_map(site_expand_content($page['html'], $snippets, $components, $inline), $components);
    if (!$searchMode && $page['path'] !== '' && preg_match('~\A(?:\s|&nbsp;|</?(?:p|div)>|<br\s*/?>)*\z~i', $page['html'])) {
        $content = site_section_list($components);
    }
    unset($components['mapPoints']);
    if (!$searchMode && $page['path'] !== '' && $originalPath === 'index.php') {
        $components['pageContent'] = $content;
        $components['snippets']['page-content'] = $content;
        $content = site_layout_block('home', $components);
        unset($components['pageContent'], $components['snippets']['page-content']);
    }
    $fields = $page['fields'];
    $title = site_expand_text($fields['Title'], $snippets);
    $heading = $fields['Heading'] !== '' ? site_expand_text($fields['Heading'], $snippets) : $title;
    if ($searchMode && !$fragment) {
        $title = $heading = site_translation('Поиск по сайту', $locale);
        $fields['Description'] = '';
        $fields['Keywords'] = '';
        $requestedPage = $_GET['search_page'] ?? '';
        $searchPage = is_string($requestedPage) && preg_match('/\A[1-9][0-9]{0,3}\z/', $requestedPage)
            ? (int) $requestedPage : 1;
        $searchOffset = ($searchPage - 1) * 20;
        $searchResults = site_search_find($searchIndex, $searchQuery, $locale, 21, $searchOffset, $base);
        $searchHasNext = count($searchResults) > 20;
        if ($searchHasNext) {
            array_pop($searchResults);
        }
        ob_start();
        require site_template_file('search-results.php');
        $content = ob_get_clean();
    }
    if ($fragment) {
        require site_template_file('content.php');
        return;
    }
    $components['title'] = $title;
    $components['searchMode'] = $searchMode;
    $components['searchQuery'] = $searchQuery;
    ob_start();
    require site_template_file('layout.php');
    echo site_place_layout_blocks((string) ob_get_clean(), $components);
}

if (site_region_settings()['timezone'] !== 'auto') {
    date_default_timezone_set(site_region_settings()['timezone']);
}
