<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return <<<'JS'
const adminLanguages = document.querySelector('.admin-language-picker');
if (adminLanguages) {
    document.addEventListener('click', (event) => {
        if (adminLanguages.open && !adminLanguages.contains(event.target)) adminLanguages.open = false;
    });
    adminLanguages.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape' || !adminLanguages.open) return;
        event.preventDefault();
        adminLanguages.open = false;
        adminLanguages.querySelector('summary').focus();
    });
}

document.querySelectorAll('[data-site-search], [data-admin-search]').forEach((form) => {
    const input = form.querySelector('input[type="search"]');
    const list = form.querySelector('.site-search-suggestions');
    const compact = form.closest('.site-search-compact');
    let delay;
    let request;
    const close = () => {
        clearTimeout(delay);
        if (request) request.abort();
        list.hidden = true;
        list.replaceChildren();
    };
    if (compact) {
        compact.addEventListener('toggle', () => {
            if (compact.open) input.focus({preventScroll: true});
            else close();
        });
        compact.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && !event.defaultPrevented && compact.open) {
                event.preventDefault();
                compact.open = false;
                compact.querySelector('summary').focus();
            }
        });
    }
    input.addEventListener('input', () => {
        close();
        const query = input.value.trim();
        if (query.length < 2 && !/[\u3000-\uD7AF]/.test(query)) return;
        delay = setTimeout(async () => {
            request = new AbortController();
            const url = new URL(form.action);
            for (const [name, value] of new FormData(form)) {
                url.searchParams.set(name, name === input.name ? query : value);
            }
            url.searchParams.set('suggest', '1');
            try {
                const response = await fetch(url, {signal: request.signal, headers: {Accept: 'application/json'}});
                if (!response.ok) return;
                const payload = await response.json();
                const items = Array.isArray(payload) ? payload : payload.suggestions;
                if (!Array.isArray(items)) return;
                if (input.value.trim() !== query) return;
                items.forEach((item) => {
                    const link = document.createElement('a');
                    link.textContent = item.title;
                    link.href = item.url;
                    const entry = document.createElement('li');
                    entry.appendChild(link);
                    list.appendChild(entry);
                });
                list.hidden = !list.childElementCount;
            } catch (error) {
                // The full search form remains available.
            }
        }, 180);
    });
    form.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !list.hidden) {
            event.preventDefault();
            close();
            input.focus();
        } else if (event.key === 'ArrowDown' && event.target === input && !list.hidden) {
            event.preventDefault();
            list.querySelector('a').focus();
        }
    });
    form.addEventListener('focusout', (event) => {
        if (!form.contains(event.relatedTarget)) close();
    });
});
JS;
