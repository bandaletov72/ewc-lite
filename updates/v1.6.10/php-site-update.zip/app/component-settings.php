<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_COMPONENTS_FILE = SITE_ROOT . '/admin/.components.php';

function site_component_schema(): array
{
    $toggle = ['on' => 'Показывать', 'off' => 'Скрывать'];
    $schema = ['gal' => [
        'label' => 'Карусель [gal]',
        'examplePath' => '/images/myfotos/',
        'settings' => [
            'arrows' => ['label' => 'Стрелки', 'default' => 'on', 'options' => $toggle],
            'numbers' => ['label' => 'Номер слайда', 'default' => 'on', 'options' => $toggle],
            'effect' => ['label' => 'Переход', 'default' => 'slide',
                'options' => ['slide' => 'Плавная прокрутка', 'fade' => 'Плавное затухание', 'none' => 'Мгновенно']],
            'fit' => ['label' => 'Заполнение кадра', 'default' => 'contain',
                'options' => ['contain' => 'Вместить целиком (contain)', 'cover' => 'Заполнить кадр (cover)']],
        ],
    ], 'fotos' => [
        'label' => 'Фотогалерея [fotos]',
        'examplePath' => '/images/myfotos/',
        'settings' => [
            'columns' => ['label' => 'Колонки на широком экране', 'default' => 'auto',
                'options' => ['auto' => 'Автоматически', 1 => '1', 2 => '2', 3 => '3', 4 => '4', 5 => '5', 6 => '6']],
            'ratio' => ['label' => 'Пропорции фотографии', 'default' => '4x3',
                'options' => ['4x3' => '4:3', '1x1' => '1:1', '16x9' => '16:9', 'original' => 'Исходные']],
            'fit' => ['label' => 'Заполнение кадра', 'default' => 'cover',
                'options' => ['cover' => 'Заполнить кадр (cover)', 'contain' => 'Вместить целиком (contain)']],
            'captions' => ['label' => 'Подписи из имён файлов', 'default' => 'off', 'options' => $toggle],
            'links' => ['label' => 'Ссылки на оригиналы', 'default' => 'on', 'options' => $toggle],
        ],
    ], 'files' => [
        'label' => 'Список файлов [files]',
        'examplePath' => '/files/myfiles/',
        'settings' => [
            'icons' => ['label' => 'Иконки файлов', 'default' => 'on', 'options' => $toggle],
            'size' => ['label' => 'Размер файла', 'default' => 'off', 'options' => $toggle],
            'order' => ['label' => 'Сортировка по имени', 'default' => 'asc', 'options' => ['asc' => 'От А до Я', 'desc' => 'От Я до А']],
            'download' => ['label' => 'При нажатии', 'default' => 'off', 'options' => ['off' => 'Открыть', 'on' => 'Скачать']],
        ],
    ]];
    $width = ['label' => 'Ширина блока', 'default' => '100', 'options' => [
        '100' => '100%', '50' => '50%', '33' => '33%', '25' => '25%',
    ]];
    foreach (['gal', 'fotos', 'files'] as $component) {
        $schema[$component]['settings']['width'] = $width;
    }
    $schema['banners'] = ['label' => 'Баннеры [banners]', 'settings' => $schema['gal']['settings']];
    $schema['banners']['settings']['fit']['default'] = 'cover';
    foreach (site_extensions() as $name => $component) {
        if (!isset($component['settings']) || !is_array($component['settings'])) {
            continue;
        }
        $settings = [];
        foreach ($component['settings'] as $key => $field) {
            if (is_string($key) && site_valid_snippet($key) && is_array($field)
                && is_string($field['label'] ?? null) && is_string($field['default'] ?? null)
                && is_array($field['options'] ?? null) && isset($field['options'][$field['default']])) {
                $settings[$key] = $field;
            }
        }
        if ($settings) {
            $schema[$name] = ['label' => is_string($component['label'] ?? null) ? $component['label'] : $name,
                'settings' => $settings];
        }
    }
    return $schema;
}

function site_component_settings(): array
{
    try {
        $saved = site_read_record(SITE_COMPONENTS_FILE);
    } catch (RuntimeException $exception) {
        $saved = [];
    }
    $settings = [];
    foreach (site_component_schema() as $id => $component) {
        foreach ($component['settings'] as $name => $field) {
            $value = $saved[$id][$name] ?? $field['default'];
            $settings[$id][$name] = is_string($value) && isset($field['options'][$value]) ? $value : $field['default'];
        }
    }
    return $settings;
}

function site_component_options(string $component, string $overrides): array
{
    static $defaults;
    if ($defaults === null) {
        $defaults = site_component_settings();
    }
    $settings = $defaults[$component];
    $fields = site_component_schema()[$component]['settings'];
    foreach (preg_split('/\s+/', trim($overrides), -1, PREG_SPLIT_NO_EMPTY) as $option) {
        $parts = explode('=', $option, 2);
        if (count($parts) === 2) {
            list($name, $value) = $parts;
            if ($name === 'width' && substr($value, -1) === '%') {
                $value = substr($value, 0, -1);
            }
            if (isset($fields[$name]['options'][$value])) {
                $settings[$name] = $value;
            }
        }
    }
    return $settings;
}
