(() => {
    window.siteFetchContent = async (path) => {
        const token = document.querySelector('meta[name="site-fragment-token"]');
        const url = new URL(path, window.location.href);
        if (!token || url.origin !== window.location.origin) {
            throw new Error('Фрагмент доступен в текущем сеансе сайта.');
        }
        url.searchParams.set('ajax', '1');
        const response = await fetch(url, {
            credentials: 'same-origin',
            headers: { Accept: 'text/html', 'X-Site-Fragment': token.content },
        });
        if (!response.ok) throw new Error('Не удалось загрузить страницу (' + response.status + ').');
        return response.text();
    };

    document.addEventListener('click', (event) => {
        document.querySelectorAll('[data-breadcrumb-siblings][open]').forEach((menu) => {
            if (!menu.contains(event.target)) menu.open = false;
        });
    });
    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        const menu = event.target.closest?.('[data-breadcrumb-siblings][open]');
        if (menu) {
            event.preventDefault();
            menu.open = false;
            menu.querySelector('summary').focus();
        }
    });

    document.querySelectorAll('.mobile-header-menu').forEach((element, index) => {
        const toggle = element.querySelector('[data-mobile-toggle]');
        const drawer = element.querySelector('[data-mobile-drawer]');
        if (!toggle || !drawer) return;
        drawer.id = 'mobile-site-menu-' + (index + 1);
        toggle.setAttribute('aria-controls', drawer.id);
        toggle.hidden = false;
        const mobile = window.matchMedia('(max-width: 40rem)');
        const closeOnResize = () => { if (!mobile.matches && drawer.open) drawer.close(); };

        toggle.addEventListener('click', () => {
            if (!drawer.open) {
                drawer.showModal();
                toggle.setAttribute('aria-expanded', 'true');
            }
        });
        drawer.querySelector('[data-mobile-close]').addEventListener('click', () => drawer.close());
        drawer.addEventListener('click', (event) => {
            if (event.target.closest('[data-mobile-navigation] a')) {
                drawer.close();
            } else if (event.target === drawer) {
                const panel = drawer.getBoundingClientRect();
                if (event.clientX < panel.left || event.clientX > panel.right) drawer.close();
            }
        });
        drawer.addEventListener('close', () => toggle.setAttribute('aria-expanded', 'false'));
        if (mobile.addEventListener) mobile.addEventListener('change', closeOnResize);
        else mobile.addListener(closeOnResize);
    });

    const formatPhone = (input) => {
        const raw = input.value;
        if (!/^ *\+?[0-9 ().-]*$/.test(raw)) return;

        const digits = raw.replace(/\D/g, '');
        const hasPlus = raw.trimStart().startsWith('+');
        const hasRussianPrefix = hasPlus ? digits[0] === '7' : /^[78]/.test(digits);
        let value = hasPlus ? '+' + digits : digits;
        if (digits && (!hasPlus || hasRussianPrefix)) {
            const local = hasRussianPrefix ? digits.slice(1) : digits;
            value = '+7';
            if (local.length) value += '(' + local.slice(0, 3);
            if (local.length > 3) value += ')' + local.slice(3, 6);
            if (local.length > 6) value += '-' + local.slice(6, 8);
            if (local.length > 8) value += '-' + local.slice(8);
        }
        if (value === raw) return;

        const caret = input.selectionStart;
        input.value = value;
        if (caret === null || caret === raw.length) return;
        let digitsBeforeCaret = raw.slice(0, caret).replace(/\D/g, '').length;
        if (digitsBeforeCaret > 0 && !hasPlus && !hasRussianPrefix) digitsBeforeCaret += 1;
        let position = 0;
        while (position < value.length && digitsBeforeCaret > 0) {
            if (/\d/.test(value[position])) digitsBeforeCaret -= 1;
            position += 1;
        }
        input.setSelectionRange(position, position);
    };

    const captchaWidgets = new WeakMap();
    let captchaScript;
    const loadCaptcha = () => {
        if (!captchaScript) {
            captchaScript = new Promise((resolve, reject) => {
                const script = document.createElement('script');
                const timer = window.setTimeout(reject, 15000);
                window.siteRecaptchaReady = () => {
                    window.clearTimeout(timer);
                    resolve(window.grecaptcha);
                };
                script.addEventListener('error', () => {
                    window.clearTimeout(timer);
                    reject();
                }, { once: true });
                script.async = true;
                script.src = 'https://www.google.com/recaptcha/api.js?onload=siteRecaptchaReady&render=explicit&hl=ru';
                document.head.append(script);
            });
        }
        return captchaScript;
    };

    const initialize = (root) => {
        const selector = '[data-gallery]:not([data-ready]), [data-contact-form]:not([data-ready])';
        const elements = [...(root.matches(selector) ? [root] : []), ...root.querySelectorAll(selector)];
        elements.forEach((element) => {
            if (element.closest('[data-banner-dialog]:not([open]), [data-action-dialog]:not([open])')) return;
            element.dataset.ready = 'true';
            if (element.matches('[data-contact-form]')) {
                const formatTelephone = (event) => {
                    if (event.target.matches('input[type="tel"]')) formatPhone(event.target);
                };
                element.addEventListener('input', formatTelephone);
                element.addEventListener('change', formatTelephone);
                element.querySelectorAll('input[type="tel"]').forEach(formatPhone);
                const button = element.querySelector('button[type="submit"]');
                const widget = element.querySelector('[data-form-captcha]');
                if (!widget) {
                    button.disabled = false;
                    return;
                }
                const status = element.querySelector('[data-captcha-status]');
                loadCaptcha().then((api) => {
                    if (!element.isConnected) {
                        delete element.dataset.ready;
                        return;
                    }
                    const id = api.render(widget, {
                        sitekey: widget.dataset.sitekey,
                        size: 'compact',
                        'error-callback': () => { status.textContent = 'CAPTCHA недоступна. Обновите страницу.'; },
                        'expired-callback': () => { status.textContent = 'Подтвердите проверку ещё раз.'; },
                        callback: () => { status.textContent = 'Проверка пройдена.'; },
                    });
                    captchaWidgets.set(element, { api, id });
                    button.disabled = false;
                }).catch(() => {
                    status.textContent = 'Не удалось загрузить CAPTCHA. Обновите страницу и попробуйте снова.';
                });
                return;
            }
            const controls = element.querySelector('.gallery-controls');
            const track = element.querySelector('[data-gallery-track]');
            const images = [...track.children];
            if (images.length < 2) return;
            const status = controls && controls.querySelector('[data-gallery-status]');
            const effect = element.dataset.galleryEffect;
            const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

            let current = -1;
            const select = (index) => {
                if (index === current) return;
                current = index;
                if (status) status.textContent = (current + 1) + ' / ' + images.length;
                images.forEach((image, position) => {
                    image.classList.toggle('is-active', position === current);
                    if (position === current) image.removeAttribute('aria-hidden');
                    else image.setAttribute('aria-hidden', 'true');
                    if (element.hasAttribute('data-banners')) image.inert = position !== current;
                });
            };
            const move = (direction) => {
                const next = (current + direction + images.length) % images.length;
                if (effect === 'fade') {
                    select(next);
                } else {
                    track.scrollTo({ left: images[next].offsetLeft,
                        behavior: effect === 'slide' && !reducedMotion.matches ? 'smooth' : 'auto' });
                }
            };

            if (controls) {
                controls.hidden = false;
                const previous = controls.querySelector('[data-gallery-prev]');
                const next = controls.querySelector('[data-gallery-next]');
                if (previous && next) {
                    previous.addEventListener('click', () => move(-1));
                    next.addEventListener('click', () => move(1));
                }
            }
            if (effect === 'fade') {
                let start;
                track.addEventListener('touchstart', (event) => {
                    start = event.touches.length === 1 ? event.touches[0] : null;
                }, { passive: true });
                track.addEventListener('touchcancel', () => { start = null; }, { passive: true });
                track.addEventListener('touchend', (event) => {
                    if (!start) return;
                    const end = Array.from(event.changedTouches).find((touch) => touch.identifier === start.identifier);
                    if (!end) return;
                    const x = end.clientX - start.clientX;
                    const y = end.clientY - start.clientY;
                    start = null;
                    if (Math.abs(x) > Math.max(35, Math.abs(y))) move(x < 0 ? 1 : -1);
                }, { passive: true });
            } else {
                track.addEventListener('scroll', () => {
                    if (track.clientWidth > 0) {
                        select(Math.max(0, Math.min(images.length - 1, Math.round(track.scrollLeft / track.clientWidth))));
                    }
                }, { passive: true });
            }
            element.addEventListener('keydown', (event) => {
                if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
                if (event.target.matches('input, textarea, select, [contenteditable]')) return;
                event.preventDefault();
                move(event.key === 'ArrowRight' ? 1 : -1);
            });
            select(0);
        });
    };

    document.addEventListener('click', (event) => {
        const opener = event.target.closest('[data-banner-open], [data-action-open]');
        const closer = event.target.closest('[data-banner-close], [data-action-close]');
        if (opener) {
            const dialog = document.getElementById(opener.dataset.bannerOpen || opener.dataset.actionOpen);
            if (dialog?.matches('[data-banner-dialog], [data-action-dialog]') && !dialog.open) {
                dialog.showModal();
                initialize(dialog);
            }
        } else if (closer) {
            closer.closest('[data-banner-dialog], [data-action-dialog]').close();
        }
    });
    initialize(document.body);
    new MutationObserver((records) => {
        records.forEach((record) => record.addedNodes.forEach((node) => {
            if (node.nodeType === 1) initialize(node);
        }));
    }).observe(document.body, { childList: true, subtree: true });

    document.addEventListener('submit', async (event) => {
        const form = event.target;
        if (!form.matches('[data-contact-form]')) return;
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        if (button.disabled) return;

        const feedback = form.querySelector('[data-form-feedback]');
        const fields = [...form.querySelectorAll('[data-message-field]')];
        fields.forEach((field) => {
            field.querySelector('[data-field-error]').hidden = true;
            field.querySelectorAll('[aria-invalid]').forEach((input) => input.removeAttribute('aria-invalid'));
        });
        feedback.hidden = true;
        const captcha = captchaWidgets.get(form);
        const token = captcha ? captcha.api.getResponse(captcha.id) : '';
        if (captcha && !token) {
            feedback.textContent = 'Подтвердите, что вы не робот.';
            feedback.classList.add('error');
            feedback.hidden = false;
            return;
        }
        button.disabled = true;
        try {
            const body = new FormData(form);
            if (captcha) body.set('g-recaptcha-response', token);
            const response = await fetch(form.action, {
                method: 'POST',
                body,
                headers: { Accept: 'application/json' },
            });
            const result = await response.json();
            feedback.textContent = result.message;
            feedback.classList.toggle('error', !result.ok);
            if (result.ok) {
                form.reset();
            } else {
                fields.forEach((field) => {
                    const name = field.dataset.messageField;
                    if (!Object.prototype.hasOwnProperty.call(result.fields || {}, name)) return;
                    const fieldError = field.querySelector('[data-field-error]');
                    fieldError.textContent = result.fields[name];
                    fieldError.hidden = false;
                    field.querySelectorAll('input, textarea, select').forEach((input) => input.setAttribute('aria-invalid', 'true'));
                });
            }
        } catch (error) {
            feedback.textContent = 'Не удалось отправить сообщение. Попробуйте ещё раз.';
            feedback.classList.add('error');
        } finally {
            feedback.hidden = false;
            button.disabled = false;
            if (captcha && form.isConnected) {
                captcha.api.reset(captcha.id);
                form.querySelector('[data-captcha-status]').textContent = 'Подтвердите, что вы не робот.';
            }
        }
    });
})();

(() => {
    const meta = document.querySelector('meta[name=site-analytics]');
    if (!meta) return;
    const enabled = JSON.parse(meta.content);
    const load = (source) => {
        const script = document.createElement('script');
        script.src = source;
        script.async = true;
        document.head.append(script);
        return script;
    };
    if (enabled.metrica) {
        if (!window.ym) {
            window.ym = function () { (window.ym.a = window.ym.a || []).push(arguments); };
            window.ym.l = Date.now();
            load('https://mc.yandex.ru/metrika/tag.js');
        }
        window.ym(Number(enabled.metrica), 'init', { clickmap: true, trackLinks: true, accurateTrackBounce: true });
    }
    if (enabled.analytics) {
        if (!window.gtag) {
            window.dataLayer = window.dataLayer || [];
            window.gtag = function () { window.dataLayer.push(arguments); };
            window.gtag('js', new Date());
            load('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(enabled.analytics));
        }
        window.gtag('config', enabled.analytics);
    }
    if (enabled.pixel) {
        if (!window.fbq) {
            const pixel = function () {
                if (pixel.callMethod) pixel.callMethod.apply(pixel, arguments);
                else pixel.queue.push(arguments);
            };
            pixel.push = pixel;
            pixel.loaded = true;
            pixel.version = '2.0';
            pixel.queue = [];
            window.fbq = pixel;
            if (!window._fbq) window._fbq = pixel;
            load('https://connect.facebook.net/en_US/fbevents.js');
        }
        window.fbq('init', enabled.pixel);
        window.fbq('track', 'PageView');
    }
    if (enabled.cloudflare) {
        const beacon = document.createElement('script');
        beacon.src = 'https://static.cloudflareinsights.com/beacon.min.js';
        beacon.defer = true;
        beacon.dataset.cfBeacon = JSON.stringify({ token: enabled.cloudflare });
        document.head.append(beacon);
    }
    if (enabled.clarity) {
        if (!window.clarity) {
            window.clarity = function () { (window.clarity.q = window.clarity.q || []).push(arguments); };
            load('https://www.clarity.ms/tag/' + encodeURIComponent(enabled.clarity));
        }
        window.clarity('consentv2', {ad_Storage: 'denied', analytics_Storage: 'granted'});
    }
    if (enabled.umami) {
        const tracker = document.createElement('script');
        tracker.src = 'https://cloud.umami.is/script.js';
        tracker.dataset.websiteId = enabled.umami;
        tracker.defer = true;
        document.head.append(tracker);
    }
})();

(() => {
    const providers = new Map();
    const loadScript = (url) => new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = url;
        script.async = true;
        const timer = setTimeout(() => reject(new Error('Map script timeout')), 12000);
        script.addEventListener('load', () => { clearTimeout(timer); resolve(); }, { once: true });
        script.addEventListener('error', () => { clearTimeout(timer); reject(new Error('Map script failed')); }, { once: true });
        document.head.append(script);
    });
    const provider = (data) => {
        if (!providers.has(data.provider)) {
            const google = data.provider === 'google';
            const params = google ? { key: data.key, v: 'weekly', language: data.locale }
                : { apikey: data.key, lang: data.locale === 'ru' ? 'ru_RU' : 'en_US' };
            const url = google ? 'https://maps.googleapis.com/maps/api/js?' : 'https://api-maps.yandex.ru/2.1/?';
            providers.set(data.provider, loadScript(url + new URLSearchParams(params)).then(() => {
                if (google) return Promise.all([window.google.maps.importLibrary('maps'), window.google.maps.importLibrary('marker')]);
                return new Promise((resolve, reject) => window.ymaps.ready(resolve, reject));
            }));
        }
        return providers.get(data.provider);
    };
    const balloon = (point) => {
        const content = document.createElement('div');
        const title = document.createElement('strong');
        title.textContent = point.title;
        content.append(title);
        if (point.url) {
            const link = document.createElement('a');
            link.href = point.url;
            link.textContent = point.button || point.title;
            link.className = 'button';
            content.append(document.createElement('br'), link);
        }
        return content;
    };
    const start = async (block) => {
        block.dataset.mapReady = 'true';
        const canvas = block.querySelector('[data-map-canvas]');
        const status = block.querySelector('[data-map-status]');
        try {
            const data = JSON.parse(block.dataset.siteMap);
            const center = data.center || data.points[0];
            const modules = await provider(data);
            if (!block.isConnected) return;
            if (data.provider === 'yandex') {
                const api = window.ymaps;
                const map = new api.Map(canvas, { center: [center.lat, center.lng], zoom: data.zoom,
                    type: { map: 'yandex#map', satellite: 'yandex#satellite', hybrid: 'yandex#hybrid' }[data.mode],
                    controls: ['zoomControl'] });
                const group = data.cluster && data.points.length > 1 ? new api.Clusterer() : new api.GeoObjectCollection();
                data.points.forEach((point) => {
                    const name = document.createElement('span');
                    name.textContent = point.title;
                    group.add(new api.Placemark([point.lat, point.lng], {
                        iconCaption: name.innerHTML, hintContent: name.innerHTML, balloonContent: balloon(point).outerHTML,
                    }, { preset: 'islands#blueDotIconWithCaption' }));
                });
                map.geoObjects.add(group);
                if (data.fit && data.points.length > 1) map.setBounds(group.getBounds(), { checkZoomRange: true, zoomMargin: 36 });
            } else {
                const [maps, markerApi] = modules;
                const map = new maps.Map(canvas, { center: { lat: center.lat, lng: center.lng },
                    zoom: data.zoom, mapId: data.mapId, mapTypeId: data.mode === 'map' ? 'roadmap' : data.mode });
                const info = new maps.InfoWindow();
                const bounds = new google.maps.LatLngBounds();
                const markers = data.points.map((point) => {
                    const position = { lat: point.lat, lng: point.lng };
                    bounds.extend(position);
                    const marker = new markerApi.AdvancedMarkerElement({ position, title: point.title });
                    marker.addListener('click', () => {
                        info.setContent(balloon(point));
                        info.open({ map, anchor: marker });
                    });
                    return marker;
                });
                if (data.cluster && markers.length > 1) {
                    try {
                        const { MarkerClusterer } = await import('https://cdn.jsdelivr.net/npm/@googlemaps/markerclusterer@2.6.2/+esm');
                        new MarkerClusterer({ map, markers });
                    } catch {
                        markers.forEach((marker) => { marker.map = map; });
                    }
                } else {
                    markers.forEach((marker) => { marker.map = map; });
                }
                if (data.fit && markers.length > 1) map.fitBounds(bounds, 36);
            }
        } catch {
            canvas.hidden = true;
            status.textContent = 'Не удалось загрузить карту.';
            status.hidden = false;
        }
    };
    const scan = (root) => {
        const selector = '[data-site-map]:not([data-map-ready])';
        if (root.matches(selector)) start(root);
        root.querySelectorAll(selector).forEach(start);
    };
    scan(document.body);
    new MutationObserver((records) => records.forEach((record) =>
        record.addedNodes.forEach((node) => { if (node.nodeType === 1) scan(node); })
    )).observe(document.body, { childList: true, subtree: true });
})();

document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-show-page-dialog]');
    const component = event.target.closest('[data-inline-component]');
    const closer = event.target.closest('[data-close-page-dialog]');
    if (opener) {
        const dialog = document.getElementById(opener.dataset.showPageDialog);
        if (dialog && !dialog.open) dialog.showModal();
    } else if (component) {
        const entry = document.getElementById(component.hash.slice(1));
        const dialog = entry && entry.closest('dialog');
        if (!dialog) return;
        event.preventDefault();
        entry.open = true;
        if (!dialog.open) dialog.showModal();
        entry.scrollIntoView({block: 'nearest'});
        entry.querySelector('textarea').focus();
    } else if (closer) {
        closer.closest('dialog').close();
    }
});

const componentDataDialog = document.querySelector('#page-component-data');
if (componentDataDialog) {
    const frame = componentDataDialog.querySelector('[data-component-data-iframe]');
    const wide = componentDataDialog.querySelector('[data-component-data-wide]');
    let saved = false;
    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-editor-data-url]');
        if (!button) return;
        frame.src = button.dataset.editorDataUrl;
        wide.href = button.dataset.editorDataWide;
        componentDataDialog.showModal();
    });
    window.addEventListener('message', (event) => {
        if (componentDataDialog.open && event.origin === location.origin && event.source === frame.contentWindow
            && event.data?.type === 'eurowebcart:component-data-saved') saved = true;
    });
    componentDataDialog.addEventListener('close', () => {
        frame.removeAttribute('src');
        if (saved) location.reload();
    });
}

document.querySelectorAll('[data-inline-editor]').forEach((form) => {
    const source = form.querySelector('textarea');
    form.addEventListener('change', (event) => {
        const kind = form.dataset.inlineEditor;
        if (event.target.matches('[data-inline-field]')) {
            const fields = Object.fromEntries(Array.from(form.querySelectorAll('[data-inline-field]'),
                (input) => [input.dataset.inlineField, input.value.trim()]));
            if (['map', 'maps', 'callback'].includes(kind)) {
                const options = Object.entries(fields).filter(([, value]) => value !== '')
                    .map(([name, value]) => name + '="' + value.replace(/&/g, '&amp;').replace(/"/g, '&quot;') + '"');
                source.value = '[' + kind + (options.length ? ' ' + options.join(' ') : '') + ']';
            } else if (['gal', 'fotos', 'files'].includes(kind)) {
                const opening = source.value.match(/^\[[^\]]+\]/)?.[0] || '[' + kind + ']';
                source.value = opening + fields.path + '[/' + kind + ']';
            } else if (kind === 'include') {
                source.value = '[include]' + fields.path + '[/include]';
            } else if (kind === 'iblock') {
                source.value = '[iblock=' + fields.template + ']' + fields.path + '[/iblock]';
            } else if (kind === 'phpModule') {
                source.value = '[php]' + fields.code + '[/php]';
            } else if (kind === 'iconName') {
                source.value = '[fa-icon=' + (fields.style ? fields.style + ':' : '') + fields.code + ']';
            } else if (kind === 'extensionTag') {
                source.value = '[' + fields.code + ']' + fields.value + '[/' + fields.code + ']';
            } else {
                source.value = '[' + fields.code + ']';
            }
            return;
        }
        if (!event.target.matches('[data-inline-option]')) return;
        source.value = source.value.replace(/^\[(gal|fotos|files)(?:[ \t][^\]]*)?\]/i, (original, tag) => {
            const options = new Map();
            for (const part of original.matchAll(/[ \t]([a-z0-9_-]+)=([a-z0-9_-]+%?)/gi)) options.set(part[1], part[2]);
            const name = event.target.dataset.inlineOption;
            if (event.target.value) options.set(name, event.target.value);
            else options.delete(name);
            return '[' + tag + Array.from(options, ([key, value]) => ' ' + key + '=' + value).join('') + ']';
        });
    });
});

const editableLinks = document.querySelectorAll('[data-inline-component]');
if (editableLinks.length) {
    const outline = document.createElement('div');
    outline.hidden = true;
    outline.className = 'inline-component-highlight';
    outline.setAttribute('aria-hidden', 'true');
    document.body.appendChild(outline);
    let activeLink = null;
    const bounds = (link) => {
        const end = document.getElementById(link.hash.slice(1) + '-preview-end');
        if (!end) return null;
        const range = document.createRange();
        range.setStartAfter(link);
        range.setEndBefore(end);
        const rect = range.getBoundingClientRect();
        if (rect.width && rect.height) return rect;
        if (link.dataset.inlineKind === 'map') {
            return document.querySelector('#content .site-map')?.getBoundingClientRect() || null;
        }
        return null;
    };
    const draw = () => {
        const rect = activeLink && bounds(activeLink);
        outline.hidden = !rect;
        if (!rect) return;
        outline.style.left = (rect.left - 3) + 'px';
        outline.style.top = (rect.top - 3) + 'px';
        outline.style.width = (rect.width + 6) + 'px';
        outline.style.height = (rect.height + 6) + 'px';
    };
    editableLinks.forEach((link) => {
        const show = () => { activeLink = link; draw(); };
        const hide = () => {
            if (activeLink === link) { activeLink = null; draw(); }
        };
        link.addEventListener('mouseenter', show);
        link.addEventListener('focus', show);
        link.addEventListener('mouseleave', hide);
        link.addEventListener('blur', hide);
        link.addEventListener('click', hide);
    });
    window.addEventListener('resize', draw, {passive: true});
    window.addEventListener('scroll', draw, {passive: true, capture: true});
}

document.addEventListener('click', (event) => {
    const top = event.target.closest('[data-scroll-top]');
    if (top) {
        event.preventDefault();
        window.scrollTo({top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
        return;
    }
    const button = event.target.closest('[data-cookie-choice]');
    const menu = button && button.closest('[data-cookie-preferences]');
    if (!menu) return;
    const choice = button.dataset.cookieChoice;
    if (!['all', 'selection', 'essential'].includes(choice)) return;
    const features = ['analytics', 'maps', 'chat'].filter(feature => {
        const option = menu.querySelector('[data-cookie-option="' + feature + '"]');
        return option && (choice === 'all' || (choice === 'selection' && option.checked));
    });
    const selection = features.join('-');
    const selected = selection === 'analytics-maps' ? 'all' : selection || 'essential';
    const path = /^\/[^;\s]*$/.test(menu.dataset.cookiePath || '') ? menu.dataset.cookiePath : '/';
    document.cookie = 'FILE_SITE_CONSENT=' + selected + '; Path=' + path + '; Max-Age=15552000; SameSite=Lax'
        + (location.protocol === 'https:' ? '; Secure' : '');
    window.location.reload();
});
