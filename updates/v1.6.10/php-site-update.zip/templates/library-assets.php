<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
try {
    $libraries = site_library_settings(site_read_record(SITE_LIBRARIES_FILE));
} catch (RuntimeException $exception) {
    $libraries = site_library_settings();
}
foreach (site_active_libraries() as $id => $library) {
    if ($id !== 'codemirror' && $libraries['enabled'][$id]) {
        echo site_library_assets($id, $library, $base);
    }
}
?>
<?php if ($libraries['font'] !== ''): ?>
    <?php
    list($fontName, $fontWeights, $fontFallback) = site_google_fonts()[$libraries['font']];
    $fontUrl = 'https://fonts.googleapis.com/css2?family=' . urlencode($fontName)
        . ($fontWeights !== '' ? ':wght@' . $fontWeights : '') . '&display=swap';
    ?>
    <link rel="stylesheet" href="<?= site_escape($fontUrl) ?>">
    <style>:root { --site-font: "<?= $fontName ?>", <?= $fontFallback ?>; }</style>
<?php endif; ?>
