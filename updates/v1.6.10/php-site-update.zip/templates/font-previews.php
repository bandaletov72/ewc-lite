<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/libraries.php';

header('Content-Type: text/css; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=86400');
$fonts = site_google_fonts();
$families = array_map(static function (array $font): string {
    return 'family=' . urlencode($font[0]);
}, $fonts);
echo '@import url("https://fonts.googleapis.com/css2?' . implode('&', $families)
    . '&display=swap");' . "\n";
foreach ($fonts as $key => $font) {
    echo '.font-preview-' . $key . ' { font-family: "' . $font[0] . '", ' . $font[2] . '; }' . "\n";
}
