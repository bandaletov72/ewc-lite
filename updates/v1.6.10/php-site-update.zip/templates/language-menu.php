<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$languages = site_region_settings()['languages'];
if ($page['path'] === '' || count($languages) < 2) {
    return;
}
?>
<nav class="site-menu language-menu" aria-label="<?= site_escape(site_translation('Язык', $locale)) ?>">
    <?php foreach ($languages as $code): ?>
        <a lang="<?= $code ?>" href="<?= site_escape(site_page_url($base, $originalPath) . '?lang=' . $code) ?>"<?= $locale === $code ? ' aria-current="true"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
    <?php endforeach; ?>
</nav>
