<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PHP_MODULES_FILE = SITE_ROOT . '/admin/.php-modules.php';

function site_php_module_settings(): array
{
    static $settings;
    if ($settings === null) {
        try {
            $settings = site_read_record(SITE_PHP_MODULES_FILE, 262144);
        } catch (RuntimeException $exception) {
            $settings = [];
        }
    }
    return $settings;
}

function site_php_module_enabled(string $name): bool
{
    return (site_php_module_settings()[$name]['enabled'] ?? true) === true;
}
