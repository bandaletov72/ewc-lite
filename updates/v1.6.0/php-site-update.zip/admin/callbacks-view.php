<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$statuses = ['new' => 'Новая', 'sending' => 'Отправляется', 'accepted' => 'Принята телефонией', 'error' => 'Ошибка API'];
?>
<h1><?= admin_l('Обратные звонки') ?></h1>
<?php if ($callbackRecord): ?>
    <article class="panel">
        <a href="<?= site_escape($callbacksUrl . '&inbox_page=' . $callbackPagination['page']) ?>">К списку заявок</a>
        <h2><?= site_escape($callbackRecord['phone']) ?></h2>
        <p><?= site_escape(admin_inbox_date($callbackIdSelected) . ' · ' . ($statuses[$callbackRecord['status']] ?? $callbackRecord['status'])) ?></p>
        <p><?= site_escape($callbackRecord['host'] . site_page_url('', $callbackRecord['page'])) ?></p>
    </article>
<?php elseif ($callbackRecords): ?>
    <div class="panel iblock-table-wrap">
        <table class="iblock-table">
            <thead><tr><th scope="col">Когда</th><th scope="col">Телефон</th><th scope="col">Страница</th><th scope="col">Статус</th><th scope="col">Действие</th></tr></thead>
            <tbody>
                <?php foreach ($callbackRecords as $id => $record): ?>
                    <tr>
                        <td><a href="<?= site_escape($callbacksUrl . '&inbox_page=' . $callbackPagination['page'] . '&callback=' . $id) ?>"><?= site_escape(admin_inbox_date($id)) ?></a>
                            <?= $callbackPagination['rows'][$id] ? '<strong>Новая</strong>' : '' ?></td>
                        <td><a href="<?= site_escape('tel:' . preg_replace('/[^0-9+]/', '', $record['phone'])) ?>"><?= site_escape($record['phone']) ?></a></td>
                        <td><?= site_escape($record['host'] . site_page_url('', $record['page'])) ?></td>
                        <td><?= site_escape($statuses[$record['status']] ?? $record['status']) ?>
                            <?php if (isset($record['error'])): ?><small class="hint"><?= site_escape($record['error']) ?></small><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($callbackConfig !== null && $callbackConfig['mode'] !== 'off' && in_array($record['status'], ['new', 'error'], true)): ?>
                                <form method="post" action="<?= site_escape($callbacksUrl) ?>">
                                    <input type="hidden" name="action" value="send-callback">
                                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                                    <input type="hidden" name="callback_id" value="<?= site_escape($id) ?>">
                                    <button type="submit">Отправить в АТС</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php admin_inbox_pager($callbackPagination, $callbacksUrl); ?>
    </div>
<?php else: ?>
    <p class="panel">Заявок пока нет.</p>
<?php endif; ?>
<?php $callbackSettingsUrl = $callbacksUrl; require __DIR__ . '/callback-settings-view.php'; ?>
