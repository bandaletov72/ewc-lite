<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$moduleSettings = site_php_module_settings();
?>
<h1><?= site_escape(admin_l('PHP-модули')) ?></h1>
<div class="form-stack">
    <?php foreach (site_extensions() as $name => $definition): ?>
        <form method="post" action="<?= site_escape($modulesUrl) ?>" class="panel form-stack">
            <h2><code><?= site_escape('[php]' . $name . '[/php]') ?></code></h2>
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="action" value="save-module">
            <input type="hidden" name="module" value="<?= site_escape($name) ?>">
            <label class="field"><?= site_escape(admin_l('Название')) ?>
                <input name="label" maxlength="120" value="<?= site_escape($moduleSettings[$name]['label'] ?? ($definition['label'] ?? $name)) ?>" required>
            </label>
            <label class="field"><?= site_escape(admin_l('Описание')) ?>
                <textarea name="description" maxlength="400" rows="3"><?= site_escape($moduleSettings[$name]['description'] ?? '') ?></textarea>
            </label>
            <label class="choice">
                <input type="checkbox" name="enabled" value="1"<?= site_php_module_enabled($name) ? ' checked' : '' ?>>
                <?= site_escape(admin_l('Доступен для вставки')) ?>
            </label>
            <div class="header-actions">
                <button type="submit" class="button-primary"><?= site_escape(admin_l('Сохранить')) ?></button>
                <a href="<?= site_escape($adminUrl) ?>"><?= site_escape(admin_l('Страницы')) ?></a>
            </div>
        </form>
    <?php endforeach; ?>
</div>
