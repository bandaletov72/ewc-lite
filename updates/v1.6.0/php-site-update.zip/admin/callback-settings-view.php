<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($callbackDraft !== null): ?>
    <form class="panel form-stack callback-settings" method="post" action="<?= site_escape($callbackSettingsUrl) ?>">
        <h2>Кнопка и подключение телефонии</h2>
        <p class="hint">Вставьте в HTML <code>[callback]</code> или укажите подпись для этой страницы, например <code>[callback=Вызвать мастера]</code>.</p>
        <input type="hidden" name="action" value="save-callback-settings">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($callbackRevision) ?>">
        <div class="fields">
            <label class="field">Текст кнопки на странице
                <input name="button" value="<?= site_escape($callbackDraft['button']) ?>" maxlength="375" required>
            </label>
            <label class="field">Текст кнопки отправки
                <input name="submit" value="<?= site_escape($callbackDraft['submit']) ?>" maxlength="375" required>
            </label>
            <label class="field">Заголовок формы
                <input name="title" value="<?= site_escape($callbackDraft['title']) ?>" maxlength="375">
            </label>
            <label class="field">Подсказка в поле телефона
                <input name="placeholder" value="<?= site_escape($callbackDraft['placeholder']) ?>" maxlength="375">
            </label>
            <label class="field">Передача в телефонию
                <select name="mode">
                    <?php foreach (['off' => 'Только сохранять заявки', 'manual' => 'По кнопке в админке', 'auto' => 'Сразу после отправки формы'] as $value => $label): ?>
                        <option value="<?= $value ?>"<?= $callbackDraft['mode'] === $value ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field">Провайдер
                <select name="provider">
                    <option value="none"<?= $callbackDraft['provider'] === 'none' ? ' selected' : '' ?>>Нет</option>
                    <option value="zadarma"<?= $callbackDraft['provider'] === 'zadarma' ? ' selected' : '' ?>>Zadarma</option>
                    <option value="webhook"<?= $callbackDraft['provider'] === 'webhook' ? ' selected' : '' ?>>HTTP API (JSON)</option>
                </select>
            </label>
            <label class="field field-wide">Откуда звонить в Zadarma (номер, SIP или добавочный)
                <input name="from" value="<?= site_escape($callbackDraft['from']) ?>" maxlength="32" placeholder="101">
            </label>
        </div>
        <p class="hint">Ключи Zadarma задаются в разделе «Интеграции» или через <code>SITE_ZADARMA_KEY</code> и <code>SITE_ZADARMA_SECRET</code>. Для HTTP API используйте <code>SITE_CALLBACK_WEBHOOK_URL</code> и при необходимости <code>SITE_CALLBACK_WEBHOOK_TOKEN</code>.</p>
        <div><button class="button-primary" type="submit">Сохранить настройки</button></div>
    </form>
<?php endif; ?>
