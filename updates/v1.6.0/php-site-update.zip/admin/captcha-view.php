<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$captcha = site_global_captcha();
?>
<h1><?= site_escape(admin_l('Общие настройки CAPTCHA')) ?></h1>
<form method="post" action="<?= site_escape($captchaUrl) ?>" class="panel form-stack">
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <input type="hidden" name="action" value="save-captcha">
    <label class="choice">
        <input type="checkbox" name="enabled" value="1"<?= $captcha['enabled'] ? ' checked' : '' ?>>
        <?= site_escape(admin_l('Использовать CAPTCHA во всех формах')) ?>
    </label>
    <div class="fields">
        <label class="field"><?= site_escape(admin_l('Ключ сайта')) ?>
            <input name="sitekey" maxlength="256" value="<?= site_escape($captcha['sitekey']) ?>" autocomplete="off">
        </label>
        <label class="field"><?= site_escape(admin_l('Секретный ключ')) ?>
            <input type="password" name="secret" maxlength="256" autocomplete="new-password">
            <small class="hint"><?= site_escape(admin_l('Пустое поле сохраняет прежний секретный ключ.')) ?></small>
        </label>
    </div>
    <p class="hint"><?= site_escape(admin_l('Укажите ключи Google reCAPTCHA v2 для домена сайта. Общие ключи также доступны при включении CAPTCHA в отдельной форме.')) ?></p>
    <div><button class="button-primary"><?= site_escape(admin_l('Сохранить')) ?></button></div>
</form>
