<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$maps = $mapsDraft ?? site_map_settings();
$services = site_integration_settings();
?>
<h1><?= admin_l('Интеграции') ?></h1>
<div class="form-stack">
    <section class="panel form-stack" id="maps">
        <h2>Яндекс Карты и Google Maps</h2>
        <form class="form-stack" method="post" action="<?= site_escape($integrationsUrl) ?>#maps">
            <input type="hidden" name="action" value="save-maps">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($mapsRevision ?? admin_settings_revision($maps)) ?>">
            <div class="fields">
                <?php foreach (['provider' => ['Провайдер', site_map_providers()], 'mode' => ['Режим', site_map_modes()]] as $key => $select): ?>
                    <label class="field"><?= site_escape($select[0]) ?>
                        <select name="<?= $key ?>">
                            <?php foreach ($select[1] as $value => $label): ?>
                                <option value="<?= $value ?>"<?= $maps[$key] === $value ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
                <label class="field">Масштаб <input type="number" name="zoom" min="1" max="20" value="<?= site_escape($maps['zoom']) ?>" required></label>
                <label class="choice"><input type="checkbox" name="cluster" value="1"<?= $maps['cluster'] === '1' ? ' checked' : '' ?>> Кластеризация точек</label>
                <?php foreach (['yandex_key' => 'API-ключ Яндекс Карт', 'google_key' => 'API-ключ Google Maps', 'google_map_id' => 'Google Map ID'] as $key => $label): ?>
                    <label class="field"><?= $label ?><input name="<?= $key ?>" value="<?= site_escape($maps[$key]) ?>" maxlength="256" autocomplete="off"></label>
                <?php endforeach; ?>
            </div>
            <code>[map lat=55.7558 lng=37.6173 title="Офис" zoom=13 provider=yandex mode=map url="/contacts/" button="Связаться"]</code>
            <small class="hint">Все точки страницы выводятся на карте в месте первой вставки. Первой точкой задаются общий режим, провайдер и масштаб. Ключи карт используются в браузере. Ограничьте их доменами в кабинете провайдера.</small>
            <div><button class="button-primary" type="submit">Сохранить настройки карт</button></div>
        </form>
    </section>
    <form class="panel form-stack" method="post" action="<?= site_escape($integrationsUrl) ?>#services" id="services">
        <h2>Внешние сервисы</h2>
        <input type="hidden" name="action" value="save-integrations">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($services)) ?>">
        <div class="fields">
            <?php foreach (site_integration_catalog() as $key => $item): ?>
                <fieldset class="field-config form-stack">
                    <legend><?= site_escape($item[0]) ?></legend>
                    <label class="choice"><input type="checkbox" name="<?= $key ?>_enabled" value="1"<?= !empty($services[$key]['enabled']) ? ' checked' : '' ?>> Подключить</label>
                    <label class="field"><?= site_escape($item[1]) ?>
                        <input name="<?= $key ?>_id" value="<?= site_escape($services[$key]['id'] ?? '') ?>" maxlength="96">
                    </label>
                </fieldset>
            <?php endforeach; ?>
            <fieldset class="field-config form-stack">
                <legend>Zadarma</legend>
                <label class="field">API-ключ <input type="password" name="zadarma_key" maxlength="256" autocomplete="new-password"></label>
                <label class="field">Секретный ключ <input type="password" name="zadarma_secret" maxlength="256" autocomplete="new-password"></label>
                <small class="hint">Пустое поле сохраняет ключ. Можно также задать ключи через переменные окружения.</small>
            </fieldset>
            <fieldset class="field-config form-stack">
                <legend>Telegram</legend>
                <label class="choice"><input type="checkbox" name="telegram_enabled" value="1"<?= !empty($services['telegram_enabled']) ? ' checked' : '' ?>> Уведомлять о новых заявках</label>
                <label class="field">Токен бота <input type="password" name="telegram_token" maxlength="128" autocomplete="new-password"></label>
                <label class="field">ID чата или @канал <input name="telegram_chat" maxlength="36" value="<?= site_escape($services['telegram_chat'] ?? '') ?>"></label>
                <small class="hint">Сообщение содержит код формы и адрес страницы. Содержимое заявки остаётся в админке.</small>
            </fieldset>
        </div>
        <div><button class="button-primary" type="submit">Сохранить внешние сервисы</button></div>
    </form>
    <?php $callbackSettingsUrl = $integrationsUrl; require __DIR__ . '/callback-settings-view.php'; ?>
    <section class="panel">
        <h2>Остальные подключения</h2>
        <ul>
            <li><a href="<?= site_escape($formsUrl) ?>">Google reCAPTCHA v2 и почтовые уведомления</a></li>
            <li><a href="<?= site_escape($librariesUrl) ?>">Google Fonts и CDN-библиотеки</a></li>
            <li><a href="<?= site_escape($updatesUrl) ?>">GitHub — обновления движка</a></li>
        </ul>
    </section>
</div>
