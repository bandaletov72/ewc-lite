<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1><?= admin_l('Библиотеки и шрифты') ?></h1>
<?php if ($libraryDraft !== null): ?>
    <form class="panel form-stack" method="post" action="<?= site_escape($librariesUrl) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($libraryRevision) ?>">
        <fieldset class="field-config form-stack">
            <legend>Библиотеки сайта и редактора</legend>
            <?php $activeLibraries = site_active_libraries(); $libraryVersions = site_library_versions(); ?>
            <?php foreach (site_library_catalog() as $key => $library): ?>
                <div class="library-option form-stack">
                    <label class="choice">
                        <input type="checkbox" name="enabled[<?= $key ?>]" value="1"<?= $libraryDraft['enabled'][$key] ? ' checked' : '' ?>>
                        <span><?= site_escape($activeLibraries[$key]['label']) ?><br><small class="hint"><?= site_escape($library['hint']) ?></small></span>
                    </label>
                    <div class="header-actions">
                        <button type="submit" name="action" value="library-update:<?= $key ?>"<?= $activeLibraries[$key]['label'] === $library['label'] ? ' disabled' : '' ?> formnovalidate><?= admin_l('Обновить') ?></button>
                        <button type="submit" name="action" value="library-rollback:<?= $key ?>"<?= !site_library_rollback($key, $activeLibraries[$key], $libraryVersions) ? ' disabled' : '' ?> formnovalidate><?= admin_l('Откатить') ?></button>
                        <button type="button" data-library-test="<?= $key ?>"><?= admin_l('Тестировать') ?></button>
                    </div>
                </div>
            <?php endforeach; ?>
        </fieldset>
        <div class="field">
            <?php $fontOptions = ['' => ['Системный']] + site_google_fonts(); ?>
            <span id="site-font-label"><?= admin_l('Шрифт сайта') ?></span>
            <?php $samples = site_language_samples(); ?>
            <div class="fields" data-font-preview-controls>
                <label class="field"><?= admin_l('Язык') ?>
                    <select data-font-preview-language>
                        <?php foreach (site_languages() as $code => $language): ?>
                            <option value="<?= $code ?>" data-sample="<?= site_escape($samples[$code]) ?>"<?= $code === $adminLanguage ? ' selected' : '' ?>><?= site_escape($language) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="field"><?= admin_l('Фраза для предпросмотра') ?>
                    <input data-font-preview-text maxlength="120" value="<?= site_escape($samples[$adminLanguage]) ?>">
                </label>
            </div>
            <details class="font-picker" data-font-picker>
                <summary aria-describedby="site-font-label site-font-hint">
                    <span data-font-current class="font-preview-<?= site_escape($libraryDraft['font']) ?>"><?= site_escape($fontOptions[$libraryDraft['font']][0]) ?></span>
                </summary>
                <div class="font-list" role="radiogroup" aria-labelledby="site-font-label">
                    <?php foreach ($fontOptions as $key => $font): ?>
                        <label class="font-option">
                            <input type="radio" name="font" value="<?= site_escape($key) ?>"<?= $libraryDraft['font'] === $key ? ' checked' : '' ?>>
                            <span data-font-name class="font-preview-<?= site_escape($key) ?>"><?= site_escape($font[0]) ?></span>
                            <span aria-hidden="true" data-font-sample class="font-sample font-preview-<?= site_escape($key) ?>"><?= site_escape($samples[$adminLanguage]) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </details>
            <small class="hint" id="site-font-hint">Выбранный шрифт заменяет системный. Все шрифты в списке поддерживают кириллицу.</small>
        </div>
        <button class="button-primary" type="submit" name="action" value="save-libraries"><?= admin_l('Сохранить') ?></button>
    </form>
    <dialog class="editor-dialog form-stack" data-library-dialog data-interface="<?= site_escape($adminLanguage) ?>"
        data-test-url="<?= site_escape(site_url($base, 'templates/library-test.php')) ?>" aria-labelledby="library-dialog-title">
        <div class="header-actions editor-dialog-heading">
            <h2 id="library-dialog-title"><?= admin_l('Проверка библиотеки') ?></h2>
            <button type="button" data-library-close aria-label="<?= admin_l('Закрыть') ?>">×</button>
        </div>
        <iframe class="library-sandbox" sandbox="allow-scripts" referrerpolicy="no-referrer" title="<?= admin_l('Проверка библиотеки') ?>"></iframe>
        <?php foreach ($activeLibraries as $key => $library): ?>
            <label class="field" data-library-code="<?= $key ?>" hidden><?= admin_l('Код вставки') ?>
                <textarea class="short-editor" readonly rows="5" spellcheck="false"><?= "\n" . site_escape(site_library_assets($key, $library, $base) . site_library_example($key)) ?></textarea>
            </label>
        <?php endforeach; ?>
    </dialog>
<?php endif; ?>
