<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_save_maps(array $draft, string $revision)
{
    if (!isset(site_map_providers()[$draft['provider']], site_map_modes()[$draft['mode']])
        || !preg_match('/\A(?:[1-9]|1[0-9]|20)\z/', $draft['zoom'])) {
        throw new RuntimeException('Проверьте провайдера, режим и масштаб карты.');
    }
    foreach (['yandex_key', 'google_key', 'google_map_id'] as $key) {
        if ($draft[$key] !== '' && !preg_match('/\A[A-Za-z0-9_-]{1,256}\z/', $draft[$key])) {
            throw new RuntimeException('Проверьте ключ карты или Google Map ID.');
        }
    }
    if (($draft['provider'] === 'yandex' && $draft['yandex_key'] === '')
        || ($draft['provider'] === 'google' && ($draft['google_key'] === '' || $draft['google_map_id'] === ''))) {
        throw new RuntimeException('Укажите API-ключ выбранного провайдера. Для Google Maps также нужен Map ID.');
    }
    $lock = admin_lock();
    try {
        site_read_record(SITE_MAPS_FILE);
        if (!hash_equals(admin_settings_revision(site_map_settings()), $revision)) {
            throw new RuntimeException('Настройки карт изменились. Откройте раздел заново.');
        }
        admin_write_record(SITE_MAPS_FILE, $draft);
    } finally {
        fclose($lock);
    }
}

function admin_save_integrations(array $input, string $revision)
{
    $lock = admin_lock();
    try {
        $settings = site_read_record(SITE_INTEGRATIONS_FILE);
        if (!hash_equals(admin_settings_revision($settings), $revision)) {
            throw new RuntimeException('Интеграции изменились. Откройте раздел заново.');
        }
        foreach (site_integration_catalog() as $key => $service) {
            $id = trim(admin_input($input, $key . '_id'));
            $enabled = admin_input($input, $key . '_enabled') === '1';
            if (($enabled || $id !== '') && !preg_match($service[2], $id)) {
                throw new RuntimeException('Проверьте идентификатор сервиса «' . $service[0] . '».');
            }
            $settings[$key] = ['enabled' => $enabled, 'id' => $id];
        }
        foreach (['zadarma_key', 'zadarma_secret', 'telegram_token'] as $key) {
            $value = trim(admin_input($input, $key));
            if ($value !== '') {
                $pattern = $key === 'telegram_token' ? '/\A[0-9]+:[A-Za-z0-9_-]{16,100}\z/' : '/\A[A-Za-z0-9_+\/=.-]{1,256}\z/';
                if (!preg_match($pattern, $value) || ($key === 'zadarma_key' && !preg_match('/\A[A-Za-z0-9_-]+\z/', $value))) {
                    throw new RuntimeException('Проверьте формат ключа или токена.');
                }
                $settings[$key] = $value;
            }
        }
        $settings['telegram_chat'] = trim(admin_input($input, 'telegram_chat'));
        $settings['telegram_enabled'] = admin_input($input, 'telegram_enabled') === '1';
        if (($settings['telegram_enabled'] || $settings['telegram_chat'] !== '')
            && !preg_match('/\A(?:-?[0-9]{1,20}|@[A-Za-z0-9_]{5,32})\z/', $settings['telegram_chat'])) {
            throw new RuntimeException('Укажите ID чата или публичное имя канала Telegram.');
        }
        if ($settings['telegram_enabled'] && empty($settings['telegram_token'])) {
            throw new RuntimeException('Для Telegram укажите токен бота.');
        }
        admin_write_record(SITE_INTEGRATIONS_FILE, $settings);
    } finally {
        fclose($lock);
    }
}
