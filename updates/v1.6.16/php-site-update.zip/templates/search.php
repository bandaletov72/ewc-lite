<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$compactSearch = $settings['searchMode'] === 'compact';
$searchLabel = site_escape(site_translation('Поиск по сайту', $locale));
$searchId = 'site-search-' . bin2hex(random_bytes(5));
?>
<div class="<?= empty($context['embeddedLayout']) ? 'container ' : '' ?>site-search-bar">
    <?php if ($compactSearch): ?>
        <details class="site-search-compact"<?= $searchMode ? ' open' : '' ?>>
            <summary aria-label="<?= $searchLabel ?>" title="<?= $searchLabel ?>">
                <span class="site-search-icon" aria-hidden="true"></span>
            </summary>
    <?php endif; ?>
    <form class="site-search" role="search" data-site-search action="<?= site_escape(site_url($base)) ?>" method="get">
        <label class="site-search-label" for="<?= $searchId ?>-input"><?= $searchLabel ?></label>
        <input id="<?= $searchId ?>-input" type="search" name="search" maxlength="100" autocomplete="off"
            placeholder="<?= $searchLabel ?>" value="<?= site_escape($searchQuery) ?>" aria-controls="<?= $searchId ?>-suggestions" required>
        <?php if (!$compactSearch): ?>
            <button type="submit"><?= site_escape(site_translation('Найти', $locale)) ?></button>
        <?php endif; ?>
        <ul class="site-search-suggestions" id="<?= $searchId ?>-suggestions" hidden></ul>
    </form>
    <?php if ($compactSearch): ?></details><?php endif; ?>
</div>
