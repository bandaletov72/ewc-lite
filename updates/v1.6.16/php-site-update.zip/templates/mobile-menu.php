<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="mobile-header-menu">
    <button class="menu-toggle" type="button" data-mobile-toggle aria-expanded="false" aria-haspopup="dialog"
        aria-label="<?= site_escape(site_translation('Меню', $locale)) ?>" hidden>
        <span class="menu-toggle-icon" aria-hidden="true"></span>
    </button>
    <dialog class="mobile-drawer" data-mobile-drawer aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
        <div class="mobile-drawer-heading">
            <strong><?= site_escape(site_translation('Меню', $locale)) ?></strong>
            <button class="mobile-drawer-close" type="button" data-mobile-close aria-label="<?= site_escape(site_translation('Закрыть меню', $locale)) ?>" autofocus><span aria-hidden="true">×</span></button>
        </div>
        <?= site_expand_content('[search]', $snippets, $context) ?>
        <nav class="site-menu" data-mobile-navigation aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
            <?php require site_template_file('navigation-links.php'); ?>
        </nav>
    </dialog>
    <noscript><nav class="site-menu" aria-label="<?= site_escape(site_translation('Мобильное меню', $locale)) ?>">
        <?php require site_template_file('navigation-links.php'); ?>
    </nav></noscript>
</div>
