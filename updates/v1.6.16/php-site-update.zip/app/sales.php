<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PURCHASE_DIR = SITE_ROOT . '/data/.purchases';
const SITE_PURCHASE_STATES = ['accepted', 'paid', 'shipped', 'closed', 'cancelled'];
const SITE_SALE_NOTICES = ['off', 'email', 'sms', 'both'];

function site_sale_amount(string $value): string
{
    if (!preg_match('/\A([0-9]{1,12})(?:[.,]([0-9]{1,2}))?\z/', trim($value), $match)) return '';
    $amount = (ltrim($match[1], '0') ?: '0') . '.' . str_pad($match[2] ?? '', 2, '0');
    return $amount === '0.00' ? '' : $amount;
}

function site_sale_target(string $method, string $target, string $currency): bool
{
    $methods = site_payment_methods();
    if (!isset($methods[$method]) || strlen($target) > 500) return false;
    if ($method === 'yoomoney' && $currency === 'RUB' && preg_match('/\A[0-9]{10,20}\z/', $target)) return true;
    return site_valid_payment_url($target, $methods[$method][1]);
}

function site_sale_decode(string $value): ?array
{
    if ($value === '') return ['enabled' => false, 'notices' => 'off', 'offers' => []];
    $decoded = strlen($value) <= 32000 ? base64_decode($value, true) : false;
    $record = is_string($decoded) ? json_decode($decoded, true) : null;
    if (!is_array($record) || !is_bool($record['enabled'] ?? null) || !in_array($record['notices'] ?? '', SITE_SALE_NOTICES, true)
        || !is_array($record['offers'] ?? null)) return null;
    $currencies = site_region_options()['currency'];
    foreach ($record['offers'] as $code => $row) {
        if (($code !== 'default' && !isset(site_languages()[$code])) || !is_array($row)
            || !is_string($row['amount'] ?? null) || $row['amount'] === '' || site_sale_amount($row['amount']) !== $row['amount']
            || !is_string($row['currency'] ?? null) || ($row['currency'] !== '' && !isset($currencies[$row['currency']]))
            || !is_string($row['method'] ?? null) || !is_string($row['target'] ?? null) || strlen($row['target']) > 500) {
            return null;
        }
    }
    return $record;
}

function site_sale_offer(string $path, string $language): array
{
    $page = site_read_page(site_page_translation($path)[0]);
    $settings = $page === null ? null : site_sale_decode($page['fields']['Sale'] ?? '');
    $offer = $settings['offers'][$language] ?? $settings['offers']['default'] ?? [];
    if (!$offer) return [];
    if ($offer['currency'] === '') $offer['currency'] = site_region_settings()['currency'];
    $offer['enabled'] = $settings['enabled'] && site_sale_target($offer['method'], $offer['target'], $offer['currency']);
    $offer['notices'] = $settings['notices'];
    return $offer;
}

function site_sale_signature(string $token, string $path, string $language, string $nonce, array $offer): string
{
    return hash_hmac('sha256', implode("\0", ['purchase', $path, $language, $nonce, json_encode($offer)]), $token);
}

function site_sale_label(string $language): array
{
    $labels = require __DIR__ . '/help-sales.php';
    return $labels[$language] ?? $labels['ru'];
}

function site_sale_markup(string $name, array $context): string
{
    $path = $context['originalPath'] ?? '';
    $language = $context['locale'] ?? site_region_settings()['public'];
    $offer = $path === '' ? [] : site_sale_offer($path, $language);
    if (!$offer) return '';
    $price = site_format_number($offer['amount'], 2) . ' ' . $offer['currency'];
    if ($name === 'item-price') return site_escape($price);
    if (!$offer['enabled'] || !isset($context['formSession']['token'])) return '';
    $labels = site_sale_label($language);
    $nonce = bin2hex(random_bytes(16));
    $signature = site_sale_signature($context['formSession']['token'], $path, $language, $nonce, $offer);
    $id = 'purchase-' . $nonce;
    $captcha = site_captcha_settings([]);
    $base = $context['base'];
    ob_start();
    require site_template_file('components/purchase.php');
    return (string) ob_get_clean();
}

function site_purchase_path(string $id): string
{
    if (!preg_match('/\A[0-9]{14}-[a-f0-9]{12}\z/', $id)) return '';
    return SITE_PURCHASE_DIR . '/' . $id . '.php';
}

function site_save_purchase(array &$record, array $offer): string
{
    $lock = admin_lock();
    try {
        if (site_localized_page($record['page'], $record['language']) === null
            || site_sale_offer($record['page'], $record['language']) !== $offer) {
            throw new RuntimeException('Условия покупки изменились.', 409);
        }
        $dir = SITE_PURCHASE_DIR;
        if (is_link($dir) || (!is_dir($dir) && !@mkdir($dir, 0700))
            || realpath($dir) !== str_replace('/', DIRECTORY_SEPARATOR, $dir)) {
            throw new RuntimeException('Не удалось открыть хранилище покупок.');
        }
        $id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(6));
        $record['event'] = bin2hex(random_bytes(8));
        admin_write_record(site_purchase_path($id), $record);
        return $id;
    } finally {
        fclose($lock);
    }
}

function site_read_purchase(string $id): array
{
    $file = site_purchase_path($id);
    if ($file === '' || realpath($file) !== str_replace('/', DIRECTORY_SEPARATOR, $file)) return [];
    return site_read_record($file);
}

function site_purchase_status_notice(string $id, array $record)
{
    $channel = $record['notices'];
    if ($channel === 'off') return;
    $labels = site_sale_label($record['language']);
    $status = $labels['statuses'][$record['state']];
    $message = $labels['order'] . ' ' . $id . ' · ' . $status;
    $results = [];
    if ($channel === 'email' || $channel === 'both') {
        $results['email'] = 'missing';
        if ($record['email'] !== '') {
            $sent = @mail($record['email'], site_mail_encode_subject($message), $message,
                "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit");
            $results['email'] = $sent ? 'sent' : 'failed';
        }
    }
    if ($channel === 'sms' || $channel === 'both') {
        $results['sms'] = 'missing';
        if ($record['phone'] !== '') {
            $results['sms'] = 'failed';
            try {
                $request = site_zadarma_request('/v1/sms/send/', ['number' => preg_replace('/\D/', '', $record['phone']), 'message' => $message], 'POST');
                list($http, $body) = site_callback_transport($request);
                $reply = json_decode((string) $body, true);
                if ($http >= 200 && $http < 300 && ($reply['status'] ?? '') === 'success'
                    && (int) ($reply['messages'] ?? 0) > 0 && empty($reply['denied_numbers'])) {
                    $results['sms'] = 'sent';
                }
            } catch (RuntimeException $exception) {
                // Delivery is recorded for staff. A notification failure leaves the order intact.
            }
        }
    }
    $lock = admin_lock();
    try {
        $current = site_read_purchase($id);
        if (($current['event'] ?? '') === $record['event']) {
            $current['delivery'] = $results;
            admin_write_record(site_purchase_path($id), $current);
        }
    } finally {
        fclose($lock);
    }
}

function site_schedule_purchase_notice(string $id, array $record)
{
    if ($record['notices'] === 'off') return;
    register_shutdown_function(static function () use ($id, $record) {
        if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
        try { site_purchase_status_notice($id, $record); }
        catch (Throwable $exception) { error_log('Purchase notification could not be recorded.'); }
    });
}

function site_submit_purchase(array $input): array
{
    $string = static function (array $values, string $key): string {
        return is_string($values[$key] ?? null) ? trim($values[$key]) : '';
    };
    $path = $string($input, 'page');
    $language = $string($input, 'language');
    $nonce = $string($input, 'nonce');
    $csrf = $string($input, 'csrf');
    $labels = site_sale_label($language);
    $token = $_SESSION['csrf'] ?? '';
    if ($token === '' || !preg_match('/\A[a-f0-9]{32}\z/', $nonce) || !in_array($language, site_region_settings()['languages'], true)) {
        return [403, $labels['invalid'], [], []];
    }
    $previous = $_SESSION['purchases'][$nonce] ?? [];
    if ($previous && $previous['time'] > time() - 600 && hash_equals($previous['csrf'], $csrf)) {
        return [200, $labels['accepted'], [], $previous['payment']];
    }
    $page = site_localized_page($path, $language);
    $offer = $page !== null ? site_sale_offer($path, $language) : [];
    if (empty($offer['enabled']) || !hash_equals(site_sale_signature($token, $path, $language, $nonce, $offer), $csrf)) {
        return [403, $labels['invalid'], [], []];
    }
    $rules = site_spam_rules();
    if (($input['website'] ?? '') !== '' || in_array(site_normalize_ip($_SERVER['REMOTE_ADDR'] ?? ''), $rules['ips'], true)) {
        return [403, $labels['invalid'], [], []];
    }
    $recent = array_filter($_SESSION['submitted'] ?? [], static function (int $stamp): bool { return $stamp > time() - 60; });
    if (count($recent) >= 5) return [429, $labels['invalid'], [], []];
    $values = is_array($input['fields'] ?? null) ? $input['fields'] : [];
    $name = $string($values, 'name');
    $email = $string($values, 'email');
    $phone = $string($values, 'phone');
    $errors = site_spam_errors(['name' => ['type' => 'text', 'value' => $name]], $rules['words']);
    if ($name === '' || strlen($name) > 360 || preg_match('/[\x00-\x1f\x7f]/', $name) || preg_match('//u', $name) !== 1) $errors['name'] = $labels['required'];
    if ($email !== '' && (strlen($email) > 254 || preg_match('/[\x00-\x1f\x7f]/', $email)
        || !filter_var($email, FILTER_VALIDATE_EMAIL))) $errors['email'] = $labels['invalid'];
    if ($phone !== '' && ($phone = site_normalize_form_phone($phone)) === '') $errors['phone'] = $labels['invalid'];
    if ($email === '' && $phone === '') $errors['email'] = $labels['contact'];
    if ($errors) return [422, $labels['invalid'], $errors, []];
    $captcha = site_captcha_settings([]);
    if ($captcha['enabled'] && !site_verify_captcha($captcha, $input['g-recaptcha-response'] ?? '', site_host())) {
        return [422, $labels['invalid'], [], []];
    }
    $now = gmdate('c');
    $record = ['time' => $now, 'updated' => $now, 'state' => 'accepted', 'name' => $name, 'email' => $email, 'phone' => $phone,
        'page' => $path, 'language' => $language, 'title' => $page['fields']['Title'], 'amount' => $offer['amount'],
        'currency' => $offer['currency'], 'method' => $offer['method'], 'notices' => $offer['notices']];
    try {
        $id = site_save_purchase($record, $offer);
    } catch (RuntimeException $exception) {
        if ($exception->getCode() === 409) return [409, $labels['invalid'], [], []];
        throw $exception;
    }
    $payment = ['id' => $id, 'url' => $offer['target']];
    if ($offer['method'] === 'yoomoney' && preg_match('/\A[0-9]{10,20}\z/', $offer['target'])) {
        $payment = ['id' => $id, 'url' => 'https://yoomoney.ru/quickpay/confirm',
            'fields' => ['receiver' => $offer['target'], 'quickpay-form' => 'button', 'paymentType' => 'AC', 'sum' => $offer['amount'], 'label' => $id]];
    }
    $_SESSION['submitted'] = array_merge($recent, [time()]);
    $cached = $_SESSION['purchases'] ?? [];
    $cached[$nonce] = ['time' => time(), 'csrf' => $csrf, 'payment' => $payment];
    $_SESSION['purchases'] = array_slice($cached, -12, null, true);
    site_schedule_purchase_notice($id, $record);
    return [200, $labels['accepted'], [], $payment];
}
