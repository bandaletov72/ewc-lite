<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Поиск в меню', 'Шорткод [search] выводит поиск в одном ряду с пунктами [main-menu] на компьютере и внутри [mobile-menu] на телефоне. Режим поиска задаётся в основных настройках. Явный [search] в тексте страницы сохраняет приоритет.'],
    'en' => ['Search in navigation', '[search] places search beside the desktop [main-menu] links and inside [mobile-menu] on phones. Choose the search mode in general settings. An explicit [search] in page content takes priority.'],
    'uk' => ['Пошук у меню', '[search] виводить пошук поруч із пунктами [main-menu] на комп’ютері й усередині [mobile-menu] на телефоні. Режим задається в основних налаштуваннях. Явний [search] у тексті сторінки має пріоритет.'],
    'ja' => ['メニューの検索', '[search] はデスクトップの [main-menu] のリンク横と、モバイルの [mobile-menu] 内に表示されます。基本設定で検索形式を変更できます。ページ本文の [search] が優先されます。'],
    'vi' => ['Tìm kiếm trong menu', '[search] đặt ô tìm kiếm cạnh các mục [main-menu] trên máy tính và trong [mobile-menu] trên điện thoại. Chọn chế độ trong cài đặt chung. [search] trong nội dung trang được ưu tiên.'],
    'fr' => ['Recherche dans le menu', '[search] affiche la recherche à côté des liens [main-menu] sur ordinateur et dans [mobile-menu] sur téléphone. Le mode se choisit dans les réglages généraux. Un [search] dans la page est prioritaire.'],
    'de' => ['Suche im Menü', '[search] steht auf dem Desktop neben den Links von [main-menu] und auf dem Handy in [mobile-menu]. Den Suchmodus wählen Sie in den allgemeinen Einstellungen. [search] im Seiteninhalt hat Vorrang.'],
    'es' => ['Búsqueda en el menú', '[search] sitúa la búsqueda junto a los enlaces de [main-menu] en escritorio y dentro de [mobile-menu] en el móvil. El modo se elige en los ajustes generales. Un [search] en el contenido tiene prioridad.'],
    'pt' => ['Pesquisa no menu', '[search] apresenta a pesquisa junto às ligações de [main-menu] no computador e dentro de [mobile-menu] no telemóvel. Selecione o modo nas configurações gerais. [search] no conteúdo tem prioridade.'],
    'ko' => ['메뉴의 검색', '[search]는 데스크톱 [main-menu] 링크 옆과 모바일 [mobile-menu] 안에 표시됩니다. 기본 설정에서 검색 모드를 선택합니다. 본문에 있는 [search]가 우선합니다.'],
    'zh' => ['菜单中的搜索', '[search] 在桌面端与 [main-menu] 的链接并排显示，在手机端显示在 [mobile-menu] 内。搜索模式在常规设置中选择。页面正文中的 [search] 优先。'],
];
