<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_MOVABLE_LAYOUTS = ['bread-crumbs' => 'breadcrumbs.php', 'main-menu' => 'main-menu.php', 'search' => 'search.php', 'lang' => 'language-menu.php'];
const SITE_LAYOUT_DEFINITIONS = SITE_ROOT . '/admin/.layout-definitions.php';

function site_custom_layouts(): array
{
    static $layouts;
    if ($layouts === null) {
        try {
            $layouts = array_filter(site_read_record(SITE_LAYOUT_DEFINITIONS), 'is_string');
        } catch (RuntimeException $exception) {
            $layouts = [];
        }
    }
    return $layouts;
}

function site_layout_visibility_default(string $name): int
{
    return $name === 'main-menu' ? 2 : 3;
}

function site_layout_placeholder(string $name, bool $default = false): string
{
    return '<!--ew-' . ($default ? 'default-' : 'placed-') . $name . '-->';
}

function site_place_layout_blocks(string $markup, array &$context): string
{
    foreach (SITE_MOVABLE_LAYOUTS as $name => $file) {
        $explicit = site_layout_placeholder($name);
        $default = site_layout_placeholder($name, true);
        $scoped = $name === 'search' ? [site_layout_placeholder('search-main-menu'), site_layout_placeholder('search-mobile-menu')] : [];
        $markers = [$default];
        if (strpos($markup, $explicit) !== false) {
            $markers = [$explicit];
        } else {
            foreach ($scoped as $slot) {
                if (strpos($markup, $slot) !== false) {
                    $markers = $scoped;
                    break;
                }
            }
        }

        foreach ($markers as $marker) {
            $position = strpos($markup, $marker);
            if ($position === false) continue;
            $context['embeddedLayout'] = $marker !== $default;
            $block = site_layout_block($name, $context);
            unset($context['embeddedLayout']);
            $markup = substr_replace($markup, $block, $position, strlen($marker));
        }
        $markup = str_replace(array_merge([$explicit, $default], $scoped), '', $markup);
    }
    return $markup;
}
