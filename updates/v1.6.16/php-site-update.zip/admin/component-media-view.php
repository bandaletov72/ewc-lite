<?php
if (!defined('SITE_ROOT')) exit;
$mediaLabels = ['gal' => admin_t('Карусель'), 'fotos' => admin_t('Фотогалерея'),
    'files' => admin_t('Список файлов'), 'banners' => site_banner_editor_labels($adminLanguage)[0]];
$fileManager = site_file_manager_labels($adminLanguage);
?>
<details data-editor-media <?= $focusedMedia ? 'open' : 'hidden' ?> data-edit-slide="<?= site_escape(site_banner_edit_slide_label($adminLanguage)) ?>"
    data-media-kinds="<?= site_escape((string) json_encode($mediaLabels, JSON_UNESCAPED_UNICODE)) ?>">
    <summary><?= site_escape($focusedMedia ? $mediaLabels[$mediaKind] : admin_t('Файлы и фото для вставленных компонентов')) ?></summary>
    <label class="field"<?= $focusedMedia ? ' hidden' : '' ?>><?= admin_l('Папка компонента') ?> <select data-media-folder></select></label>
    <?php if ($focusedMedia): ?>
        <div class="header-actions">
            <button type="button" data-media-parent hidden aria-label="<?= site_escape($fileManager[1]) ?>">↑</button>
            <code data-media-path><?= site_escape($resolvedMediaFolder) ?></code>
        </div>
        <div class="component-media-folders" data-media-subfolders></div>
        <div class="header-actions">
            <input data-media-new-folder maxlength="64" pattern="[A-Za-z0-9_\-]{1,64}" required
                placeholder="<?= site_escape($fileManager[2]) ?>" aria-label="<?= site_escape($fileManager[2]) ?>" title="<?= site_escape($fileManager[4]) ?>">
            <button type="button" data-media-mkdir><?= site_escape($fileManager[3]) ?></button>
        </div>
    <?php endif; ?>
    <div class="header-actions">
        <input type="file" multiple data-media-upload aria-label="<?= admin_l('Выберите файлы для загрузки') ?>">
        <button type="button" data-media-upload-button><?= admin_l('Загрузить файлы') ?></button>
    </div>
    <p class="hint" role="status" data-media-feedback></p>
    <ol class="media-list" data-media-list></ol>
</details>
