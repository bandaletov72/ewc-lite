<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_banner_selection(array $query): array
{
    $folder = trim(admin_input($query, 'folder'));
    $name = strtolower(trim(admin_input($query, 'banner')));
    $sets = site_banner_sets();
    if (($name !== '' && !site_valid_banner_set_id($name) && !isset($sets[$name])
            && !($folder !== '' && $name === site_banner_id('', $folder)))
        || ($folder !== '' && site_asset_path($folder, 'images') === '')) {
        throw new RuntimeException('Укажите ID набора из A–Z, a–z, дефиса и подчёркивания или допустимую папку изображений.');
    }
    $id = site_banner_id($name, $folder);
    $set = $sets[$id] ?? [];
    $folder = $folder !== '' ? rtrim($folder, '/') . '/' : ($set['folder'] ?? '');
    return [$id, $folder, $set];
}

function admin_banner_slide_draft(array $input): array
{
    $data = site_banner_slide_defaults();
    foreach ($data as $key => $default) {
        if (is_string($default)) $data[$key] = trim(admin_input($input, $key));
    }
    $data['active'] = admin_input($input, 'active') === '1';
    $data['action'] = admin_input($input, 'actionChoice');
    return $data;
}

function admin_validate_banner_slide(array $data)
{
    foreach (['image', 'url', 'buttonUrl'] as $key) {
        if ($data[$key] !== '' && (strlen($data[$key]) > 2048 || !site_redirect_safe_target($data[$key]))) {
            throw new RuntimeException('Укажите допустимый URL изображения или ссылки.');
        }
    }
    foreach (['color', 'textColor'] as $key) {
        if (!preg_match('/\A#[a-fA-F0-9]{6}\z/', $data[$key])) throw new RuntimeException('Укажите цвет в формате #RRGGBB.');
    }
    foreach (['title' => 400, 'button' => 160, 'caption' => 32768] as $key => $limit) {
        if (strlen($data[$key]) > $limit || strpos($data[$key], "\0") !== false || preg_match('//u', $data[$key]) !== 1) {
            throw new RuntimeException('Проверьте длину и кодировку текста кадра.');
        }
    }
    foreach (['from', 'until'] as $key) {
        if (!site_schedule_date_valid($data[$key])) throw new RuntimeException('Проверьте даты активности кадра.');
    }
    if ($data['from'] !== '' && $data['until'] !== '' && $data['from'] >= $data['until']) {
        throw new RuntimeException('Окончание активности должно быть позже её начала.');
    }
    if (!in_array($data['align'], ['left', 'center', 'right'], true)
        || (!array_key_exists($data['font'], site_banner_fonts()) && !isset(site_google_fonts()[$data['font']]))
        || !in_array($data['action'], ['none', 'url', 'callback', 'form'], true)
        || ($data['action'] !== 'none' && $data['button'] === '')
        || ($data['action'] === 'url' && $data['buttonUrl'] === '')
        || ($data['action'] === 'form' && (!site_valid_form_id($data['form']) || !isset(site_forms()[$data['form']])))) {
        throw new RuntimeException('Проверьте шрифт, положение надписи и действие кнопки.');
    }
}

function admin_save_banner(string $operation, array $query, array $input, string $base): string
{
    $lock = admin_lock();
    try {
        list($name, $folder, $set) = admin_banner_selection($query);
        if (!hash_equals(admin_settings_revision($set), admin_input($input, 'revision'))) {
            throw new RuntimeException('Набор уже изменился. Откройте редактор заново.');
        }
        $slides = site_banner_slides($set, $folder);
        $id = admin_input($input, 'slide');
        if ($operation === 'save-banner') {
            $data = admin_banner_slide_draft($input);
            admin_validate_banner_slide($data);
            if ($id === 'new') {
                $id = 's-' . bin2hex(random_bytes(8));
            } elseif (!isset($slides[$id])) {
                throw new RuntimeException('Кадр не найден.');
            }
            $set['slides'][$id] = $data;
        } else {
            if (!isset($slides[$id])) throw new RuntimeException('Кадр не найден.');
            if ($operation === 'move-banner') {
                $order = array_keys($slides);
                $position = array_search($id, $order, true);
                $target = $position + (admin_input($input, 'direction') === 'up' ? -1 : 1);
                if (isset($order[$target])) {
                    list($order[$position], $order[$target]) = [$order[$target], $order[$position]];
                    $set['order'] = $order;
                }
            } elseif ($operation === 'restore-banner') {
                unset($set['slides'][$id]['excluded']);
            } elseif ($operation === 'delete-banner') {
                if (strpos($id, 'f-') === 0) {
                    $set['slides'][$id]['excluded'] = true;
                } else {
                    unset($set['slides'][$id]);
                    $set['order'] = array_values(array_diff($set['order'] ?? [], [$id]));
                }
                $id = '';
            }
        }
        $set['folder'] = $folder;
        $sets = site_banner_sets();
        $sets[$name] = $set;
        admin_write_record(SITE_BANNERS_FILE, $sets, SITE_BANNERS_LIMIT);
        return site_banner_admin_url($base, $name, $folder, $id !== '' ? ['slide' => $id] : []) . '#banner-editor';
    } finally {
        fclose($lock);
    }
}
