<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_upload_component_asset(array $upload, string $folder, array $extensions): string
{
    $name = $upload['name'] ?? '';
    $temporary = $upload['tmp_name'] ?? '';
    if (($upload['error'] ?? null) !== UPLOAD_ERR_OK || !is_string($temporary)
        || !is_uploaded_file($temporary) || !is_string($name)) {
        throw new RuntimeException('Не удалось загрузить файл. Проверьте ограничения загрузки PHP.');
    }
    $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($extension, $extensions, true) || filesize($temporary) > 33554432) {
        throw new RuntimeException('Этот формат файла не поддерживается или файл превышает 32 МиБ.');
    }
    $imageTypes = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
        'gif' => 'image/gif', 'webp' => 'image/webp', 'avif' => 'image/avif'];
    if (isset($imageTypes[$extension])) {
        $image = @getimagesize($temporary);
        if (($image['mime'] ?? '') !== $imageTypes[$extension]
            && ($extension !== 'avif' || !preg_match('/\A....ftypavi[fs]/s', file_get_contents($temporary, false, null, 0, 16)))) {
            throw new RuntimeException('Содержимое изображения не соответствует его расширению.');
        }
    }
    $stem = admin_image_name($name) ?: 'file';
    $target = $folder . '/' . $stem . '.' . $extension;
    for ($number = 2; file_exists($target) || is_link($target); $number++) {
        $target = $folder . '/' . $stem . '-' . $number . '.' . $extension;
    }
    if (!move_uploaded_file($temporary, $target)) {
        throw new RuntimeException('Не удалось записать файл в папку.');
    }
    clearstatcache(true);
    return basename($target);
}

function admin_component_media(string $action, array $input, string $base)
{
    $type = admin_input($input, 'type');
    $argument = admin_input($input, 'folder');
    $asset = $type === 'files' ? 'files' : 'images';
    $path = in_array($type, ['files', 'gal', 'fotos', 'banners'], true) ? site_asset_path($argument, $asset) : '';
    if ($path === '') {
        admin_json(422, ['message' => 'Укажите допустимую папку компонента.']);
    }
    $folder = SITE_ROOT . '/' . $path;
    $extensions = site_component_asset_extensions($type);
    $getFiles = static function () use ($argument, $base, $asset, $extensions, $type, $input, $path): array {
        $files = site_asset_files($argument, $base, $asset, $extensions);
        if ($type === 'banners') {
            $set = strtolower(admin_input($input, 'banner'));
            if (!site_valid_banner_set_id($set) && !site_valid_snippet($set)) $set = '';
            $set = site_banner_id($set, $argument);
            foreach ($files as &$file) {
                $file['edit'] = site_banner_admin_url($base, $set, $argument,
                    ['slide' => site_banner_file_slide_id($path, $file['name'])]) . '#banner-editor';
            }
        }
        $result = ['files' => $files];
        if (admin_input($input, 'browse') === '1') {
            $root = SITE_ROOT . '/' . $path;
            $result['folders'] = [];
            if (is_dir($root) && realpath($root) === str_replace('/', DIRECTORY_SEPARATOR, $root)) {
                foreach (scandir($root) ?: [] as $name) {
                    if (site_valid_part($name) && is_dir($root . '/' . $name) && !is_link($root . '/' . $name)
                        && realpath($root . '/' . $name) === str_replace('/', DIRECTORY_SEPARATOR, $root . '/' . $name)) {
                        $result['folders'][] = $name;
                    }
                }
            }
        }
        return $result;
    };
    if ($action === 'list-media') {
        admin_json(200, $getFiles());
    }

    try {
        $lock = admin_lock();
        try {
            if ($action === 'create-media-folder') {
                foreach (explode('/', $path) as $part) {
                    if (!site_valid_part($part)) throw new RuntimeException('В именах папок разрешены A–Z, a–z, 0–9, дефис и подчёркивание.');
                }
                admin_make_page_directory($path . '/file');
            } elseif ($action === 'upload-media') {
                admin_make_page_directory($path . '/file');
                admin_upload_component_asset($_FILES['upload'] ?? [], $folder, $extensions);
            } else {
                $list = array_column(site_asset_files($argument, $base, $asset, $extensions), 'name');
                if ($action === 'delete-media') {
                    $name = admin_input($input, 'file');
                    if (!in_array($name, $list, true) || !@unlink($folder . '/' . $name)) {
                        throw new RuntimeException('Файл уже удалён или недоступен для удаления.');
                    }
                } else {
                    $order = json_decode(admin_input($input, 'order'), true);
                    if (!is_array($order) || array_values($order) !== $order || count($order) !== count($list)) {
                        throw new RuntimeException('Список файлов изменился. Обновите его.');
                    }
                    $left = $list;
                    foreach ($order as $name) {
                        $position = array_search($name, $left, true);
                        if ($position === false) {
                            throw new RuntimeException('Список файлов изменился. Обновите его.');
                        }
                        unset($left[$position]);
                    }
                    admin_write_record($folder . '/.asset-order.php', $order, 131072);
                }
            }
        } finally {
            fclose($lock);
        }
        admin_json(200, $getFiles());
    } catch (RuntimeException $exception) {
        admin_json(422, ['message' => $exception->getMessage()]);
    }
}
