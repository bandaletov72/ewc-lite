<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => [
        'Обновить тему',
        'Установите подписанное обновление CMS из GitHub, затем примените файлы темы из установленной версии. Штатные шаблоны, CSS и скрипты темы будут заменены.',
        'Режим обновления',
        'Только дизайн',
        'Дизайн и замена страниц из комплекта',
        'Во втором режиме CMS создаст резервную копию и заменит страницы, которые входят в комплект темы. Добавленные вами страницы, настройки и инфоблоки сохранятся.',
        'Подтверждаю замену страниц из комплекта, если выбран второй режим.',
        'Дизайн и добавление недостающих страниц',
    ],
    'en' => [
        'Update theme',
        'Install the signed CMS update from GitHub, then apply the theme files included in that version. The bundled templates, CSS and scripts will be replaced.',
        'Update mode', 'Design only', 'Design and replace bundled pages',
        'The second mode backs up the site and replaces bundled pages. Custom pages, settings and data blocks are kept.',
        'I confirm replacement of bundled pages if the second mode is selected.',
        'Design and add missing pages',
    ],
    'uk' => [
        'Оновити тему',
        'Установіть підписане оновлення CMS із GitHub, а потім застосуйте файли теми з цієї версії. Штатні шаблони, CSS і скрипти буде замінено.',
        'Режим оновлення', 'Лише дизайн', 'Дизайн і заміна сторінок із комплекту',
        'Другий режим створює резервну копію і замінює сторінки з комплекту. Власні сторінки, налаштування й інфоблоки збережуться.',
        'Підтверджую заміну сторінок із комплекту, якщо вибрано другий режим.',
        'Дизайн і додавання відсутніх сторінок',
    ],
    'de' => [
        'Theme aktualisieren',
        'Installieren Sie das signierte CMS-Update von GitHub und übernehmen Sie die darin enthaltenen Theme-Dateien. Mitgelieferte Vorlagen, CSS und Skripte werden ersetzt.',
        'Aktualisierungsmodus', 'Nur Design', 'Design und mitgelieferte Seiten ersetzen',
        'Der zweite Modus erstellt eine Sicherung und ersetzt mitgelieferte Seiten. Eigene Seiten, Einstellungen und Datenblöcke bleiben erhalten.',
        'Ich bestätige das Ersetzen der mitgelieferten Seiten, falls der zweite Modus gewählt ist.',
        'Design und fehlende Seiten hinzufügen',
    ],
    'fr' => [
        'Mettre à jour le thème',
        'Installez la mise à jour signée du CMS depuis GitHub, puis appliquez les fichiers du thème fournis dans cette version. Les modèles, feuilles CSS et scripts fournis seront remplacés.',
        'Mode de mise à jour', 'Design uniquement', 'Design et remplacement des pages fournies',
        'Le second mode crée une sauvegarde et remplace les pages fournies. Vos pages, réglages et blocs de données sont conservés.',
        'Je confirme le remplacement des pages fournies si le second mode est sélectionné.',
        'Design et ajout des pages manquantes',
    ],
    'es' => [
        'Actualizar tema',
        'Instala la actualización firmada del CMS desde GitHub y después aplica los archivos del tema incluidos en esa versión. Se reemplazarán las plantillas, el CSS y los scripts incluidos.',
        'Modo de actualización', 'Solo diseño', 'Diseño y reemplazo de páginas incluidas',
        'El segundo modo crea una copia de seguridad y reemplaza las páginas incluidas. Se conservan tus páginas, ajustes y bloques de datos.',
        'Confirmo el reemplazo de las páginas incluidas si elijo el segundo modo.',
        'Diseño y adición de páginas faltantes',
    ],
    'pt' => [
        'Atualizar tema',
        'Instale a atualização assinada do CMS pelo GitHub e aplique os arquivos do tema dessa versão. Os modelos, o CSS e os scripts incluídos serão substituídos.',
        'Modo de atualização', 'Apenas design', 'Design e substituição das páginas incluídas',
        'O segundo modo cria uma cópia de segurança e substitui as páginas incluídas. Suas páginas, configurações e blocos de dados são mantidos.',
        'Confirmo a substituição das páginas incluídas se o segundo modo for selecionado.',
        'Design e adição das páginas em falta',
    ],
    'ja' => [
        'テーマを更新',
        'GitHub から署名済みの CMS 更新をインストールし、その版に含まれるテーマファイルを適用します。同梱のテンプレート、CSS、スクリプトは置き換わります。',
        '更新モード', 'デザインのみ', 'デザインと同梱ページの置き換え',
        '2 番目のモードではサイトをバックアップし、同梱ページを置き換えます。独自のページ、設定、データブロックは保持されます。',
        '2 番目のモードを選択した場合は、同梱ページの置き換えを確認します。',
        'デザインと不足ページの追加',
    ],
    'ko' => [
        '테마 업데이트',
        'GitHub에서 서명된 CMS 업데이트를 설치한 후 해당 버전에 포함된 테마 파일을 적용하세요. 기본 템플릿, CSS, 스크립트가 교체됩니다.',
        '업데이트 방식', '디자인만', '디자인 및 기본 페이지 교체',
        '두 번째 방식은 사이트를 백업하고 기본 페이지를 교체합니다. 사용자 페이지, 설정 및 데이터 블록은 유지됩니다.',
        '두 번째 방식을 선택한 경우 기본 페이지 교체에 동의합니다.',
        '디자인 및 누락된 페이지 추가',
    ],
    'vi' => [
        'Cập nhật giao diện',
        'Cài đặt bản cập nhật CMS có chữ ký từ GitHub rồi áp dụng tệp giao diện của phiên bản đó. Mẫu, CSS và tập lệnh đi kèm sẽ được thay thế.',
        'Chế độ cập nhật', 'Chỉ thiết kế', 'Thiết kế và thay các trang đi kèm',
        'Chế độ thứ hai sao lưu trang web và thay các trang đi kèm. Trang tự tạo, cài đặt và khối dữ liệu được giữ lại.',
        'Tôi xác nhận thay các trang đi kèm nếu chọn chế độ thứ hai.',
        'Thiết kế và thêm trang còn thiếu',
    ],
    'zh' => [
        '更新主题',
        '从 GitHub 安装已签名的 CMS 更新，然后应用该版本附带的主题文件。随附模板、CSS 和脚本将被替换。',
        '更新模式', '仅更新设计', '更新设计并替换随附页面',
        '第二种模式会备份网站并替换随附页面。自定义页面、设置和数据块会保留。',
        '如果选择第二种模式，我确认替换随附页面。',
        '更新设计并添加缺少的页面',
    ],
];
