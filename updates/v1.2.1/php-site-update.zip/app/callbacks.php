<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_CALLBACK_SETTINGS = SITE_ROOT . '/admin/.callback-settings.php';
const SITE_CALLBACKS_DIR = SITE_ROOT . '/admin/callbacks';

function site_callback_settings(): array
{
    $defaults = ['button' => 'Заказать обратный звонок', 'submit' => 'Отправить номер',
        'mode' => 'off', 'provider' => 'zadarma', 'from' => ''];
    return array_replace($defaults, site_read_record(SITE_CALLBACK_SETTINGS));
}

function site_callback_form(array $settings): array
{
    return [
        'button' => $settings['submit'],
        'fields' => [
            ['name' => 'phone', 'label' => 'Ваш телефон', 'type' => 'tel', 'required' => true, 'options' => []],
        ],
    ];
}

function site_callback_ids(): array
{
    $ids = [];
    foreach (glob(SITE_CALLBACKS_DIR . '/*.php') ?: [] as $file) {
        $id = basename($file, '.php');
        if (preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id)) {
            $ids[] = $id;
        }
    }
    rsort($ids, SORT_STRING);
    return $ids;
}

function site_callback_read(string $id): array
{
    if (preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id) !== 1) {
        return [];
    }
    return site_read_record(SITE_CALLBACKS_DIR . '/' . $id . '.php');
}

function site_callback_create(array $message, string $ip): string
{
    $phone = $message['fields']['phone']['value'];
    $source = $ip === '' ? '' : hash('sha256', $ip);
    $recentCount = 0;
    $earliest = gmdate('YmdHis', time() - 900);
    $samePhoneCutoff = gmdate('YmdHis', time() - 60);
    $lock = admin_lock();
    try {
        if ((!is_dir(SITE_CALLBACKS_DIR) && !@mkdir(SITE_CALLBACKS_DIR, 0755))
            || realpath(SITE_CALLBACKS_DIR) !== str_replace('/', DIRECTORY_SEPARATOR, SITE_CALLBACKS_DIR)) {
            throw new RuntimeException('Не удалось подготовить каталог обратных звонков.');
        }
        $guard = SITE_CALLBACKS_DIR . '/index.php';
        if (!is_file($guard) && !admin_replace_file($guard, "<?php\nhttp_response_code(404);\nexit;\n")) {
            throw new RuntimeException('Не удалось закрыть каталог обратных звонков.');
        }
        foreach (site_callback_ids() as $id) {
            $time = substr($id, 0, 14);
            if ($time < $earliest) {
                break;
            }
            $old = site_callback_read($id);
            if ($time >= $samePhoneCutoff && ($old['phone'] ?? '') === $phone) {
                throw new RuntimeException('Запрос на этот номер уже принят. Попробуйте позже.', 429);
            }
            if ($source !== '' && ($old['source'] ?? '') === $source) {
                $recentCount++;
                if ($recentCount >= 3) {
                    throw new RuntimeException('Слишком много заявок на звонок. Попробуйте позже.', 429);
                }
            }
        }
        $id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
        $record = ['time' => $message['time'], 'host' => $message['host'], 'page' => $message['page'],
            'phone' => $phone, 'source' => $source, 'status' => 'new'];
        admin_write_record(SITE_CALLBACKS_DIR . '/' . $id . '.php', $record);
        return $id;
    } finally {
        fclose($lock);
    }
}

function site_callback_request(array $settings, string $id, array $call): array
{
    $phone = preg_replace('/[^0-9+]/', '', $call['phone']);
    if ($settings['provider'] === 'zadarma') {
        $key = (string) getenv('SITE_ZADARMA_KEY');
        $secret = (string) getenv('SITE_ZADARMA_SECRET');
        if ($secret === '' || !preg_match('/\A[A-Za-z0-9_-]+\z/', $key) || $settings['from'] === '') {
            throw new RuntimeException('Проверьте ключи Zadarma и номер или добавочный оператора.');
        }
        $method = '/v1/request/callback/';
        $query = http_build_query(['from' => $settings['from'], 'to' => $phone], '', '&');
        $signature = base64_encode(hash_hmac('sha1', $method . $query . md5($query), $secret));
        return ['method' => 'GET', 'url' => 'https://api.zadarma.com' . $method . '?' . $query,
            'headers' => ['Accept: application/json', 'Authorization: ' . $key . ':' . $signature], 'content' => ''];
    }

    $url = (string) getenv('SITE_CALLBACK_WEBHOOK_URL');
    $token = (string) getenv('SITE_CALLBACK_WEBHOOK_TOKEN');
    if (!preg_match('~\Ahttps://~', $url) || !filter_var($url, FILTER_VALIDATE_URL)
        || ($token !== '' && preg_match('/[\x00-\x20\x7F]/', $token))) {
        throw new RuntimeException('Проверьте HTTPS-адрес и токен HTTP API.');
    }
    $headers = ['Accept: application/json', 'Content-Type: application/json', 'Idempotency-Key: ' . $id];
    if ($token !== '') {
        $headers[] = 'Authorization: Bearer ' . $token;
    }
    return ['method' => 'POST', 'url' => $url, 'headers' => $headers,
        'content' => json_encode(['id' => $id, 'phone' => $phone, 'host' => $call['host'],
            'page' => $call['page'], 'requested_at' => $call['time']], JSON_UNESCAPED_SLASHES)];
}

function site_callback_transport(array $request): array
{
    $context = stream_context_create(['http' => [
        'method' => $request['method'], 'header' => implode("\r\n", $request['headers']),
        'content' => $request['content'], 'timeout' => 5, 'follow_location' => 0, 'ignore_errors' => true,
    ]]);
    $body = @file_get_contents($request['url'], false, $context, 0, 8192);
    preg_match('~\AHTTP/\S+\s+([0-9]{3})~', $http_response_header[0] ?? '', $match);
    return [(int) ($match[1] ?? 0), $body];
}

function site_callback_dispatch(string $id, array $settings, callable $transport = null)
{
    if (!in_array($settings['mode'], ['manual', 'auto'], true)) {
        throw new RuntimeException('Передача в телефонию выключена.');
    }
    $lock = admin_lock();
    try {
        $call = site_callback_read($id);
        if (!$call || !in_array($call['status'], ['new', 'error'], true)) {
            throw new RuntimeException('Заявка уже отправлена или обрабатывается.');
        }
        $file = SITE_CALLBACKS_DIR . '/' . $id . '.php';
        $call['status'] = 'sending';
        unset($call['error']);
        admin_write_record($file, $call);
    } finally {
        fclose($lock);
    }
    try {
        $request = site_callback_request($settings, $id, $call);
        list($code, $body) = ($transport ?? 'site_callback_transport')($request);
        if ($body === false || $code < 200 || $code >= 300) {
            throw new RuntimeException($code > 0 ? 'Телефония ответила HTTP ' . $code . '.' : 'Телефония не ответила вовремя.');
        }
        if ($settings['provider'] === 'zadarma') {
            $result = json_decode($body, true);
            if (($result['status'] ?? '') !== 'success') {
                throw new RuntimeException('Zadarma отклонила заявку. Проверьте настройки оператора в АТС.');
            }
        }
        $call['status'] = 'accepted';
    } catch (RuntimeException $exception) {
        $call['status'] = 'error';
        $call['error'] = $exception->getMessage();
    }
    admin_write_record($file, $call);
    if ($call['status'] === 'error') {
        throw new RuntimeException($call['error']);
    }
}
