(() => {
    const sizeSelector = '[data-component-width]';
    let sizeUpdate = 0;
    const resizeComponents = () => {
        cancelAnimationFrame(sizeUpdate);
        sizeUpdate = requestAnimationFrame(() => {
            const content = document.querySelector('.page-content');
            const contentBox = content?.getBoundingClientRect();
            document.querySelectorAll(sizeSelector).forEach((block) => {
                if (!block.getClientRects().length || block.closest('dialog')) return;
                const rightWidth = block.dataset.componentWidth === 'page' || !contentBox
                    ? { left: 0, width: document.documentElement.clientWidth } : contentBox;
                const currentLeft = parseFloat(getComputedStyle(block).left) || 0;
                const shift = rightWidth.left - (block.getBoundingClientRect().left - currentLeft);
                block.style.setProperty('--component-expanded-width', rightWidth.width + 'px');
                block.style.setProperty('--component-expanded-offset', shift + 'px');
            });
        });
    };
    if ('ResizeObserver' in window) {
        const sizeWatcher = new ResizeObserver(resizeComponents);
        sizeWatcher.observe(document.documentElement);
        const content = document.querySelector('.page-content');
        if (content) sizeWatcher.observe(content);
    }
    window.addEventListener('resize', resizeComponents, { passive: true });
    if (document.querySelector(sizeSelector)) resizeComponents();
    new MutationObserver((records) => {
        if (records.some((record) => [...record.addedNodes].some((node) => node.nodeType === 1
            && (node.matches(sizeSelector) || node.querySelector(sizeSelector))))) resizeComponents();
    }).observe(document.body, { childList: true, subtree: true });

    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const entrance = {
        fade: { opacity: 0 },
        slide: { opacity: 0, translate: '0 16px' },
        scale: { opacity: 0, scale: '.97' },
    }[document.body.dataset.scrollAnimation];
    if (entrance && 'IntersectionObserver' in window && Element.prototype.animate && !motion.matches) {
        const seen = new WeakSet();
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(({ isIntersecting, target }) => {
                if (!isIntersecting) return;
                observer.unobserve(target);
                target.classList.remove('site-scroll-pending');
                if (!motion.matches && !target.contains(document.activeElement) && !target.matches(':focus')) {
                    const end = { opacity: 1 };
                    if (entrance.translate) end.translate = '0 0';
                    if (entrance.scale) end.scale = '1';
                    target.animate([entrance, end], { duration: 550, easing: 'ease-out' });
                }
            });
        }, { rootMargin: '0px 0px -8% 0px' });
        const observeBlocks = () => {
            document.querySelectorAll('.site-main > h1, .page-content > *, .page-preset > *').forEach((block) => {
                if (seen.has(block) || block.matches('script, style, template, [hidden]')) return;
                seen.add(block);
                const bounds = block.getBoundingClientRect();
                if (bounds.height > 0 && bounds.top >= window.innerHeight) {
                    block.classList.add('site-scroll-pending');
                    observer.observe(block);
                }
            });
        };
        observeBlocks();
        const main = document.querySelector('.site-main');
        if (main) new MutationObserver(observeBlocks).observe(main, { childList: true, subtree: true });
    }

    window.siteFetchContent = async (path) => {
        const token = document.querySelector('meta[name="site-fragment-token"]');
        const url = new URL(path, window.location.href);
        if (!token || url.origin !== window.location.origin) {
            throw new Error('Фрагмент доступен в текущем сеансе сайта.');
        }
        url.searchParams.set('ajax', '1');
        const response = await fetch(url, {
            credentials: 'same-origin',
            headers: { Accept: 'text/html', 'X-Site-Fragment': token.content },
        });
        if (!response.ok) throw new Error('Не удалось загрузить страницу (' + response.status + ').');
        return response.text();
    };

    document.addEventListener('change', async (event) => {
        const picker = event.target.closest('[data-city-picker]');
        if (!picker || !event.target.matches('[data-city-select]')) return;
        const fields = [...document.querySelectorAll('[data-city-select]')];
        const previous = fields.map((field) => [...field.options].find((option) => option.defaultSelected)?.value || '');
        const token = document.querySelector('meta[name="site-fragment-token"]');
        const url = new URL(picker.dataset.cityUrl, window.location.href);
        const error = picker.querySelector('[data-city-error]');
        document.querySelectorAll('[data-city-error]').forEach((message) => { message.hidden = true; });
        fields.forEach((field) => { field.disabled = true; });
        try {
            if (!token || url.origin !== window.location.origin) throw new Error();
            url.searchParams.set('city_select', event.target.value);
            const response = await fetch(url, {
                credentials: 'same-origin',
                headers: { Accept: 'application/json', 'X-Site-Fragment': token.content },
            });
            if (!response.ok) throw new Error();
            const update = await response.json();
            fields.forEach((field) => {
                field.value = update.city;
                [...field.options].forEach((option) => { option.defaultSelected = option.selected; });
                const label = field.closest('[data-city-picker]').querySelector('[data-city-current]');
                if (label && field.selectedOptions[0]) label.textContent = field.selectedOptions[0].textContent;
            });
            document.querySelectorAll('[data-city-phones]').forEach((list) => { list.innerHTML = update.phones; });
            document.querySelectorAll('[data-city-token]').forEach((node) => {
                node.innerHTML = update.tokens[node.dataset.cityToken] ?? '';
            });
            document.querySelectorAll('[data-city-contact]').forEach((node) => {
                node.innerHTML = update.contacts[node.dataset.cityContact] ?? '';
            });
        } catch (exception) {
            fields.forEach((field, index) => { field.value = previous[index]; });
            error.hidden = false;
        } finally {
            fields.forEach((field) => { field.disabled = false; });
        }
    });

    document.addEventListener('click', (event) => {
        document.querySelectorAll('[data-language-dropdown][open]').forEach((menu) => {
            if (!menu.contains(event.target)) menu.open = false;
        });
        document.querySelectorAll('[data-breadcrumb-siblings][open]').forEach((menu) => {
            if (!menu.contains(event.target)) menu.open = false;
        });
    });
    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        const menu = event.target.closest?.('[data-breadcrumb-siblings][open], [data-language-dropdown][open]');
        if (menu) {
            event.preventDefault();
            menu.open = false;
            menu.querySelector('summary').focus();
        }
    });

    document.querySelectorAll('[data-breadcrumb-siblings]').forEach((menu) => {
        const align = () => {
            if (!menu.open) return;
            const list = menu.querySelector('ul');
            const available = document.documentElement.clientWidth - 8 - menu.getBoundingClientRect().left;
            list.style.setProperty('--breadcrumb-offset', Math.min(0, available - list.offsetWidth) + 'px');
        };
        menu.addEventListener('toggle', align);
        window.addEventListener('resize', align, { passive: true });
    });

    document.querySelectorAll('.mobile-header-menu').forEach((element, index) => {
        const toggle = element.querySelector('[data-mobile-toggle]');
        const drawer = element.querySelector('[data-mobile-drawer]');
        if (!toggle || !drawer) return;
        drawer.id = 'mobile-site-menu-' + (index + 1);
        toggle.setAttribute('aria-controls', drawer.id);
        toggle.hidden = false;
        const mobile = window.matchMedia('(max-width: 40rem)');
        const closeOnResize = () => { if (!mobile.matches && drawer.open) drawer.close(); };

        toggle.addEventListener('click', () => {
            if (!drawer.open) {
                drawer.showModal();
                toggle.setAttribute('aria-expanded', 'true');
            }
        });
        drawer.querySelector('[data-mobile-close]').addEventListener('click', () => drawer.close());
        drawer.addEventListener('click', (event) => {
            if (event.target.closest('[data-mobile-navigation] a')) {
                drawer.close();
            } else if (event.target === drawer) {
                const panel = drawer.getBoundingClientRect();
                if (event.clientX < panel.left || event.clientX > panel.right) drawer.close();
            }
        });
        drawer.addEventListener('close', () => toggle.setAttribute('aria-expanded', 'false'));
        if (mobile.addEventListener) mobile.addEventListener('change', closeOnResize);
        else mobile.addListener(closeOnResize);
    });

    const phoneParts = (input, raw) => {
        const original = raw.replace(/\D/g, '');
        const hasPlus = raw.trimStart().startsWith('+');
        const profile = JSON.parse(input.form.dataset.phoneProfile || '{"code":"7","prefixes":"78"}');
        let digits = original;
        if (!hasPlus && digits && profile.code) {
            digits = profile.code + (profile.prefixes.includes(digits[0]) ? digits.slice(1) : digits);
        }
        return { original, digits, international: Boolean(hasPlus || (digits && profile.code)), limit: digits[0] === '7' ? 11 : 15 };
    };

    const acceptedPhone = new WeakMap();
    const formatPhone = (input) => {
        const raw = input.value;
        const { original, digits, international, limit } = phoneParts(input, raw);
        if (!/^ *\+?[0-9 ().-]*$/.test(raw) || digits.length > limit) {
            input.value = acceptedPhone.get(input) ?? '';
            return;
        }
        let value = (international ? '+' : '') + digits;
        if (international && digits[0] === '7') {
            const local = digits.slice(1);
            value = '+7';
            if (local.length) value += '(' + local.slice(0, 3);
            if (local.length > 3) value += ')' + local.slice(3, 6);
            if (local.length > 6) value += '-' + local.slice(6, 8);
            if (local.length > 8) value += '-' + local.slice(8);
        }
        acceptedPhone.set(input, value);
        if (value === raw) return;

        const caret = input.selectionStart;
        input.value = value;
        if (caret === null || caret === raw.length) return;
        let digitsBeforeCaret = raw.slice(0, caret).replace(/\D/g, '').length;
        if (digitsBeforeCaret > 0) digitsBeforeCaret += digits.length - original.length;
        let position = 0;
        while (position < value.length && digitsBeforeCaret > 0) {
            if (/\d/.test(value[position])) digitsBeforeCaret -= 1;
            position += 1;
        }
        input.setSelectionRange(position, position);
    };

    const rejectExtraPhoneInput = (event, input, inserted) => {
        if (typeof inserted !== 'string' || input.selectionStart === null || input.selectionEnd === null) return;
        const candidate = input.value.slice(0, input.selectionStart) + inserted + input.value.slice(input.selectionEnd);
        const { digits, limit } = phoneParts(input, candidate);
        if (!/^ *\+?[0-9 ().-]*$/.test(candidate) || digits.length > limit) event.preventDefault();
    };

    const validatePhone = (input, showError) => {
        formatPhone(input);
        const value = input.value;
        const valid = !value || (/^\+7\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}$|^\+[1-68-9][0-9]{6,14}$/.test(value)
            && (input.maxLength < 0 || value.length <= input.maxLength));
        const message = input.form.dataset.phoneError || 'Укажите полный номер телефона, включая код страны.';
        input.setCustomValidity(valid ? '' : message);
        if (!showError) return;
        const label = input.closest('[data-message-field]');
        const hint = label?.querySelector('[data-field-error]');
        if (hint) {
            hint.textContent = valid ? '' : message;
            hint.hidden = valid;
        }
        if (valid) input.removeAttribute('aria-invalid');
        else input.setAttribute('aria-invalid', 'true');
    };

    const captchaWidgets = new WeakMap();
    let captchaScript;
    const loadCaptcha = () => {
        if (!captchaScript) {
            captchaScript = new Promise((resolve, reject) => {
                const script = document.createElement('script');
                const timer = window.setTimeout(reject, 15000);
                window.siteRecaptchaReady = () => {
                    window.clearTimeout(timer);
                    resolve(window.grecaptcha);
                };
                script.addEventListener('error', () => {
                    window.clearTimeout(timer);
                    reject();
                }, { once: true });
                script.async = true;
                script.src = 'https://www.google.com/recaptcha/api.js?onload=siteRecaptchaReady&render=explicit&hl=ru';
                document.head.append(script);
            });
        }
        return captchaScript;
    };

    const drawIblockChart = (element) => {
        const frame = element.querySelector('.iblock-chart-canvas');
        const canvas = frame.querySelector('canvas');
        const { type, labels, datasets } = JSON.parse(element.dataset.iblockChart);
        const horizontal = type === 'horizontal';
        const palette = ['#329681', '#5b7ed7', '#da7756', '#9973bf', '#c19832', '#3a9ab8', '#c26695', '#608750'];
        const sectors = ['pie', 'doughnut', 'polarArea'].includes(type);
        datasets.forEach((series, index) => {
            const color = palette[index];
            series.backgroundColor = sectors ? labels.map((_, position) => palette[position % palette.length]) : color + '55';
            series.borderColor = sectors ? getComputedStyle(element).getPropertyValue('--surface').trim() : color;
            series.borderWidth = 2;
            if (type === 'line') series.tension = .2;
        });
        const ink = () => getComputedStyle(element).color;
        const line = () => getComputedStyle(element).getPropertyValue('--line').trim();
        const axis = () => ({ ticks: { color: ink }, grid: { color: line } });
        const scales = sectors && type !== 'polarArea' ? {}
            : type === 'radar' || type === 'polarArea'
                ? { r: { ...axis(), angleLines: { color: line }, pointLabels: { color: ink } } }
                : { x: axis(), y: axis() };
        frame.hidden = false;
        try {
            new window.Chart(canvas, {
                type: horizontal ? 'bar' : type,
                data: { labels, datasets },
                options: {
                    indexAxis: horizontal ? 'y' : 'x',
                    responsive: true, maintainAspectRatio: false, animation: false,
                    locale: document.documentElement.lang || undefined,
                    scales, plugins: { legend: { labels: { color: ink, usePointStyle: true } } }
                }
            });
            element.querySelector('details').open = false;
        } catch (error) {
            window.Chart.getChart(canvas)?.destroy();
            frame.hidden = true;
        }
    };

    const chartSelector = '[data-iblock-chart]';
    const initialize = (root) => {
        const selector = '[data-gallery]:not([data-ready]), [data-contact-form]:not([data-ready]), ' + chartSelector + ':not([data-ready])';
        const elements = [...(root.matches(selector) ? [root] : []), ...root.querySelectorAll(selector)];
        elements.forEach((element) => {
            if (element.closest('[data-banner-dialog]:not([open]), [data-action-dialog]:not([open])')) return;
            element.dataset.ready = 'true';
            if (element.matches(chartSelector)) {
                if (typeof window.Chart === 'function') drawIblockChart(element);
                return;
            }
            if (element.matches('[data-contact-form]')) {
                const formatTelephone = (event) => {
                    if (event.target.matches('input[type="tel"]')) validatePhone(event.target, true);
                };
                element.addEventListener('input', formatTelephone);
                element.addEventListener('change', formatTelephone);
                element.addEventListener('beforeinput', (event) => {
                    if (event.target.matches('input[type="tel"]') && event.inputType?.startsWith('insert')) {
                        rejectExtraPhoneInput(event, event.target, event.data);
                    }
                });
                element.addEventListener('paste', (event) => {
                    if (event.target.matches('input[type="tel"]')) rejectExtraPhoneInput(event, event.target, event.clipboardData?.getData('text'));
                });
                element.querySelectorAll('input[type="tel"]').forEach((input) => validatePhone(input, false));
                const button = element.querySelector('button[type="submit"]');
                const widget = element.querySelector('[data-form-captcha]');
                if (!widget) {
                    button.disabled = false;
                    return;
                }
                const status = element.querySelector('[data-captcha-status]');
                loadCaptcha().then((api) => {
                    if (!element.isConnected) {
                        delete element.dataset.ready;
                        return;
                    }
                    const id = api.render(widget, {
                        sitekey: widget.dataset.sitekey,
                        size: 'compact',
                        'error-callback': () => { status.textContent = 'CAPTCHA недоступна. Обновите страницу.'; },
                        'expired-callback': () => { status.textContent = 'Подтвердите проверку ещё раз.'; },
                        callback: () => { status.textContent = 'Проверка пройдена.'; },
                    });
                    captchaWidgets.set(element, { api, id });
                    button.disabled = false;
                }).catch(() => {
                    status.textContent = 'Не удалось загрузить CAPTCHA. Обновите страницу и попробуйте снова.';
                });
                return;
            }
            const controls = element.querySelector('.gallery-controls');
            const track = element.querySelector('[data-gallery-track]');
            const images = [...track.children];
            if (images.length < 2) return;
            const status = controls && controls.querySelector('[data-gallery-status]');
            const effect = element.dataset.galleryEffect;
            const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

            let current = -1;
            const select = (index) => {
                if (index === current) return;
                current = index;
                if (status) status.textContent = (current + 1) + ' / ' + images.length;
                images.forEach((image, position) => {
                    image.classList.toggle('is-active', position === current);
                    if (position === current) image.removeAttribute('aria-hidden');
                    else image.setAttribute('aria-hidden', 'true');
                    if (element.hasAttribute('data-banners')) image.inert = position !== current;
                });
            };
            const move = (direction) => {
                const next = (current + direction + images.length) % images.length;
                if (effect === 'fade') {
                    select(next);
                } else {
                    track.scrollTo({ left: images[next].offsetLeft,
                        behavior: effect === 'slide' && !reducedMotion.matches ? 'smooth' : 'auto' });
                }
            };

            if (controls) {
                controls.hidden = false;
                const previous = controls.querySelector('[data-gallery-prev]');
                const next = controls.querySelector('[data-gallery-next]');
                if (previous && next) {
                    previous.addEventListener('click', () => move(-1));
                    next.addEventListener('click', () => move(1));
                }
            }
            if (effect === 'fade') {
                let start;
                track.addEventListener('touchstart', (event) => {
                    start = event.touches.length === 1 ? event.touches[0] : null;
                }, { passive: true });
                track.addEventListener('touchcancel', () => { start = null; }, { passive: true });
                track.addEventListener('touchend', (event) => {
                    if (!start) return;
                    const end = Array.from(event.changedTouches).find((touch) => touch.identifier === start.identifier);
                    if (!end) return;
                    const x = end.clientX - start.clientX;
                    const y = end.clientY - start.clientY;
                    start = null;
                    if (Math.abs(x) > Math.max(35, Math.abs(y))) move(x < 0 ? 1 : -1);
                }, { passive: true });
            } else {
                track.addEventListener('scroll', () => {
                    if (track.clientWidth > 0) {
                        select(Math.max(0, Math.min(images.length - 1, Math.round(track.scrollLeft / track.clientWidth))));
                    }
                }, { passive: true });
            }
            element.addEventListener('keydown', (event) => {
                if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
                if (event.target.matches('input, textarea, select, [contenteditable]')) return;
                event.preventDefault();
                move(event.key === 'ArrowRight' ? 1 : -1);
            });
            select(0);
        });
    };

    document.addEventListener('click', (event) => {
        const opener = event.target.closest('[data-banner-open], [data-action-open]');
        const closer = event.target.closest('[data-banner-close], [data-action-close]');
        if (opener) {
            const dialog = document.getElementById(opener.dataset.bannerOpen || opener.dataset.actionOpen);
            if (dialog?.matches('[data-banner-dialog], [data-action-dialog]') && !dialog.open) {
                dialog.showModal();
                initialize(dialog);
            }
        } else if (closer) {
            closer.closest('[data-banner-dialog], [data-action-dialog]').close();
        }
    });
    initialize(document.body);
    new MutationObserver((records) => {
        records.forEach((record) => {
            record.addedNodes.forEach((node) => {
                if (node.nodeType === 1) initialize(node);
            });
            if (typeof window.Chart !== 'function') return;
            record.removedNodes.forEach((node) => {
                if (node.nodeType !== 1 || node.isConnected) return;
                const charts = [...(node.matches(chartSelector) ? [node] : []), ...node.querySelectorAll(chartSelector)];
                charts.forEach((chart) => {
                    window.Chart.getChart(chart.querySelector('canvas'))?.destroy();
                    delete chart.dataset.ready;
                });
            });
        });
    }).observe(document.body, { childList: true, subtree: true });

    document.addEventListener('submit', async (event) => {
        const form = event.target;
        if (!form.matches('[data-contact-form]')) return;
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        if (button.disabled) return;

        const feedback = form.querySelector('[data-form-feedback]');
        const fields = [...form.querySelectorAll('[data-message-field]')];
        fields.forEach((field) => {
            field.querySelector('[data-field-error]').hidden = true;
            field.querySelectorAll('[aria-invalid]').forEach((input) => input.removeAttribute('aria-invalid'));
        });
        feedback.hidden = true;
        const captcha = captchaWidgets.get(form);
        const token = captcha ? captcha.api.getResponse(captcha.id) : '';
        if (captcha && !token) {
            feedback.textContent = 'Подтвердите, что вы не робот.';
            feedback.classList.add('error');
            feedback.hidden = false;
            return;
        }
        button.disabled = true;
        try {
            const body = new FormData(form);
            if (captcha) body.set('g-recaptcha-response', token);
            const response = await fetch(form.action, {
                method: 'POST',
                body,
                headers: { Accept: 'application/json' },
            });
            const result = await response.json();
            feedback.textContent = result.message;
            feedback.classList.toggle('error', !result.ok);
            if (result.ok) {
                if (form.matches('[data-purchase-form]') && result.payment?.url) {
                    if (result.payment.fields) {
                        const transfer = document.createElement('form');
                        transfer.method = 'POST';
                        transfer.action = result.payment.url;
                        Object.entries(result.payment.fields).forEach(([name,value]) => {
                            const input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = name;
                            input.value = value;
                            transfer.append(input);
                        });
                        document.body.append(transfer);
                        transfer.submit();
                    } else location.assign(result.payment.url);
                    return;
                }
                form.insertAdjacentElement('afterend', feedback);
                form.hidden = true;
                feedback.hidden = false;
                feedback.tabIndex = -1;
                feedback.focus({ preventScroll: true });
            } else {
                fields.forEach((field) => {
                    const name = field.dataset.messageField;
                    if (!Object.prototype.hasOwnProperty.call(result.fields || {}, name)) return;
                    const fieldError = field.querySelector('[data-field-error]');
                    fieldError.textContent = result.fields[name];
                    fieldError.hidden = false;
                    field.querySelectorAll('input, textarea, select').forEach((input) => input.setAttribute('aria-invalid', 'true'));
                });
            }
        } catch (error) {
            feedback.textContent = 'Не удалось отправить сообщение. Попробуйте ещё раз.';
            feedback.classList.add('error');
        } finally {
            feedback.hidden = false;
            button.disabled = false;
            if (captcha && form.isConnected) {
                captcha.api.reset(captcha.id);
                form.querySelector('[data-captcha-status]').textContent = 'Подтвердите, что вы не робот.';
            }
        }
    });
})();

(() => {
    const meta = document.querySelector('meta[name=site-analytics]');
    if (!meta) return;
    const enabled = JSON.parse(meta.content);
    const load = (source) => {
        const script = document.createElement('script');
        script.src = source;
        script.async = true;
        document.head.append(script);
        return script;
    };
    if (enabled.metrica) {
        if (!window.ym) {
            window.ym = function () { (window.ym.a = window.ym.a || []).push(arguments); };
            window.ym.l = Date.now();
            load('https://mc.yandex.ru/metrika/tag.js');
        }
        window.ym(Number(enabled.metrica), 'init', { clickmap: true, trackLinks: true, accurateTrackBounce: true });
    }
    if (enabled.analytics) {
        if (!window.gtag) {
            window.dataLayer = window.dataLayer || [];
            window.gtag = function () { window.dataLayer.push(arguments); };
            window.gtag('js', new Date());
            load('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(enabled.analytics));
        }
        window.gtag('config', enabled.analytics);
    }
    if (enabled.pixel) {
        if (!window.fbq) {
            const pixel = function () {
                if (pixel.callMethod) pixel.callMethod.apply(pixel, arguments);
                else pixel.queue.push(arguments);
            };
            pixel.push = pixel;
            pixel.loaded = true;
            pixel.version = '2.0';
            pixel.queue = [];
            window.fbq = pixel;
            if (!window._fbq) window._fbq = pixel;
            load('https://connect.facebook.net/en_US/fbevents.js');
        }
        window.fbq('init', enabled.pixel);
        window.fbq('track', 'PageView');
    }
    if (enabled.cloudflare) {
        const beacon = document.createElement('script');
        beacon.src = 'https://static.cloudflareinsights.com/beacon.min.js';
        beacon.defer = true;
        beacon.dataset.cfBeacon = JSON.stringify({ token: enabled.cloudflare });
        document.head.append(beacon);
    }
    if (enabled.clarity) {
        if (!window.clarity) {
            window.clarity = function () { (window.clarity.q = window.clarity.q || []).push(arguments); };
            load('https://www.clarity.ms/tag/' + encodeURIComponent(enabled.clarity));
        }
        window.clarity('consentv2', {ad_Storage: 'denied', analytics_Storage: 'granted'});
    }
    if (enabled.umami) {
        const tracker = document.createElement('script');
        tracker.src = 'https://cloud.umami.is/script.js';
        tracker.dataset.websiteId = enabled.umami;
        tracker.defer = true;
        document.head.append(tracker);
    }
})();

(() => {
    const providers = new Map();
    const loadScript = (url) => new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = url;
        script.async = true;
        const timer = setTimeout(() => reject(new Error('Map script timeout')), 12000);
        script.addEventListener('load', () => { clearTimeout(timer); resolve(); }, { once: true });
        script.addEventListener('error', () => { clearTimeout(timer); reject(new Error('Map script failed')); }, { once: true });
        document.head.append(script);
    });
    const provider = (data) => {
        if (!providers.has(data.provider)) {
            const google = data.provider === 'google';
            const params = google ? { key: data.key, v: 'weekly', language: data.locale }
                : { apikey: data.key, lang: data.locale === 'ru' ? 'ru_RU' : 'en_US' };
            const url = google ? 'https://maps.googleapis.com/maps/api/js?' : 'https://api-maps.yandex.ru/2.1/?';
            providers.set(data.provider, loadScript(url + new URLSearchParams(params)).then(() => {
                if (google) return Promise.all([window.google.maps.importLibrary('maps'), window.google.maps.importLibrary('marker')]);
                return new Promise((resolve, reject) => window.ymaps.ready(resolve, reject));
            }));
        }
        return providers.get(data.provider);
    };
    const balloon = (point) => {
        const content = document.createElement('div');
        if (point.card) {
            // Page cards are rendered from escaped fields and a formatted announcement on the server.
            content.innerHTML = point.card;
            return content;
        }
        const title = document.createElement('strong');
        title.textContent = point.title;
        content.append(title);
        if (point.url) {
            const link = document.createElement('a');
            link.href = point.url;
            link.textContent = point.button || point.title;
            link.className = 'button';
            content.append(document.createElement('br'), link);
        }
        return content;
    };
    const start = async (block) => {
        block.dataset.mapReady = 'true';
        const canvas = block.querySelector('[data-map-canvas]');
        const status = block.querySelector('[data-map-status]');
        try {
            const data = JSON.parse(block.dataset.siteMap);
            const center = data.center || data.points[0];
            const modules = await provider(data);
            if (!block.isConnected) return;
            if (data.provider === 'yandex') {
                const api = window.ymaps;
                const map = new api.Map(canvas, { center: [center.lat, center.lng], zoom: data.zoom,
                    type: { map: 'yandex#map', satellite: 'yandex#satellite', hybrid: 'yandex#hybrid' }[data.mode],
                    controls: ['zoomControl'] });
                const group = data.cluster && data.points.length > 1 ? new api.Clusterer() : new api.GeoObjectCollection();
                data.points.forEach((point) => {
                    const name = document.createElement('span');
                    name.textContent = point.title;
                    group.add(new api.Placemark([point.lat, point.lng], {
                        iconCaption: name.innerHTML, hintContent: name.innerHTML, balloonContent: balloon(point).outerHTML,
                    }, { preset: 'islands#blueDotIconWithCaption' }));
                });
                map.geoObjects.add(group);
                if (data.fit && data.points.length > 1) map.setBounds(group.getBounds(), { checkZoomRange: true, zoomMargin: 36 });
            } else {
                const [maps, markerApi] = modules;
                const map = new maps.Map(canvas, { center: { lat: center.lat, lng: center.lng },
                    zoom: data.zoom, mapId: data.mapId, mapTypeId: data.mode === 'map' ? 'roadmap' : data.mode });
                const info = new maps.InfoWindow();
                const bounds = new google.maps.LatLngBounds();
                const markers = data.points.map((point) => {
                    const position = { lat: point.lat, lng: point.lng };
                    bounds.extend(position);
                    const marker = new markerApi.AdvancedMarkerElement({ position, title: point.title });
                    marker.addListener('click', () => {
                        info.setContent(balloon(point));
                        info.open({ map, anchor: marker });
                    });
                    return marker;
                });
                if (data.cluster && markers.length > 1) {
                    try {
                        const { MarkerClusterer } = await import('https://cdn.jsdelivr.net/npm/@googlemaps/markerclusterer@2.6.2/+esm');
                        new MarkerClusterer({ map, markers });
                    } catch {
                        markers.forEach((marker) => { marker.map = map; });
                    }
                } else {
                    markers.forEach((marker) => { marker.map = map; });
                }
                if (data.fit && markers.length > 1) map.fitBounds(bounds, 36);
            }
        } catch {
            canvas.hidden = true;
            status.textContent = 'Не удалось загрузить карту.';
            status.hidden = false;
        }
    };
    const scan = (root) => {
        const selector = '[data-site-map]:not([data-map-ready])';
        if (root.matches(selector)) start(root);
        root.querySelectorAll(selector).forEach(start);
    };
    scan(document.body);
    new MutationObserver((records) => records.forEach((record) =>
        record.addedNodes.forEach((node) => { if (node.nodeType === 1) scan(node); })
    )).observe(document.body, { childList: true, subtree: true });
})();

document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-show-page-dialog]');
    const component = event.target.closest('[data-inline-component]');
    const closer = event.target.closest('[data-close-page-dialog]');
    if (opener) {
        const dialog = document.getElementById(opener.dataset.showPageDialog);
        if (dialog && !dialog.open) dialog.showModal();
    } else if (component) {
        const entry = document.getElementById(component.hash.slice(1));
        const dialog = entry && entry.closest('dialog');
        if (!dialog) return;
        event.preventDefault();
        entry.open = true;
        if (!dialog.open) dialog.showModal();
        entry.scrollIntoView({block: 'nearest'});
        (entry.querySelector('[data-inline-field], [data-inline-option], [data-editor-data-url]') || entry.querySelector('summary'))?.focus();
    } else if (closer) {
        const dialog = closer.closest('dialog');
        if (dialog.dispatchEvent(new Event('cancel', {cancelable: true}))) dialog.close();
    }
});

(() => {
    const selector = '[data-page-menu-branch]';
    const branches = (element) => {
        const items = [];
        for (let branch = element.closest?.(selector); branch; branch = branch.parentElement.closest(selector)) items.push(branch);
        return items;
    };
    for (const type of ['pointerover', 'pointerout']) {
        document.addEventListener(type, (event) => {
            if (event.pointerType !== 'mouse') return;
            const entering = type === 'pointerover';
            branches(event.target).forEach((branch) => {
                if (!branch.closest('.mobile-drawer') && !branch.contains(event.relatedTarget)
                    && (entering || !branch.contains(document.activeElement))) {
                    branch.querySelector(':scope > details').open = entering;
                }
            });
        });
    }
    document.addEventListener('toggle', (event) => {
        const disclosure = event.target;
        if (!disclosure.matches('details[open]') || !disclosure.parentElement.matches(selector)) return;
        const submenu = disclosure.querySelector(':scope > ul');
        submenu.classList.remove('is-end-aligned');
        if (submenu.getBoundingClientRect().right > document.documentElement.clientWidth - 8) submenu.classList.add('is-end-aligned');
    }, true);
    document.addEventListener('focusout', (event) => {
        if (!event.relatedTarget) return;
        branches(event.target).forEach((branch) => {
            if (!branch.contains(event.relatedTarget)) branch.querySelector(':scope > details').open = false;
        });
    });
    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        const branch = branches(event.target).find((item) => item.querySelector(':scope > details[open]'));
        if (!branch) return;
        event.preventDefault();
        const disclosure = branch.querySelector(':scope > details');
        disclosure.open = false;
        disclosure.querySelector(':scope > summary').focus();
    });
})();

let openLayoutEditor;
let openPageEditor;
document.querySelectorAll('#page-component-data, #page-banner-editor, #page-layout-editor, #page-content-editor').forEach((componentDataDialog) => {
    const frame = componentDataDialog.querySelector('[data-component-data-iframe]');
    const wide = componentDataDialog.querySelector('[data-component-data-wide]');
    const isBanner = componentDataDialog.id === 'page-banner-editor';
    const isLayout = componentDataDialog.id === 'page-layout-editor';
    const isPage = componentDataDialog.id === 'page-content-editor';
    const selector = isLayout ? '[data-layout-edit-control][data-layout-edit-modal]'
        : (isPage ? '[data-page-editor-link]' : (isBanner ? '[data-banner-editor-url]' : '[data-editor-data-url]'));
    let saved = false;
    const open = (url, wideUrl) => {
        if (componentDataDialog.open) return;
        saved = false;
        frame.src = url;
        if (wide) wide.href = wideUrl;
        componentDataDialog.showModal();
    };
    if (isLayout) openLayoutEditor = open;
    if (isPage) {
        openPageEditor = (href) => {
            const url = new URL(href, location.href);
            url.searchParams.set('embed', '1');
            open(url.href);
        };
        componentDataDialog.addEventListener('cancel', (event) => {
            if (frame.contentDocument?.dispatchEvent(new Event('ewc:page-editor-close', {cancelable: true})) === false) {
                event.preventDefault();
            }
        });
    }
    document.addEventListener('click', (event) => {
        const button = event.target.closest(selector);
        if (!button || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        if (isPage) openPageEditor(button.href);
        else open(isLayout ? button.dataset.layoutEditModal : (isBanner ? button.dataset.bannerEditorUrl : button.dataset.editorDataUrl),
            button.dataset.editorDataWide);
    });
    window.addEventListener('message', (event) => {
        if (componentDataDialog.open && event.origin === location.origin && event.source === frame.contentWindow
            && event.data?.type === 'eurowebcart:component-data-saved') saved = true;
    });
    componentDataDialog.addEventListener('close', () => {
        frame.removeAttribute('src');
        if (saved) location.reload();
    });
});

document.querySelectorAll('[data-inline-editor]').forEach((form) => {
    const source = form.elements.code;
    const preview = form.querySelector('[data-copy-code-text]');
    const manualCode = form.querySelector('[data-copy-code-editor]');
    const pencil = form.querySelector('[data-copy-code-pencil]');
    const publishCode = () => {
        preview.textContent = source.value;
        if (!manualCode.hidden && manualCode.value !== source.value) manualCode.value = source.value;
        form.querySelector('[data-copy-code-status]').textContent = '';
    };
    pencil.addEventListener('click', () => {
        const editing = manualCode.hidden;
        manualCode.hidden = !editing;
        preview.hidden = editing;
        pencil.setAttribute('aria-expanded', String(editing));
        if (editing) {
            manualCode.value = source.value;
            manualCode.focus();
        }
    });
    manualCode.addEventListener('input', () => {
        source.value = manualCode.value;
        publishCode();
    });
    const openingTag = /^\[(?:[^"\]]+|"[^"]*")+\]/;
    const attribute = /[ \t]+([a-z][a-z0-9_-]*)=(?:"[^"]*"|[^ \t\]]+)/gi;
    const dimensions = new Set(['width', 'height', 'mobile-height', 'height-mobile']);
    const modifyOpening = (code, name, value) => code.replace(openingTag, (opening) => {
        const clear = opening.replace(attribute, (part, key) => {
            return key === name || (name === 'mobile-height' && key === 'height-mobile') ? '' : part;
        });
        return clear.slice(0, -1) + (value ? ' ' + name + '=' + value : '') + ']';
    });
    form.addEventListener('change', (event) => {
        const kind = form.dataset.inlineEditor;
        if (event.target.matches('[data-inline-field]')) {
            const original = source.value;
            const preserved = Array.from((original.match(openingTag)?.[0] || '').matchAll(attribute))
                .filter((part) => dimensions.has(part[1]) || (kind === 'map' && ['url', 'button'].includes(part[1])));
            const fields = Object.fromEntries(Array.from(form.querySelectorAll('[data-inline-field]'),
                (input) => [input.dataset.inlineField, input.value.trim()]));
            if (kind === 'iblock') {
                const field = event.target.dataset.inlineField;
                if (fields.path === ':new:') return;
                if (field === 'limit' && !event.target.validity.valid) return;
                let code = (original.match(openingTag)?.[0] || '[iblock=' + fields.template + ']')
                    + fields.path + '[/iblock]';
                if (field === 'template') {
                    code = code.replace(/^\[iblock=[^\s\]]+/i, '[iblock=' + fields.template);
                } else if (field !== 'path') {
                    const value = fields[field];
                    const encoded = !value || field === 'limit' ? value : '"'
                        + value.replace(/[&"\[\]]/g, char => '&#' + char.charCodeAt(0) + ';') + '"';
                    code = modifyOpening(code, field, encoded);
                }
                source.value = code;
                publishCode();
                return;
            }
            if (['map', 'maps', 'maplist', 'points', 'route', 'callback'].includes(kind)) {
                const section = fields.section;
                delete fields.section;
                const options = Object.entries(fields).filter(([, value]) => value !== '')
                    .map(([name, value]) => name + '="' + value.replace(/&/g, '&amp;').replace(/"/g, '&quot;') + '"');
                source.value = '[' + kind + (options.length ? ' ' + options.join(' ') : '') + ']';
                if (section) source.value += section + '[/' + kind + ']';
            } else if (['gal', 'fotos', 'files'].includes(kind)) {
                const opening = source.value.match(/^\[[^\]]+\]/)?.[0] || '[' + kind + ']';
                source.value = opening + fields.path + '[/' + kind + ']';
            } else if (kind === 'include') {
                source.value = '[include]' + fields.path + '[/include]';
            } else if (kind === 'phpModule') {
                source.value = '[php]' + fields.code + '[/php]';
            } else if (kind === 'iconName') {
                source.value = '[fa-icon=' + (fields.style ? fields.style + ':' : '') + fields.code + ']';
            } else if (kind === 'extensionTag') {
                source.value = '[' + fields.code + ']' + fields.value + '[/' + fields.code + ']';
            } else {
                source.value = '[' + fields.code + ']';
            }
            if (!['gal', 'fotos', 'files', 'route'].includes(kind)) {
                for (const part of preserved) {
                    source.value = modifyOpening(source.value, part[1], part[0].slice(part[0].indexOf('=') + 1));
                }
            }
            publishCode();
            return;
        }
        if (!event.target.matches('[data-inline-option]')) return;
        if (kind === 'callback') {
            source.value = source.value.replace(/^\[callback=([^\]]+)\]/i, (_, label) =>
                '[callback button="' + label.replaceAll('&', '&amp;').replaceAll('"', '&quot;') + '"]');
        }
        source.value = modifyOpening(source.value, event.target.dataset.inlineOption, event.target.value);
        publishCode();
    });
});

const editableLinks = document.querySelectorAll('[data-inline-component]');
const layoutMarkers = [...document.querySelectorAll('[data-layout-edit-start]')];
const layoutList = document.querySelector('[data-page-layout-list]');
if (layoutList) {
    const found = new Set();
    layoutMarkers.forEach((marker) => {
        const name = marker.dataset.layoutEditName;
        if (found.has(name)) return;
        found.add(name);
        const item = document.createElement('li');
        const link = document.createElement('a');
        link.href = marker.dataset.layoutEditUrl;
        link.dataset.layoutEditControl = '';
        link.dataset.layoutEditModal = marker.dataset.layoutEditModal;
        link.setAttribute('aria-haspopup', 'dialog');
        link.textContent = '[' + name + ']';
        item.append(link);
        layoutList.append(item);
    });
    layoutList.previousElementSibling.hidden = found.size > 0;
}

const layoutOutline = document.querySelector('[data-layout-edit-outline]');
if (layoutOutline && openLayoutEditor) {
    const edit = layoutOutline.querySelector('[data-layout-edit-control]');
    const hint = layoutOutline.querySelector('[data-layout-edit-hint]');
    const templateLabel = edit.textContent;
    const templateHint = hint?.textContent || '';
    const markers = [...document.querySelectorAll('[data-layout-edit-start], [data-page-edit-start]')];
    const pageEnds = [...document.querySelectorAll('[data-page-edit-end]')];
    const spans = markers.reverse().flatMap((start) => {
        const { pageEditStart, layoutEditStart, pageEditUrl, layoutEditUrl, layoutEditModal } = start.dataset;
        const end = pageEditStart ? pageEnds.find((marker) =>
            marker.dataset.pageEditEnd === pageEditStart && (start.compareDocumentPosition(marker) & Node.DOCUMENT_POSITION_FOLLOWING))
            : document.getElementById(layoutEditStart);
        if (!end) return [];
        const range = document.createRange();
        range.setStartAfter(start);
        range.setEndBefore(end);
        return [{ range, href: pageEditUrl || layoutEditUrl, modal: layoutEditModal }];
    });
    const pageLink = document.querySelector('.editor-bar [data-page-editor-link]');
    const heading = document.querySelector('#content > h1');
    const contentStart = document.querySelector('#content [data-page-edit-start]');
    if (pageLink && heading && (!contentStart || (heading.compareDocumentPosition(contentStart) & Node.DOCUMENT_POSITION_FOLLOWING))) {
        const range = document.createRange();
        range.selectNode(heading);
        const url = new URL(pageLink.href);
        url.hash = 'page-heading';
        spans.unshift({ range, href: url.href });
    }
    const priorityControls = '.banner-edit-tools, [data-inline-component], dialog[open], .editor-bar';
    const containsPoint = (box, x, y) => box.width > 0 && box.height > 0
        && x >= box.left && x < box.right && y >= box.top && y < box.bottom;
    // The inner content range takes priority over its enclosing layout.
    const layoutAt = (x, y) => spans.find(({ range }) => containsPoint(range.getBoundingClientRect(), x, y)
        && Array.from(range.getClientRects()).some((box) => containsPoint(box, x, y)));
    let request = 0;
    let active = null;
    const hide = () => { cancelAnimationFrame(request); active = null; layoutOutline.hidden = true; };
    document.addEventListener('dblclick', (event) => {
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey
            || event.target.closest(priorityControls + ', a, button, input, select, textarea, label, summary, [contenteditable]')) return;
        const candidate = layoutAt(event.clientX, event.clientY);
        if (!candidate) return;
        event.preventDefault();
        hide();
        if (candidate.modal) openLayoutEditor(candidate.modal);
        else if (openPageEditor) openPageEditor(candidate.href);
        else location.assign(candidate.href);
    });
    document.addEventListener('pointermove', (event) => {
        if (event.pointerType === 'touch') return;
        const overEdit = edit.contains(event.target);
        const underEdit = overEdit && document.elementsFromPoint(event.clientX, event.clientY)
            .find((element) => !layoutOutline.contains(element));
        if ((underEdit || event.target).closest(priorityControls)) { hide(); return; }
        cancelAnimationFrame(request);
        request = requestAnimationFrame(() => {
            const candidate = layoutAt(event.clientX, event.clientY);
            if (overEdit && active && (!candidate || spans.indexOf(active) <= spans.indexOf(candidate))) return;
            if (!candidate) { hide(); return; }
            active = candidate;
            const { range, href, modal } = candidate;
            const box = range.getBoundingClientRect();
            const x = Math.max(2, box.left);
            const y = Math.max(2, box.top);
            Object.assign(layoutOutline.style, {
                left: x + 'px', top: y + 'px', width: Math.max(0, Math.min(innerWidth - 2, box.right) - x) + 'px',
                height: Math.max(0, Math.min(innerHeight - 2, box.bottom) - y) + 'px',
            });
            edit.href = href;
            if (modal) edit.dataset.layoutEditModal = modal;
            else delete edit.dataset.layoutEditModal;
            edit.toggleAttribute('data-page-editor-link', !modal);
            edit.textContent = modal ? templateLabel : (layoutOutline.dataset.pageLabel || templateLabel);
            if (hint) hint.textContent = modal ? templateHint : (layoutOutline.dataset.pageHint || '');
            layoutOutline.hidden = false;
        });
    });
    window.addEventListener('scroll', hide, { passive: true });
    window.addEventListener('resize', hide);
    document.documentElement.addEventListener('mouseleave', hide);
}
if (editableLinks.length) {
    const outline = document.createElement('div');
    outline.hidden = true;
    outline.className = 'inline-component-highlight';
    outline.setAttribute('aria-hidden', 'true');
    document.body.appendChild(outline);
    let activeLink = null;
    const bounds = (link) => {
        const end = document.getElementById(link.hash.slice(1) + '-preview-end');
        if (!end) return null;
        const range = document.createRange();
        range.setStartAfter(link);
        range.setEndBefore(end);
        const rect = range.getBoundingClientRect();
        if (rect.width && rect.height) return rect;
        if (link.dataset.inlineKind === 'map') {
            return document.querySelector('#content .site-map')?.getBoundingClientRect() || null;
        }
        return null;
    };
    const draw = () => {
        const rect = activeLink && bounds(activeLink);
        outline.hidden = !rect;
        if (!rect) return;
        outline.style.left = (rect.left - 3) + 'px';
        outline.style.top = (rect.top - 3) + 'px';
        outline.style.width = (rect.width + 6) + 'px';
        outline.style.height = (rect.height + 6) + 'px';
    };
    editableLinks.forEach((link) => {
        const show = () => { activeLink = link; draw(); };
        const hide = () => {
            if (activeLink === link) { activeLink = null; draw(); }
        };
        link.addEventListener('mouseenter', show);
        link.addEventListener('focus', show);
        link.addEventListener('mouseleave', hide);
        link.addEventListener('blur', hide);
        link.addEventListener('click', hide);
    });
    window.addEventListener('resize', draw, {passive: true});
    window.addEventListener('scroll', draw, {passive: true, capture: true});
}

document.addEventListener('click', (event) => {
    const top = event.target.closest('[data-scroll-top]');
    if (top) {
        event.preventDefault();
        window.scrollTo({top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
        return;
    }
    const mapConsent = event.target.closest('[data-map-consent]');
    if (mapConsent) {
        const current = mapConsent.dataset.mapConsent.split('-');
        const permissions = ['analytics', 'maps', 'chat'].filter((feature) => feature === 'maps' || current.includes(feature)).join('-');
        const selected = permissions === 'analytics-maps' ? 'all' : permissions;
        const path = /^\/[^;\s]*$/.test(mapConsent.dataset.cookiePath || '') ? mapConsent.dataset.cookiePath : '/';
        document.cookie = 'FILE_SITE_CONSENT=' + selected + '; Path=' + path + '; Max-Age=15552000; SameSite=Lax'
            + (location.protocol === 'https:' ? '; Secure' : '');
        window.location.reload();
        return;
    }
    const button = event.target.closest('[data-cookie-choice]');
    const menu = button && button.closest('[data-cookie-preferences]');
    if (!menu) return;
    const choice = button.dataset.cookieChoice;
    if (!['all', 'selection', 'essential'].includes(choice)) return;
    const features = ['analytics', 'maps', 'chat'].filter(feature => {
        const option = menu.querySelector('[data-cookie-option="' + feature + '"]');
        return option && (choice === 'all' || (choice === 'selection' && option.checked));
    });
    const selection = features.join('-');
    const selected = selection === 'analytics-maps' ? 'all' : selection || 'essential';
    const path = /^\/[^;\s]*$/.test(menu.dataset.cookiePath || '') ? menu.dataset.cookiePath : '/';
    document.cookie = 'FILE_SITE_CONSENT=' + selected + '; Path=' + path + '; Max-Age=15552000; SameSite=Lax'
        + (location.protocol === 'https:' ? '; Secure' : '');
    window.location.reload();
});

(() => {
    document.addEventListener('click', function (event) {
        const link = event.target.closest('[data-kt-photo]');
        if (link && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey && typeof HTMLDialogElement !== 'undefined') {
            const dialog = document.createElement('dialog');
            dialog.className = 'kt-lightbox';
            if (typeof dialog.showModal !== 'function') return;
            event.preventDefault();
            const bar = document.createElement('div');
            bar.className = 'kt-lightbox-bar';
            const caption = document.createElement('strong');
            caption.textContent = link.dataset.caption;
            dialog.setAttribute('aria-label', caption.textContent);
            const close = document.createElement('button');
            close.type = 'button';
            const collection = link.closest('[data-kt-collection]');
            close.className = 'dialog-close';
            close.setAttribute('aria-label', collection.dataset.photoClose);
            close.addEventListener('click', function () { dialog.close(); });
            const image = document.createElement('img');
            const photos = JSON.parse(link.dataset.photos || '[]');
            let position = 0;
            image.src = photos[0] || link.href;
            image.alt = caption.textContent;
            bar.append(caption, close);
            dialog.append(bar, image);
            if (photos.length > 1) {
                const controls = document.createElement('div');
                controls.className = 'kt-lightbox-controls kt-lightbox-bar';
                const status = document.createElement('span');
                status.setAttribute('role', 'status');
                const show = function (offset) {
                    position = (position + offset + photos.length) % photos.length;
                    image.src = photos[position];
                    status.textContent = `${position + 1} / ${photos.length}`;
                };
                const control = function (label, offset) {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.textContent = label;
                    button.addEventListener('click', function () { show(offset); });
                    return button;
                };
                controls.append(control(collection.dataset.photoPrev, -1), status, control(collection.dataset.photoNext, 1));
                dialog.append(controls);
                dialog.addEventListener('keydown', function (key) {
                    if (key.key === 'ArrowLeft' || key.key === 'ArrowRight') { key.preventDefault(); show(key.key === 'ArrowLeft' ? -1 : 1); }
                });
                show(0);
            }
            dialog.addEventListener('close', function () { dialog.remove(); link.focus(); }, { once: true });
            dialog.addEventListener('click', function (click) { if (click.target === dialog) dialog.close(); });
            document.body.append(dialog);
            dialog.showModal();
        }

        const filter = event.target.closest('[data-kt-filter]');
        if (!filter) return;
        const collection = filter.closest('[data-kt-collection]');
        if (!collection) return;
        collection.querySelectorAll('[data-kt-filter]').forEach(function (button) {
            button.setAttribute('aria-pressed', String(button === filter));
        });
        collection.querySelectorAll('[data-kt-category]').forEach(function (card) {
            card.hidden = filter.dataset.ktFilter !== '' && card.dataset.ktCategory !== filter.dataset.ktFilter;
        });
    });

    function konturEnableFilters() {
        document.querySelectorAll('[data-kt-filters]').forEach(function (filters) { filters.hidden = false; });
    }
    konturEnableFilters();
    new MutationObserver(konturEnableFilters).observe(document.body, { childList: true, subtree: true });

})();
document.querySelectorAll('.editor-bar').forEach((bar) => {
    const tooltip = document.createElement('span');
    tooltip.className = 'editor-bar-tooltip';
    tooltip.setAttribute('aria-hidden', 'true');
    tooltip.hidden = true;
    bar.append(tooltip);
    let hovered = null;
    let focused = null;
    const update = () => {
        const control = hovered || focused;
        tooltip.hidden = !control;
        if (!control) return;
        tooltip.textContent = control.dataset.navTooltip;
        const bounds = bar.getBoundingClientRect();
        const item = control.getBoundingClientRect();
        const width = tooltip.offsetWidth;
        const center = item.left - bounds.left + (item.width - width) / 2;
        tooltip.style.left = Math.max(6, Math.min(center, bounds.width - width - 6)) + 'px';
        tooltip.style.top = (item.bottom - bounds.top + 5) + 'px';
    };
    const findControl = (node) => node?.closest?.('.toolbar-item[data-nav-tooltip]') || null;
    bar.addEventListener('pointerover', (event) => {
        if (event.pointerType === 'touch') return;
        hovered = findControl(event.target);
        update();
    });
    bar.addEventListener('pointerleave', () => { hovered = null; update(); });
    bar.addEventListener('focusin', (event) => {
        focused = event.target.matches(':focus-visible') ? findControl(event.target) : null;
        if (focused) hovered = null;
        update();
    });
    bar.addEventListener('focusout', () => { focused = null; update(); });
    window.addEventListener('resize', update, {passive: true});
});


document.addEventListener('click', async (event) => {
    const link = event.target.closest('[data-reviews-more]');
    if (!link || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    if (link.getAttribute('aria-busy') === 'true') return;
    const section = link.closest('.site-reviews');
    const feedback = section.querySelector('[data-reviews-feedback]');
    link.setAttribute('aria-busy', 'true');
    feedback.hidden = true;
    try {
        const response = await fetch(link.href, {cache: 'no-store'});
        if (!response.ok) throw new Error('Review page unavailable');
        const markup = new DOMParser().parseFromString(await response.text(), 'text/html');
        const nextSection = markup.getElementById(section.id);
        const incoming = nextSection?.querySelector('[data-review-list]');
        if (!incoming) throw new Error('Review list unavailable');
        const list = section.querySelector('[data-review-list]');
        const first = incoming.firstElementChild;
        list.append(...incoming.children);
        if (first) {
            first.tabIndex = -1;
            first.focus();
        }
        const nextLink = nextSection.querySelector('[data-reviews-more]');
        if (nextLink) link.href = nextLink.getAttribute('href');
        else if (!first && document.activeElement === link) {
            section.tabIndex = -1;
            section.focus();
        }
        if (!nextLink) link.remove();
    } catch (error) {
        feedback.textContent = link.dataset.loadError;
        feedback.hidden = false;
    } finally {
        link.removeAttribute('aria-busy');
    }
});
