<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$footerText = $settings['footer'];
if ($footerText === '') {
    $footerText = '© [year] ' . $settings['name'];
} elseif (strpos($footerText, '[year]') === false) {
    $footerText = preg_replace('/\A(©\s*(?:[0-9]{4}\s*[-–—]\s*)?)[0-9]{4}(?=\s|$)/u', '$1[year]', $footerText) ?? $footerText;
}
?>
<footer class="site-footer">
    <div class="container"><?= site_escape(str_replace('[year]', date('Y'), $footerText)) ?></div>
</footer>
