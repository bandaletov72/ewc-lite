<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($carousel): ?>
<div class="gallery" data-gallery data-gallery-effect="<?= site_escape($options['effect']) ?>" data-gallery-fit="<?= site_escape($options['fit']) ?>" role="group" aria-label="Фотогалерея">
    <div class="gallery-track" data-gallery-track<?= count($images) > 1 ? ' tabindex="0"' : '' ?>>
        <?php foreach ($images as $index => $image): ?>
            <img class="gallery-slide<?= $index === 0 ? ' is-active' : '' ?>" src="<?= site_escape($image['url']) ?>" alt="<?= site_escape($image['alt']) ?>" <?= $index > 0 && $options['effect'] !== 'fade' ? 'loading="lazy"' : '' ?> decoding="async">
        <?php endforeach; ?>
    </div>
    <?php if (count($images) > 1 && ($options['arrows'] === 'on' || $options['numbers'] === 'on')): ?>
        <div class="gallery-controls" hidden>
            <?php if ($options['arrows'] === 'on'): ?>
                <button class="gallery-arrow gallery-prev" type="button" data-gallery-prev aria-label="Предыдущее фото"></button>
                <button class="gallery-arrow gallery-next" type="button" data-gallery-next aria-label="Следующее фото"></button>
            <?php endif; ?>
            <?php if ($options['numbers'] === 'on'): ?>
                <span class="gallery-status" role="status" data-gallery-status></span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php else: ?>
    <ul class="photo-grid" aria-label="Фотогалерея">
        <?php foreach ($images as $image): ?>
            <li><a href="<?= site_escape($image['url']) ?>"><img src="<?= site_escape($image['url']) ?>" alt="<?= site_escape($image['alt']) ?>" loading="lazy" decoding="async"></a></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
