<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<ul class="file-list" aria-label="Файлы">
    <?php foreach ($files as $file): ?>
        <li><a href="<?= site_escape($file['url']) ?>">
            <span class="file-icon file-icon-<?= $file['extension'] ?>" aria-hidden="true"><?= strtoupper($file['extension']) ?></span>
            <span><?= site_escape($file['name']) ?></span>
        </a></li>
    <?php endforeach; ?>
</ul>
