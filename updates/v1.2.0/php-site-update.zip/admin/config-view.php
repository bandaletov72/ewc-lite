<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($error !== ''): ?>
    <p class="notice error" role="alert"><?= site_escape($error) ?></p>
<?php elseif ($notice !== ''): ?>
    <p class="notice" role="status"><?= site_escape($notice) ?></p>
<?php endif; ?>

<?php if (in_array($section, ['settings', 'contacts', 'theme', 'components', 'updates'], true)): ?>
    <nav class="site-menu scope-menu" aria-label="Разделы настроек">
        <?php foreach (['settings' => ['Основные', $settingsUrl], 'contacts' => ['Контакты и соцсети', $contactsUrl], 'theme' => ['Тема и цвета', $themeUrl], 'components' => ['Компоненты', $componentsUrl], 'updates' => ['Обновления', $updatesUrl]] as $key => $item): ?>
            <a href="<?= site_escape($item[1]) ?>"<?= $section === $key ? ' aria-current="page"' : '' ?>><?= site_escape($item[0]) ?></a>
        <?php endforeach; ?>
    </nav>
<?php endif; ?>

<?php if ($section === 'settings'): ?>
    <h1>Настройки сайта</h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($settingsUrl) ?>">
        <input type="hidden" name="action" value="save-settings">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($settingsRevision) ?>">
        <?php foreach (['name' => 'Название сайта', 'description' => 'Метаописание по умолчанию', 'footer' => 'Текст подвала'] as $name => $label): ?>
            <div class="field">
                <label for="setting-<?= $name ?>"><?= $label ?></label>
                <input id="setting-<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($settingsDraft[$name]) ?>" <?= $name === 'name' ? 'required' : '' ?> <?= $name === 'footer' ? 'aria-describedby="footer-hint"' : '' ?> maxlength="375">
                <?php if ($name === 'footer'): ?>
                    <small class="hint" id="footer-hint">Используйте [year] для текущего года, например «© [year] Название сайта».</small>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <div class="field">
            <label for="variables">Переменные для шаблонов</label>
            <textarea class="short-editor" id="variables" name="variables" rows="4" spellcheck="false" aria-describedby="variables-hint" placeholder="company = Название компании"><?= "\n" . site_escape($variablesDraft) ?></textarea>
            <small class="hint" id="variables-hint">Одна переменная на строку в формате «ключ = значение».</small>
        </div>
        <div><button class="button-primary" type="submit">Сохранить</button></div>
    </form>
<?php elseif (in_array($section, ['contacts', 'theme', 'components'], true)): ?>
    <?php require __DIR__ . '/appearance-view.php'; ?>
<?php elseif ($section === 'updates'): ?>
    <h1>Обновления движка</h1>
    <section class="panel form-stack">
        <p>Установлена версия <?= site_escape(site_update_version()) ?>.</p>
        <?php $repository = site_update_github_repo(); ?>
        <?php if ($repository !== ''): ?>
            <p>Источник обновлений <a href="<?= site_escape('https://github.com/' . $repository) ?>"><?= site_escape($repository) ?></a>.</p>
        <?php else: ?>
            <p>Задайте репозиторий GitHub в <code>SITE_GITHUB_REPO</code> или <code>maintenance/github.php</code>.</p>
        <?php endif; ?>
        <form method="post" action="<?= site_escape($updatesUrl) ?>">
            <input type="hidden" name="action" value="update-engine">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <button class="button-primary" type="submit" <?= $repository === '' ? 'disabled' : '' ?>>Обновить движок</button>
        </form>
    </section>
<?php elseif ($section === 'domains'): ?>
    <h1>Домены и поддомены</h1>
    <?php if ($domainsError !== ''): ?>
        <p class="notice error" role="alert"><?= site_escape($domainsError) ?></p>
    <?php else: ?>
        <div class="editor-grid">
            <section class="panel">
                <h2>Добавленные домены</h2>
                <?php if (!$domains): ?>
                    <p>Список пока пуст.</p>
                <?php else: ?>
                    <ul class="page-list">
                        <?php foreach ($domains as $domain): ?>
                            <li><a href="<?= site_escape($snippetsUrl . '&domain=' . rawurlencode($domain)) ?>"><?= site_escape($domain) ?><small>Подшаблоны домена</small></a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <form class="panel form-stack" method="post" action="<?= site_escape($domainsUrl) ?>">
                <input type="hidden" name="action" value="add-domain">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <div class="field">
                    <label for="domain">Имя нового поддомена</label>
                    <input id="domain" name="domain" value="<?= site_escape($domainDraft) ?>" placeholder="msk.example.ru" maxlength="253" required>
                </div>
                <div><button class="button-primary" type="submit">Добавить поддомен</button></div>
            </form>
        </div>
    <?php endif; ?>
<?php elseif ($section === 'snippets'): ?>
    <h1>Подшаблоны</h1>
    <nav class="site-menu scope-menu" aria-label="Область подшаблонов">
        <?php if ($currentHost !== ''): ?>
            <a href="<?= site_escape($snippetsUrl) ?>"<?= !$sharedScope && $domainSelection === '' ? ' aria-current="page"' : '' ?>>Текущий домен</a>
        <?php endif; ?>
        <a href="<?= site_escape($snippetsUrl . '&scope=shared') ?>"<?= $sharedScope ? ' aria-current="page"' : '' ?>>Общие значения</a>
        <?php foreach ($domains as $domain): ?>
            <a href="<?= site_escape($snippetsUrl . '&domain=' . rawurlencode($domain)) ?>"<?= !$sharedScope && $domainSelection !== '' && $scopeHost === $domain ? ' aria-current="page"' : '' ?>><?= site_escape($domain) ?></a>
        <?php endforeach; ?>
    </nav>
    <?php if ($snippetError !== ''): ?>
        <p class="notice error" role="alert"><?= site_escape($snippetError) ?></p>
    <?php endif; ?>
    <?php if ($scopeValid && ($snippetError === '' || $snippetEntries)): ?>
        <p class="hint"><?= $sharedScope ? 'Общие значения применяются на доменах без своего значения.' : 'Значения домена ' . site_escape($scopeHost) . ' имеют приоритет перед общими.' ?></p>
        <div class="editor-grid">
            <nav class="panel" aria-label="Список подшаблонов">
                <ul class="page-list">
                    <li><a href="<?= site_escape($scopeUrl) ?>"<?= $snippet === null ? ' aria-current="page"' : '' ?>>Добавить подшаблон</a></li>
                    <?php foreach ($snippetEntries as $key => $item): ?>
                        <li><a href="<?= site_escape($scopeUrl . '&snippet=' . rawurlencode($key)) ?>"<?= $snippet !== null && $snippet['name'] === $key ? ' aria-current="page"' : '' ?>>
                            <code>[<?= site_escape($key) ?>]</code>
                            <small><?= site_escape($item['description']) ?><?= !isset($own[$key]) ? ' · общее значение' : '' ?></small>
                        </a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
            <?php
            $editor = $snippet ?? ['name' => '', 'values' => ['description' => '', 'value' => ''], 'revision' => '', 'locked' => false];
            $inherited = $editor['locked'] && $editor['revision'] === '';
            ?>
            <form class="panel form-stack" method="post" action="<?= site_escape($scopeUrl . ($editor['locked'] ? '&snippet=' . rawurlencode($editor['name']) : '')) ?>">
                <h2><?= $inherited ? 'Переопределить общее значение' : ($editor['locked'] ? 'Редактировать подшаблон' : 'Новый подшаблон') ?></h2>
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <input type="hidden" name="revision" value="<?= site_escape($editor['revision']) ?>">
                <input type="hidden" name="locked" value="<?= $editor['locked'] ? '1' : '0' ?>">
                <div class="field">
                    <label for="snippet">Подшаблон</label>
                    <input id="snippet" name="snippet" value="<?= site_escape($editor['name'] === '' ? '' : '[' . $editor['name'] . ']') ?>" placeholder="[tel]" maxlength="66" <?= $editor['locked'] ? 'readonly' : 'required' ?>>
                </div>
                <div class="field">
                    <label for="snippet-description">Описание</label>
                    <input id="snippet-description" name="description" value="<?= site_escape($editor['values']['description']) ?>" placeholder="Телефон для связи" maxlength="375" required>
                </div>
                <div class="field">
                    <label for="snippet-value">Значение</label>
                    <textarea id="snippet-value" class="short-editor" name="value" rows="5" spellcheck="false" aria-describedby="snippet-hint"><?= "\n" . site_escape($editor['values']['value']) ?></textarea>
                    <small class="hint" id="snippet-hint">Здесь можно указать текст или HTML. Имя в квадратных скобках вставляется в страницу или её заголовок.</small>
                </div>
                <div class="header-actions">
                    <button class="button-primary" type="submit" name="action" value="save-snippet">Сохранить</button>
                    <?php if ($editor['revision'] !== ''): ?>
                        <button type="submit" name="action" value="delete-snippet" formnovalidate><?= !$sharedScope && isset($shared[$editor['name']]) ? 'Вернуть общее значение' : 'Удалить значение' ?></button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    <?php endif; ?>
<?php elseif ($section === 'forms'): ?>
    <?php require __DIR__ . '/forms-view.php'; ?>
<?php elseif ($section === 'spam'): ?>
    <h1>Антиспам</h1>
    <?php if ($spamEditorError !== ''): ?>
        <p class="notice error" role="alert"><?= site_escape($spamEditorError) ?></p>
    <?php elseif ($spamDraft !== null): ?>
        <form class="panel form-stack" method="post" action="<?= site_escape($spamUrl) ?>">
            <input type="hidden" name="action" value="save-spam">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($spamRevision) ?>">
            <p class="hint">Ссылки блокируются во всех формах. Добавляйте слово, выражение или IP-адрес на отдельной строке.</p>
            <div class="fields">
                <div class="field">
                    <label for="spam-words">Запрещённые слова и выражения</label>
                    <textarea class="short-editor" id="spam-words" name="words" rows="7" spellcheck="false" placeholder="casino"><?= "\n" . site_escape($spamDraft['words']) ?></textarea>
                </div>
                <div class="field">
                    <label for="spam-ips">Заблокированные IP-адреса</label>
                    <textarea class="short-editor" id="spam-ips" name="ips" rows="7" spellcheck="false" placeholder="192.0.2.10"><?= "\n" . site_escape($spamDraft['ips']) ?></textarea>
                </div>
            </div>
            <div><button class="button-primary" type="submit">Сохранить правила</button></div>
        </form>
    <?php endif; ?>
<?php elseif ($section === 'messages'): ?>
    <?php require __DIR__ . '/messages-view.php'; ?>
<?php elseif ($section === 'callbacks'): ?>
    <?php require __DIR__ . '/callbacks-view.php'; ?>
<?php elseif ($section === 'iblocks'): ?>
    <?php require __DIR__ . '/iblocks-view.php'; ?>
<?php endif; ?>
