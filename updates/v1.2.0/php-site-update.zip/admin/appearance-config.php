<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_contacts_draft(array $posted): array
{
    $draft = ['heading' => trim(admin_input($posted, 'heading')), 'phones' => [], 'channels' => []];
    foreach (is_array($posted['phones'] ?? null) ? $posted['phones'] : [] as $phone) {
        if (is_array($phone)) {
            $draft['phones'][] = ['number' => trim(admin_input($phone, 'number')), 'text' => trim(admin_input($phone, 'text'))];
        }
    }
    foreach (site_channels() as $id => $name) {
        $channel = $posted['channels'][$id] ?? [];
        if (is_array($channel)) {
            $draft['channels'][$id] = ['url' => trim(admin_input($channel, 'url')), 'text' => trim(admin_input($channel, 'text'))];
        }
    }
    return $draft;
}

function admin_save_contacts(array $draft, string $revision)
{
    if ($draft['heading'] !== '' && !admin_valid_form_label($draft['heading'])) {
        throw new RuntimeException('Проверьте заголовок блока контактов.');
    }
    $phones = [];
    foreach ($draft['phones'] as $phone) {
        if ($phone['number'] === '' && $phone['text'] === '') {
            continue;
        }
        $number = site_normalize_form_phone($phone['number']);
        if ($number === '' || ($phone['text'] !== '' && !admin_valid_form_label($phone['text']))) {
            throw new RuntimeException('Укажите полный номер телефона и проверьте его подпись.');
        }
        $phones[] = ['number' => $number, 'text' => $phone['text']];
    }
    $channels = [];
    foreach (site_channels() as $id => $name) {
        $channel = $draft['channels'][$id] ?? ['url' => '', 'text' => ''];
        if ($channel['url'] === '') {
            if ($channel['text'] !== '' && !admin_valid_form_label($channel['text'])) {
                throw new RuntimeException('Проверьте подпись ссылки для ' . $name . '.');
            }
            if ($channel['text'] !== '') {
                $channels[$id] = $channel;
            }
            continue;
        }
        if (strlen($channel['url']) > 2048 || !preg_match('~\Ahttps?://~i', $channel['url'])
            || !filter_var($channel['url'], FILTER_VALIDATE_URL)
            || ($channel['text'] !== '' && !admin_valid_form_label($channel['text']))) {
            throw new RuntimeException('Проверьте ссылку и подпись для ' . $name . '.');
        }
        $channels[$id] = $channel;
    }

    $lock = admin_lock();
    try {
        site_read_record(SITE_CONTACTS_FILE);
        if (!hash_equals(admin_settings_revision(site_contact_settings()), $revision)) {
            throw new RuntimeException('Контакты уже изменились. Скопируйте правки и откройте раздел заново.');
        }
        admin_write_record(SITE_CONTACTS_FILE, ['heading' => $draft['heading'], 'phones' => $phones, 'channels' => $channels]);
    } finally {
        fclose($lock);
    }
}

function admin_theme_draft(array $posted): array
{
    $draft = ['mode' => admin_input($posted, 'mode')];
    foreach (['light', 'dark'] as $scheme) {
        $palette = is_array($posted[$scheme] ?? null) ? $posted[$scheme] : [];
        foreach (site_theme_fields() as $name => $label) {
            $draft[$scheme][$name] = strtolower(trim(admin_input($palette, $name)));
        }
    }
    return $draft;
}

function admin_save_theme(array $draft, string $revision)
{
    if (!in_array($draft['mode'], ['auto', 'light', 'dark'], true)) {
        throw new RuntimeException('Выберите режим темы.');
    }
    foreach (['light', 'dark'] as $scheme) {
        foreach ($draft[$scheme] as $color) {
            if (!site_theme_color($color)) {
                throw new RuntimeException('Используйте цвет в формате #RRGGBB.');
            }
        }
    }

    $lock = admin_lock();
    try {
        site_read_record(SITE_THEME_FILE);
        if (!hash_equals(admin_settings_revision(site_theme_settings()), $revision)) {
            throw new RuntimeException('Тема уже изменилась. Скопируйте правки и откройте раздел заново.');
        }
        admin_write_record(SITE_THEME_FILE, $draft);
    } finally {
        fclose($lock);
    }
}

function admin_components_draft(array $posted): array
{
    $draft = [];
    foreach (site_component_schema() as $id => $component) {
        $values = is_array($posted[$id] ?? null) ? $posted[$id] : [];
        foreach ($component['settings'] as $key => $field) {
            $draft[$id][$key] = admin_input($values, $key);
        }
    }
    return $draft;
}

function admin_save_components(array $draft, string $revision)
{
    foreach (site_component_schema() as $id => $component) {
        foreach ($component['settings'] as $key => $field) {
            if (!isset($field['options'][$draft[$id][$key]])) {
                throw new RuntimeException('Проверьте настройки компонента «' . $component['label'] . '».');
            }
        }
    }
    $lock = admin_lock();
    try {
        $stored = site_read_record(SITE_COMPONENTS_FILE);
        if (!hash_equals(admin_settings_revision(site_component_settings()), $revision)) {
            throw new RuntimeException('Настройки компонентов уже изменились. Откройте раздел заново.');
        }
        admin_write_record(SITE_COMPONENTS_FILE, array_replace_recursive($stored, $draft));
    } finally {
        fclose($lock);
    }
}
