<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_page_path(string $input): string
{
    if ($input === '') {
        return '';
    }
    if ($input[0] === '/') {
        $input = substr($input, 1);
    }
    if ($input === '' || substr($input, -1) === '/') {
        return $input . 'index.php';
    }
    return strpos(basename($input), '.') === false ? $input . '/index.php' : $input;
}

function admin_page_bytes(string $path, array $fields, string $html): string
{
    if (!site_valid_path($path)) {
        throw new RuntimeException('Укажите адрес страницы на сайте, например /services/.');
    }

    if (!site_valid_metadata($fields)) {
        throw new RuntimeException('Заполните заголовок вкладки и укажите порядок от 0 до 99999.');
    }

    $headers = [];
    foreach ($fields as $name => $value) {
        $headers[] = $name . ': ' . $value;
    }

    $bytes = site_page_header($path) . "\n" . implode("\n", $headers) . "\n\n" . $html;
    if (strlen($bytes) > SITE_PAGE_LIMIT || preg_match('//u', $bytes) !== 1 || strpos($bytes, "\0") !== false) {
        throw new RuntimeException('Используйте текст UTF-8. Размер файла должен быть не больше 512 КиБ.');
    }

    return $bytes;
}

function admin_make_page_directory(string $path)
{
    $directory = SITE_ROOT;
    $parts = explode('/', $path);
    array_pop($parts);
    foreach ($parts as $part) {
        $directory .= DIRECTORY_SEPARATOR . $part;
        if (is_link($directory) || (!is_dir($directory) && !@mkdir($directory, 0755))) {
            throw new RuntimeException('Не удалось создать каталог страницы. Проверьте путь и права записи.');
        }
        if (realpath($directory) !== $directory) {
            throw new RuntimeException('Выберите каталог внутри сайта.');
        }
    }
}

function admin_current_page(string $path, string $revision): array
{
    $current = site_read_page($path);
    if ($current === null || !hash_equals($current['revision'], $revision)) {
        throw new RuntimeException('Файл изменился с момента открытия. Скопируйте правки и откройте страницу заново.');
    }
    return $current;
}

function admin_save_page(string $path, array $fields, string $html, string $revision, bool $creating)
{
    if (!site_valid_path($path)) {
        throw new RuntimeException('Укажите адрес страницы на сайте, например /services/.');
    }
    $lock = admin_lock();

    try {
        $file = SITE_ROOT . '/' . $path;
        if ($creating) {
            if (file_exists($file) || is_link($file)) {
                throw new RuntimeException('Этот путь уже занят. Выберите другой.');
            }
            $fields['Hidden'] = '0';
        } else {
            $current = admin_current_page($path, $revision);
            $fields['Hidden'] = $current['fields']['Hidden'];
        }
        $bytes = admin_page_bytes($path, $fields, $html);

        admin_make_page_directory($path);
        if (!admin_replace_file($file, $bytes)) {
            throw new RuntimeException('Не удалось сохранить файл. Проверьте права записи в каталоге страницы.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_update_page_status(string $path, string $revision, string $operation): string
{
    if (!in_array($operation, ['hide', 'show', 'delete'], true) || ($path === 'index.php' && $operation === 'delete')) {
        throw new RuntimeException('Это действие недоступно для выбранной страницы.');
    }
    $lock = admin_lock();
    try {
        $page = admin_current_page($path, $revision);
        $file = SITE_ROOT . '/' . $path;
        if ($operation === 'delete') {
            if (!@unlink($file)) {
                throw new RuntimeException('Не удалось удалить файл страницы.');
            }
            clearstatcache(true);
            if (function_exists('opcache_invalidate')) {
                @opcache_invalidate($file, true);
            }
            return 'Страница удалена.';
        }

        $page['fields']['Hidden'] = $operation === 'hide' ? '1' : '0';
        if (!admin_replace_file($file, admin_page_bytes($path, $page['fields'], $page['html']))) {
            throw new RuntimeException('Не удалось изменить видимость страницы.');
        }
        return $operation === 'hide' ? 'Страница скрыта.' : 'Страница опубликована.';
    } finally {
        fclose($lock);
    }
}
