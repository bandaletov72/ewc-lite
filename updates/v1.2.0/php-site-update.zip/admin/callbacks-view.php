<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$statuses = ['new' => 'Новая', 'sending' => 'Отправляется', 'accepted' => 'Принята телефонией', 'error' => 'Ошибка API'];
?>
<h1>Обратные звонки</h1>
<?php if ($callbackRecords): ?>
    <div class="panel iblock-table-wrap">
        <table class="iblock-table">
            <thead><tr><th scope="col">Когда (UTC)</th><th scope="col">Телефон</th><th scope="col">Страница</th><th scope="col">Статус</th><th scope="col">Действие</th></tr></thead>
            <tbody>
                <?php foreach ($callbackRecords as $id => $record): ?>
                    <tr>
                        <td><?= site_escape(gmdate('d.m.Y H:i', strtotime($record['time']))) ?></td>
                        <td><a href="<?= site_escape('tel:' . preg_replace('/[^0-9+]/', '', $record['phone'])) ?>"><?= site_escape($record['phone']) ?></a></td>
                        <td><?= site_escape($record['host'] . site_page_url('', $record['page'])) ?></td>
                        <td><?= site_escape($statuses[$record['status']] ?? $record['status']) ?>
                            <?php if (isset($record['error'])): ?><small class="hint"><?= site_escape($record['error']) ?></small><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($callbackConfig !== null && $callbackConfig['mode'] !== 'off' && in_array($record['status'], ['new', 'error'], true)): ?>
                                <form method="post" action="<?= site_escape($callbacksUrl) ?>">
                                    <input type="hidden" name="action" value="send-callback">
                                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                                    <input type="hidden" name="callback_id" value="<?= site_escape($id) ?>">
                                    <button type="submit">Отправить в АТС</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <p class="panel">Заявок пока нет.</p>
<?php endif; ?>
<?php if ($callbackDraft !== null): ?>
    <form class="panel form-stack callback-settings" method="post" action="<?= site_escape($callbacksUrl) ?>">
        <h2>Кнопка и подключение телефонии</h2>
        <p class="hint">Вставьте в HTML <code>[callback]</code> или укажите подпись для этой страницы, например <code>[callback=Вызвать мастера]</code>.</p>
        <input type="hidden" name="action" value="save-callback-settings">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($callbackRevision) ?>">
        <div class="fields">
            <label class="field">Текст кнопки на странице
                <input name="button" value="<?= site_escape($callbackDraft['button']) ?>" maxlength="375" required>
            </label>
            <label class="field">Текст кнопки отправки
                <input name="submit" value="<?= site_escape($callbackDraft['submit']) ?>" maxlength="375" required>
            </label>
            <label class="field">Передача в телефонию
                <select name="mode">
                    <?php foreach (['off' => 'Только сохранять заявки', 'manual' => 'По кнопке в админке', 'auto' => 'Сразу после отправки формы'] as $value => $label): ?>
                        <option value="<?= $value ?>"<?= $callbackDraft['mode'] === $value ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field">Провайдер
                <select name="provider">
                    <option value="zadarma"<?= $callbackDraft['provider'] === 'zadarma' ? ' selected' : '' ?>>Zadarma</option>
                    <option value="webhook"<?= $callbackDraft['provider'] === 'webhook' ? ' selected' : '' ?>>HTTP API (JSON)</option>
                </select>
            </label>
            <label class="field field-wide">Откуда звонить в Zadarma (номер, SIP или добавочный)
                <input name="from" value="<?= site_escape($callbackDraft['from']) ?>" maxlength="32" placeholder="101">
            </label>
        </div>
        <p class="hint">Ключи Zadarma задаются через <code>SITE_ZADARMA_KEY</code> и <code>SITE_ZADARMA_SECRET</code>. Для HTTP API используйте <code>SITE_CALLBACK_WEBHOOK_URL</code> и при необходимости <code>SITE_CALLBACK_WEBHOOK_TOKEN</code>.</p>
        <div><button class="button-primary" type="submit">Сохранить настройки</button></div>
    </form>
<?php endif; ?>
