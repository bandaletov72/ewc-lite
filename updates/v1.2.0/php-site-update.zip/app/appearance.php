<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_CONTACTS_FILE = SITE_ROOT . '/admin/.contacts.php';
const SITE_THEME_FILE = SITE_ROOT . '/admin/.theme.php';

function site_channels(): array
{
    return ['tg' => 'Telegram', 'vk' => 'ВКонтакте', 'whatsapp' => 'WhatsApp',
        'youtube' => 'YouTube', 'instagram' => 'Instagram', 'max' => 'MAX'];
}

function site_contact_settings(): array
{
    $defaults = ['heading' => 'Связаться с нами', 'phones' => [], 'channels' => []];
    try {
        return array_replace($defaults, site_read_record(SITE_CONTACTS_FILE));
    } catch (RuntimeException $exception) {
        return $defaults;
    }
}

function site_contact_tokens(): array
{
    $codes = array_keys(site_channels());
    return ['wa' => 'whatsapp', 'yt' => 'youtube', 'ig' => 'instagram', 'phones' => 'phones', 'contacts' => 'contacts']
        + array_combine($codes, $codes);
}

function site_contact_markup(string $code, string $base, array $settings): string
{
    $items = [];
    if ($code === 'phones' || $code === 'contacts') {
        foreach ($settings['phones'] as $phone) {
            $href = 'tel:' . preg_replace('/[^0-9+]/', '', $phone['number']);
            $items[] = ['href' => $href, 'icon' => 'phone', 'text' => $phone['text'] !== '' ? $phone['text'] : $phone['number'], 'label' => $phone['number']];
        }
    }
    if ($code !== 'phones') {
        foreach (site_channels() as $id => $name) {
            if (($code === 'contacts' || $id === $code) && !empty($settings['channels'][$id]['url'])) {
                $item = $settings['channels'][$id];
                $items[] = ['href' => $item['url'], 'icon' => $id, 'text' => $item['text'] !== '' ? $item['text'] : $name, 'label' => $name];
            }
        }
    }
    if (!$items) {
        return '';
    }

    ob_start();
    require site_template_file('components/contact-links.php');
    return (string) ob_get_clean();
}

function site_theme_fields(): array
{
    return ['paper' => 'Фон страницы', 'surface' => 'Поверхности и поля', 'ink' => 'Основной текст',
        'muted' => 'Второстепенный текст', 'accent' => 'Ссылки и кнопки',
        'accent-wash' => 'Выделение', 'line' => 'Разделители и обводки'];
}

function site_theme_color(string $value): bool
{
    return preg_match('/\A#[0-9a-fA-F]{6}\z/', $value) === 1;
}

function site_theme_settings(): array
{
    $defaults = [
        'mode' => 'auto',
        'light' => ['paper' => '#f7f8f6', 'surface' => '#ffffff', 'ink' => '#192823',
            'muted' => '#50645b', 'accent' => '#12634e', 'accent-wash' => '#e5f2eb', 'line' => '#d8e2dc'],
        'dark' => ['paper' => '#141c19', 'surface' => '#1c2822', 'ink' => '#ecf4ee',
            'muted' => '#b0c3b8', 'accent' => '#79d4b1', 'accent-wash' => '#2b4339', 'line' => '#466054'],
    ];
    try {
        $record = site_read_record(SITE_THEME_FILE);
    } catch (RuntimeException $exception) {
        return $defaults;
    }
    if (in_array($record['mode'] ?? '', ['auto', 'light', 'dark'], true)) {
        $defaults['mode'] = $record['mode'];
    }
    foreach (['light', 'dark'] as $scheme) {
        foreach ($defaults[$scheme] as $name => $color) {
            $candidate = $record[$scheme][$name] ?? null;
            if (is_string($candidate) && site_theme_color($candidate)) {
                $defaults[$scheme][$name] = strtolower($candidate);
            }
        }
    }
    return $defaults;
}

function site_theme_css(string $scheme, array $palette): string
{
    $channels = [];
    foreach ([1, 3, 5] as $offset) {
        $channel = hexdec(substr($palette['accent'], $offset, 2)) / 255;
        $channels[] = $channel <= 0.04045 ? $channel / 12.92 : pow(($channel + 0.055) / 1.055, 2.4);
    }
    $luminance = 0.2126 * $channels[0] + 0.7152 * $channels[1] + 0.0722 * $channels[2];
    $palette['on-accent'] = $luminance > 0.179 ? '#000000' : '#ffffff';
    $palette['error-surface'] = $scheme === 'dark' ? '#422626' : '#fbe8e6';
    $palette['error-ink'] = $scheme === 'dark' ? '#ffb4aa' : '#782a24';
    $css = ':root { color-scheme: ' . $scheme . ';';
    foreach ($palette as $name => $color) {
        $css .= ' --' . $name . ': ' . $color . ';';
    }
    return $css . " }\n";
}
