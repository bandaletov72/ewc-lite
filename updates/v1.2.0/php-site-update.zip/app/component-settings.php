<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_COMPONENTS_FILE = SITE_ROOT . '/admin/.components.php';

function site_component_schema(): array
{
    $toggle = ['on' => 'Показывать', 'off' => 'Скрывать'];
    $schema = ['gal' => [
        'label' => 'Карусель [gal]',
        'settings' => [
            'arrows' => ['label' => 'Стрелки', 'default' => 'on', 'options' => $toggle],
            'numbers' => ['label' => 'Номер слайда', 'default' => 'on', 'options' => $toggle],
            'effect' => ['label' => 'Переход', 'default' => 'slide',
                'options' => ['slide' => 'Плавная прокрутка', 'fade' => 'Плавное затухание', 'none' => 'Мгновенно']],
            'fit' => ['label' => 'Заполнение кадра', 'default' => 'contain',
                'options' => ['contain' => 'Вместить целиком (contain)', 'cover' => 'Заполнить кадр (cover)']],
        ],
    ]];
    foreach (site_extensions() as $name => $component) {
        if (!isset($component['settings']) || !is_array($component['settings'])) {
            continue;
        }
        $settings = [];
        foreach ($component['settings'] as $key => $field) {
            if (is_string($key) && site_valid_snippet($key) && is_array($field)
                && is_string($field['label'] ?? null) && is_string($field['default'] ?? null)
                && is_array($field['options'] ?? null) && isset($field['options'][$field['default']])) {
                $settings[$key] = $field;
            }
        }
        if ($settings) {
            $schema[$name] = ['label' => is_string($component['label'] ?? null) ? $component['label'] : $name,
                'settings' => $settings];
        }
    }
    return $schema;
}

function site_component_settings(): array
{
    try {
        $saved = site_read_record(SITE_COMPONENTS_FILE);
    } catch (RuntimeException $exception) {
        $saved = [];
    }
    $settings = [];
    foreach (site_component_schema() as $id => $component) {
        foreach ($component['settings'] as $name => $field) {
            $value = $saved[$id][$name] ?? $field['default'];
            $settings[$id][$name] = is_string($value) && isset($field['options'][$value]) ? $value : $field['default'];
        }
    }
    return $settings;
}

function site_gallery_options(string $overrides): array
{
    static $defaults;
    if ($defaults === null) {
        $defaults = site_component_settings()['gal'];
    }
    $settings = $defaults;
    $fields = site_component_schema()['gal']['settings'];
    foreach (preg_split('/\s+/', trim($overrides), -1, PREG_SPLIT_NO_EMPTY) as $option) {
        $parts = explode('=', $option, 2);
        if (isset($parts[1], $fields[$parts[0]]['options'][$parts[1]])) {
            $settings[$parts[0]] = $parts[1];
        }
    }
    return $settings;
}
