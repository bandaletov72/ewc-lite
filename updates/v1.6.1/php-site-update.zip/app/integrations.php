<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_INTEGRATIONS_FILE = SITE_ROOT . '/admin/.integrations.php';

function site_integration_catalog(): array
{
    return [
        'metrica' => ['Яндекс Метрика', 'Номер счётчика', '/\A[0-9]{1,16}\z/'],
        'analytics' => ['Google Analytics 4', 'Идентификатор потока G-…', '/\AG-[A-Z0-9]{4,32}\z/'],
        'pixel' => ['Meta Pixel', 'Идентификатор пикселя', '/\A[0-9]{1,24}\z/'],
        'cloudflare' => ['Cloudflare Web Analytics', 'Токен счётчика', '/\A[A-Za-z0-9_-]{8,96}\z/'],
    ];
}

function site_integration_settings(): array
{
    try {
        return site_read_record(SITE_INTEGRATIONS_FILE);
    } catch (RuntimeException $exception) {
        return [];
    }
}

function site_public_analytics(): array
{
    $stored = site_integration_settings();
    $enabled = [];
    foreach (site_integration_catalog() as $key => $item) {
        $service = $stored[$key] ?? [];
        if (($service['enabled'] ?? false) === true && is_string($service['id'] ?? null)
            && preg_match($item[2], $service['id'])) {
            $enabled[$key] = $service['id'];
        }
    }
    return $enabled;
}

function site_integration_secret(string $key, string $env): string
{
    $value = site_integration_settings()[$key] ?? '';
    return is_string($value) && $value !== '' ? $value : (string) getenv($env);
}

function site_notify_telegram(array $message)
{
    $settings = site_integration_settings();
    $token = $settings['telegram_token'] ?? '';
    $chat = $settings['telegram_chat'] ?? '';
    if (($settings['telegram_enabled'] ?? false) !== true || !is_string($token) || !is_string($chat)
        || !preg_match('/\A[0-9]+:[A-Za-z0-9_-]{16,100}\z/', $token)
        || !preg_match('/\A(?:-?[0-9]{1,20}|@[A-Za-z0-9_]{5,32})\z/', $chat)) {
        return;
    }
    $text = "Новая заявка с сайта\nФорма: " . $message['form'] . "\nСтраница: " . $message['host'] . site_page_url('', $message['page']);
    $options = ['http' => ['method' => 'POST', 'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query(['chat_id' => $chat, 'text' => $text]), 'timeout' => 4, 'follow_location' => 0]];
    @file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage', false, stream_context_create($options), 0, 8192);
}
