<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return <<<'JS'
(() => {
    if (!window.CodeMirror || !CodeMirror.runMode) return;
    const modes = {auto: 'Auto', html: 'HTML', css: 'CSS', javascript: 'JavaScript', php: 'PHP', raw: 'RAW'};
    const mime = {html: 'text/html', css: 'text/css', javascript: 'text/javascript',
        php: 'application/x-httpd-php-open'};
    document.querySelectorAll('textarea[data-code-mode]').forEach((input) => {
        if (input.closest('[data-test-code]')) return;
        const frame = document.createElement('span');
        frame.className = 'editor-code-frame';
        const modeLabel = document.createElement('label');
        modeLabel.className = 'editor-code-mode';
        const mode = document.createElement('select');
        mode.setAttribute('aria-label', 'Syntax');
        for (const [name, label] of Object.entries(modes)) mode.add(new Option(label, name));
        modeLabel.append(mode);
        const highlight = document.createElement('pre');
        highlight.className = 'editor-code-highlight cm-s-default';
        highlight.setAttribute('aria-hidden', 'true');
        input.before(modeLabel, frame);
        frame.append(highlight, input);
        input.wrap = 'off';
        const scroll = () => {
            highlight.scrollTop = input.scrollTop;
            highlight.scrollLeft = input.scrollLeft;
        };
        const refresh = () => {
            const syntax = mode.value === 'auto' ? input.dataset.codeMode : mode.value;
            const active = Boolean(mime[syntax]) && input.value.length < 160000;
            frame.hidden = input.hidden;
            modeLabel.hidden = input.hidden;
            frame.toggleAttribute('data-highlight', active);
            highlight.hidden = !active;
            if (active) {
                CodeMirror.runMode(input.value + '\n', mime[syntax], highlight);
                scroll();
            }
        };
        let timer;
        input.addEventListener('input', () => {
            clearTimeout(timer);
            timer = setTimeout(refresh, 35);
        });
        input.addEventListener('scroll', scroll);
        mode.addEventListener('change', refresh);
        new MutationObserver(refresh).observe(input, {attributes: true, attributeFilter: ['hidden']});
        refresh();
    });
})();
JS;
