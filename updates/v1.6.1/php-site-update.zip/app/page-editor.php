<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_editor_session(string $base): array
{
    $cookie = $_COOKIE['FILE_SITE_ADMIN'] ?? '';
    if (!is_string($cookie) || !preg_match('/\A[A-Za-z0-9,-]{16,128}\z/', $cookie)) {
        return [];
    }
    require_once SITE_ROOT . '/admin/access.php';
    try {
        $auth = admin_auth_state();
    } catch (RuntimeException $exception) {
        return [];
    }
    if (!isset($auth['password'])) {
        return [];
    }
    session_name('FILE_SITE_ADMIN');
    session_cache_limiter('');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params(0, site_url($base), '', !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', true);
    if (!@session_start(['read_and_close' => true])) {
        return [];
    }
    $state = $_SESSION;
    $_SESSION = [];
    if (!is_string($state['auth'] ?? null) || !hash_equals(admin_auth_key($auth), $state['auth'])
        || !is_string($state['csrf'] ?? null)) {
        return [];
    }
    return ['csrf' => $state['csrf'], 'edit' => ($state['public_edit'] ?? false) === true];
}

function site_inline_component_type(array $match, array $extensions, array $snippets): string
{
    if (!empty($match['galleryTag'])) {
        return strtolower($match['galleryTag']);
    }
    foreach (['files', 'include', 'iblock', 'form', 'callback', 'map', 'phpModule', 'extensionTag', 'iconName'] as $key) {
        if (!empty($match[$key])) {
            return $key;
        }
    }
    $name = strtolower($match['snippet'] ?? '');
    return isset($snippets[$name]) || isset($extensions[$name]) || isset(site_layout_blocks()[$name]) ? 'snippet' : '';
}

function site_inline_components(string $html, array $extensions, array $snippets): array
{
    preg_match_all(site_content_pattern($extensions), $html, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER);
    $items = [];
    foreach ($matches as $match) {
        $flat = array_map(static function (array $entry): string { return $entry[0]; }, $match);
        $type = site_inline_component_type($flat, $extensions, $snippets);
        if ($type !== '') {
            $items[] = ['code' => $match[0][0], 'offset' => $match[0][1], 'kind' => $type,
                'options' => $flat['galleryOptions'] ?? ($flat['fileOptions'] ?? ''), 'arguments' => $flat];
        }
    }
    return $items;
}

function site_inline_editor_fields(array $item): array
{
    $kind = $item['kind'];
    $arg = $item['arguments'];
    if ($kind === 'map' || $kind === 'callback') {
        $options = site_shortcode_options($arg[$kind === 'map' ? 'map' : 'callbackOptions'] ?? '');
        if ($kind === 'callback' && !empty($arg['callbackLabel'])) {
            $options['button'] = trim($arg['callbackLabel']);
        }
        $names = $kind === 'map' ? ['lat' => 'Широта', 'lng' => 'Долгота', 'title' => 'Название точки', 'zoom' => 'Масштаб',
            'provider' => 'Провайдер', 'mode' => 'Режим', 'url' => 'URL кнопки', 'button' => 'Текст кнопки']
            : ['button' => 'Текст кнопки', 'title' => 'Заголовок формы', 'submit' => 'Текст кнопки отправки', 'placeholder' => 'Подсказка в поле телефона'];
    } elseif ($kind === 'iblock') {
        $names = ['template' => 'Вид инфоблока', 'path' => 'Путь'];
        $options = ['template' => $arg['iblockTemplate'], 'path' => trim($arg['iblock'])];
    } elseif (in_array($kind, ['include', 'gal', 'fotos', 'files'], true)) {
        $names = ['path' => 'Путь'];
        $options = ['path' => trim($arg[in_array($kind, ['gal', 'fotos'], true) ? 'gallery' : $kind])];
    } elseif (in_array($kind, ['form', 'phpModule', 'snippet', 'iconName'], true)) {
        $names = ['code' => 'Код'];
        $options = ['code' => $arg[$kind]];
        if ($kind === 'iconName') {
            $names['style'] = 'Стиль';
            $options['style'] = $arg['iconStyle'] ?? '';
        }
    } elseif ($kind === 'extensionTag') {
        $names = ['code' => 'Код', 'value' => 'Значение'];
        $options = ['code' => $arg['extensionTag'], 'value' => $arg['extensionArg']];
    } else {
        return [];
    }
    $fields = [];
    foreach ($names as $name => $label) {
        $fields[$name] = [$label, $options[$name] ?? ''];
    }
    return $fields;
}
