<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PERFORMANCE_FILE = SITE_ROOT . '/admin/.performance.php';
const SITE_SEARCH_FILE = SITE_ROOT . '/data/.search-index.php';
const SITE_SEARCH_LIMIT = 67108864;

function site_performance_settings(): array
{
    static $settings;
    if ($settings === null) {
        try {
            $stored = site_read_record(SITE_PERFORMANCE_FILE);
        } catch (RuntimeException $exception) {
            $stored = [];
        }
        $settings = ['cache' => ($stored['cache'] ?? false) === true,
            'generation' => is_string($stored['generation'] ?? null) ? $stored['generation'] : ''];
    }
    return $settings;
}

function site_page_cache_file(string $path): string
{
    return SITE_ROOT . '/data/.page-cache-' . hash('sha256', $path) . '.php';
}

function site_page_cache_write(string $file, array $record)
{
    $encoded = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) {
        return;
    }
    $temporary = SITE_ROOT . '/data/.cache-write-' . bin2hex(random_bytes(12)) . '.php';
    $bytes = SITE_RECORD_HEADER . $encoded;
    try {
        if (@file_put_contents($temporary, $bytes) === strlen($bytes)) {
            @rename($temporary, $file);
        }
    } finally {
        if (is_file($temporary)) {
            @unlink($temporary);
        }
    }
}

function site_search_text(string $html, int $limit = 0): string
{
    $html = preg_replace('~<!--.*?-->|<(script|style|template)\b[^>]*>.*?</\1\s*>~is', ' ', $html);
    $html = preg_replace('~\[(gal|fotos|files|include|php)(?:[ \t=][^\]]*)?\].*?\[/\1\]|\[iblock=[^\]]*\].*?\[/?iblock\]~is', ' ', $html);
    $html = preg_replace('~\[[a-z][a-z0-9_-]*(?:[=\s][^\]]*)?\]|</?(?:p|div|li|br|td|section|h[1-6])\b[^>]*>~i', ' ', $html);
    $plain = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $plain = preg_replace('/[\s\p{Z}\p{Cc}]+/u', ' ', $plain);
    return trim($limit > 0 ? site_search_clip($plain ?? '', $limit) : ($plain ?? ''));
}

function site_search_clip(string $text, int $limit): string
{
    if (strlen($text) <= $limit) {
        return $text;
    }
    $prefix = substr($text, 0, $limit);
    return preg_match('//u', $prefix) === 1 ? $prefix : preg_replace('/[\xC0-\xF7][\x80-\xBF]*\z/', '', $prefix);
}

function site_search_index(): array
{
    try {
        return site_read_record(SITE_SEARCH_FILE, SITE_SEARCH_LIMIT);
    } catch (RuntimeException $exception) {
        return [];
    }
}

function site_search_query($raw): string
{
    return is_string($raw) && strlen($raw) <= 320 && preg_match('//u', $raw) === 1 ? trim($raw) : '';
}

function site_search_find(array $index, string $query, string $locale, int $limit): array
{
    if (!preg_match_all('/[\p{L}\p{N}\p{M}]+/u', $query, $matches) || count($matches[0]) > 8
        || (strlen($query) < 2 && !preg_match('/[^\x00-\x7f]/', $query))) {
        return [];
    }
    $words = array_unique($matches[0]);
    $tokens = array_map(static function (string $word): string { return '~' . preg_quote($word, '~') . '~iu'; }, $words);
    $ranked = [];
    foreach (($index['pages'] ?? []) as $path => $variants) {
        $entry = $variants[$locale] ?? $variants['ru'] ?? null;
        if ($entry === null) {
            continue;
        }
        $score = 0;
        foreach ($tokens as $pattern) {
            if (preg_match($pattern, $entry['title'])) {
                $score += 10;
            } elseif (preg_match($pattern, $entry['description'])) {
                $score += 5;
            } elseif (preg_match($pattern, $entry['text'])) {
                $score += 1;
            } else {
                continue 2;
            }
        }
        $ranked[$path] = $score;
    }
    arsort($ranked, SORT_NUMERIC);
    $results = [];
    foreach (array_slice($ranked, 0, $limit * 3, true) as $path => $score) {
        $entry = $index['pages'][$path][$locale] ?? $index['pages'][$path]['ru'];
        $variant = site_localized_page($path, $locale);
        if ($variant === null || $variant['revision'] !== $entry['revision']) {
            continue;
        }
        $results[] = ['path' => $path, 'title' => $entry['title'],
            'description' => $entry['description'] !== '' ? $entry['description'] : site_search_clip($entry['text'], 300)];
        if (count($results) >= $limit) {
            break;
        }
    }
    return $results;
}
