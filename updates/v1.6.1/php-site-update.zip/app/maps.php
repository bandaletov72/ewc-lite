<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_MAPS_FILE = SITE_ROOT . '/admin/.maps.php';

function site_map_providers(): array
{
    return ['off' => 'Выключено', 'yandex' => 'Яндекс Карты', 'google' => 'Google Maps'];
}

function site_map_modes(): array
{
    return ['map' => 'Схема', 'satellite' => 'Спутник', 'hybrid' => 'Гибрид'];
}

function site_map_settings(): array
{
    $default = ['provider' => 'off', 'mode' => 'map', 'zoom' => '12', 'cluster' => '1', 'yandex_key' => '', 'google_key' => '', 'google_map_id' => ''];
    try {
        $stored = site_read_record(SITE_MAPS_FILE);
    } catch (RuntimeException $exception) {
        return $default;
    }
    return array_replace($default, array_intersect_key(array_filter($stored, 'is_string'), $default));
}

function site_map_url(string $url): string
{
    if ($url === '' || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
        return '';
    }
    if ($url[0] === '/' && substr($url, 0, 2) !== '//') {
        return $url;
    }
    return preg_match('~\Ahttps?://~i', $url) && filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
}

function site_component_map(string $argument, array &$context): string
{
    if (!isset($context['mapPoints'])) {
        return '';
    }
    $options = site_shortcode_options($argument);
    $lat = $options['lat'] ?? '';
    $lng = $options['lng'] ?? '';
    $title = trim($options['title'] ?? '');
    if (!preg_match('/\A-?[0-9]{1,3}(?:\.[0-9]{1,10})?\z/', $lat)
        || !preg_match('/\A-?[0-9]{1,3}(?:\.[0-9]{1,10})?\z/', $lng)
        || abs((float) $lat) > 90 || abs((float) $lng) > 180
        || $title === '' || strlen($title) > 500) {
        return '';
    }
    $first = !$context['mapPoints'];
    $url = site_map_url($options['url'] ?? '');
    if ($url !== '' && $url[0] === '/') {
        $url = site_url($context['base'], substr($url, 1));
    }
    $context['mapPoints'][] = [
        'lat' => (float) $lat, 'lng' => (float) $lng, 'title' => $title,
        'url' => $url, 'button' => trim($options['button'] ?? ''),
    ];
    if (!$first) {
        return '';
    }
    $context['mapOptions'] = $options;
    $context['mapSlot'] = '<!--site-map-' . bin2hex(random_bytes(12)) . '-->';
    return $context['mapSlot'];
}

function site_finish_map(string $html, array &$context): string
{
    if (!$context['mapPoints']) {
        return $html;
    }
    $settings = site_map_settings();
    $options = $context['mapOptions'];
    $provider = $settings['provider'] === 'off' ? 'off' : ($options['provider'] ?? $settings['provider']);
    if (!in_array($provider, ['google', 'yandex'], true)) {
        $provider = $settings['provider'];
    }
    $mode = $options['mode'] ?? $settings['mode'];
    $zoom = $options['zoom'] ?? $settings['zoom'];
    $data = [
        'provider' => $provider, 'key' => $settings[$provider . '_key'] ?? '',
        'mapId' => $settings['google_map_id'], 'locale' => $context['locale'],
        'mode' => isset(site_map_modes()[$mode]) ? $mode : 'map',
        'zoom' => ctype_digit($zoom) && (int) $zoom >= 1 && (int) $zoom <= 20 ? (int) $zoom : (int) $settings['zoom'],
        'fit' => !isset($options['zoom']), 'cluster' => $settings['cluster'] === '1', 'points' => $context['mapPoints'],
    ];
    ob_start();
    require site_template_file('components/map.php');
    return str_replace($context['mapSlot'], (string) ob_get_clean(), $html);
}
