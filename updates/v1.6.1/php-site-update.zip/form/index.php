<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';
require SITE_ROOT . '/admin/files.php';

function form_reply(int $status, string $text, array $fields = [])
{
    http_response_code($status);
    echo json_encode(['ok' => $status === 200, 'message' => $text, 'fields' => (object) $fields], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    form_reply(405, 'Используйте форму на странице сайта.');
}
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > SITE_FORM_REQUEST_LIMIT) {
    form_reply(413, 'Запрос слишком большой. Сократите сообщение и попробуйте снова.');
}

$base = site_base('form/index.php');
if (!site_public_session($base)) {
    form_reply(503, 'Форма временно недоступна.');
}
$id = $_POST['form'] ?? '';
$pagePath = $_POST['page'] ?? '';
$data = $_POST['fields'] ?? [];
if (!is_string($id) || ($id !== 'callback' && !site_valid_form_id($id)) || !is_string($pagePath) || !is_array($data)) {
    form_reply(400, 'Форма не найдена.');
}
if (!isset($_POST['csrf'], $_SESSION['csrf']) || !is_string($_POST['csrf'])
    || !hash_equals(site_form_signature($_SESSION['csrf'], $id, $pagePath), $_POST['csrf'])) {
    form_reply(403, 'Обновите страницу и попробуйте снова.');
}
$page = site_read_page($pagePath);
list($basePage, $language) = site_page_translation($pagePath);
if ($page === null || $page['fields']['Hidden'] === '1'
    || ($language !== '' && (!in_array($language, site_region_settings()['languages'], true) || site_localized_page($basePage, $language) === null))) {
    form_reply(400, 'Страница с формой не найдена.');
}

try {
    if ($id === 'callback') {
        $callback = site_callback_settings();
        $form = site_callback_form($callback);
    } else {
        $forms = site_forms();
        $form = $forms[$id] ?? null;
    }
    $rules = site_spam_rules();
} catch (RuntimeException $exception) {
    form_reply(503, 'Форма временно недоступна.');
}
if ($form === null) {
    form_reply(404, 'Форма не найдена.');
}
$ip = site_normalize_ip($_SERVER['REMOTE_ADDR'] ?? '');
if (in_array($ip, $rules['ips'], true) || ($_POST['website'] ?? '') !== '') {
    form_reply(403, 'Отправка сообщения заблокирована.');
}

$now = time();
$recent = array_filter($_SESSION['submitted'] ?? [], static function (int $submitted) use ($now): bool {
    return $submitted > $now - 60;
});
if (count($recent) >= 5) {
    header('Retry-After: 60');
    form_reply(429, 'Слишком много отправок. Попробуйте через минуту.');
}

$submission = site_validate_message($form, $data);
$errors = $submission['errors'] + site_spam_errors($submission['fields'], $rules['words']);
if ($errors) {
    form_reply(422, 'Проверьте отмеченные поля.', $errors);
}

$message = ['time' => gmdate('c'), 'host' => site_host(), 'page' => $pagePath, 'form' => $id, 'fields' => $submission['fields']];
if (strlen(json_encode($message, JSON_UNESCAPED_UNICODE)) > 27000) {
    form_reply(422, 'Сократите сообщение и попробуйте снова.');
}
$captcha = site_captcha_settings($form);
if ($captcha['enabled']) {
    try {
        if (!site_verify_captcha($captcha, $_POST['g-recaptcha-response'] ?? '', $message['host'])) {
            form_reply(422, 'Подтвердите, что вы не робот, и попробуйте снова.');
        }
    } catch (RuntimeException $exception) {
        form_reply(503, 'Не удалось проверить CAPTCHA. Попробуйте позже.');
    }
}
try {
    if ($id === 'callback') {
        $callbackId = site_callback_create($message, $ip);
    } else {
        site_save_message($message);
    }
} catch (RuntimeException $exception) {
    if ($exception->getCode() === 429) {
        form_reply(429, $exception->getMessage());
    }
    form_reply(503, 'Не удалось сохранить сообщение. Попробуйте позже.');
}
$recent[] = $now;
$_SESSION['submitted'] = $recent;
session_write_close();
site_notify_telegram($message);
if ($id === 'callback') {
    if ($callback['mode'] === 'auto') {
        try {
            site_callback_dispatch($callbackId, $callback);
        } catch (RuntimeException $exception) {
            // The request is already on file for staff to review.
        }
    }
    form_reply(200, 'Заявка принята. Мы вам перезвоним.');
}
site_notify_message($form, $submission['replyTo'], $message);
form_reply(200, 'Сообщение отправлено.');
