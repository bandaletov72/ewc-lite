<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$moduleSettings = site_php_module_settings();
$modules = site_extensions();
$usage = site_php_module_usage($modules);
?>
<h1><?= admin_l('PHP-модули') ?></h1>
<div class="form-stack">
    <details class="panel">
        <summary class="button button-primary"><strong><?= admin_l('Создать модуль') ?></strong></summary>
        <form method="post" action="<?= site_escape($modulesUrl) ?>" class="form-stack">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="action" value="save-module-source">
            <input type="hidden" name="create" value="1">
            <div class="fields">
                <label class="field"><?= admin_l('Имя модуля') ?><input name="module" required pattern="[a-z][a-z0-9_-]{0,63}" maxlength="64"></label>
                <label class="field"><?= admin_l('Имя файла') ?><input name="filename" maxlength="68" placeholder="module.php"></label>
            </div>
            <label class="field">PHP
                <textarea name="code" rows="8" data-code-mode="php" spellcheck="false" placeholder="return 'Hello';" required></textarea>
            </label>
            <p class="hint"><?= admin_l('Введите тело функции без тегов PHP. Возвращаемая строка вставляется в страницу.') ?></p>
            <div><button class="button-primary"><?= admin_l('Создать модуль') ?></button></div>
        </form>
    </details>
    <?php foreach ($modules as $name => $definition): ?>
        <?php list($source, $revision, $filename) = site_php_module_source($name); ?>
        <?php $moduleLabel = $moduleSettings[$name]['label'] ?? ($definition['label'] ?? $name); ?>
        <details class="panel form-stack">
            <summary><strong><?= site_escape($moduleLabel) ?></strong> <code><?= site_escape('[php]' . $name . '[/php]') ?></code></summary>
            <form method="post" action="<?= site_escape($modulesUrl) ?>" class="form-stack">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <input type="hidden" name="action" value="save-module">
                <input type="hidden" name="module" value="<?= site_escape($name) ?>">
                <label class="field"><?= admin_l('Название') ?><input name="label" maxlength="120" value="<?= site_escape($moduleLabel) ?>" required></label>
                <label class="field"><?= admin_l('Описание') ?><textarea name="description" maxlength="400" rows="3"><?= site_escape($moduleSettings[$name]['description'] ?? '') ?></textarea></label>
                <label class="choice"><input type="checkbox" name="enabled" value="1"<?= site_php_module_enabled($name) ? ' checked' : '' ?>><?= admin_l('Доступен для вставки') ?></label>
                <div><button class="button-primary"><?= admin_l('Сохранить настройки') ?></button></div>
            </form>
            <form method="post" action="<?= site_escape($modulesUrl) ?>" class="form-stack">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <input type="hidden" name="action" value="save-module-source">
                <input type="hidden" name="module" value="<?= site_escape($name) ?>">
                <input type="hidden" name="revision" value="<?= site_escape($revision) ?>">
                <label class="field"><?= admin_l('Имя файла') ?><input name="filename" maxlength="68" value="<?= site_escape($filename) ?>" required></label>
                <label class="field"><?= admin_l('Исходный код') ?> · PHP
                    <textarea name="code" rows="9" data-code-mode="php" spellcheck="false" required><?= "\n" . site_escape($source) ?></textarea>
                </label>
                <div><button class="button-primary"><?= admin_l('Сохранить код') ?></button></div>
            </form>
            <section>
                <h3><?= admin_l('Страницы с этим модулем') ?></h3>
                <?php if (empty($usage[$name])): ?>
                    <p class="hint"><?= admin_l('Модуль пока нигде не вставлен.') ?></p>
                <?php else: ?>
                    <ul class="page-list">
                        <?php foreach ($usage[$name] as $path => $pageTitle): ?>
                            <li><a href="<?= site_escape(admin_page_edit_url($adminUrl, $path)) ?>"><?= site_escape($pageTitle) ?> <small><?= site_escape(site_page_url('', $path)) ?></small></a></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
        </details>
    <?php endforeach; ?>
</div>
