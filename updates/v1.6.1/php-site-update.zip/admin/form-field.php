<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$prefix = 'fields[' . $index . ']';
$lengths = site_form_length_limits();
?>
<fieldset class="field-config form-stack" data-form-row>
    <legend>Поле формы</legend>
    <div class="fields">
        <label class="field">Подпись
            <input name="<?= $prefix ?>[label]" value="<?= site_escape($field['label']) ?>" placeholder="Ваш телефон" maxlength="375" required>
        </label>
        <label class="field">Ключ поля
            <input name="<?= $prefix ?>[name]" value="<?= site_escape($field['name']) ?>" data-form-field-key placeholder="phone" maxlength="64" required>
        </label>
        <label class="field">Тип
            <select name="<?= $prefix ?>[type]" data-field-type>
                <?php foreach (site_form_types() as $type => $label): ?>
                    <option value="<?= $type ?>" data-default-length="<?= $lengths[$type][0] ?>" data-max-length="<?= $lengths[$type][1] ?>"<?= $field['type'] === $type ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="field">Максимальная длина
            <input type="number" name="<?= $prefix ?>[maxLength]" data-field-length min="1"
                max="<?= $lengths[$field['type']][1] ?? 12000 ?>" placeholder="<?= $lengths[$field['type']][0] ?? 375 ?>"
                value="<?= site_escape((string) ($field['maxLength'] ?? '')) ?>">
            <small class="hint">Пустое поле использует предел по умолчанию для выбранного типа.</small>
        </label>
        <label class="choice field-required"><input type="checkbox" name="<?= $prefix ?>[required]" value="1"<?= $field['required'] ? ' checked' : '' ?>> Обязательное поле</label>
    </div>
    <label class="field" data-field-options>Варианты для radio и select
        <textarea class="short-editor" name="<?= $prefix ?>[options]" rows="3" placeholder="Один вариант на строку"><?= "\n" . site_escape(implode("\n", $field['options'])) ?></textarea>
    </label>
    <div><button type="button" data-remove-field>Удалить поле</button></div>
</fieldset>
