<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1><?= admin_l('Сообщения') ?></h1>
<?php if ($message): ?>
    <article class="panel">
        <a href="<?= site_escape($messagesUrl . '&inbox_page=' . $messagePagination['page']) ?>"><?= admin_l('К списку сообщений') ?></a>
        <h2>Сообщение из [<?= site_escape($message['form']) ?>]</h2>
        <p class="hint"><?= site_escape($message['host'] . ' / ' . $message['page']) ?></p>
        <dl class="message-fields">
            <?php foreach ($message['fields'] as $field): ?>
                <dt><?= site_escape($field['label']) ?></dt>
                <dd><?= $field['value'] === '' ? '—' : site_escape($field['value']) ?></dd>
            <?php endforeach; ?>
        </dl>
    </article>
<?php elseif (!$messagePagination['rows']): ?>
    <p class="panel"><?= admin_l('Сообщений пока нет.') ?></p>
<?php else: ?>
    <div class="panel">
        <ul class="page-list">
            <?php foreach ($messagePagination['rows'] as $id => $unread): ?>
                <li>
                    <a href="<?= site_escape($messagesUrl . '&inbox_page=' . $messagePagination['page'] . '&message=' . $id) ?>">
                        <?= site_escape(admin_inbox_date($id)) ?> <?= $unread ? '<strong>Новое</strong>' : '' ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php admin_inbox_pager($messagePagination, $messagesUrl); ?>
    </div>
<?php endif; ?>
