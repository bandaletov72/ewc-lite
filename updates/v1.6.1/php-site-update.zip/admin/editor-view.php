<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$tokens = array_unique(array_merge(['header', 'menu', 'mobile-menu', 'footer', 'year', 'date', 'time', 'contacts', 'phones', 'soc-icons'],
    array_keys(site_snippet_values($currentHost)), array_keys($siteSettings['variables'])));
?>
<div class="field field-wide" data-content-editor>
    <label for="html">Содержимое страницы</label>
    <div class="header-actions" data-editor-toolbar hidden>
        <button type="button" data-editor-mode="html" aria-pressed="true">HTML</button>
        <button type="button" data-editor-mode="visual" aria-pressed="false">Визуальный редактор</button>
    </div>
    <div class="header-actions" data-editor-format hidden>
        <button type="button" data-editor-command="bold"><strong>Жирный</strong></button>
        <button type="button" data-editor-command="italic"><em>Курсив</em></button>
        <button type="button" data-editor-command="formatBlock" data-editor-value="h2">Заголовок H2</button>
        <button type="button" data-editor-command="insertUnorderedList">Маркированный список</button>
        <button type="button" data-editor-command="createLink">Ссылка</button>
    </div>
    <textarea id="html" name="html" data-code-mode="html" spellcheck="false" rows="12"><?= "\n" . site_escape($page['html']) ?></textarea>
    <iframe data-editor-frame hidden sandbox="allow-same-origin"
        data-src="<?= site_escape(site_url($base, 'templates/editor-frame.php')) ?>" title="Визуальный редактор страницы"></iframe>
    <details data-editor-insert hidden>
        <summary><?= admin_l('Вставить шаблон или компонент') ?></summary>
        <div class="fields">
            <label class="field">Компонент
                <select data-editor-component>
                    <?php foreach (['snippet' => 'Подшаблон', 'gal' => 'Карусель', 'fotos' => 'Фотогалерея', 'files' => 'Список файлов',
                        'include' => 'Другая страница', 'form' => 'Форма', 'callback' => 'Обратный звонок',
                        'iblock' => 'Инфоблок', 'map' => 'Точка на карте', 'php' => 'PHP-модули'] as $key => $label): ?>
                        <option value="<?= $key ?>"><?= site_escape($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="php"><?= site_escape(admin_l('PHP-модули')) ?>
                <select data-editor-param="module">
                    <?php foreach (site_extensions() as $name => $definition): ?>
                        <?php if (!site_php_module_enabled($name)) continue; ?>
                        <option value="<?= site_escape($name) ?>"><?= site_escape(site_php_module_settings()[$name]['label'] ?? ($definition['label'] ?? $name)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="snippet">Подшаблон
                <select data-editor-param="token">
                    <?php foreach ($tokens as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                </select>
            </label>
            <?php foreach ([
                'path' => ['Путь', 'gal fotos files include iblock', '/images/myfotos/'],
                'form' => ['Код формы', 'form', 'form1'],
                'title' => ['Название точки или заголовок формы', 'map callback', 'Офис'],
                'lat' => ['Широта', 'map', '55.7558'],
                'lng' => ['Долгота', 'map', '37.6173'],
                'zoom' => ['Масштаб', 'map', '13'],
                'url' => ['URL кнопки', 'map', '/contacts/'],
                'button' => ['Текст кнопки', 'map callback', 'Подробнее'],
                'submit' => ['Текст кнопки отправки', 'callback', 'Отправить номер'],
                'placeholder' => ['Подсказка в поле телефона', 'callback', '+7(900)123-45-67'],
            ] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <input data-editor-param="<?= $key ?>" placeholder="<?= site_escape($field[2]) ?>">
                </label>
            <?php endforeach; ?>
            <?php foreach (['layout' => ['Вид инфоблока', 'iblock', ['table' => 'Таблица', 'phones' => 'Телефоны']],
                'provider' => ['Карты', 'map', ['' => 'По умолчанию', 'yandex' => 'Яндекс Карты', 'google' => 'Google Maps']],
                'mode' => ['Режим', 'map', ['' => 'По умолчанию'] + site_map_modes()]] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <select data-editor-param="<?= $key ?>">
                        <?php foreach ($field[2] as $value => $label): ?><option value="<?= $value ?>"><?= site_escape($label) ?></option><?php endforeach; ?>
                    </select>
                </label>
            <?php endforeach; ?>
            <?php foreach (site_component_schema() as $kind => $definition): ?>
                <?php foreach ($definition['settings'] as $name => $field): ?>
                    <label class="field" data-editor-show="<?= site_escape($kind) ?>"><?= site_escape($field['label']) ?>
                        <select data-editor-option="<?= site_escape($name) ?>">
                            <option value="">По умолчанию</option>
                            <?php foreach ($field['options'] as $option => $label): ?><option value="<?= site_escape($option) ?>"><?= site_escape($label) ?></option><?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <p class="hint" data-editor-feedback role="status"></p>
        <button type="button" data-editor-insert-button><?= admin_l('Вставить в текст') ?></button>
    </details>
    <details data-editor-media hidden>
        <summary><?= admin_l('Фотографии и файлы компонентов') ?></summary>
        <label class="field"><?= admin_l('Папка компонента') ?> <select data-media-folder></select></label>
        <div class="header-actions">
            <input type="file" multiple data-media-upload aria-label="<?= admin_l('Выберите файлы для загрузки') ?>">
            <button type="button" data-media-upload-button>Загрузить файлы</button>
        </div>
        <p class="hint" role="status" data-media-feedback></p>
        <ol class="media-list" data-media-list></ol>
    </details>
</div>
