const themeMode = document.getElementById('theme-mode');
if (themeMode) {
    const sheet = document.querySelector('[data-admin-theme]');
    themeMode.addEventListener('change', () => {
        const url = new URL(sheet.href, location.href);
        url.searchParams.set('preview_mode', themeMode.value);
        sheet.href = url.href;
    });
}

document.querySelectorAll('[data-content-editor]').forEach((editor) => {
    const html = editor.querySelector('textarea');
    const frame = editor.querySelector('[data-editor-frame]');
    const form = editor.closest('form');
    const format = editor.querySelector('[data-editor-format]');
    const feedback = editor.querySelector('[data-editor-feedback]');
    const component = editor.querySelector('[data-editor-component]');
    let visual = false;
    let editorDocument = null;
    let range = null;
    let dirty = false;

    editor.querySelector('[data-editor-toolbar]').hidden = false;
    editor.querySelector('[data-editor-insert]').hidden = false;

    const sync = () => {
        if (editorDocument && dirty) html.value = editorDocument.body.innerHTML;
        dirty = false;
    };
    const updateMode = (next) => {
        visual = next === 'visual';
        if (!visual) sync();
        html.hidden = visual;
        frame.hidden = !visual;
        format.hidden = !visual;
        editor.querySelectorAll('[data-editor-mode]').forEach((button) =>
            button.setAttribute('aria-pressed', String(button.dataset.editorMode === next)));
        if (visual && !frame.hasAttribute('src')) {
            frame.src = frame.dataset.src;
        } else if (visual && editorDocument) {
            range = null;
            editorDocument.body.innerHTML = html.value;
        }
    };
    frame.addEventListener('load', () => {
        if (!frame.hasAttribute('src') || !frame.contentDocument?.body) return;
        editorDocument = frame.contentDocument;
        editorDocument.body.innerHTML = html.value;
        editorDocument.body.contentEditable = 'true';
        editorDocument.addEventListener('input', () => {
            dirty = true;
            editor.dispatchEvent(new CustomEvent('content-source', { detail: editorDocument.body.innerHTML }));
        });
        editorDocument.addEventListener('click', (event) => {
            if (event.target.closest?.('a')) event.preventDefault();
        });
        editorDocument.addEventListener('selectionchange', () => {
            const selection = editorDocument.getSelection();
            if (selection.rangeCount > 0 && editorDocument.body.contains(selection.anchorNode)) {
                range = selection.getRangeAt(0).cloneRange();
            }
        });
    });
    form.addEventListener('submit', sync);
    const visualSelection = () => {
        const selection = editorDocument.getSelection();
        frame.contentWindow.focus();
        editorDocument.body.focus();
        if (range && editorDocument.body.contains(range.startContainer)) {
            selection.removeAllRanges();
            selection.addRange(range);
        }
        return selection;
    };
    const selectParameters = () => {
        editor.querySelectorAll('[data-editor-show]').forEach((field) => {
            field.hidden = !field.dataset.editorShow.split(' ').includes(component.value);
        });
        feedback.textContent = '';
    };
    selectParameters();
    component.addEventListener('change', selectParameters);

    const parameter = (key) => editor.querySelector('[data-editor-param="' + key + '"]').value.trim();
    const quote = (value) => '"' + value.replaceAll('"', '”') + '"';
    const build = () => {
        const tag = component.value;
        if (tag === 'snippet') return '[' + parameter('token') + ']';
        if (tag === 'php') {
            const name = parameter('module');
            return name ? '[php]' + name + '[/php]' : '';
        }
        if (tag === 'form') {
            const name = parameter('form');
            return /^form[1-9][0-9]{0,8}$/.test(name) ? '[' + name + ']' : '';
        }
        if (tag === 'callback') {
            const fields = ['button', 'title', 'submit', 'placeholder'].filter(parameter)
                .map((field) => field + '=' + quote(parameter(field)));
            return '[callback' + (fields.length ? ' ' + fields.join(' ') : '') + ']';
        }
        if (tag === 'map') {
            const lat = parameter('lat');
            const lng = parameter('lng');
            if (!/^-?\d{1,3}(\.\d+)?$/.test(lat) || !/^-?\d{1,3}(\.\d+)?$/.test(lng)
                || Math.abs(Number(lat)) > 90 || Math.abs(Number(lng)) > 180 || !parameter('title')) return '';
            const fields = ['lat=' + lat, 'lng=' + lng, 'title=' + quote(parameter('title'))];
            for (const field of ['zoom', 'provider', 'mode', 'url', 'button']) {
                if (parameter(field)) fields.push(field + '=' + quote(parameter(field)));
            }
            return '[map ' + fields.join(' ') + ']';
        }
        const path = parameter('path');
        if (!path.startsWith('/') || /[\[\]]/.test(path)) return '';
        if (tag === 'iblock') return '[iblock=' + parameter('layout') + ']' + path + '[/iblock]';
        const params = Array.from(editor.querySelectorAll('[data-editor-option]')).filter((input) => !input.closest('label').hidden && input.value)
            .map((input) => ' ' + input.dataset.editorOption + '=' + input.value).join('');
        return '[' + tag + params + ']' + path + '[/' + tag + ']';
    };
    editor.addEventListener('click', (event) => {
        const mode = event.target.closest('[data-editor-mode]');
        const command = event.target.closest('[data-editor-command]');
        if (mode) {
            updateMode(mode.dataset.editorMode);
        } else if (command && editorDocument) {
            let value = command.dataset.editorValue || null;
            if (command.dataset.editorCommand === 'createLink') {
                value = window.prompt('Введите адрес ссылки');
                if (!value || !/^(https?:\/\/|\/(?![\/\\])|#)/i.test(value)) return;
            }
            visualSelection();
            editorDocument.execCommand(command.dataset.editorCommand, false, value);
            dirty = true;
        } else if (event.target.closest('[data-editor-insert-button]')) {
            const code = build();
            if (!code || (visual && !editorDocument)) {
                feedback.textContent = 'Проверьте параметры компонента.';
                return;
            }
            if (visual) {
                const selection = visualSelection();
                if (!selection.rangeCount) return;
                const current = selection.getRangeAt(0);
                current.deleteContents();
                current.insertNode(editorDocument.createTextNode(code));
                selection.collapseToEnd();
                dirty = true;
            } else {
                html.setRangeText(code, html.selectionStart, html.selectionEnd, 'end');
                html.focus();
            }
            feedback.textContent = 'Код вставлен.';
            editor.dispatchEvent(new CustomEvent('content-source', { detail: visual ? editorDocument.body.innerHTML : html.value }));
        }
    });
});

document.querySelectorAll('[data-editor-media]').forEach((manager) => {
    const editor = manager.closest('[data-content-editor]');
    const page = manager.closest('[data-page-admin]');
    const select = manager.querySelector('[data-media-folder]');
    const input = manager.querySelector('[data-media-upload]');
    const upload = manager.querySelector('[data-media-upload-button]');
    const status = manager.querySelector('[data-media-feedback]');
    const list = manager.querySelector('[data-media-list]');
    let files = [];
    let folders = [];
    let busy = false;
    let dragged = null;

    const api = async (action, target, options = {}) => {
        const body = new FormData();
        Object.entries({ action, ajax: '1', csrf: page.dataset.csrf, type: target.type, folder: target.path, ...options })
            .forEach(([key, value]) => body.append(key, value));
        const reply = await fetch(page.dataset.adminUrl, { method: 'POST', body });
        const response = await reply.json();
        if (!reply.ok || !response.ok) throw new Error(response.message || 'Не удалось выполнить действие.');
        return response.files;
    };
    const show = (items) => {
        files = items;
        list.replaceChildren();
        files.forEach(({ name, url }, index) => {
            const item = document.createElement('li');
            item.dataset.position = index;
            const row = document.createElement('div');
            row.className = 'header-actions';
            const handle = document.createElement('button');
            handle.type = 'button';
            handle.className = 'media-drag';
            handle.draggable = true;
            handle.textContent = '⠿';
            handle.setAttribute('aria-label', 'Перетащить ' + name);
            const link = document.createElement('a');
            link.href = url;
            link.target = '_blank';
            link.rel = 'noopener';
            link.textContent = name;
            const position = document.createElement('input');
            position.type = 'number';
            position.min = '1';
            position.max = String(files.length);
            position.value = String(index + 1);
            position.dataset.mediaPosition = '';
            position.setAttribute('aria-label', 'Позиция файла ' + name);
            const remove = document.createElement('button');
            remove.type = 'button';
            remove.dataset.mediaRemove = name;
            remove.textContent = 'Удалить';
            row.append(handle, link, position, remove);
            item.append(row);
            list.append(item);
        });
    };
    const run = async (operation) => {
        const target = folders[Number(select.value)];
        if (busy || !target) return;
        busy = true;
        select.disabled = true;
        upload.disabled = true;
        manager.setAttribute('aria-busy', 'true');
        try {
            await operation(target);
        } catch (error) {
            status.textContent = error.message || 'Не удалось выполнить действие.';
        } finally {
            busy = false;
            select.disabled = false;
            upload.disabled = false;
            manager.removeAttribute('aria-busy');
        }
    };
    const load = () => run(async (target) => {
        status.textContent = 'Загружаем список…';
        show(await api('list-media', target));
        status.textContent = files.length ? '' : 'Папка пуста.';
    });
    const scan = (source) => {
        if (busy) return;
        const selected = folders[Number(select.value)];
        const found = new Map();
        for (const match of source.matchAll(/\[(gal|fotos|files)(?:[\t ][^\]\r\n]*)?\]([^\[\]]+)\[\/\1\]/gi)) {
            const type = match[1].toLowerCase();
            const path = match[2].trim();
            if (path.startsWith('/')) found.set(type + ':' + path, { type, path });
        }
        folders = [...found.values()];
        manager.hidden = folders.length === 0;
        select.replaceChildren(...folders.map((entry, i) => new Option('[' + entry.type + '] ' + entry.path, String(i))));
        const index = folders.findIndex((entry) => selected && entry.type === selected.type && entry.path === selected.path);
        if (folders.length) select.value = String(Math.max(0, index));
        if (manager.open && index === -1) load();
    };
    scan(editor.querySelector('textarea').value);
    editor.querySelector('textarea').addEventListener('input', (event) => scan(event.target.value));
    editor.addEventListener('content-source', (event) => scan(event.detail));
    manager.addEventListener('toggle', () => { if (manager.open) load(); });
    select.addEventListener('change', load);
    upload.addEventListener('click', () => run(async (target) => {
        const selected = [...input.files];
        if (!selected.length) {
            status.textContent = 'Выберите файлы.';
            return;
        }
        const failures = [];
        let saved = 0;
        for (const file of selected) {
            status.textContent = 'Загрузка ' + (saved + failures.length + 1) + ' из ' + selected.length + '…';
            try {
                show(await api('upload-media', target, { upload: file }));
                saved += 1;
            } catch (error) {
                failures.push(file.name + ' — ' + error.message);
            }
        }
        input.value = '';
        status.textContent = 'Загружено: ' + saved + ' из ' + selected.length + '.' + (failures.length ? ' ' + failures.join(' ') : '');
    }));
    list.addEventListener('click', (event) => {
        const button = event.target.closest('[data-media-remove]');
        if (!button || busy || !window.confirm('Удалить файл «' + button.dataset.mediaRemove + '»?')) return;
        run(async (target) => {
            show(await api('delete-media', target, { file: button.dataset.mediaRemove }));
            status.textContent = 'Файл удалён.';
        });
    });
    const move = (from, to) => {
        if (!Number.isInteger(to) || to < 0 || to >= files.length || from === to) return;
        run(async (target) => {
            const order = files.map((file) => file.name);
            order.splice(to, 0, order.splice(from, 1)[0]);
            show(await api('order-media', target, { order: JSON.stringify(order) }));
            status.textContent = 'Порядок сохранён.';
        });
    };
    list.addEventListener('change', (event) => {
        if (event.target.matches('[data-media-position]')) {
            move(Number(event.target.closest('li').dataset.position), Number(event.target.value) - 1);
        }
    });
    list.addEventListener('dragstart', (event) => {
        if (!event.target.matches('.media-drag') || busy) return;
        dragged = Number(event.target.closest('li').dataset.position);
        event.dataTransfer.setData('text/plain', String(dragged));
    });
    list.addEventListener('dragend', () => { dragged = null; });
    list.addEventListener('dragover', (event) => {
        if (dragged !== null && event.target.closest('li')) event.preventDefault();
    });
    list.addEventListener('drop', (event) => {
        const target = event.target.closest('li');
        if (dragged === null || !target) return;
        event.preventDefault();
        move(dragged, Number(target.dataset.position));
        dragged = null;
    });
});

document.querySelectorAll('[data-update-latest]').forEach(async (status) => {
    try {
        const response = await fetch(status.dataset.updateLatest, { headers: { Accept: 'application/json' } });
        const data = await response.json();
        if (!response.ok || !data.ok) {
            status.textContent = data.message;
            return;
        }
        status.querySelector('[data-update-version]').textContent = data.version;
        if (data.cached) {
            status.querySelector('[data-update-label]').textContent = 'Последняя проверенная версия на GitHub';
        }
    } catch {
        status.textContent = 'Не удалось проверить последнюю версию на GitHub.';
    }
});

document.querySelectorAll('[data-font-picker]').forEach((picker) => {
    const summary = picker.querySelector('summary');
    const current = picker.querySelector('[data-font-current]');
    const controls = picker.parentElement.querySelector('[data-font-preview-controls]');
    const language = controls.querySelector('[data-font-preview-language]');
    const phrase = controls.querySelector('[data-font-preview-text]');
    const edited = new Map();
    const refreshSample = () => {
        picker.querySelectorAll('[data-font-sample]').forEach((sample) => { sample.textContent = phrase.value; });
    };
    phrase.addEventListener('input', () => {
        edited.set(language.value, phrase.value);
        refreshSample();
    });
    language.addEventListener('change', () => {
        phrase.value = edited.has(language.value) ? edited.get(language.value) : language.selectedOptions[0].dataset.sample;
        refreshSample();
    });
    const close = () => {
        picker.open = false;
        summary.focus();
    };
    picker.addEventListener('change', (event) => {
        if (!event.target.matches('input[name="font"]')) return;
        const label = event.target.closest('label').querySelector('[data-font-name]');
        current.textContent = label.textContent;
        current.className = label.className;
    });
    picker.addEventListener('click', (event) => {
        if (event.detail > 0 && event.target.matches('input[name="font"]')) close();
    });
    picker.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' || (event.key === 'Enter' && event.target.matches('input[name="font"]'))) {
            event.preventDefault();
            close();
        }
    });
    document.addEventListener('pointerdown', (event) => {
        if (picker.open && !picker.contains(event.target)) picker.open = false;
    });
});

document.addEventListener('beforeinput', (event) => {
    if (!event.data || !(event.target instanceof HTMLInputElement)) return;
    const field = event.target;
    if ((field.matches('[data-identifier-input]') && /[^A-Za-z0-9_-]/.test(event.data))
        || (field.matches('[data-address-input]') && /[^A-Za-z0-9_./-]/.test(event.data))) {
        event.preventDefault();
    }
});

(() => {
    const admin = document.querySelector('[data-page-admin]');
    if (!admin) return;
    const tree = admin.querySelector('[data-page-tree]');
    const status = document.querySelector('[data-page-feedback]');
    const editor = admin.querySelector('[data-page-editor]');
    const move = admin.querySelector('[data-page-move-form]');
    const folderMove = admin.querySelector('[data-folder-move-form]');
    const folders = () => [...tree.querySelectorAll('[data-page-folder]')].map((node) => node.dataset.pageFolder).sort();
    let dragged = null;
    let saving = false;

    const feedback = (message, error = false) => {
        status.textContent = message;
        status.classList.toggle('error', error);
        status.hidden = false;
    };
    const request = async (fields) => {
        if (saving) return false;
        saving = true;
        admin.setAttribute('aria-busy', 'true');
        const oldPath = editor ? editor.dataset.pagePath : '';
        const body = new URLSearchParams({
            ajax: '1', csrf: admin.dataset.csrf,
            current_path: oldPath, current_revision: oldPath ? editor.elements.revision.value : '',
            ...fields,
        });
        try {
            const response = await fetch(admin.dataset.adminUrl, {
                method: 'POST', body, headers: { Accept: 'application/json' },
            });
            const result = await response.json();
            if (!response.ok || !result.ok) {
                feedback(result.message || 'Действие не выполнено.', true);
                return false;
            }
            const open = new Map([...tree.querySelectorAll('[data-page-folder]')].map((folder) => [
                folder.dataset.pageFolder, folder.open,
            ]));
            tree.innerHTML = result.tree;
            tree.querySelectorAll('[data-page-folder]').forEach((folder) => {
                const path = folder.dataset.pageFolder;
                if (result.openFolder === path || (result.openFolder || '').startsWith(path + '/')) {
                    folder.open = true;
                    return;
                }
                if (result.page && result.page.path !== oldPath && result.page.path.startsWith(path + '/')) return;
                if (open.has(path)) folder.open = open.get(path);
            });
            if (oldPath && result.page === null) {
                editor.closest('[data-page-editor-wrapper]').hidden = true;
                editor.dataset.pagePath = '';
                window.history.replaceState(null, '', admin.dataset.adminUrl);
            } else if (oldPath && result.page) {
                const page = result.page;
                editor.dataset.pagePath = page.path;
                editor.elements.path.value = page.address;
                editor.elements.revision.value = page.revision;
                editor.elements.MenuVisible.checked = page.menu;
                if (editor.elements.Order.value === editor.elements.Order.defaultValue) {
                    editor.elements.Order.value = page.order;
                }
                editor.elements.Order.defaultValue = page.order;
                const link = editor.querySelector('[data-page-open]');
                link.href = page.publicUrl;
                link.hidden = page.hidden;
                if (move) {
                    move.setAttribute('action', page.editUrl);
                    move.elements.path.value = page.path;
                    move.elements.revision.value = page.revision;
                }
                if (oldPath !== page.path) window.history.replaceState(null, '', page.editUrl);
            }
            if (move) {
                const list = move.querySelector('datalist');
                list.replaceChildren(...folders().map((folder) => {
                    const option = document.createElement('option');
                    option.value = '/' + folder + '/';
                    return option;
                }));
            }
            feedback(result.message);
            return true;
        } catch (error) {
            feedback('Не удалось получить ответ. Обновите страницу и проверьте результат.', true);
            return false;
        } finally {
            saving = false;
            admin.removeAttribute('aria-busy');
        }
    };
    const rowOf = (element) => element.closest('li[data-page-node]');
    const targetOf = (row) => ({ path: row.dataset.pagePath, revision: row.dataset.pageRevision });
    const ask = {
        hide: 'Скрыть страницу?',
        show: 'Опубликовать страницу?',
        delete: 'Удалить страницу? Это действие нельзя отменить.',
    };

    admin.addEventListener('click', (event) => {
        if (event.target.closest('[data-page-drag]')) event.preventDefault();
        const moveFolderButton = event.target.closest('[data-page-folder-move]');
        if (moveFolderButton) {
            event.preventDefault();
            if (saving) return;
            const source = moveFolderButton.closest('[data-page-folder]').dataset.pageFolder;
            const parent = source.includes('/') ? source.substring(0, source.lastIndexOf('/')) : '';
            const choices = ['', ...folders()].filter((folder) =>
                folder !== parent && folder !== source && !folder.startsWith(source + '/')
            );
            folderMove.elements.path.value = source;
            folderMove.querySelector('[data-folder-move-label]').textContent = 'Переместить /' + source + '/';
            folderMove.elements.folder.replaceChildren(new Option('Выберите папку', ''), ...choices.map((folder) =>
                folder === '' ? new Option('/ (корень сайта)', '/') : new Option('/' + folder + '/', '/' + folder + '/')
            ));
            folderMove.hidden = false;
            folderMove.elements.folder.focus();
            return;
        }
        if (event.target.closest('[data-folder-move-cancel]')) {
            folderMove.hidden = true;
            return;
        }
        const link = event.target.closest('[data-page-action]');
        if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        const operation = link.dataset.pageAction;
        if (!saving && window.confirm(ask[operation])) {
            request({ action: 'change-page-status', operation, ...targetOf(rowOf(link)) });
        }
    });
    admin.addEventListener('change', async (event) => {
        const box = event.target;
        if (!box.matches('[data-page-menu]')) return;
        const checked = box.checked;
        const target = editor && editor.contains(box)
            ? { path: editor.dataset.pagePath, revision: editor.elements.revision.value }
            : targetOf(rowOf(box));
        box.disabled = true;
        const saved = await request({ action: 'page-menu', ...target, visible: checked ? '1' : '0' });
        if (!saved) box.checked = !checked;
        box.disabled = false;
    });
    admin.addEventListener('submit', async (event) => {
        if (saving) {
            event.preventDefault();
            return;
        }
        if (event.target === folderMove) {
            event.preventDefault();
            if (await request(Object.fromEntries(new FormData(folderMove)))) folderMove.hidden = true;
            return;
        }
        if (event.target !== move) return;
        event.preventDefault();
        const values = Object.fromEntries(new FormData(move));
        if (await request(values)) {
            move.elements.folder.value = '';
            move.closest('[data-page-move]').open = false;
        }
    });

    const siblings = (row) => [...row.parentElement.children].filter((item) =>
        item.dataset.pagePath && item.dataset.pagePath !== 'index.php'
    );
    const reorder = async (row, to) => {
        const items = siblings(row);
        const from = items.indexOf(row);
        if (from === to || to < 0 || to >= items.length) return;
        const folder = row.parentElement.dataset.pageGroup;
        const path = row.dataset.pagePath;
        items.splice(from, 1);
        items.splice(to, 0, row);
        if (await request({ action: 'page-order', folder, items: JSON.stringify(items.map(targetOf)) })) {
            const moved = [...tree.querySelectorAll('[data-page-node]')].find((item) => item.dataset.pagePath === path);
            if (moved) {
                const handle = [...moved.querySelectorAll('[data-page-drag]')].find((item) => rowOf(item) === moved);
                if (handle) handle.focus();
            }
        }
    };
    tree.addEventListener('keydown', (event) => {
        const handle = event.target.closest('[data-page-drag]');
        if (!handle || saving || !['ArrowUp', 'ArrowDown'].includes(event.key)) return;
        event.preventDefault();
        const row = rowOf(handle);
        reorder(row, siblings(row).indexOf(row) + (event.key === 'ArrowUp' ? -1 : 1));
    });
    tree.addEventListener('dragstart', (event) => {
        const handle = event.target.closest('[data-page-drag]');
        if (!handle || saving) {
            event.preventDefault();
            return;
        }
        dragged = rowOf(handle);
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', dragged.dataset.pagePath);
        dragged.classList.add('is-moving');
    });
    tree.addEventListener('dragover', (event) => {
        const row = rowOf(event.target);
        if (!dragged || !siblings(dragged).includes(row)) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
    });
    tree.addEventListener('drop', (event) => {
        if (!dragged) return;
        const to = siblings(dragged).indexOf(rowOf(event.target));
        if (to === -1) return;
        event.preventDefault();
        reorder(dragged, to);
    });
    tree.addEventListener('dragend', () => {
        if (dragged) dragged.classList.remove('is-moving');
        dragged = null;
    });
})();

document.querySelectorAll('[data-theme-presets]').forEach((form) => {
    form.addEventListener('submit', (event) => {
        if (event.submitter && event.submitter.value === 'delete-theme-preset' && !window.confirm('Удалить сохранённую тему?')) {
            event.preventDefault();
        }
    });
});

document.querySelectorAll('[data-component-code]').forEach((component) => {
    const example = component.querySelector('[data-component-example]');
    const fields = [...component.querySelectorAll('[data-component-param]')];
    const updateExample = () => {
        const name = component.dataset.componentCode;
        const params = fields.map((field) => field.dataset.componentParam + '=' + field.value).join(' ');
        example.textContent = '[' + name + ' ' + params + ']' + example.dataset.componentExample + '[/' + name + ']';
    };
    component.addEventListener('change', updateExample);
});

(() => {
    const form = document.querySelector('[data-form-config]');
    if (!form) return;

    const rows = form.querySelector('[data-form-rows]');
    const template = form.querySelector('[data-empty-field]');
    const variables = form.querySelector('[data-mail-variables]');
    let mailTarget = form.querySelector('#form-mail-body');
    let nextIndex = rows.children.length;
    const variableCodes = () => {
        const keys = new Set([...rows.querySelectorAll('[data-form-field-key]')]
            .map((input) => input.value.trim()).filter((name) => /^[a-z][a-z0-9_]{0,63}$/.test(name)));
        variables.replaceChildren();
        keys.forEach((name) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.dataset.mailVariable = '{' + name + '}';
            button.textContent = button.dataset.mailVariable;
            variables.append(button);
        });
    };
    const updateOptions = (row) => {
        const select = row.querySelector('[data-field-type]');
        const option = select.selectedOptions[0];
        const type = select.value;
        const length = row.querySelector('[data-field-length]');
        length.max = option.dataset.maxLength;
        length.placeholder = option.dataset.defaultLength;
        row.querySelector('[data-field-options]').hidden = type !== 'radio' && type !== 'select';
    };
    [...rows.children].forEach(updateOptions);
    variableCodes();

    form.addEventListener('focusin', (event) => {
        if (event.target.matches('[data-mail-template]')) mailTarget = event.target;
    });
    variables.addEventListener('click', (event) => {
        const button = event.target.closest('[data-mail-variable]');
        if (!button) return;
        if (document.activeElement.matches('[data-mail-template]')) mailTarget = document.activeElement;
        mailTarget.setRangeText(button.dataset.mailVariable, mailTarget.selectionStart, mailTarget.selectionEnd, 'end');
        mailTarget.focus();
    });
    rows.addEventListener('input', (event) => {
        if (event.target.matches('[data-form-field-key]')) variableCodes();
    });

    form.querySelector('[data-add-field]').addEventListener('click', () => {
        const row = template.content.firstElementChild.cloneNode(true);
        row.querySelectorAll('[name]').forEach((field) => {
            field.name = field.name.replace('__INDEX__', String(nextIndex));
        });
        nextIndex += 1;
        rows.append(row);
        updateOptions(row);
        row.querySelector('input').focus();
    });
    rows.addEventListener('change', (event) => {
        if (event.target.matches('[data-field-type]')) updateOptions(event.target.closest('[data-form-row]'));
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-field]')) {
            event.target.closest('[data-form-row]').remove();
            variableCodes();
        }
    });
})();

(() => {
    const form = document.querySelector('[data-contacts-config]');
    if (!form) return;

    const rows = form.querySelector('[data-phone-rows]');
    const template = form.querySelector('[data-phone-template]');
    let nextIndex = rows.children.length;
    form.querySelector('[data-add-phone]').addEventListener('click', () => {
        const row = template.content.firstElementChild.cloneNode(true);
        row.querySelectorAll('[name]').forEach((input) => {
            input.name = input.name.replace('__INDEX__', String(nextIndex));
        });
        nextIndex += 1;
        rows.append(row);
        row.querySelector('input').focus();
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-phone]')) event.target.closest('[data-phone-row]').remove();
    });
})();

(() => {
    const copy = document.querySelector('[data-copy-iblock]');
    if (!copy) return;

    const csv = document.getElementById('iblock-csv');
    const status = document.querySelector('[data-copy-status]');
    copy.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(csv.value);
            status.textContent = 'CSV скопирован.';
        } catch (error) {
            csv.focus();
            csv.select();
            status.textContent = 'Текст выделен. Нажмите Ctrl+C.';
        }
    });
})();

(() => {
    const form = document.querySelector('[data-iblock-editor]');
    if (!form) return;
    const status = form.querySelector('[data-iblock-status]');
    const submit = form.querySelector('[type="submit"]');
    let saving = false;
    let queued = false;
    const feedback = (message, error = false) => {
        status.textContent = message;
        status.classList.toggle('error', error);
        status.hidden = false;
    };
    const save = async () => {
        if (saving) {
            queued = true;
            return;
        }
        if (!form.reportValidity()) return;

        saving = true;
        submit.disabled = true;
        feedback('Сохраняем инфоблок…');
        const values = new URLSearchParams({ ajax: '1' });
        for (const [name, value] of new FormData(form)) {
            values.append(name, value);
        }
        try {
            const response = await fetch(form.getAttribute('action'), {
                method: 'POST', body: values, headers: { Accept: 'application/json' },
            });
            if (!response.headers.get('Content-Type')?.includes('application/json')) {
                feedback(response.redirected
                    ? 'Сессия завершена. Войдите снова в отдельной вкладке и повторите сохранение.'
                    : 'Сервер вернул неожиданный ответ (HTTP ' + response.status + '). Правки остались в редакторе.', true);
                queued = false;
                return;
            }
            const result = await response.json();
            if (!result.ok) {
                feedback(result.message, true);
                queued = false;
                return;
            }

            form.elements.revision.value = result.revision;
            if (form.dataset.iblockNew === '1') {
                form.dataset.iblockNew = '0';
                form.setAttribute('action', result.url);
                form.elements.id.value = result.id;
                form.elements.id.readOnly = true;
                form.querySelector('[data-iblock-heading-title]').textContent = 'Редактирование инфоблока';
                form.querySelector('[data-iblock-mode-link]').href = result.modeUrl;
                const shortcode = form.querySelector('[data-iblock-shortcode]');
                shortcode.querySelector('code').textContent = result.shortcode;
                shortcode.hidden = false;
                const list = document.querySelector('[data-iblock-list]');
                list.querySelectorAll('[aria-current]').forEach((link) => link.removeAttribute('aria-current'));
                const item = document.createElement('li');
                const link = document.createElement('a');
                link.href = result.url;
                link.textContent = result.id;
                link.setAttribute('aria-current', 'page');
                item.append(link);
                list.append(item);
                const empty = document.querySelector('[data-iblock-empty]');
                if (empty) empty.hidden = true;
                history.replaceState(null, '', result.url);
            }
            feedback(result.message);
        } catch (error) {
            feedback('Ответ о сохранении не получен. Правки остались в редакторе.', true);
            queued = false;
        } finally {
            saving = false;
            submit.disabled = false;
            if (queued) {
                queued = false;
                save();
            }
        }
    };
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        save();
    });
    if (!form.matches('[data-iblock-config]')) return;

    const columns = form.querySelector('[data-iblock-columns]');
    const heading = form.querySelector('[data-iblock-heading]');
    const rows = form.querySelector('[data-iblock-rows]');
    const template = form.querySelector('[data-iblock-column-template]');
    let nextColumn = columns.children.length;
    let nextRow = rows.children.length;

    const cellInput = (cell, column, value = '') => {
        const type = column.querySelector('[data-column-type]').value;
        const row = cell.closest('tr');
        const input = document.createElement({ bool: 'select', textarea: 'textarea' }[type] || 'input');
        input.dataset.cellType = type;
        input.name = 'rows[' + row.dataset.rowIndex + '][' + column.dataset.columnIndex + ']';
        if (type === 'textarea') {
            input.rows = 3;
        } else if (type === 'bool') {
            [['', '—'], ['1', 'Да'], ['0', 'Нет']].forEach(([id, label]) => {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = label;
                input.append(option);
            });
        } else {
            input.type = type === 'price' ? 'text' : type;
            if (type === 'price') {
                input.inputMode = 'decimal';
                input.pattern = '[0-9]{1,15}([.,][0-9]{1,2})?';
            }
            if (type === 'number') {
                input.step = 'any';
                value = value.replace(',', '.');
            }
        }
        input.value = value;
        if (value && input.value === '') {
            input.dataset.previousValue = value;
            input.setCustomValidity('Замените прежнее значение значением нового типа.');
            input.addEventListener('input', () => {
                delete input.dataset.previousValue;
                input.setCustomValidity('');
            }, { once: true });
        }
        cell.replaceChildren(input);
        return input;
    };

    const sync = (column) => {
        const index = column.dataset.columnIndex;
        const label = column.querySelector('[data-column-label]').value || 'Столбец';
        const type = column.querySelector('[data-column-type]').value;
        heading.querySelector('[data-cell-column="' + index + '"]').textContent = label;
        rows.querySelectorAll('[data-cell-column="' + index + '"]').forEach((cell) => {
            let input = cell.firstElementChild;
            if (input.dataset.cellType !== type) {
                input = cellInput(cell, column, input.dataset.previousValue || input.value);
            }
            input.setAttribute('aria-label', label);
        });
    };
    const addCell = (row, column) => {
        const index = column.dataset.columnIndex;
        const cell = document.createElement('td');
        cell.dataset.cellColumn = index;
        row.insertBefore(cell, row.querySelector('[data-iblock-actions]'));
        cellInput(cell, column);
    };

    [...columns.children].forEach(sync);
    form.querySelector('[data-add-column]').addEventListener('click', () => {
        const column = template.content.firstElementChild.cloneNode(true);
        column.dataset.columnIndex = String(nextColumn);
        column.querySelectorAll('[name]').forEach((input) => {
            input.name = input.name.replace('__INDEX__', String(nextColumn));
        });
        const cell = document.createElement('th');
        cell.scope = 'col';
        cell.dataset.cellColumn = String(nextColumn++);
        heading.insertBefore(cell, heading.querySelector('[data-iblock-actions]'));
        columns.append(column);
        [...rows.children].forEach((row) => addCell(row, column));
        sync(column);
        column.querySelector('input').focus();
    });
    form.querySelector('[data-add-row]').addEventListener('click', () => {
        if (!columns.children.length) return;
        const row = document.createElement('tr');
        row.dataset.rowIndex = String(nextRow++);
        const order = document.createElement('td');
        order.className = 'iblock-order';
        const handle = document.createElement('button');
        handle.className = 'iblock-drag';
        handle.type = 'button';
        handle.draggable = true;
        handle.dataset.dragRow = '';
        handle.title = 'Перетащить строку';
        handle.setAttribute('aria-label', 'Переместить строку. Используйте стрелки вверх и вниз');
        handle.textContent = '⠿';
        order.append(handle);
        row.append(order);
        const actions = document.createElement('td');
        actions.dataset.iblockActions = '';
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.dataset.removeRow = '';
        remove.textContent = 'Удалить строку';
        actions.append(remove);
        row.append(actions);
        rows.append(row);
        [...columns.children].forEach((column) => {
            addCell(row, column);
            sync(column);
        });
        row.querySelector('[data-cell-type]').focus();
    });
    columns.addEventListener('input', (event) => {
        if (event.target.matches('[data-column-label], [data-column-type]')) {
            sync(event.target.closest('[data-column-index]'));
        }
    });
    columns.addEventListener('click', (event) => {
        if (!event.target.matches('[data-remove-column]')) return;
        const column = event.target.closest('[data-column-index]');
        const index = column.dataset.columnIndex;
        form.querySelectorAll('[data-cell-column="' + index + '"]').forEach((cell) => cell.remove());
        column.remove();
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-row]')) event.target.closest('tr').remove();
    });

    let dragging;
    let startOrder;
    const order = () => [...rows.children].map((row) => row.dataset.rowIndex).join(',');
    const saveOrder = () => {
        if (form.dataset.iblockNew === '0') save();
    };
    rows.addEventListener('dragstart', (event) => {
        const handle = event.target.closest('[data-drag-row]');
        if (!handle) return;
        dragging = handle.closest('tr');
        startOrder = order();
        dragging.classList.add('is-dragging');
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', dragging.dataset.rowIndex);
    });
    rows.addEventListener('dragover', (event) => {
        const over = event.target.closest('tr');
        if (!dragging || !over || over === dragging) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
        const box = over.getBoundingClientRect();
        if (event.clientY < box.top + box.height / 2) rows.insertBefore(dragging, over);
        else rows.insertBefore(dragging, over.nextElementSibling);
    });
    rows.addEventListener('drop', (event) => {
        if (dragging) event.preventDefault();
    });
    rows.addEventListener('dragend', () => {
        if (!dragging) return;
        dragging.classList.remove('is-dragging');
        dragging = null;
        if (startOrder !== order()) saveOrder();
    });
    rows.addEventListener('keydown', (event) => {
        const handle = event.target.closest('[data-drag-row]');
        if (!handle || !['ArrowDown', 'ArrowUp'].includes(event.key)) return;
        event.preventDefault();
        const row = handle.closest('tr');
        const down = event.key === 'ArrowDown';
        const neighbor = down ? row.nextElementSibling : row.previousElementSibling;
        if (!neighbor) return;
        rows.insertBefore(row, down ? neighbor.nextElementSibling : neighbor);
        handle.focus();
        saveOrder();
    });
})();

document.querySelectorAll('[data-library-dialog]').forEach((dialog) => {
    const frame = dialog.querySelector('iframe');
    document.querySelectorAll('[data-library-test]').forEach((button) => {
        button.addEventListener('click', () => {
            const name = button.dataset.libraryTest;
            const url = new URL(dialog.dataset.testUrl, window.location.href);
            url.searchParams.set('id', name);
            url.searchParams.set('lang', dialog.dataset.interface);
            dialog.querySelectorAll('[data-library-code]').forEach((code) => { code.hidden = code.dataset.libraryCode !== name; });
            frame.src = url.href;
            if (!dialog.open) dialog.showModal();
        });
    });
    dialog.querySelector('[data-library-close]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('close', () => frame.removeAttribute('src'));
});
