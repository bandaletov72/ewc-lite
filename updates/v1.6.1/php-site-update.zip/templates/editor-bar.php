<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$editText = static function (string $text) use ($locale): string {
    return site_escape(site_translation($text, $locale));
};
$editAdmin = site_url($base, 'admin/');
$editPath = $searchMode ? '' : $page['path'];
$editUrl = $editAdmin . '?' . http_build_query(['page' => site_page_url('', $editPath)]);
$editParent = $editPath !== '' && dirname($originalPath) !== '.' ? dirname($originalPath) : '';
$editHidden = '<input type="hidden" name="csrf" value="' . site_escape($editor['csrf']) . '">'
    . '<input type="hidden" name="path" value="' . site_escape($editPath) . '">'
    . '<input type="hidden" name="revision" value="' . site_escape($page['revision'] ?? '') . '">';
?>
<nav class="editor-bar" aria-label="<?= $editText('Панель администратора') ?>">
    <a href="<?= site_escape($editAdmin) ?>"><?= $editText('Админка') ?></a>
    <?php if ($editPath !== ''): ?>
        <a href="<?= site_escape($editUrl) ?>"><?= $editText('Править страницу') ?></a>
        <a href="<?= site_escape($editAdmin . '?new=1&parent=' . rawurlencode($editParent)) ?>"><?= $editText('Новый раздел') ?></a>
        <a href="<?= site_escape($editAdmin . '?components=1') ?>"><?= $editText('Компоненты') ?></a>
        <a href="<?= site_escape($editAdmin . '?layout=1') ?>"><?= $editText('Шаблоны оформления') ?></a>
        <a href="<?= site_escape($editAdmin . '?snippets=1') ?>"><?= $editText('Подшаблоны') ?></a>
        <?php foreach (['CSS', 'JS'] as $asset): ?>
            <button type="button" data-show-page-dialog="page-asset-<?= $asset ?>"><?= $asset ?></button>
        <?php endforeach; ?>
        <form method="post" action="<?= site_escape($editAdmin) ?>">
            <?= $editHidden ?>
            <input type="hidden" name="visible" value="<?= $page['fields']['MenuVisible'] === '1' ? '0' : '1' ?>">
            <button name="action" value="live-page-menu"><?= $editText($page['fields']['MenuVisible'] === '1' ? 'Убрать из меню' : 'Показать в меню') ?></button>
        </form>
        <a href="<?= site_escape($editUrl . '&confirm=hide') ?>"><?= $editText('Скрыть') ?></a>
        <?php if ($editPath !== 'index.php'): ?>
            <a href="<?= site_escape($editUrl . '&confirm=delete') ?>"><?= $editText('Удалить') ?></a>
        <?php endif; ?>
    <?php endif; ?>
    <form class="editor-bar-toggle" method="post" action="<?= site_escape($editAdmin) ?>">
        <?= $editHidden ?>
        <input type="hidden" name="enabled" value="<?= $editor['edit'] ? '0' : '1' ?>">
        <button name="action" value="public-edit-mode" role="switch" aria-checked="<?= $editor['edit'] ? 'true' : 'false' ?>">
            <?= $editText('Режим правки') ?> · <?= $editText($editor['edit'] ? 'Вкл.' : 'Выкл.') ?>
        </button>
    </form>
</nav>
<?php if ($editPath !== ''): ?>
    <?php foreach (['CSS' => 'css', 'JS' => 'javascript'] as $asset => $syntax): ?>
        <dialog class="editor-dialog" id="page-asset-<?= $asset ?>" aria-labelledby="page-asset-title-<?= $asset ?>">
            <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>">
                <div class="header-actions editor-dialog-heading">
                    <h2 id="page-asset-title-<?= $asset ?>"><?= $asset ?> · <?= site_escape($heading) ?></h2>
                    <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
                </div>
                <?= $editHidden ?>
                <input type="hidden" name="asset" value="<?= $asset ?>">
                <textarea name="code" aria-label="<?= $asset ?>" class="short-editor" data-code-mode="<?= $syntax ?>" spellcheck="false" rows="16"><?= "\n" . site_escape(site_asset_decode($page['fields'][$asset] ?? '') ?? '') ?></textarea>
                <div><button class="button-primary" name="action" value="live-page-asset"><?= $editText('Сохранить') ?></button></div>
            </form>
        </dialog>
    <?php endforeach; ?>
<?php endif; ?>
<?php if ($inline): ?>
    <?php $inlineComponents = site_inline_components($page['html'], $components['extensions'], $snippets); ?>
    <?php if ($inlineComponents): ?>
        <dialog class="editor-dialog" id="page-inline-editor" aria-labelledby="page-inline-title">
            <div class="header-actions editor-dialog-heading">
                <h2 id="page-inline-title"><?= $editText('Компоненты страницы') ?></h2>
                <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
            </div>
            <?php $inlineSchema = site_component_schema(); ?>
            <?php foreach ($inlineComponents as $index => $item): ?>
                <?php $inlineCode = $item['code']; ?>
                <details id="inline-component-<?= $index ?>" class="inline-component-entry">
                    <summary><code><?= site_escape(site_search_clip($inlineCode, 145)) ?></code></summary>
                    <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>" data-inline-editor="<?= site_escape($item['kind']) ?>">
                        <?= $editHidden ?>
                        <input type="hidden" name="index" value="<?= $index ?>">
                        <div class="fields">
                            <?php foreach (site_inline_editor_fields($item) as $field => list($label, $value)): ?>
                                <label class="field"><?= $editText($label) ?>
                                    <input data-inline-field="<?= site_escape($field) ?>" value="<?= site_escape($value) ?>" maxlength="500">
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <?php if (in_array($item['kind'], ['gal', 'fotos', 'files'], true)): ?>
                            <?php preg_match_all('/([a-z0-9_-]+)=([a-z0-9_-]+)%?/i', $item['options'], $optionsFound, PREG_SET_ORDER); ?>
                            <?php $selectedOptions = array_column($optionsFound, 2, 1); ?>
                            <div class="fields">
                                <?php foreach ($inlineSchema[$item['kind']]['settings'] as $name => $option): ?>
                                    <label class="field"><?= $editText($option['label']) ?>
                                        <select data-inline-option="<?= site_escape($name) ?>">
                                            <option value=""><?= $editText('По умолчанию') ?></option>
                                            <?php foreach ($option['options'] as $value => $label): ?>
                                                <option value="<?= site_escape((string) $value) ?>"<?= (string) $value === ($selectedOptions[$name] ?? null) ? ' selected' : '' ?>><?= $editText($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <label class="field"><?= $editText('Код вставки') ?>
                            <textarea name="code" rows="3" maxlength="4000" spellcheck="false"><?= "\n" . site_escape($inlineCode) ?></textarea>
                        </label>
                        <div><button class="button-primary" name="action" value="live-component"><?= $editText('Сохранить') ?></button></div>
                    </form>
                </details>
            <?php endforeach; ?>
        </dialog>
    <?php endif; ?>
<?php endif; ?>
