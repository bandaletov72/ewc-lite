<?php
header('Content-Type: text/html; charset=UTF-8');
header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
header('X-Content-Type-Options: nosniff');
?>
<!doctype html>
<html><head><meta charset="UTF-8"><title>Визуальный редактор</title></head><body></body></html>
