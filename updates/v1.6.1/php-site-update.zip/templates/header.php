<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<a class="brand" href="<?= site_escape(site_url($base)) ?>"><?= site_brand_logo_html($brand, $base) ?><?= $brand['logo'] !== '' || $brand['logo_dark'] !== '' ? ' ' : '' ?><?= site_escape($settings['name']) ?></a>
<nav class="site-menu desktop-menu" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
    <?php require site_template_file('navigation-links.php'); ?>
</nav>
