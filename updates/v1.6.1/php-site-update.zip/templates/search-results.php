<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if (!isset($searchIndex['built'])): ?>
    <p><?= site_escape(site_translation('Поиск пока недоступен.', $locale)) ?></p>
<?php elseif ($searchQuery === ''): ?>
    <p><?= site_escape(site_translation('Введите запрос.', $locale)) ?></p>
<?php elseif (!$searchResults): ?>
    <p><?= site_escape(site_translation('Ничего не найдено.', $locale)) ?></p>
<?php else: ?>
    <ul class="site-search-results">
        <?php foreach ($searchResults as $result): ?>
            <li>
                <a href="<?= site_escape(site_page_url($base, $result['path'])) ?>"><?= site_escape($result['title']) ?></a>
                <?php if ($result['description'] !== ''): ?><p><?= site_escape($result['description']) ?></p><?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
