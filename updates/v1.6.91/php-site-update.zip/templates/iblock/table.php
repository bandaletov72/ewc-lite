<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$hasTagFilters = !empty($tagLabels);
$columnClasses = array_map(static function (array $column): string {
    if (in_array($column['type'], ['price', 'number'], true)) return ' class="iblock-number"';
    return $column['type'] === 'form' ? ' class="iblock-action"' : '';
}, $block['columns']);
?>
<?php if ($hasTagFilters): ?>
<div data-iblock-filter>
    <div class="iblock-tag-buttons" data-iblock-tag-buttons role="group" aria-label="<?= site_escape(site_translation('Фильтр по тегам', $locale)) ?>" hidden>
        <button type="button" data-iblock-tag="" aria-pressed="true"><?= site_escape(site_translation('ВСЕ', $locale)) ?></button>
        <?php foreach ($tagLabels as $tagId => $label): ?>
            <button type="button" data-iblock-tag="<?= $tagId ?>" aria-pressed="false">#<?= site_escape($label) ?></button>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<div class="iblock-table-wrap content-iblock-table" tabindex="0">
    <table class="iblock-table">
        <thead><tr>
            <?php foreach ($block['columns'] as $index => $column): ?>
                <th scope="col"<?= $columnClasses[$index] ?>><?= site_escape($column['label']) ?></th>
            <?php endforeach; ?>
        </tr></thead>
        <tbody>
            <?php foreach ($block['rows'] as $rowIndex => $row): ?>
                <tr<?= $hasTagFilters ? ' data-iblock-row-tags="' . site_escape(implode(' ', $rowTags[$rowIndex] ?? [])) . '"' : '' ?>>
                    <?php foreach ($block['columns'] as $index => $column): ?>
                        <?php
                        $value = $row[$index] ?? '';
                        $cell = $column['type'] === 'form' && isset($iblockContext)
                            ? site_render_action_button(['action' => 'form', 'form' => $value, 'label' => site_translation('Заказать', $locale)], $iblockContext)
                            : site_iblock_cell($value, $column['type']);
                        ?>
                        <td<?= $columnClasses[$index] ?>><?= $cell ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php if ($hasTagFilters): ?></div><?php endif; ?>
