<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<dialog class="editor-dialog component-data-dialog" id="page-component-data" aria-labelledby="page-component-data-label">
    <div class="header-actions editor-dialog-heading">
        <h2 id="page-component-data-label"><?= site_escape($editSettingsText) ?></h2>
        <a class="button" data-component-data-wide target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
        <button class="dialog-close" type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>"></button>
    </div>
    <?php $frameLabels = site_component_frame_labels($editor['language']); ?>
    <div class="form-stack" data-component-frame-status hidden>
        <p class="notice" role="status" data-component-frame-message
            data-loading="<?= site_escape($frameLabels[0]) ?>" data-error="<?= site_escape($frameLabels[1]) ?>"></p>
        <div><button type="button" data-component-frame-retry hidden><?= site_escape($frameLabels[2]) ?></button></div>
    </div>
    <iframe data-component-data-iframe title="<?= site_escape($editSettingsText) ?>"></iframe>
</dialog>
