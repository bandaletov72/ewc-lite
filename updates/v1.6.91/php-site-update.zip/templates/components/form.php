<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php
$captcha = site_captcha_settings($form);
$phoneProfile = site_phone_profile();
$phonePlaceholder = $phoneProfile['code'] === '7' ? '+7(900)123-45-67' : '+' . $phoneProfile['code'];
?>
<?php if (empty($session['token'])): ?>
    <p>Форма временно недоступна.</p>
<?php else: ?>
    <form class="contact-form panel form-stack" method="post" action="<?= site_escape(site_url($base, 'form/')) ?>" data-contact-form
        data-phone-profile="<?= site_escape((string) json_encode($phoneProfile)) ?>"
        data-phone-error="<?= site_escape(site_translation('Укажите полный номер телефона, включая код страны.', $context['locale'] ?? 'ru')) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape(site_form_signature($session['token'], $id, $page)) ?>">
        <input type="hidden" name="form" value="<?= site_escape($id) ?>">
        <input type="hidden" name="page" value="<?= site_escape($page) ?>">
        <div hidden><label>Сайт <input name="website" type="text" tabindex="-1" autocomplete="off"></label></div>
        <?php foreach ($form['fields'] as $field): ?>
            <?php
            $fieldId = $instance . '-' . $field['name'];
            $name = 'fields[' . $field['name'] . ']';
            $fieldAttrs = ' name="' . site_escape($name) . '" aria-describedby="' . site_escape($fieldId . '-error') . '"'
                . ($field['required'] ? ' required' : '');
            ?>
            <div class="field" data-message-field="<?= site_escape($field['name']) ?>">
                <?php if ($field['type'] === 'radio'): ?>
                    <fieldset<?= !empty($form['showRatingStars']) ? ' class="review-rating"' : '' ?>>
                        <legend><?= site_escape($field['label']) ?></legend>
                        <?php foreach ($field['options'] as $option): ?>
                            <?php if (!empty($form['showRatingStars'])): ?>
                                <label>
                                    <input type="radio"<?= $fieldAttrs ?> value="<?= site_escape($option) ?>"
                                        aria-label="<?= site_escape(sprintf($labels[4], $option)) ?>">
                                    <span aria-hidden="true">★</span>
                                </label>
                            <?php else: ?>
                                <label class="choice"><input type="radio"<?= $fieldAttrs ?> value="<?= site_escape($option) ?>"> <?= site_escape($option) ?></label>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </fieldset>
                <?php else: ?>
                    <label for="<?= site_escape($fieldId) ?>"><?= site_escape($field['label']) ?></label>
                    <?php if ($field['type'] === 'textarea'): ?>
                        <textarea id="<?= site_escape($fieldId) ?>"<?= $fieldAttrs ?> rows="5" maxlength="<?= site_form_field_length($field) ?>"></textarea>
                    <?php elseif ($field['type'] === 'select'): ?>
                        <select id="<?= site_escape($fieldId) ?>"<?= $fieldAttrs ?>>
                            <option value="">Выберите вариант</option>
                            <?php foreach ($field['options'] as $option): ?>
                                <option value="<?= site_escape($option) ?>"><?= site_escape($option) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <input id="<?= site_escape($fieldId) ?>" type="<?= site_escape($field['type']) ?>"<?= $fieldAttrs ?>
                            maxlength="<?= site_form_field_length($field) ?>"
                            <?= $field['type'] === 'tel' ? 'autocomplete="tel" placeholder="' . site_escape($field['placeholder'] ?? $phonePlaceholder) . '" pattern="\+7\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}|\+[1-68-9][0-9]{6,14}"' : '' ?>
                            <?= $field['type'] === 'email' ? 'autocomplete="email" pattern="[^@\s]+@[^@\s]+\.[^@\s]+" title="Введите email в формате name@example.ru"' : '' ?>>
                    <?php endif; ?>
                <?php endif; ?>
                <small class="field-error" id="<?= site_escape($fieldId . '-error') ?>" data-field-error hidden></small>
            </div>
        <?php endforeach; ?>
        <?php if ($captcha['enabled']): ?>
            <div data-form-captcha data-sitekey="<?= site_escape($captcha['sitekey']) ?>"></div>
            <p class="hint" data-captcha-status role="status">Подтвердите, что вы не робот.</p>
        <?php endif; ?>
        <div><button class="button-primary" type="submit" disabled><?= site_escape($form['button']) ?></button></div>
        <p class="notice" role="status" data-form-feedback hidden></p>
        <noscript><p>Для отправки формы включите JavaScript.</p></noscript>
    </form>
<?php endif; ?>
