<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<section id="<?= site_escape($anchor) ?>" class="site-reviews" aria-labelledby="<?= site_escape($anchor . '-title') ?>">
    <h2 id="<?= site_escape($anchor . '-title') ?>"><?= site_escape($labels[0]) ?></h2>
    <div class="review-list" data-review-list>
        <?php foreach ($rows as $row): ?>
            <article class="panel">
                <h3><?= site_escape($row['name']) ?></h3>
                <p class="review-score" role="img" aria-label="<?= site_escape(sprintf($labels[4], $row['rating'])) ?>">
                    <span aria-hidden="true"><?= site_review_stars((int) $row['rating']) ?></span>
                </p>
                <p class="review-text"><?= site_escape($row['review']) ?></p>
            </article>
        <?php endforeach; ?>
    </div>
    <?php if (!$rows): ?><p><?= site_escape($labels[7]) ?></p><?php endif; ?>
    <?php if ($url !== ''): ?>
        <a class="button" data-reviews-more data-load-error="<?= site_escape($labels[13]) ?>" href="<?= site_escape($url) ?>"><?= site_escape($labels[8]) ?></a>
    <?php endif; ?>
    <p data-reviews-feedback role="status" hidden></p>
    <div class="review-form-action">
        <?php
        ob_start();
        require site_template_file('components/form.php');
        $body = (string) ob_get_clean();
        $label = $labels[9];
        $options = ['hideButton' => !$showButton];
        require site_template_file('components/action-button.php');
        ?>
    </div>
</section>
