<?php if (!defined('SITE_ROOT')) exit; ?>
<?php if (empty($options['hideButton'])): ?>
<button class="button-primary" type="button" data-action-open="<?= site_escape($dialogId) ?>" aria-haspopup="dialog"><?= site_escape($label) ?></button>
<?php endif; ?>
<dialog class="editor-dialog" data-action-dialog id="<?= site_escape($dialogId) ?>" aria-labelledby="<?= site_escape($dialogId . '-title') ?>">
    <div class="header-actions editor-dialog-heading">
        <h2 id="<?= site_escape($dialogId . '-title') ?>"><?= site_escape($options['title'] ?? $label) ?></h2>
        <button class="dialog-close" type="button" data-action-close aria-label="<?= site_escape(site_translation('Закрыть', $locale)) ?>"></button>
    </div>
    <?= $body ?>
</dialog>
