<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

header('Content-Type: text/css; charset=UTF-8');
header('Cache-Control: no-cache');
header('X-Content-Type-Options: nosniff');
$theme = site_theme_settings(($_GET['scope'] ?? '') === 'admin');
$preview = $_GET['preview_mode'] ?? '';
if (in_array($preview, ['auto', 'dark', 'light'], true)) {
    $theme['mode'] = $preview;
}
$scheme = $theme['mode'] === 'dark' ? 'dark' : 'light';
echo site_theme_css($scheme, $theme[$scheme]);
if ($theme['mode'] === 'auto') {
    echo "@media (prefers-color-scheme: dark) {\n", site_theme_css('dark', $theme['dark']), "}\n";
}
