<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_city_domains(string $host): array
{
    $urlHost = parse_url(site_settings()['publicUrl'], PHP_URL_HOST);
    $domains = [];
    foreach (array_merge(site_read_record(SITE_DOMAINS_FILE), [$host, $urlHost]) as $domain) {
        if (is_string($domain) && site_normalize_domain($domain) === $domain && $domain !== '') {
            $domains[$domain] = $domain;
        }
    }
    asort($domains, SORT_STRING);
    return array_values($domains);
}

function admin_city_draft(array $input): array
{
    $phones = site_city_rows();
    foreach ($phones as $index => $row) {
        $entry = $input['phones'][$index] ?? [];
        if (is_array($entry)) {
            $phones[$index] = [
                'label' => trim(admin_input($entry, 'label')),
                'phone' => trim(admin_input($entry, 'phone')),
            ];
        }
    }
    return ['name' => trim(admin_input($input, 'name')), 'domain' => admin_input($input, 'domain'), 'phones' => $phones,
        'email' => admin_input($input, 'email'),
        'address' => trim(admin_input($input, 'address')),
        'publicEmail' => trim(admin_input($input, 'publicEmail')),
        'hours' => trim(admin_input($input, 'hours')),
        'channels' => admin_contact_channel_draft(is_array($input['channels'] ?? null) ? $input['channels'] : [])];
}

function admin_save_city(string $id, array $city, string $revision, string $host, string $language): string
{
    $labels = site_city_language($language);
    $texts = array_column($city['phones'], 'label');
    $texts[] = $city['name'];
    $texts[] = $city['address'];
    $texts[] = $city['hours'];
    foreach ($texts as $value) {
        if (strlen($value) > 480 || preg_match('/\A[^\p{Cc}]*\z/u', $value) !== 1) {
            throw new RuntimeException($labels['invalid']);
        }
    }
    foreach ($city['phones'] as &$row) {
        if ($row['phone'] === '' || preg_match('~\A' . SITE_SNIPPET_TOKEN . '\z~i', $row['phone'])) continue;
        $row['phone'] = $row['phone'][0] === '+' ? site_normalize_form_phone($row['phone']) : '';
        if ($row['phone'] === '') throw new RuntimeException($labels['phoneFormat']);
    }
    unset($row);
    $city['email'] = admin_message_recipients($city['email'], $language);
    if ($city['publicEmail'] !== '' && (strlen($city['publicEmail']) > 254 || !filter_var($city['publicEmail'], FILTER_VALIDATE_EMAIL))) {
        throw new RuntimeException(site_header_contact_labels($language)[4]);
    }
    $city['channels'] = admin_validate_contact_channels($city['channels']);
    $lock = admin_lock();
    try {
        $cities = site_cities();
        if (!hash_equals(admin_settings_revision($cities), $revision)) {
            throw new RuntimeException(admin_l('Настройки изменились. Скопируйте правки и откройте раздел заново.'));
        }
        if ($city['name'] === '' || ($id !== 'new' && !isset($cities[$id]))
            || ($city['domain'] !== '' && !in_array($city['domain'], admin_city_domains($host), true))) {
            throw new RuntimeException($labels['invalid']);
        }
        foreach ($cities as $existingId => $existing) {
            if ($city['domain'] !== '' && $id !== $existingId && $existing['domain'] === $city['domain']) {
                throw new RuntimeException($labels['invalid']);
            }
        }
        $id = $id === 'new' ? 'city-' . bin2hex(random_bytes(8)) : $id;
        $cities[$id] = $city;
        admin_write_record(site_content_record(SITE_CITIES_FILE), $cities, SITE_CITIES_LIMIT);
        return $id;
    } finally {
        fclose($lock);
    }
}

function admin_delete_city(string $id, string $revision)
{
    $lock = admin_lock();
    try {
        $cities = site_cities();
        if (!isset($cities[$id]) || !hash_equals(admin_settings_revision($cities), $revision)) {
            throw new RuntimeException(admin_l('Настройки изменились. Скопируйте правки и откройте раздел заново.'));
        }
        unset($cities[$id]);
        admin_write_record(site_content_record(SITE_CITIES_FILE), $cities, SITE_CITIES_LIMIT);
    } finally {
        fclose($lock);
    }
}
