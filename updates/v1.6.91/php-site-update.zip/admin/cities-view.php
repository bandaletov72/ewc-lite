<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$labels = site_city_language($adminLanguage);
$contactLabels = site_city_contact_labels($adminLanguage);
try {
    $cities = site_cities();
    $availableDomains = admin_city_domains($currentHost);
} catch (RuntimeException $exception) {
    echo '<p class="notice error" role="alert">' . admin_l($exception->getMessage()) . '</p>';
    return;
}
$selected = $cityDraftId ?? admin_input($_GET, 'city');
if ($selected !== 'new' && !isset($cities[$selected])) $selected = key($cities) ?? 'new';
$city = $cityDraft ?? ($cities[$selected] ?? ['name' => '', 'domain' => '', 'phones' => site_city_rows()]);
$domains = array_diff($availableDomains, array_column(array_diff_key($cities, [$selected => true]), 'domain'));
if ($city['domain'] !== '' && !in_array($city['domain'], $domains, true)) $domains[] = $city['domain'];
?>
<h1><?= site_escape($labels['cities']) ?></h1>
<nav class="site-menu scope-menu" aria-label="<?= site_escape($labels['cities']) ?>">
    <?php foreach ($cities as $id => $item): ?>
        <a href="<?= site_escape($citiesUrl . '&city=' . $id) ?>"<?= $id === $selected ? ' aria-current="page"' : '' ?>><?= site_escape($item['name']) ?></a>
    <?php endforeach; ?>
    <a href="<?= site_escape($citiesUrl . '&city=new') ?>"<?= $selected === 'new' ? ' aria-current="page"' : '' ?>>+ <?= site_escape($labels['add']) ?></a>
</nav>
<form class="panel form-stack" method="post" action="<?= site_escape($citiesUrl . '&city=' . $selected) ?>">
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($cities)) ?>">
    <input type="hidden" name="action" value="save-city">
    <input type="hidden" name="city" value="<?= site_escape($selected) ?>">
    <label class="field"><?= site_escape($labels['name']) ?>
        <input name="name" required maxlength="120" value="<?= site_escape($city['name']) ?>">
    </label>
    <label class="field"><?= site_escape($labels['domain']) ?>
        <select name="domain">
            <option value=""><?= site_escape($labels['unbound']) ?></option>
            <?php foreach ($domains as $domain): ?>
                <option value="<?= site_escape($domain) ?>"<?= $domain === $city['domain'] ? ' selected' : '' ?>><?= site_escape($domain) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label class="field"><?= site_escape($contactLabels[1]) ?>
        <input type="email" name="email" multiple maxlength="<?= SITE_MAIL_ADDRESS_LIMIT ?>"
            value="<?= site_escape($city['email'] ?? '') ?>" placeholder="city@example.com">
        <small class="hint"><?= site_escape($contactLabels[2]) ?></small>
    </label>
    <?php $headerContactLabels = site_header_contact_labels($adminLanguage);
    $headerFieldLabels = array_combine(array_keys(site_header_contact_keys()), array_slice($headerContactLabels, 0, 3)); ?>
    <div class="fields">
        <?php foreach (site_header_contact_keys() as $code => $key): ?>
            <label class="field"><?= site_escape($headerFieldLabels[$code]) ?>
                <code>[<?= site_escape($code) ?>]</code>
                <input name="<?= site_escape($key) ?>" type="<?= $code === 'email' ? 'email' : 'text' ?>"
                    maxlength="<?= $code === 'email' ? 254 : 120 ?>" value="<?= site_escape($city[$key] ?? '') ?>">
            </label>
        <?php endforeach; ?>
    </div>
    <p class="hint"><?= site_escape($headerContactLabels[3]) ?></p>
    <?php foreach ($city['phones'] as $index => $row): ?>
        <details class="field-config disclosure-panel"<?= $error !== '' ? ' open' : '' ?>>
            <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= site_escape($labels['phone']) ?> <?= $index + 1 ?>
                <?php if ($row['label'] !== ''): ?><span><?= site_escape($row['label']) ?></span><?php endif; ?>
                <code>[<?= site_escape(site_city_phone_tokens()[$index]) ?>]</code></summary>
            <div class="form-stack">
            <label class="field"><?= site_escape($labels['label']) ?>
                <input name="phones[<?= $index ?>][label]" maxlength="120" value="<?= site_escape($row['label']) ?>">
            </label>
            <label class="field"><?= site_escape($labels['phone']) ?>
                <input type="tel" inputmode="text" name="phones[<?= $index ?>][phone]" maxlength="66" value="<?= site_escape($row['phone']) ?>"
                    placeholder="+7 (900) 000-00-00" data-city-phone-input aria-describedby="city-phone-<?= $index ?>-error city-fields-hint">
                <small id="city-phone-<?= $index ?>-error" class="notice error" aria-live="polite" data-city-phone-error hidden><?= site_escape($labels['phoneFormat']) ?></small>
            </label>
            </div>
        </details>
    <?php endforeach; ?>
    <details class="field-config disclosure-panel"<?= $error !== '' ? ' open' : '' ?>>
        <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= site_escape($contactLabels[3]) ?></summary>
        <div class="form-stack">
            <p class="hint"><?= site_escape($contactLabels[5]) ?></p>
            <?php foreach (site_channels() as $key => $name): ?>
                <?php $channel = $city['channels'][$key] ?? []; ?>
                <fieldset class="fields">
                    <legend><?= site_escape($name) ?></legend>
                    <label class="field">URL
                        <input type="url" name="channels[<?= $key ?>][url]" maxlength="2048" value="<?= site_escape($channel['url'] ?? '') ?>">
                    </label>
                    <label class="field"><?= site_escape($labels['label']) ?>
                        <input name="channels[<?= $key ?>][text]" maxlength="120" value="<?= site_escape($channel['text'] ?? '') ?>">
                    </label>
                </fieldset>
            <?php endforeach; ?>
        </div>
    </details>
    <p class="hint" id="city-fields-hint"><?= site_escape($labels['optional']) ?></p>
    <div><button type="submit" class="button-primary"><?= admin_l('Сохранить') ?></button></div>
    <?php if ($selected !== 'new'): ?>
        <details class="field-config disclosure-panel">
            <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= admin_l('Удалить') ?></summary>
            <div class="header-actions">
                <strong><?= site_escape($city['name']) ?></strong>
                <button type="submit" name="delete_city" value="1" formnovalidate><?= admin_l('Подтвердить удаление') ?></button>
            </div>
        </details>
    <?php endif; ?>
</form>
