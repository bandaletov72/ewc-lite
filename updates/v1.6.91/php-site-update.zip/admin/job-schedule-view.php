<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<fieldset>
    <legend><?= site_escape($scheduleLabels[3]) ?></legend>
    <div class="header-actions">
        <?php foreach (explode('|', $scheduleLabels[17]) as $day => $name): ?>
            <label class="choice"><input type="checkbox" name="days[]" value="<?= $day + 1 ?>"<?= in_array($day + 1, $schedule['days'], true) ? ' checked' : '' ?>> <?= site_escape($name) ?></label>
        <?php endforeach; ?>
    </div>
</fieldset>
<div class="fields">
    <label class="field"><?= site_escape($scheduleLabels[4]) ?><input type="time" name="from" required value="<?= site_escape($schedule['from']) ?>"></label>
    <label class="field"><?= site_escape($scheduleLabels[5]) ?><input type="time" name="to" required value="<?= site_escape($schedule['to']) ?>"></label>
</div>
<p class="hint"><?= site_escape($scheduleLabels[6]) ?> <code><?= site_escape(date_default_timezone_get()) ?></code>.</p>
<p class="hint"><?= admin_l('Добавьте команду в планировщик сервера с запуском каждые 15 минут.') ?> <code>php update.php --scheduled</code></p>
<div><button class="button-primary" type="submit"><?= admin_l('Сохранить') ?></button></div>
