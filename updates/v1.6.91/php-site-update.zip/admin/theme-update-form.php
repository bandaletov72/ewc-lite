<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
    <p class="hint"><?= site_escape($updateLabels[1]) ?></p>
    <form class="form-stack" method="post" action="<?= site_escape($themeUpdateUrl) ?>" data-update-stream>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="action" value="design-update">
        <input type="hidden" name="theme" value="<?= site_escape($selected) ?>">
        <fieldset>
            <legend><?= site_escape($updateLabels[2]) ?></legend>
            <label class="choice"><input name="update_mode" type="radio" value="design" checked> <?= site_escape($updateLabels[3]) ?></label>
            <label class="choice"><input name="update_mode" type="radio" value="pages"> <?= site_escape($updateLabels[4]) ?></label>
            <?php if ($selected === 'dezinfektori'): ?>
                <label class="choice"><input name="update_mode" type="radio" value="missing"> <?= site_escape($updateLabels[7]) ?></label>
            <?php endif; ?>
        </fieldset>
        <p class="hint"><?= site_escape($updateLabels[5]) ?></p>
        <label class="choice"><input type="checkbox" name="confirm_replace" value="1"> <?= site_escape($updateLabels[6]) ?></label>
        <div><button class="button-primary" type="submit"><?= site_escape($updateLabels[0]) ?></button></div>
        <?php require __DIR__ . '/update-progress-view.php'; ?>
    </form>
