<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<section class="panel form-stack" id="theme-demo">
    <h2><?= site_escape($storeLabels[10] . ' · ' . $demoItem['name']) ?></h2>
    <?php if ($storeUnavailable): ?><p role="status"><?= site_escape($storeLabels[1]) ?></p><?php endif; ?>
    <?php if ($demoProducts): ?>
        <?php $demoReady = site_shop_enabled() && function_exists('shop_decode_tables'); ?>
        <form class="form-stack" method="post" data-theme-demo data-update-stream
            action="<?= site_escape($designUrl . '&store=1&demo=' . rawurlencode($demoId) . '#theme-demo') ?>">
            <input type="hidden" name="action" value="theme-store-demo">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="theme" value="<?= site_escape($demoId) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($demoItem['sha256']) ?>">
            <input type="hidden" name="catalog_revision" value="<?= site_escape(site_shop_enabled() ? shop_generation() : '') ?>">
            <fieldset class="form-stack theme-demo-selection">
            <label hidden class="choice"><input type="checkbox" data-theme-demo-all checked> <?= site_escape($storeLabels[13]) ?></label>
            <div class="theme-demo-options">
                <?php foreach ($demoProducts as $number => $product): ?>
                    <label class="choice">
                        <input type="checkbox" name="products[]" value="<?= $number ?>" checked>
                        <span><?= site_escape($product['name']) ?></span>
                        <small><?= site_escape(site_format_number((string) $product['price'])) ?> ₽</small>
                    </label>
                <?php endforeach; ?>
            </div>
            <p class="hint"><?= site_escape($storeLabels[15]) ?></p>
            <label class="choice"><input type="checkbox" name="confirm_replace" value="1" required> <?= site_escape($storeLabels[14]) ?></label>
            </fieldset>
            <?php if (!$demoReady): ?><p class="hint"><?= site_escape($storeLabels[site_shop_enabled() ? 27 : 11]) ?></p><?php endif; ?>
            <div><button type="submit" class="button-primary"<?= $demoReady ? '' : ' disabled data-module-disabled="1"' ?>><?= site_escape($storeLabels[10]) ?></button></div>
            <?php $demoProgressLabel = $storeLabels[21]; require __DIR__ . '/update-progress-view.php'; unset($demoProgressLabel); ?>
        </form>
    <?php endif; ?>
</section>
