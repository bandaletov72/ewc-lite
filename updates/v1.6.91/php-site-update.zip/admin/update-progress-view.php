<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }
$progressLabels = admin_update_progress_labels($adminLanguage);
?>
<section class="update-progress form-stack" data-update-progress data-start="<?= site_escape($demoProgressLabel ?? $progressLabels[($progressMode ?? '') === 'index' ? 'index-start' : 'start']) ?>"
    data-failure="<?= site_escape($progressLabels['connection']) ?>"
    <?php foreach (['running', 'done', 'failed', 'unknown'] as $status): ?>
        data-<?= $status ?>="<?= site_escape($progressLabels[$status]) ?>"
    <?php endforeach; ?> hidden>
    <div class="update-progress-summary">
        <div role="status" aria-atomic="true">
            <strong data-update-state-label></strong>
            <p data-update-current></p>
        </div>
        <strong data-update-percent aria-hidden="true"></strong>
    </div>
    <progress max="100" value="0" aria-label="<?= site_escape($demoProgressLabel ?? $progressLabels[($progressMode ?? '') === 'index' ? 'index-progress' : 'progress']) ?>"></progress>
    <ol data-update-log></ol>
    <div><button type="button" data-update-reload hidden><?= site_escape($progressLabels['reload']) ?></button></div>
</section>
