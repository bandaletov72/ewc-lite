<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

return [
    'ru' => [
        'Бэкапы', 'Требует внимания. Нет резервной копии моложе месяца.', 'Расписание', 'Дни недели',
        'С', 'До', 'Одинаковое время начала и окончания означает весь день. Часовой пояс', 'Укажите корректное время и выберите дни для включённого расписания.',
        'Обновлять автоматически', 'Автоматический бэкап', 'Проверить обновления', 'Спам-фильтры',
        'Тема', 'Сначала обновите движок, чтобы получить новую версию темы.', 'Активная тема не входит в комплект CMS.', 'Актуальная версия',
        'Доступно обновление', 'Пн|Вт|Ср|Чт|Пт|Сб|Вс', 'Настройки расписания', 'Сохраняем правила спам-фильтра',
    ],
    'en' => [
        'Backups', 'Attention required. There is no backup less than a month old.', 'Schedule', 'Days of the week',
        'From', 'To', 'Matching start and end times mean all day. Time zone', 'Enter valid times and select days for an enabled schedule.',
        'Update automatically', 'Automatic backup', 'Check for updates', 'Spam filters',
        'Theme', 'Update the engine first to get the new theme version.', 'The active theme is outside the CMS bundle.', 'Up to date',
        'Update available', 'Mon|Tue|Wed|Thu|Fri|Sat|Sun', 'Schedule settings', 'Saving spam filter rules',
    ],
    'uk' => [
        'Резервні копії', 'Потрібна увага. Немає копії, створеної менш ніж місяць тому.', 'Розклад', 'Дні тижня',
        'З', 'До', 'Однаковий час початку й кінця означає весь день. Часовий пояс', 'Вкажіть коректний час і виберіть дні для ввімкненого розкладу.',
        'Оновлювати автоматично', 'Автоматична резервна копія', 'Перевірити оновлення', 'Спам-фільтри',
        'Тема', 'Спершу оновіть рушій, щоб отримати нову версію теми.', 'Активна тема не входить до комплекту CMS.', 'Актуальна версія',
        'Доступне оновлення', 'Пн|Вт|Ср|Чт|Пт|Сб|Нд', 'Налаштування розкладу', 'Зберігаємо правила спам-фільтра',
    ],
    'de' => [
        'Sicherungen', 'Achtung. Es gibt keine Sicherung, die jünger als einen Monat ist.', 'Zeitplan', 'Wochentage',
        'Von', 'Bis', 'Gleiche Start- und Endzeit bedeutet ganztägig. Zeitzone', 'Gültige Uhrzeiten eingeben und Tage für den aktiven Zeitplan wählen.',
        'Automatisch aktualisieren', 'Automatische Sicherung', 'Auf Updates prüfen', 'Spamfilter',
        'Theme', 'Zuerst die CMS-Software aktualisieren, um die neue Theme-Version zu erhalten.', 'Das aktive Theme gehört nicht zum CMS-Paket.', 'Aktuell',
        'Update verfügbar', 'Mo|Di|Mi|Do|Fr|Sa|So', 'Zeitplaneinstellungen', 'Spamfilterregeln werden gespeichert',
    ],
    'fr' => [
        'Sauvegardes', 'Attention. Aucune sauvegarde de moins d’un mois.', 'Planification', 'Jours de la semaine',
        'De', 'À', 'Des heures identiques signifient toute la journée. Fuseau horaire', 'Saisissez des heures valides et choisissez des jours pour la planification active.',
        'Mettre à jour automatiquement', 'Sauvegarde automatique', 'Rechercher les mises à jour', 'Filtres antispam',
        'Thème', 'Mettez d’abord le CMS à jour pour obtenir la nouvelle version du thème.', 'Le thème actif ne fait pas partie du CMS.', 'À jour',
        'Mise à jour disponible', 'Lun|Mar|Mer|Jeu|Ven|Sam|Dim', 'Paramètres de planification', 'Enregistrement des règles antispam',
    ],
    'es' => [
        'Copias de seguridad', 'Requiere atención. No hay copias de hace menos de un mes.', 'Horario', 'Días de la semana',
        'Desde', 'Hasta', 'Horas iguales abarcan todo el día. Zona horaria', 'Introduce horas válidas y elige días para el horario activo.',
        'Actualizar automáticamente', 'Copia de seguridad automática', 'Buscar actualizaciones', 'Filtros antispam',
        'Tema', 'Actualiza primero el CMS para obtener la nueva versión del tema.', 'El tema activo no forma parte del paquete del CMS.', 'Al día',
        'Actualización disponible', 'Lun|Mar|Mié|Jue|Vie|Sáb|Dom', 'Configuración del horario', 'Guardando las reglas antispam',
    ],
    'pt' => [
        'Cópias de segurança', 'Atenção. Não há cópias com menos de um mês.', 'Agendamento', 'Dias da semana',
        'Das', 'Até', 'Horários iguais abrangem o dia todo. Fuso horário', 'Informe horários válidos e escolha dias para o agendamento ativo.',
        'Atualizar automaticamente', 'Cópia automática', 'Verificar atualizações', 'Filtros antispam',
        'Tema', 'Atualize primeiro o CMS para obter a nova versão do tema.', 'O tema ativo não faz parte do pacote do CMS.', 'Atualizado',
        'Atualização disponível', 'Seg|Ter|Qua|Qui|Sex|Sáb|Dom', 'Configurações de agendamento', 'Salvando regras antispam',
    ],
    'ja' => [
        'バックアップ', '要確認。直近1か月以内のバックアップがありません。', 'スケジュール', '曜日',
        '開始', '終了', '開始と終了が同じ場合は終日です。タイムゾーン', '有効な時刻を入力し、スケジュールの曜日を選択してください。',
        '自動更新', '自動バックアップ', '更新を確認', 'スパムフィルター',
        'テーマ', '新しいテーマを取得するには、先に CMS を更新してください。', '現在のテーマは CMS に同梱されていません。', '最新',
        '更新あり', '月|火|水|木|金|土|日', 'スケジュール設定', 'スパムフィルターのルールを保存しています',
    ],
    'ko' => [
        '백업', '확인이 필요합니다. 최근 한 달 이내의 백업이 없습니다.', '일정', '요일',
        '시작', '종료', '시작과 종료가 같으면 하루 종일입니다. 시간대', '유효한 시간을 입력하고 활성 일정의 요일을 선택하세요.',
        '자동 업데이트', '자동 백업', '업데이트 확인', '스팸 필터',
        '테마', '새 테마 버전을 받으려면 먼저 CMS를 업데이트하세요.', '활성 테마는 CMS 패키지에 포함되지 않습니다.', '최신 버전',
        '업데이트 가능', '월|화|수|목|금|토|일', '일정 설정', '스팸 필터 규칙을 저장하는 중',
    ],
    'vi' => [
        'Bản sao lưu', 'Cần chú ý. Không có bản sao lưu nào trong vòng một tháng.', 'Lịch chạy', 'Ngày trong tuần',
        'Từ', 'Đến', 'Giờ bắt đầu và kết thúc giống nhau nghĩa là cả ngày. Múi giờ', 'Nhập giờ hợp lệ và chọn ngày cho lịch đang bật.',
        'Tự động cập nhật', 'Tự động sao lưu', 'Kiểm tra cập nhật', 'Bộ lọc spam',
        'Giao diện', 'Cập nhật CMS trước để nhận phiên bản giao diện mới.', 'Giao diện hiện tại không nằm trong gói CMS.', 'Đã cập nhật',
        'Có bản cập nhật', 'T2|T3|T4|T5|T6|T7|CN', 'Cài đặt lịch chạy', 'Đang lưu quy tắc lọc spam',
    ],
    'zh' => [
        '备份', '需要注意。没有一个月以内的备份。', '计划', '星期',
        '从', '到', '起止时间相同表示全天。时区', '请输入有效时间，并为启用的计划选择日期。',
        '自动更新', '自动备份', '检查更新', '垃圾过滤规则',
        '主题', '请先更新 CMS，以获取新版主题。', '当前主题不包含在 CMS 安装包中。', '已是最新',
        '有可用更新', '周一|周二|周三|周四|周五|周六|周日', '计划设置', '正在保存垃圾过滤规则',
    ],
];
