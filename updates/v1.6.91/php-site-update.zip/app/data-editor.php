<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_inline_data_target(array $item, string $base, string $host, array $settings): array
{
    $type = $item['kind'];
    $args = $item['arguments'];
    $query = [];
    $anchor = '';
    if ($type === 'iblock' && ($id = site_iblock_id_from_argument($args['iblock'])) !== '') {
        $query = ['iblocks' => '1', 'id' => $id];
    } elseif ($type === 'banners') {
        $selection = site_banner_shortcode_set($args['bannerOptions'] ?? '', $args['bannerFolder'] ?? '');
        if ($selection === null) return [];
        $url = site_banner_admin_url($base, $selection[0], $selection[1]);
        return ['modal' => $url . '&embed=1#banner-editor', 'wide' => $url . '&wide=1#banner-editor'];
    } elseif (in_array($type, ['gal', 'fotos', 'files'], true)) {
        $folder = trim($args[$type === 'files' ? 'files' : 'gallery']);
        if (site_asset_path($folder, $type === 'files' ? 'files' : 'images') !== '') {
            $query = ['media' => $type, 'folder' => $folder];
        }
    } elseif ($type === 'form' && site_valid_form_id(strtolower($args['form']))) {
        $query = ['forms' => '1', 'id' => strtolower($args['form'])];
    } elseif ($type === 'phpModule' && site_valid_snippet(strtolower($args['phpModule']))) {
        $name = strtolower($args['phpModule']);
        if (isset(site_extensions()[$name])) $query = ['modules' => '1', 'module' => $name];
    } elseif ($type === 'points') {
        $name = 'points-output';
        $query = ['layout' => '1', 'template' => $name];
        try {
            if ($host !== '' && isset(site_read_layout_snippets($host)[$name])) {
                $query = ['domains' => '1', 'templates' => $host === site_host() ? 'current' : $host, 'template' => $name];
            }
        } catch (RuntimeException $exception) {
            return [];
        }
        $anchor = '#layout-' . $name;
    } elseif ($type === 'callback') {
        $query = ['callbacks' => '1'];
    } elseif ($type === 'reviews') {
        $query = ['reviews' => '1'];
    } elseif (in_array($type, ['map', 'maps', 'maplist'], true)) {
        $options = site_shortcode_options($args['mapOptions'] ?? '');
        if ($type === 'maps' && site_valid_iblock_name($options['source'] ?? '')) {
            $query = ['iblocks' => '1', 'id' => $options['source']];
        } else {
            $query = ['integrations' => '1'];
            $anchor = '#maps';
        }
    } elseif ($type === 'snippet') {
        $name = strtolower($args['snippet']);
        if (isset(site_contact_tokens()[$name])) {
            $query = ['contacts' => '1'];
        } elseif (site_valid_snippet($name) && !isset(site_layout_blocks()[$name])) {
            try {
                $own = $host !== '' && isset(site_read_snippets($host)[$name]);
                if ($own || isset(site_read_snippets()[$name])) {
                    $query = ['snippets' => '1', 'snippet' => $name] + ($own ? ($host === site_host() ? [] : ['domain' => $host]) : ['scope' => 'shared']);
                } elseif (isset($settings['variables'][$name])) {
                    $query = ['settings' => '1'];
                    $anchor = '#variables';
                }
            } catch (RuntimeException $exception) {
                return [];
            }
        }
    }
    if (!$query) {
        return [];
    }
    $url = site_url($base, 'admin/') . '?' . http_build_query($query);
    return ['modal' => $url . '&embed=1' . $anchor, 'wide' => $url . '&wide=1' . $anchor];
}

function site_data_editor_labels(string $locale): array
{
    $options = [
        'ru' => ['Данные', 'На весь экран'], 'en' => ['Data', 'Full screen'], 'uk' => ['Дані', 'На весь екран'],
        'ja' => ['データ', '全画面'], 'vi' => ['Dữ liệu', 'Toàn màn hình'], 'fr' => ['Données', 'Plein écran'],
        'de' => ['Daten', 'Vollbild'], 'es' => ['Datos', 'Pantalla completa'], 'pt' => ['Dados', 'Ecrã inteiro'], 'ko' => ['데이터', '전체 화면'],
        'zh' => ['数据', '全屏'],
    ];
    return $options[$locale] ?? $options['ru'];
}

function site_component_frame_labels(string $locale): array
{
    $labels = [
        'ru' => ['Загружаем редактор…', 'Не удалось загрузить редактор.', 'Повторить', 'Если редактор в окне не загрузился, нажмите «Повторить» или откройте его кнопкой «На весь экран».'],
        'en' => ['Loading the editor…', 'Could not load the editor.', 'Retry', 'If the editor fails to load in the dialog, select Retry or use Full screen to open it separately.'],
        'uk' => ['Завантажуємо редактор…', 'Не вдалося завантажити редактор.', 'Повторити', 'Якщо редактор у вікні не завантажився, натисніть «Повторити» або відкрийте його кнопкою «На весь екран».'],
        'de' => ['Editor wird geladen…', 'Der Editor konnte nicht geladen werden.', 'Erneut versuchen', 'Wenn der Editor im Dialog nicht lädt, wählen Sie „Erneut versuchen“ oder öffnen Sie ihn über „Vollbild“.'],
        'fr' => ['Chargement de l’éditeur…', 'Impossible de charger l’éditeur.', 'Réessayer', 'Si l’éditeur ne se charge pas dans la fenêtre, cliquez sur « Réessayer » ou ouvrez-le en plein écran.'],
        'es' => ['Cargando el editor…', 'No se pudo cargar el editor.', 'Reintentar', 'Si el editor no carga en el cuadro de diálogo, pulsa «Reintentar» o ábrelo a pantalla completa.'],
        'pt' => ['A carregar o editor…', 'Não foi possível carregar o editor.', 'Tentar novamente', 'Se o editor não carregar na janela, selecione «Tentar novamente» ou abra-o em ecrã inteiro.'],
        'ja' => ['エディターを読み込んでいます…', 'エディターを読み込めませんでした。', '再試行', 'ダイアログでエディターが読み込まれない場合は、再試行するか全画面で開いてください。'],
        'ko' => ['편집기 불러오는 중…', '편집기를 불러올 수 없습니다.', '다시 시도', '대화 상자에서 편집기가 로드되지 않으면 다시 시도하거나 전체 화면으로 여세요.'],
        'vi' => ['Đang tải trình chỉnh sửa…', 'Không thể tải trình chỉnh sửa.', 'Thử lại', 'Nếu trình chỉnh sửa trong hộp thoại không tải được, hãy chọn «Thử lại» hoặc mở toàn màn hình.'],
        'zh' => ['正在加载编辑器…', '无法加载编辑器。', '重试', '如果弹窗中的编辑器加载失败，请点击“重试”或以全屏方式打开。'],
    ];
    return $labels[$locale] ?? $labels['ru'];
}

function site_file_manager_labels(string $locale): array
{
    $labels = [
        'zh' => ['文件管理器', '上一级', '新文件夹名称', '创建文件夹', '请使用 A–Z、a–z、0–9、连字符及下划线。'],
        'ru' => ['Файловый менеджер', 'На уровень выше', 'Имя новой папки', 'Создать папку', 'Используйте A–Z, a–z, 0–9, дефис и подчёркивание.'],
        'en' => ['File manager', 'Parent folder', 'New folder name', 'Create folder', 'Use A–Z, a–z, 0–9, hyphens and underscores.'],
        'uk' => ['Менеджер файлів', 'На рівень вище', 'Назва нової папки', 'Створити папку', 'Використовуйте A–Z, a–z, 0–9, дефіс і підкреслення.'],
        'ja' => ['ファイルマネージャー', '親フォルダー', '新しいフォルダー名', 'フォルダーを作成', 'A–Z、a–z、0–9、ハイフン、アンダースコアを使用してください。'],
        'vi' => ['Trình quản lý tệp', 'Thư mục cha', 'Tên thư mục mới', 'Tạo thư mục', 'Dùng A–Z, a–z, 0–9, dấu gạch nối và gạch dưới.'],
        'fr' => ['Gestionnaire de fichiers', 'Dossier parent', 'Nom du nouveau dossier', 'Créer le dossier', 'Utilisez A–Z, a–z, 0–9, le tiret et le trait de soulignement.'],
        'de' => ['Dateimanager', 'Übergeordneter Ordner', 'Name des neuen Ordners', 'Ordner erstellen', 'Verwenden Sie A–Z, a–z, 0–9, Bindestriche und Unterstriche.'],
        'es' => ['Gestor de archivos', 'Carpeta superior', 'Nombre de la carpeta nueva', 'Crear carpeta', 'Usa A–Z, a–z, 0–9, guiones y guiones bajos.'],
        'pt' => ['Gerenciador de arquivos', 'Pasta superior', 'Nome da nova pasta', 'Criar pasta', 'Use A–Z, a–z, 0–9, hífens e sublinhados.'],
        'ko' => ['파일 관리자', '상위 폴더', '새 폴더 이름', '폴더 만들기', 'A–Z, a–z, 0–9, 하이픈, 밑줄을 사용하세요.'],
    ];
    return $labels[$locale] ?? $labels['ru'];
}

function site_media_folder_labels(string $locale): array
{
    static $labels;
    if ($labels === null) $labels = require __DIR__ . '/help-media-folders.php';
    return $labels[$locale] ?? $labels['ru'];
}
