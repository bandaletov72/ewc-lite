<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

return [
    'ru' => ['Адрес', 'Публичный email', 'Часы работы', 'Контакты города показываются в шапке. Пустые поля используют значения общих подшаблонов.', 'Укажите один действительный публичный email.'],
    'en' => ['Address', 'Public email', 'Opening hours', 'City contact details appear in the header. Empty fields use the shared snippet values.', 'Enter one valid public email address.'],
    'uk' => ['Адреса', 'Публічна електронна пошта', 'Години роботи', 'Контакти міста відображаються в шапці. Порожні поля використовують спільні підшаблони.', 'Укажіть одну чинну публічну адресу електронної пошти.'],
    'de' => ['Adresse', 'Öffentliche E-Mail', 'Öffnungszeiten', 'Die Kontaktdaten der Stadt erscheinen im Kopfbereich. Leere Felder verwenden gemeinsame Vorlagenwerte.', 'Geben Sie eine gültige öffentliche E-Mail-Adresse ein.'],
    'fr' => ['Adresse', 'E-mail public', 'Horaires', 'Les coordonnées de la ville apparaissent dans l’en-tête. Les champs vides utilisent les valeurs communes.', 'Saisissez une adresse e-mail publique valide.'],
    'es' => ['Dirección', 'Correo público', 'Horario', 'Los datos de la ciudad se muestran en la cabecera. Los campos vacíos usan los valores compartidos.', 'Introduce una dirección de correo público válida.'],
    'pt' => ['Morada', 'E-mail público', 'Horário de funcionamento', 'Os contactos da cidade aparecem no cabeçalho. Campos vazios usam os valores dos submodelos partilhados.', 'Introduza um endereço de e-mail público válido.'],
    'ja' => ['住所', '公開メールアドレス', '営業時間', '都市の連絡先はヘッダーに表示されます。空欄には共通スニペットの値を使用します。', '有効な公開メールアドレスを一つ入力してください。'],
    'ko' => ['주소', '공개 이메일', '영업시간', '도시 연락처는 머리글에 표시됩니다. 비어 있는 항목은 공용 스니펫 값을 사용합니다.', '유효한 공개 이메일 주소 하나를 입력하세요.'],
    'vi' => ['Địa chỉ', 'Email công khai', 'Giờ làm việc', 'Thông tin liên hệ của thành phố hiển thị ở đầu trang. Các ô trống dùng giá trị mẫu con dùng chung.', 'Nhập một địa chỉ email công khai hợp lệ.'],
    'zh' => ['地址', '公开邮箱', '营业时间', '城市联系方式显示在页眉。留空时使用共享子模板的值。', '请输入一个有效的公开邮箱地址。'],
];
