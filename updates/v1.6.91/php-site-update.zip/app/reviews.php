<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_REVIEWS_SETTINGS = SITE_ROOT . '/admin/.reviews.php';
const SITE_REVIEW_PREFIX = SITE_ROOT . '/data/.review-';
const SITE_REVIEW_BATCH = 10;
const SITE_REVIEW_BATCH_MAX = 100;
const SITE_REVIEW_MORE_LABEL_MAX = 100;

function site_review_labels(string $locale): array
{
    static $catalog;
    if ($catalog === null) $catalog = require __DIR__ . '/help-reviews.php';
    return $catalog[$locale] ?? $catalog['ru'];
}

function site_review_form(string $locale, bool $allowLegacyZero = false): array
{
    $labels = site_review_labels($locale);
    return ['button' => $labels[5], 'showRatingStars' => true, 'fields' => [
        ['name' => 'name', 'label' => $labels[1], 'type' => 'text', 'required' => true, 'maxLength' => 100, 'options' => []],
        ['name' => 'review', 'label' => $labels[2], 'type' => 'textarea', 'required' => true, 'maxLength' => 3000, 'options' => []],
        ['name' => 'rating', 'label' => $labels[3], 'type' => 'radio', 'required' => true, 'maxLength' => 1,
            'options' => $allowLegacyZero ? ['0', '1', '2', '3', '4', '5'] : ['1', '2', '3', '4', '5']],
    ]];
}

function site_review_stars(int $rating): string
{
    return str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
}

function site_review_id($id): bool
{
    return is_string($id) && preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id) === 1;
}

function site_review_scope(): string
{
    return site_content_root() === SITE_ROOT ? '' : site_design_active();
}

function site_review_read(string $id): array
{
    if (!site_review_id($id)) return [];
    $file = SITE_REVIEW_PREFIX . $id . '.php';
    if (is_link($file)) return [];
    $row = site_read_record($file);
    if (($row['theme'] ?? null) !== site_review_scope() || !is_string($row['page'] ?? null)
        || !site_valid_path($row['page']) || !is_string($row['name'] ?? null) || !is_string($row['review'] ?? null)
        || !is_string($row['rating'] ?? null) || !in_array($row['rating'], ['0', '1', '2', '3', '4', '5'], true)
        || !in_array($row['status'] ?? '', ['pending', 'approved', 'rejected'], true)) return [];
    return $row;
}

function site_review_page($cursor, int $limit, bool $approved, string $filter = '', string $priority = ''): array
{
    $ids = glob(SITE_REVIEW_PREFIX . '*.php') ?: [];
    rsort($ids, SORT_STRING);
    // Keep the cursor's group even if its review is removed between requests.
    $otherCursor = $priority !== '' && is_string($cursor) && strpos($cursor, 'other-') === 0
        && site_review_id(substr($cursor, 6));
    $before = $otherCursor ? substr($cursor, 6) : (site_review_id($cursor) ? $cursor : '');
    $rows = [];
    $otherRows = [];
    foreach ($ids as $file) {
        $id = substr(basename($file, '.php'), strlen('.review-'));
        $atOrAfterCursor = $before !== '' && strcmp($id, $before) >= 0;
        if ($atOrAfterCursor && ($priority === '' || $otherCursor)) continue;
        try {
            $row = site_review_read($id);
        } catch (RuntimeException $exception) {
            continue;
        }
        if (!$row || ($approved && $row['status'] !== 'approved') || ($filter !== '' && $row['page'] !== $filter)) continue;
        if ($priority !== '' && $row['page'] !== $priority) {
            if (count($otherRows) <= $limit) $otherRows[$id] = $row;
            if ($otherCursor && count($otherRows) > $limit) break;
        } elseif (!$otherCursor && !$atOrAfterCursor) {
            $rows[$id] = $row;
            if (count($rows) > $limit) break;
        }
    }
    $ordered = $rows + $otherRows;
    if (count($ordered) <= $limit) return [$ordered, ''];

    $batch = array_slice($ordered, 0, $limit, true);
    end($batch);
    $id = key($batch);
    return [$batch, (isset($otherRows[$id]) ? 'other-' : '') . $id];
}

function site_review_settings(): array
{
    $record = site_read_record(site_content_record(SITE_REVIEWS_SETTINGS));
    $page = $record['page'] ?? '';
    $batch = $record['batch'] ?? SITE_REVIEW_BATCH;
    $moreLabel = $record['moreLabel'] ?? '';
    return [
        'page' => is_string($page) && site_valid_path($page) ? $page : '',
        'batch' => is_int($batch) && $batch >= 1 && $batch <= SITE_REVIEW_BATCH_MAX ? $batch : SITE_REVIEW_BATCH,
        'moreLabel' => is_string($moreLabel) && site_review_valid_more_label($moreLabel) ? $moreLabel : '',
        'autoApprove' => ($record['autoApprove'] ?? false) === true,
    ];
}

function site_review_valid_more_label(string $label): bool
{
    return preg_match('/\A[^\p{Cc}]{0,' . SITE_REVIEW_MORE_LABEL_MAX . '}\z/u', $label) === 1;
}

function site_review_store(array $fields, string $page): bool
{
    $lock = admin_lock();
    try {
        $settings = site_review_settings();
        $moderationFields = array_intersect_key($fields, ['name' => true, 'review' => true]);
        foreach ($moderationFields as &$field) {
            $field['value'] = preg_replace('/\s+/u', ' ', $field['value']) ?? $field['value'];
        }
        unset($field);
        $approved = $settings['autoApprove'] && !site_spam_errors($moderationFields, site_spam_rules()['words']);
        $id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
        admin_write_record(SITE_REVIEW_PREFIX . $id . '.php', [
            'theme' => site_review_scope(), 'page' => site_page_translation($page)[0], 'status' => $approved ? 'approved' : 'pending',
            'name' => $fields['name']['value'], 'review' => $fields['review']['value'], 'rating' => $fields['rating']['value'],
        ]);
        return $approved;
    } finally {
        fclose($lock);
    }
}

function site_component_reviews(array &$context, bool $currentPageFirst = false, bool $showButton = true): string
{
    $page = $context['page'] ?? '';
    if (!site_valid_path($page)) return '';
    $locale = $context['locale'] ?? 'ru';
    $labels = site_review_labels($locale);
    $base = $context['base'];
    $number = ($context['reviewInstances'] ?? 0) + 1;
    $context['reviewInstances'] = $number;
    $anchor = 'reviews-' . $number;
    $cursor = ($_GET['review_block'] ?? '') === (string) $number ? ($_GET['reviews_before'] ?? '') : '';
    try {
        $settings = site_review_settings();
        $priority = $currentPageFirst ? site_page_translation($page)[0] : '';
        $filter = $currentPageFirst ? '' : $settings['page'];
        list($rows, $next) = site_review_page($cursor, $settings['batch'], true, $filter, $priority);
    } catch (RuntimeException $exception) {
        return '';
    }
    $url = '';
    if ($next !== '') {
        $query = $_GET;
        unset($query['ajax']);
        $query['review_block'] = $number;
        $query['reviews_before'] = $next;
        $url = '?' . http_build_query($query) . '#' . $anchor;
    }
    if ($settings['moreLabel'] !== '') $labels[8] = $settings['moreLabel'];
    $id = 'reviews';
    $form = site_review_form($locale);
    $session = $context['formSession'];
    $instance = $anchor . '-form';
    $dialogId = $context['reviewDialogId'] = $anchor . '-dialog';
    ob_start();
    require site_template_file('components/reviews.php');
    $markup = (string) ob_get_clean();
    if (empty($context['layoutEdit'])) return $markup;

    $target = site_inline_data_target(['kind' => 'reviews', 'arguments' => []], $base, '', []);
    $editorLocale = $context['editorLocale'] ?? $locale;
    return '<a class="inline-component-link" href="' . site_escape($target['wide'])
        . '" data-reviews-edit data-layout-edit-control data-layout-edit-modal="' . site_escape($target['modal'])
        . '" data-editor-modal-label="' . site_escape(site_review_labels($editorLocale)[0]) . '" aria-haspopup="dialog">'
        . site_escape(site_translation('Править компонент', $editorLocale)) . '</a>' . $markup;
}
