<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_SPAM_FILE = SITE_ROOT . '/admin/.spam.php';

const SITE_SPAM_PRESET_PATH = 'app/spam-defaults.php';
const SITE_SPAM_PRESET_LIMIT = 65536;

function site_spam_admin_labels(string $locale): array
{
    $labels = require __DIR__ . '/help-spam.php';
    return $labels[$locale] ?? $labels['ru'];
}

function site_spam_valid_version($version): bool
{
    return is_string($version) && preg_match('/\A[0-9]+\.[0-9]+\.[0-9]+\z/', $version) === 1;
}

function site_spam_version(): string
{
    $bundled = site_read_record(SITE_ROOT . '/' . SITE_SPAM_PRESET_PATH, SITE_SPAM_PRESET_LIMIT)['version'] ?? '';
    $downloaded = site_read_record(SITE_SPAM_FILE)['downloaded']['version'] ?? '';
    if (!site_spam_valid_version($bundled)) $bundled = '1.0.0';
    return site_spam_valid_version($downloaded) && version_compare($downloaded, $bundled, '>') ? $downloaded : $bundled;
}

function site_spam_presets(array $record): array
{
    $bundled = site_read_record(SITE_ROOT . '/' . SITE_SPAM_PRESET_PATH, SITE_SPAM_PRESET_LIMIT);
    $presets = [];
    foreach (['words', 'agents', 'ips'] as $field) {
        $downloaded = is_array($record['downloaded'][$field] ?? null) ? array_filter($record['downloaded'][$field], 'is_string') : [];
        $presets[$field] = array_values(array_unique(array_merge($bundled[$field] ?? [], $downloaded)));
    }
    return $presets;
}

function site_spam_rules(?array $record = null): array
{
    $record = $record ?? site_read_record(SITE_SPAM_FILE);
    $presets = site_spam_presets($record);
    $rules = [];
    foreach ($presets as $field => $items) {
        $saved = is_array($record[$field] ?? null) ? array_filter($record[$field], 'is_string') : [];
        $seen = is_array($record['seen'][$field] ?? null) ? array_filter($record['seen'][$field], 'is_string') : [];
        $rules[$field] = array_values(array_unique(array_merge($saved, array_diff($items, $seen))));
    }
    return $rules;
}

function site_normalize_ip(string $ip): string
{
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return '';
    }
    $canonical = strtolower(inet_ntop(inet_pton($ip)));
    return strpos($canonical, '::ffff:') === 0 && filter_var(substr($canonical, 7), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
        ? substr($canonical, 7) : $canonical;
}

function site_spam_ip_rule(string $rule): string
{
    $exact = site_normalize_ip($rule);
    if ($exact !== '') return $exact;
    $parts = explode('.', $rule);
    if (count($parts) !== 4) return '';
    foreach ($parts as $part) {
        if ($part === '*') continue;
        if (!preg_match('/\A(0|[1-9][0-9]{0,2})(?:-(0|[1-9][0-9]{0,2}))?\z/', $part, $match)) return '';
        $low = (int) $match[1];
        $high = (int) ($match[2] ?? $match[1]);
        if ($low > $high || $high > 255) return '';
    }
    return $rule;
}

function site_spam_request_blocked(string $ip, string $agent, array $rules): bool
{
    if ($ip !== '' && in_array($ip, $rules['ips'], true)) return true;
    foreach ($rules['agents'] as $fragment) {
        if ($fragment !== '' && stripos($agent, $fragment) !== false) return true;
    }
    $octets = explode('.', $ip);
    if (count($octets) !== 4) return false;
    foreach ($rules['ips'] as $rule) {
        if (strpos($rule, '*') === false && strpos($rule, '-') === false) continue;
        $parts = explode('.', $rule);
        if (count($parts) !== 4 || site_spam_ip_rule($rule) === '') continue;
        foreach ($parts as $i => $part) {
            if ($part === '*') continue;
            $bounds = explode('-', $part, 2);
            $octet = (int) $octets[$i];
            if ($octet < (int) $bounds[0] || $octet > (int) ($bounds[1] ?? $bounds[0])) continue 2;
        }
        return true;
    }
    return false;
}

function site_has_url(string $value): bool
{
    $pattern = <<<'REGEX'
~
  [a-z][a-z0-9+.-]*://\S+
  | (?:www\.|mailto:)\S+
  | (?<![\p{L}\p{N}@_.-])
    (?:[\p{L}\p{N}](?:[\p{L}\p{N}-]{0,61}[\p{L}\p{N}])?\.)+
    (?:xn--[a-z0-9-]{2,59}|[\p{L}]{2,63})
    (?![\p{L}\p{N}_-])
  | (?:\b[0-9]{1,3}\.){3}[0-9]{1,3}(?::[0-9]+)?/
~iux
REGEX;
    return preg_match($pattern, $value) === 1;
}

function site_spam_errors(array $fields, array $words): array
{
    $errors = [];
    foreach ($fields as $name => $field) {
        if ($field['value'] === '') {
            continue;
        }
        if ($field['type'] !== 'email' && $field['type'] !== 'tel' && site_has_url($field['value'])) {
            $errors[$name] = 'Удалите ссылки из этого поля.';
            continue;
        }
        foreach ($words as $word) {
            if ($word !== '' && preg_match('~(?<![\p{L}\p{N}_])' . preg_quote($word, '~') . '(?![\p{L}\p{N}_])~iu', $field['value']) === 1) {
                $errors[$name] = 'Это поле содержит запрещённое слово или выражение.';
                break;
            }
        }
    }
    return $errors;
}
