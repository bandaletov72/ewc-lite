<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php $appearanceLabels = site_appearance_labels($adminLanguage); ?>
<?php if ($error !== ''): ?>
    <p class="notice error" role="alert"><?= admin_l($error) ?></p>
<?php elseif ($notice !== ''): ?>
    <p class="notice" role="status"><?= admin_l($notice) ?></p>
<?php endif; ?>

<?php if (in_array($section, ['settings', 'contacts', 'components', 'updates', 'libraries', 'region', 'captcha'], true)): ?>
    <nav class="site-menu scope-menu" aria-label="<?= admin_l('Разделы настроек') ?>">
        <?php foreach (['settings' => [admin_t('Основные'), $settingsUrl], 'contacts' => [admin_t('Контакты и соцсети'), $contactsUrl], 'components' => [admin_t('Компоненты'), $componentsUrl], 'libraries' => [$appearanceLabels[2], $librariesUrl], 'region' => [admin_t('Региональные настройки'), $regionUrl], 'captcha' => ['CAPTCHA', $captchaUrl], 'updates' => [admin_t('Обновления'), $updatesUrl]] as $key => $item): ?>
            <a href="<?= site_escape($item[1]) ?>"<?= $section === $key ? ' aria-current="page"' : '' ?>><?= admin_l($item[0]) ?></a>
        <?php endforeach; ?>
    </nav>
<?php endif; ?>

<?php if ($section === 'settings'): ?>
    <h1><?= admin_l('Настройки сайта') ?></h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($settingsUrl) ?>">
        <input type="hidden" name="action" value="save-settings">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($settingsRevision) ?>">
        <?php $brandHelp = require SITE_ROOT . '/app/help-site-subtitle.php'; ?>
        <?php foreach (['name' => admin_t('Название сайта'), 'subtitle' => ($brandHelp[$adminLanguage] ?? $brandHelp['ru'])[0],
            'description' => admin_t('Метаописание по умолчанию'), 'footer' => admin_t('Текст подвала')] as $name => $label): ?>
            <div class="field">
                <label for="setting-<?= $name ?>"><?= admin_l($label) ?></label>
                <input id="setting-<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($settingsDraft[$name]) ?>" <?= $name === 'name' ? 'required' : '' ?> <?= $name === 'footer' ? 'aria-describedby="footer-hint"' : '' ?> maxlength="375">
                <?php if ($name === 'footer'): ?>
                    <small class="hint" id="footer-hint"><?= admin_l('Используйте [year] для текущего года, например «© [year] Название сайта».') ?></small>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php $contactLabels = site_city_contact_labels($adminLanguage); ?>
        <label class="field" id="message-recipients"><?= site_escape($contactLabels[0]) ?>
            <input type="email" name="message_recipients" multiple maxlength="<?= SITE_MAIL_ADDRESS_LIMIT ?>"
                value="<?= site_escape($settingsDraft['messageRecipients']) ?>" placeholder="office@example.com, sales@example.com">
            <small class="hint"><?= site_escape($contactLabels[2]) ?></small>
        </label>
        <label class="field"><?= admin_l('Публичный адрес сайта') ?>
            <input type="url" name="public_url" value="<?= site_escape($settingsDraft['publicUrl']) ?>" placeholder="https://example.com/" maxlength="2048">
            <small class="hint"><?= admin_l('Пустое поле использует адрес открытого сайта.') ?> <code>[site-url]</code></small>
        </label>
        <input type="hidden" name="breadcrumb_option" value="1">
        <label class="choice">
            <input type="checkbox" name="breadcrumbs" value="1"<?= $settingsDraft['breadcrumbs'] ? ' checked' : '' ?>>
            <?= admin_l('Показывать хлебные крошки') ?>
        </label>
        <label class="field" id="site-search-settings"><?= admin_l('Вид поиска') ?>
            <select name="search_mode">
                <?php foreach (['off' => admin_t('Выключен'), 'compact' => admin_t('Компактный (лупа)'), 'expanded' => admin_t('Расширенный')] as $value => $label): ?>
                    <option value="<?= $value ?>"<?= $settingsDraft['searchMode'] === $value ? ' selected' : '' ?>><?= admin_l($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php $phpLabels = site_php_admin_labels($adminLanguage); ?>
        <?php $animationLabels = site_scroll_animation_labels($adminLanguage); ?>
        <label class="field" id="scroll-animation"><?= site_escape($animationLabels[0]) ?>
            <select name="scroll_animation">
                <?php foreach (SITE_SCROLL_ANIMATIONS as $index => $effect): ?>
                    <option value="<?= $effect ?>"<?= $settingsDraft['scrollAnimation'] === $effect ? ' selected' : '' ?>><?= site_escape($animationLabels[$index + 1]) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="field" id="php-error-reporting"><?= site_escape($phpLabels[1]) ?> <code>error_reporting</code>
            <select name="error_reporting">
                <?php foreach (array_keys(site_error_reporting_levels()) as $index => $level): ?>
                    <option value="<?= $level ?>"<?= $settingsDraft['errorReporting'] === $level ? ' selected' : '' ?>><?= site_escape($phpLabels[2][$index]) ?></option>
                <?php endforeach; ?>
            </select>
            <small class="hint"><?= site_escape($phpLabels[4]) ?></small>
        </label>
        <div class="field">
            <label for="variables"><?= admin_l('Переменные для шаблонов') ?></label>
            <textarea class="short-editor" id="variables" name="variables" rows="4" spellcheck="false" aria-describedby="variables-hint" placeholder="<?= admin_l('[city] = Москва
[spb] = Санкт-Петербург') ?>"><?= "\n" . site_escape($variablesDraft) ?></textarea>
            <small class="hint" id="variables-hint"><?= admin_l('Одна переменная на строку, например [city] = Москва. Для вставки используйте [city].') ?></small>
        </div>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить') ?></button></div>
    </form>
    <?php require __DIR__ . '/recovery-settings-view.php'; ?>
    <?php require __DIR__ . '/branding-view.php'; ?>
<?php elseif ($section === 'page_templates'): ?>
    <?php require __DIR__ . '/page-templates-view.php'; ?>
<?php elseif ($section === 'cities'): ?>
    <?php require __DIR__ . '/cities-view.php'; ?>
<?php elseif ($section === 'region'): ?>
    <?php require __DIR__ . '/region-view.php'; ?>
<?php elseif ($section === 'integrations'): ?>
    <?php require __DIR__ . '/integrations-view.php'; ?>
<?php elseif ($section === 'libraries'): ?>
    <?php require __DIR__ . '/libraries-view.php'; ?>
<?php elseif (in_array($section, ['layout', 'headers', 'functions', 'assets', 'design', 'theme', 'fonts'], true)): ?>
    <nav class="site-menu scope-menu" aria-label="<?= admin_l('Оформление сайта') ?>">
        <?php foreach (['layout' => ['Шаблоны оформления', $layoutEditorUrl], 'design' => [site_design_labels($adminLanguage)[0], $designUrl],
            'theme' => [$appearanceLabels[0], $themeUrl], 'fonts' => [$appearanceLabels[1], $fontsUrl],
            'headers' => ['Служебные заголовки', $headersUrl], 'functions' => ['Функции', $functionsUrl], 'assets' => ['CSS и JS', $assetsUrl]] as $key => $item): ?>
            <a href="<?= site_escape($item[1]) ?>"<?= $section === $key ? ' aria-current="page"' : '' ?>><?= admin_l($item[0]) ?></a>
        <?php endforeach; ?>
    </nav>
    <?php if ($section === 'design'): ?>
        <?php require __DIR__ . '/design-themes-view.php'; ?>
    <?php elseif ($section === 'theme'): ?>
        <?php require __DIR__ . '/appearance-view.php'; ?>
    <?php elseif ($section === 'fonts'): ?>
        <?php require __DIR__ . '/fonts-view.php'; ?>
    <?php elseif ($section === 'headers'): ?>
        <?php require __DIR__ . '/headers-view.php'; ?>
    <?php elseif ($section === 'functions'): ?>
        <?php require __DIR__ . '/functions-view.php'; ?>
    <?php elseif ($section === 'assets'): ?>
        <?php require __DIR__ . '/assets-view.php'; ?>
    <?php elseif (!empty($layoutError)): ?>
        <p class="notice error" role="alert"><?= admin_l($layoutError) ?></p>
    <?php elseif ($layoutDraft !== null): ?>
        <h1><?= admin_l('Шаблоны оформления') ?></h1>
        <?php require __DIR__ . '/domain-templates-view.php'; ?>
    <?php endif; ?>
<?php elseif (in_array($section, ['contacts', 'components'], true)): ?>
    <?php require __DIR__ . '/appearance-view.php'; ?>
<?php elseif ($section === 'updates'): ?>
    <h1><?= admin_l('Обновления движка') ?></h1>
    <section class="panel form-stack">
        <p><?= admin_l('Установлена версия') ?> <span data-update-installed><?= site_escape(site_update_version()) ?></span>.</p>
        <p role="status" data-update-latest="<?= site_escape($updatesUrl . '&check=1') ?>"><span data-update-label><?= admin_l('Последняя версия на GitHub') ?></span> <strong data-update-version><?= admin_l('проверяется…') ?></strong></p>
        <?php $repository = site_update_github_repo(); ?>
        <?php if ($repository !== ''): ?>
            <p><?= admin_l('Источник обновлений') ?> <a href="<?= site_escape('https://github.com/' . $repository) ?>"><?= site_escape($repository) ?></a>.</p>
        <?php else: ?>
            <p><?= admin_l('Задайте репозиторий GitHub в') ?> <code>SITE_GITHUB_REPO</code> <?= admin_l('или') ?> <code>maintenance/github.php</code>.</p>
        <?php endif; ?>
        <?php $releaseLabels = admin_update_progress_labels($adminLanguage); ?>
        <section data-update-notes hidden>
            <h2><?= site_escape($releaseLabels['release-notes']) ?></h2>
            <p class="update-release-notes" data-update-note-text data-empty="<?= site_escape($releaseLabels['release-notes-empty']) ?>"></p>
        </section>
        <form class="form-stack" method="post" action="<?= site_escape($updatesUrl) ?>" data-update-stream>
            <input type="hidden" name="action" value="update-engine">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <div><button class="button-primary" type="submit" <?= $repository === '' ? 'disabled' : '' ?>><?= admin_l('Обновить движок') ?></button></div>
            <?php require __DIR__ . '/update-progress-view.php'; ?>
        </form>
    </section>
<?php elseif ($section === 'domains'): ?>
    <h1><?= admin_l('Домены и поддомены') ?></h1>
    <?php if ($domainsError !== ''): ?>
        <p class="notice error" role="alert"><?= admin_l($domainsError) ?></p>
    <?php else: ?>
        <div class="editor-grid">
            <section class="panel">
                <h2><?= admin_l('Добавленные домены') ?></h2>
                <div class="header-actions">
                    <a class="button" href="<?= site_escape($layoutEditorUrl) ?>"><?= admin_l('Общие шаблоны') ?></a>
                    <?php if ($currentHost !== '' && !in_array($currentHost, $domains, true)): ?>
                        <a class="button" href="<?= site_escape($domainsUrl . '&templates=current') ?>"<?= $layoutSelection === 'current' ? ' aria-current="page"' : '' ?>><?= admin_l('Шаблоны текущего домена') ?></a>
                    <?php endif; ?>
                </div>
                <?php if (!$domains): ?>
                    <p><?= admin_l('Список пока пуст.') ?></p>
                <?php else: ?>
                    <ul class="page-list">
                        <?php foreach ($domains as $domain): ?>
                            <li class="domain-template-row">
                                <strong><?= site_escape($domain) ?></strong>
                                <div class="header-actions">
                                    <a href="<?= site_escape($domainsUrl . '&templates=' . rawurlencode($domain)) ?>"<?= $layoutHost === $domain && $layoutSelection !== '' ? ' aria-current="page"' : '' ?>><?= admin_l('Шаблоны') ?></a>
                                    <a href="<?= site_escape($snippetsUrl . '&domain=' . rawurlencode($domain)) ?>"><?= admin_l('Подшаблоны') ?></a>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
            <form class="panel form-stack" id="add-domain" method="post" action="<?= site_escape($domainsUrl) ?>">
                <input type="hidden" name="action" value="add-domain">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <div class="field">
                    <label for="domain"><?= admin_l('Имя нового поддомена') ?></label>
                    <input id="domain" name="domain" value="<?= site_escape($domainDraft) ?>" placeholder="msk.example.ru" maxlength="253" required>
                </div>
                <div><button class="button-primary" type="submit"><?= admin_l('Добавить поддомен') ?></button></div>
            </form>
        </div>
        <?php if (!empty($layoutError)): ?>
            <p class="notice error" role="alert"><?= admin_l($layoutError) ?></p>
        <?php elseif ($layoutDraft !== null): ?>
            <?php require __DIR__ . '/domain-templates-view.php'; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php elseif ($section === 'snippets'): ?>
    <?php if (!$embeddedData): ?>
    <h1><?= admin_l('Подшаблоны') ?></h1>
    <nav class="site-menu scope-menu" aria-label="<?= admin_l('Область подшаблонов') ?>">
        <?php if ($currentHost !== ''): ?>
            <a href="<?= site_escape($snippetsUrl) ?>"<?= !$sharedScope && $domainSelection === '' ? ' aria-current="page"' : '' ?>><?= admin_l('Текущий домен') ?></a>
        <?php endif; ?>
        <a href="<?= site_escape($snippetsUrl . '&scope=shared') ?>"<?= $sharedScope ? ' aria-current="page"' : '' ?>><?= admin_l('Общие значения') ?></a>
        <?php foreach ($domains as $domain): ?>
            <a href="<?= site_escape($snippetsUrl . '&domain=' . rawurlencode($domain)) ?>"<?= !$sharedScope && $domainSelection !== '' && $scopeHost === $domain ? ' aria-current="page"' : '' ?>><?= site_escape($domain) ?></a>
        <?php endforeach; ?>
        <a class="button" href="<?= site_escape($domainsUrl) ?>#add-domain">+ <?= $adminLanguage === 'ru' ? 'Добавить домен' : admin_l('Добавить поддомен') ?></a>
    </nav>
    <?php endif; ?>
    <?php if ($snippetError !== ''): ?>
        <p class="notice error" role="alert"><?= admin_l($snippetError) ?></p>
    <?php endif; ?>
    <?php if ($scopeValid && ($embeddedData ? $snippet !== null : ($snippetError === '' || $snippetEntries))): ?>
        <p class="hint"><?= $sharedScope ? admin_t('Общие значения применяются на доменах без своего значения.') : admin_t('Значения домена ') . site_escape($scopeHost) . admin_t(' имеют приоритет перед общими.') ?></p>
        <?php if (!$embeddedData): ?>
        <div class="editor-grid">
            <nav class="panel" aria-label="<?= admin_l('Список подшаблонов') ?>">
                <ul class="page-list">
                    <li><a href="<?= site_escape($scopeUrl) ?>"<?= $snippet === null ? ' aria-current="page"' : '' ?>><?= admin_l('Добавить подшаблон') ?></a></li>
                    <?php foreach ($snippetEntries as $key => $item): ?>
                        <li><a href="<?= site_escape($scopeUrl . '&snippet=' . rawurlencode($key)) ?>"<?= $snippet !== null && $snippet['name'] === $key ? ' aria-current="page"' : '' ?>>
                            <code>[<?= site_escape($key) ?>]</code>
                            <small><?= site_escape($item['description']) ?><?= !isset($own[$key]) ? admin_t(' · общее значение') : '' ?></small>
                        </a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        <?php endif; ?>
            <?php
            $editor = $snippet ?? ['name' => '', 'values' => ['description' => '', 'value' => ''], 'revision' => '', 'locked' => false];
            $inherited = $editor['locked'] && $editor['revision'] === '';
            ?>
            <form class="panel form-stack" method="post" action="<?= site_escape($scopeUrl . ($editor['locked'] ? '&snippet=' . rawurlencode($editor['name']) : '')) ?>">
                <h2><?= $inherited ? admin_t('Переопределить общее значение') : ($editor['locked'] ? admin_t('Редактировать подшаблон') : admin_t('Новый подшаблон')) ?></h2>
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <input type="hidden" name="revision" value="<?= site_escape($editor['revision']) ?>">
                <input type="hidden" name="locked" value="<?= $editor['locked'] ? '1' : '0' ?>">
                <div class="field">
                    <?php $snippetCode = $editor['name'] === '' ? '' : '[' . $editor['name'] . ']'; ?>
                    <?php if ($editor['locked']): ?>
                        <input type="hidden" name="snippet" value="<?= site_escape($snippetCode) ?>">
                        <?= site_copy_code($snippetCode, $adminLanguage, admin_t('Подшаблон')) ?>
                    <?php else: ?>
                        <label for="snippet"><?= admin_l('Подшаблон') ?></label>
                        <input id="snippet" name="snippet" value="<?= site_escape($snippetCode) ?>" placeholder="[tel]" maxlength="66" required>
                    <?php endif; ?>
                </div>
                <div class="field">
                    <label for="snippet-description"><?= admin_l('Описание') ?></label>
                    <input id="snippet-description" name="description" value="<?= site_escape($editor['values']['description']) ?>" placeholder="<?= admin_l('Телефон для связи') ?>" maxlength="375" required>
                </div>
                <div class="field">
                    <label for="snippet-value"><?= admin_l('Значение') ?></label>
                    <textarea id="snippet-value" class="short-editor" name="value" rows="5" spellcheck="false" aria-describedby="snippet-hint"><?= "\n" . site_escape($editor['values']['value']) ?></textarea>
                    <small class="hint" id="snippet-hint"><?= admin_l('Здесь можно указать текст или HTML. Имя в квадратных скобках вставляется в страницу или её заголовок.') ?></small>
                </div>
                <div class="header-actions">
                    <button class="button-primary" type="submit" name="action" value="save-snippet"><?= admin_l('Сохранить') ?></button>
                    <?php if (!$embeddedData && $editor['revision'] !== ''): ?>
                        <button type="submit" name="action" value="delete-snippet" formnovalidate><?= !$sharedScope && isset($shared[$editor['name']]) ? admin_t('Вернуть общее значение') : admin_t('Удалить значение') ?></button>
                    <?php endif; ?>
                </div>
            </form>
        <?php if (!$embeddedData): ?></div><?php endif; ?>
    <?php endif; ?>
<?php elseif ($section === 'forms'): ?>
    <?php require __DIR__ . '/forms-view.php'; ?>
<?php elseif ($section === 'spam'): ?>
    <?php $spamLabels = site_spam_admin_labels($adminLanguage); ?>
    <h1><?= admin_l('Антиспам') ?></h1>
    <?php if ($spamEditorError !== ''): ?>
        <p class="notice error" role="alert"><?= admin_l($spamEditorError) ?></p>
    <?php elseif ($spamDraft !== null): ?>
        <form class="panel form-stack" method="post" action="<?= site_escape($spamUrl) ?>">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($spamRevision) ?>">
            <p class="hint"><?= site_escape($spamLabels[3]) ?></p>
            <div class="fields">
                <div class="field">
                    <label for="spam-words"><?= admin_l('Запрещённые слова и выражения') ?></label>
                    <textarea class="short-editor" id="spam-words" name="words" rows="7" spellcheck="false" placeholder="casino"><?= "\n" . site_escape($spamDraft['words']) ?></textarea>
                </div>
                <div class="field">
                    <label for="spam-ips"><?= admin_l('Заблокированные IP-адреса') ?></label>
                    <textarea class="short-editor" id="spam-ips" name="ips" rows="7" spellcheck="false" placeholder="192.0.2.*"><?= "\n" . site_escape($spamDraft['ips']) ?></textarea>
                </div>
                <div class="field field-wide">
                    <label for="spam-agents"><?= site_escape($spamLabels[1]) ?></label>
                    <textarea class="short-editor" id="spam-agents" name="agents" rows="5" spellcheck="false" placeholder="Bad Robot"><?= "\n" . site_escape($spamDraft['agents'] ?? '') ?></textarea>
                </div>
            </div>
            <p class="hint"><?= site_escape($spamLabels[4]) ?></p>
            <div class="header-actions">
                <button class="button-primary" type="submit" name="action" value="save-spam"><?= admin_l('Сохранить правила') ?></button>
                <button type="submit" name="action" value="refresh-spam"><?= site_escape($spamLabels[0]) ?></button>
            </div>
        </form>
    <?php endif; ?>
<?php elseif ($section === 'messages'): ?>
    <?php require __DIR__ . '/messages-view.php'; ?>
<?php elseif ($section === 'reviews'): ?>
    <?php require __DIR__ . '/reviews-view.php'; ?>
<?php elseif ($section === 'callbacks'): ?>
    <?php require __DIR__ . '/callbacks-view.php'; ?>
<?php elseif ($section === 'purchases'): ?>
    <?php require __DIR__ . '/purchases-view.php'; ?>
<?php elseif ($section === 'iblocks'): ?>
    <?php require __DIR__ . '/iblocks-view.php'; ?>
<?php elseif ($section === 'captcha'): ?>
    <?php require __DIR__ . '/captcha-view.php'; ?>
<?php elseif ($section === 'maintenance'): ?>
    <?php require __DIR__ . '/maintenance-view.php'; ?>
<?php elseif ($section === 'modules'): ?>
    <?php require __DIR__ . '/modules-view.php'; ?>
<?php elseif ($section === 'find'): ?>
    <?php require __DIR__ . '/settings-search.php'; ?>
<?php elseif ($section === 'help'): ?>
    <?php require __DIR__ . '/help-view.php'; ?>
<?php endif; ?>
