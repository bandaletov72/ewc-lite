# Eurowebcart CMS Light

作者 - Бандалетов Павел。 [原始项目和更新](https://github.com/bandaletov72/php-site-updates)。

最低 PHP 版本为 7.2。该网站和管理面板支持 PHP 8.6。对于您的 PHP 模块和模板，请使用服务器上安装的版本的语法。

[管理员常见问题解答](faq.md) 也可在“帮助”选项卡中找到。

[当前版本的十种语言帮助 ](../README.md) 描述了搜索、网站编辑、本地化和维护。 [英文版管理员常见问题解答](../en/faq.md)。

对于定期维护，请将命令 `php update.php --scheduled` 添加到托管调度程序，周期为 15 分钟。在维护部分，您可以独立启用重新索引并设置签名 GitHub 更新的检查间隔。

## 本地发布

转到 `php-site` 目录并启动内置 PHP 服务器。

```sh
php -S 127.0.0.1:8000 router.php
```

该网站将在地址 `http://127.0.0.1:8000/` 上打开，管理面板位于 `http://127.0.0.1:8000/admin/`。

## 安装和首次登录

在本地服务器上，打开 `/admin/` 并创建一个帐户。第二步，设置站点名称、元描述、页脚文本、调色板和主题模式。如果您有 PHP GD，则可以立即下载徽标。向导将从中创建一个网站图标。单击“保存并打开管理”或继续当前设置。如果您退出向导，它将在您下次登录时继续。

在主机上，从项目目录运行 `php admin/setup.php` 并在向导的第一步中输入一次性代码。当您创建帐户时，将兑换该代码。安装前再次运行该命令将替换之前的代码。安装更新会保留以前的帐户和设置。如果更新之前的版本使用`SITE_ADMIN_PASSWORD_HASH`，则使用登录名`admin`和之前的密码保存登录。

为了使应用程序正常工作，您需要 PHP 会话以及对 `admin/`、`admin/write-lock.php`、`admin/inbox/`、`data/` 和可编辑页面目录的写入权限。要在根目录创建页面和目录，请授予 PHP 进程对项目根目录的写入权限。使用带有 HTTPS 的 Web 服务器，处理索引文件列表中的 `.php` 和 `index.php`。禁用目录列表。对于反向代理后面的 HTTPS，请通过可信服务器配置将 `HTTPS` 属性传递给 PHP。

## 页面和菜单

在管理面板中，主页列为 `/`，文件夹中的其余页面列为 `/contacts/`。例如，要创建子页面，请输入 `/Services-1/Repair/`。管理面板将创建目录和 `index.php` 本身。对于单独的文件，请输入类似 `/Services-1/About_2.php` 的地址。文件和文件夹名称中允许使用 `A–Z`、`a–z`、`0–9`、连字符和下划线。输入的名称不带空格。在根目录下，只允许使用主页。保留`data`、`admin`、`templates`、`css`、`js`等服务目录。

在页面列表中，可以展开文件夹。在菜单复选框中，隐藏、发布和删除都是通过 AJAX 保存的。隐藏、发布、删除都需要确认。拖动 ⠿ 图标对相邻页面进行排序。隐藏页面在发布前停止打开并从菜单中消失。

在页面编辑器中，打开“移动页面”块并指定目标文件夹。例如，如果您将 `/contacts/` 转账至 `/company/`，则新地址将为 `/company/contacts/`。嵌套页面保留在相同的地址。更新您自己的链接和指向迁移页面的 `[include]` 代码。

拖动⠿图标可更改同一级别内的顺序。对于一页，在其设置中打开“移动页面”。文件夹旁边的图标可打开父部分的选择。选择不同的分区或根文件夹，然后单击移动文件夹。该文件夹与所有附加的页面和文件一起传输。检查指向旧地址的链接和 [include]。

可以在文本编辑器中编辑内容并通过 FTP 或 SFTP 添加内容。文件必须采用 UTF-8 无 BOM 格式。将 PHP 服务块保存到 `__halt_compiler();` 行。在新页面文件中，在所需深度插入示例中的此块，并检查根 `index.php` 的相对路径。接下来是标题、一个空行和页面的 HTML 片段。

```php
<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Контакты
Heading: Как с нами связаться
Description: Контактная информация
Menu: Контакты
MenuVisible: 1
Order: 20

<p>Укажите здесь контактную информацию.</p>
```

`Title` 为必填项。空的 `Heading` 取自 `Title`。 `Description`填写页面的元描述。 `MenuVisible: 1` 在菜单中显示链接，`MenuVisible: 0` 隐藏它。对于 `index.php` 文件夹，取消选中该复选框也会隐藏菜单中的所有子页面。如果缺少 `MenuVisible`，则该复选框将继承之前的规则，并在填写 `Menu` 时被视为已启用。启用该复选框后，空字段 `Menu` 将替换为标头 `Title`。 `Order` 指定一级内的顺序，默认为 100。

CSS 和 JS 选项卡存储公共页面的常用 CSS 和 JavaScript。页面编辑器有一个单独的块“CSS 和 JavaScript 页面”。页面代码是在通用代码之后加载的。仅指定文件的内容，不指定 `<style>` 和 `<script>` 标签。每个字段允许的大小最大为 64 KiB。要从 CSS 链接到图像，您可以使用站点根目录中的路径。“帮助”选项卡包含可用模板和组件的示例。

在“设计模板”部分，您可以查看 `header.php`、`footer.php`、`menu.php` 和 `mobile-menu.php` 的源，并为每个模板设置通用 HTML。 “服务标头”将通用元标记、计数器代码和脚本插入 `<head>` 或 `</body>` 之前。在每个发布的完整页面上，`rel="canonical"` 都是由其常规地址形成的，不带查询参数。

## 设置、子模板和域

在“设置”部分，您可以设置站点名称、默认元描述、页脚文本和变量。在页脚文本中，`[year]` 自动显示当前年份。每行写入一个变量，例如 `[city] = Москва` 和 `[spb] = Санкт-Петербург`。要在网站标题、页面内容、页眉或页脚中显示值，请插入 `[city]`。在 PHP 模板中，您可以使用 `site_escape($settings['variables']['city'] ?? '')`。

系统替换包括 `[year]`、`[month]`、`[day]`、`[time]`（小时和分钟）、`[dmY]` 和 `[date]`（日期 DD.MM.YYYY）、`[datetime]`（日期和时间）。使用 PHP 时区。

在“基本 → 站点徽标和图标”中，您可以上传 PNG、JPEG、GIF 或 WebP。下载由 PHP GD 处理。创建图标按钮可以根据所选或保存的徽标创建透明的 64×64 PNG。图像存储在`templates/images/branding/` 和`templates/icons/branding/` 中。

“子模板”存储每个代码的名称、描述和含义。对于电话，创建 `[tel]`。要通过子模板设置选项卡标题，请创建 `[title]` 并在页面上的 `Title` 字段中指定它。选项卡标题后显示站点的名称。替换适用于页面文本和文本元数据。对于链接，插入整个 `<a>` 标记作为子模板值，并将代码放置在标记之间的文本中。在元数据中，HTML 从值转换为文本。

在“域”部分添加子域。在同名子域的管理面板中，选择“当前域”，或从常规列表中打开所需的域。局部含义优先于一般含义。公共页面在其地址中按域选择值，内部链接保存它。要连接子域，请在您的主机上配置 DNS 和 Web 服务器，以便该域提供相同的项目目录。

域旁边的“模板”按钮可打开 `[header]`、`[mobile-menu]`、`[menu]` 和 `[footer]` 编辑器。对于每个块，您可以设置自己的 HTML 或使用通用版本。通用模板在同一部分中配置。

## HTML 中的组件

|代码|结果 |
| --- | --- |
| `[gal]/images/myfotos/[/gal]` |具有平滑滚动、箭头和滑动功能的照片轮播 |
| `[fotos]/images/myfotos/[/fotos]` |照片库，附有原件链接 |
| `[files]/files/myfiles[/files]` |带有扩展名的图标的文件列表 |
| `[include]/contacts/[/include]` |另一个页面的 HTML 及其子模板和组件 |
| `[form1]` |在“表单”部分配置的表单|
| `[callback=Вызвать мастера]` |回电请求按钮和表格|
| `[iblock=table]/data/myiblock.txt[iblock]` |信息块表|
| `[iblock=phones]/data/myiblock.txt[iblock]` |信息块电话列表|
| `[phones]`、`[contacts]` |电话或整个定制的接触块|
| `[soc-icons]` |具有自定义链接的所有社交网络的图标|
| `[tg]`、`[vk]`、`[whatsapp]`、`[youtube]`、`[instagram]`、`[max]` |带有图标和签名的社交网络链接 |

将照片放入 `templates/images/myfotos/` 或 `images/myfotos/`。文件列表显示 `zip`、`pdf`、`xls`、`xlsx`、`doc`、`docx`、`png`、`gif`、`jpg`、`jpeg`、`mp4`、 `mov` 和 `mp3`。对于 `[include]`，最多支持十层嵌套。跳过当前线程中的页面重复。将组件代码放置在页面正文中，位于 HTML 块之间的单独一行上。

在“设置→联系人和社交网络”中设置链接、号码、签名和块标题。在“设置→主题和颜色”中，可以使用系统、深色和浅色模式以及个人调色板。在“设置→组件”中，您可以设置轮播和照片库的常规参数。在设置下有插入选定值的示例。页面代码中的参数会覆盖通用值。

在“主题和颜色”中，您可以将所选设置的副本保存在您自己的名称下或保留自动名称。 “应用”更改当前设计。使用默认值应用保存的主题并记住它以用于将主题重置为默认值命令。从列表中删除会保留站点的当前设计。

```text
[gal arrows=off numbers=off effect=fade fit=cover]/images/myfotos/[/gal]
[fotos columns=4 ratio=1x1 fit=cover captions=on links=off]/images/myfotos/[/fotos]
[files icons=on size=on order=desc download=on]/files/myfiles/[/files]
```

对于 `[fotos]`，可以手动设置宽屏幕的列数或自动选择。在窄屏幕上，网格会减少列数。可用的宽高比为 4:3、1:1、16:9 和原始、`cover` 和 `contain` 模式、文件名签名以及原始链接。

## 表单和反垃圾邮件

在“表单”部分，您可以编辑`[form1]`，创建`[form2]`和以下表单。对于表单，指定了收件人的地址、按钮签名和字段。该字段可以有最大长度。空值使用字段类型的默认限制。当您输入 `89031234567` 时，电话字段将其格式设置为 `+7(903)123-45-67`。服务器检查长度、类型、有效选择，并限制请求的总大小。免费输入字段接受纯文本。输出时消息中的 HTML 会被转义，并且新消息中的 HTML 标记会被拒绝。

“使用验证码”复选框启用 Google reCAPTCHA v2，对所选表单进行“我不是机器人”检查。输入域的站点密钥和秘密密钥。该秘密存储在受保护的设置文件中，仅用于服务器验证。 [服务器验证文档](https://developers.google.com/recaptcha/docs/verify)。

表单通过 AJAX 提交。申请保存在“消息”部分。如果指定了收件人，则 `mail()` 用于通知，这需要在主机上配置邮件。在反垃圾邮件部分，您可以编辑单词、表达式、IPv4 和 IPv6 地址的列表。链接在服务器上被阻止。发件人地址取自 `REMOTE_ADDR`。在反向代理后面，为可信代理配置Web服务器中原始IP的恢复。

每个表单都有一个“邮件模板”，其中包含“收件人”、“抄送（抄送）”、“电子邮件主题”和“电子邮件正文”字段。地址用逗号分隔。如果至少指定了一个主要收件人，则会发送副本。字段键插入到大括号中的主题和文本中，例如 `Привет {name}!`。空字段值被替换为空字符串，未知密钥保留在字母中。如果主题或正文为空，则使用标准信件的相应部分。

## 回调

将 `[callback]` 或 `[callback=Вызвать мастера]` 插入 HTML 页面。该按钮将打开一个包含电话号码的表单。请求保存在“回调”部分。按钮的签名以及将请求传输到电话的模式也在那里设置。默认情况下，选择“无”提供商并仅保存请求。可以启用电话从列表中手动发送或在收到号码后立即发送。

- **Zadarma.** 在管理面板中设置号码、SIP 或操作员分机，并通过 `SITE_ZADARMA_KEY` 和 `SITE_ZADARMA_SECRET` 将密钥传输到 PHP。 [Zadarma API](https://zadarma.com/en/support/api/) 文档
- **HTTP API。** 使用 HTTPS 地址指定 `SITE_CALLBACK_WEBHOOK_URL`，也可以选择指定 `SITE_CALLBACK_WEBHOOK_TOKEN`。该站点发送包含 JSON 字段 `id`、`phone`、`host`、`page`、`requested_at` 和标头 `Idempotency-Key` 的 POST。令牌作为 Bearer 进行转移。响应代码 2xx 将请求转移到“电话已接受”状态。

授予 PHP 进程写入权限给 `admin/callbacks/`。应用程序使用表单反垃圾邮件设置。重复同一号码的时间限制为一分钟；每 15 分钟最多接受 3 个通过 IP 的请求。

## 信息块和封闭数据文件夹

在“信息块”部分中，您可以创建数据集、编辑和拖动行。信息块名称和列键中允许使用 `A–Z`、`a–z`、`0–9`、连字符和下划线。输入的名称和密钥不带空格。列名和单元格值可以用俄语书写。控件对应于列类型，并通过 AJAX 完成保存。☰“编辑为文本”按钮将整个信息块切换为带有 `|` 分隔符和复制按钮的 CSV。前三行包含列的键、名称和类型。然后是数据线。CSV 中的日期为 `ГГГГ-ММ-ДД`，是/否存储为 `1` 或 `0`。

```text
name|phone|is_open
Название|Телефон|Открыто
text|tel|bool
Справочная|+7(903)123-45-67|1
```

`phones` 模板使用 `tel` 类型的列和带有标题的文本列。您可以将模板放置在 `templates/local/iblock/имя.php` 中，其中 `$block['columns']` 和 `$block['rows']` 可用。

代码里面的路径`/data/myiblock.txt`对应的是文件`data/myiblock.txt.php`。这是带有 PHP 存根的 UTF-8 文本，直接调用时会返回 404。 `router.php` 在本地运行时关闭整个文件夹。`data/` 有针对 Apache 和 IIS 的规则。对于 Apache，启用 `data/.htaccess`。在 Nginx 上，在站点配置中配置要关闭的文件夹，并在子目录中安装时考虑前缀。

```nginx
location = /data { return 404; }
location ^~ /data/ { return 404; }
```

安装后，检查对 `/data/` 的直接请求和信息块文件是否收到 403 或 404。

## 加载 HTML 片段

通常的地址 `/contacts/` 打开整个页面。如果 `X-Site-Fragment` 标头中存在会话密钥，则请求 `?ajax=1` 将返回带有 H1 的 `<main>` 和已处理的内容。片段链接到当前原点。带有键的页面和片段无需缓存即可提供。

在网站页面上的 JavaScript 中，使用内置函数。

```js
const html = await window.siteFetchContent('/contacts/');
document.getElementById('content').outerHTML = html;
```

在子目录中安装时，传递带有站点前缀的 URL。脚本和样式取自插入片段的页面。公共页面仍然可以通过常规地址访问。

## 模板和资源

在“设置 → 库和字体”中，分别启用 jQuery、Bootstrap、Font Awesome、Material UI、Alpine.js、htmx、Chart.js 和 GLightbox。 Font Awesome 存储在本地。启用后，浏览器会从 CDN 下载其余库。 Material UI 可在脚本 `type="module"` 到 `import { Button } from '@mui/material'` 中使用。对于图标，`[fa-icon=house]` 或常用标记 `<i class="fa-solid fa-house"></i>` 是合适的。

提供 10 种带有西里尔字母的 Google 字体。该选择将替换站点的系统字体。值“System”返回先前的设计。在“设置→主题和颜色→保存的主题”中有五个现成的调色板，带有浅色和深色选项。

|路径|目的地 |
| --- | --- |
| `index.php` |主页和一般入口点|
| `contacts/index.php` |单独目录中的页面示例 |
| `admin/` |登录和页面编辑器 |
| `app/site.php` |阅读 `SITE_NAME` 中的页面、构建菜单和网站标题 |
| `templates/layout.php` |总体布局、选项卡标题、元数据和内容区域 |
| `templates/header.php`、`menu.php`、`footer.php` |页眉、菜单和页脚 |
| `templates/css/`、`js/`、`icons/`、`images/` |样式、脚本、图标和图像 |
| `templates/components/`、`templates/iblock/` |组件标记和信息块模板 |
| `data/` |防止直接 HTTP 访问的信息块文件 |

该引擎组装了 `[header]`、`[mobile-menu]`、`[menu]` 和 `[footer]` 的完整页面。它们是顶部栏、移动菜单、右侧菜单和页脚。它们可以通过管理面板中的同名子模板重新定义，包括子域的单独选项。使用相同的相对路径将 PHP 模板覆盖存储在 `templates/local/` 中，例如 `templates/local/footer.php`。

## 引擎更新

新安装需要完整的存档。对于实时站点，请使用 `php-site-update.zip`。它仅包含引擎和标准模板。保存的页面、信息块、设置、密码、消息和用户扩展不包含在存档中。

单击“设置→更新”中的“更新引擎”或从托管调度程序运行相同的检查。

```sh
php update.php --github
```

默认源是 `bandaletov72/php-site-updates`。对于您自己的存储库，将其设置为 `SITE_GITHUB_REPO`。公共存储库不需要令牌。对于私有存储库，将变量 `SITE_GITHUB_TOKEN` 传递给具有内容读取权限的 PHP 进程。服务器需要 Zip 和 OpenSSL PHP 扩展以及向 GitHub 发出 HTTPS 请求的能力。

对于手动安装，请使用 ZIP。

```sh
php update.php /path/to/php-site-update.zip
```

在没有 `update.php` 的旧版本上，首先将包解压到项目顶部，保留现有的 `.htaccess` 和 `maintenance/` 中的文件（如果有）。如果您编辑了标准模板，请在更新之前将编辑内容传输到 `templates/local/`。安装程序会验证文件的列表和校验和，对于 GitHub，它还会使用可信公钥 `maintenance/release-public.pem` 验证签名。

对于下一个版本，将版本更改为 `app/version.php` 并通过 `php update.php --build php-site-update.zip` 构建包。使用 SHA-256 的 RSA 私钥对 ZIP 进行签名，并将私钥与站点分开存储。然后将 ZIP 和 `.sig` 推送到带有标签 `vX.Y.Z` 的 GitHub Release 或 `updates/vX.Y.Z/` 并将 `updates/latest.json` 更新为 `{"version":"X.Y.Z"}`。

## 扩展

引擎模块可以随更新一起添加到 `app/extensions/`。将您自己的模块存储在更新包之外的 `extensions/` 中。 PHP 文件返回定义数组。对于单个组件，`kind` 等于 `single`，对于带参数的组件，它等于 `wrapped`。引擎识别现有页面上的新代码。组件可以在 `settings` 中声明选项菜单，将每个选项设置为 `label`、`default` 和数组 `options`。这些值转到 `$context['settings']`。

```php
<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return ['notice' => [
    'kind' => 'wrapped',
    'render' => static function (string $text, array $context): string {
        return '<strong>' . site_escape($text) . '</strong>';
    },
]];
```

示例组件作为 `[notice]Важное сообщение[/notice]` 插入。

## 1.6.3版本新增

### 家庭和隐私政策

打开“设计模板”编辑主页和/privacy.php页面。代码[page-content]显示主页的内容。在策略 [site-name] 和 [site-url] 中，从“设置→常规”中获取名称和公共地址。使用有关您的站点和数据处理的信息完成初始文本。

### Cookie 并返回顶部

在页脚中，[conf-policy] 提供指向策略的链接，[cookies] 打开设置，[top] 滚动到页面顶部。分析和内置 CMS 地图正在等待达成协议。手动添加到模板或服务标头的脚本需要自己的配置。

### 编辑functions.php

打开“服务标题”选项卡后的“设计模板→功能”。将闭包添加到返回的数组中。在 PHP 模板中，调用 `translit("Москва")` 或 `ew_call("translit", "München")`。在 HTML 中插入 [func=translit value="Москва и München"]。该示例生成 `Moskva i Muenchen`。

### 编辑标准模板

在“设计模板”字段中已经包含突出显示的 PHP 和 HTML 源代码。编辑标准模板时，选择“自定义 PHP”。保存会创建自定义版本。使用模板旁边的按钮，您可以撤消上次编辑或恢复原始内容。

### 保存前 PHP 检查

设计模板、模块和 functions.php 编辑器使用 `php -l` 命令检查语法。如果出现错误，则保留以前的版本。要选择服务器上的 PHP CLI，请使用变量 `SITE_PHP_LINT_BINARY`。

### 背光和紧凑搜索

新安装时默认启用 CodeMirror。该设置位于“库和字体”中。在紧凑搜索中，字段向左扩展，十字清除该行，然后按 Enter 键开始搜索。

### 管理菜单和编辑面板

管理面板标题下的菜单和网站上的编辑面板显示带有标题的图标。图标保留在窄屏幕上。悬停时工具提示会打开，键盘会聚焦在窄屏幕上。 “隐藏”位于其余页面操作旁边。编辑模式开关位于右侧。

### PHP模块说明及代码

在“PHP 模块”中，简短描述适用于纯文本。将函数主体粘贴到单独的字段“源代码·PHP”中。

## 管理标题中的按钮 · 1.6.4

地球仪打开站点，箭头结束管理员会话。手机上仅显示图标。当您将鼠标悬停或使用键盘聚焦时，会出现工具提示。

“内容”、“表格和应用程序”以及“网站和服务”立即开放。其选项卡位于所选部分的标题下。

将 [bread-crumbs] 或 [search] 插入主页 (index.php) 或模板的 HTML 中。该块将在指定位置出现一次。面包屑复选框和搜索模式也适用于插入的标签。 [privacy] 显示指向 /privacy/ 的链接。政策文本在“页面”部分进行编辑。

```text
[bread-crumbs]
[search]
[privacy]
```

## 服务文件、地图和模板 · 1.6.5

打开“维护→服务文件”。这里编辑.htaccess、robots.txt和sitemap.xml。生成 sitemap.xml 会使用“在站点地图中显示”复选框获取已发布的页面。以前的版本可用于 .htaccess。

在页面上填写纬度和经度。 [map]将显示其积分，[maps]将收集已发布页面的积分。在这两个标签中，center 指定中心，zoom 指定比例。交互式地图使用 Integrations 的提供程序。

带有下拉小节的 [main-menu] 显示在标题下方。在设计模板中，创建您自己的模板并配置移动设备和桌面设备上的可见性。在“子模板”中，“+ 添加域”按钮会导致添加表单。要参考该策略，请使用 [privacy]。

在“集成”中，指定 JivoSite、Microsoft Clarity 和 Umami Cloud ID、Botfaqtor 代码或 Slack 传入 Webhook。说明链接位于字段旁边。在扎达玛，检查您的余额、发送测试短信或拨打国际号码进行测试呼叫。短信和通话可能需要付费。对于 [payment]，插入现成的付款链接 YuMoney、PayPal 和 SBP。付款状态在提供商的帐户中检查。

在 HTML 和可视化编辑器中，图标格式化文本、添加 H1–H5 和列表。定位光标并单独选择模板、组件、图像或图标。保存的代码可用于表单，其参数可用于组件。启用库后，Font Awesome 插入即可使用。

单击左侧的文件夹名称可管理右侧的部分。您可以在其中选择父部分、配置常规菜单和移动菜单，或指定转换 URL。空白部分页面显示小节。在“维护”中，设置 /contact.html => /contacts/ 等规则，并在 /error/ 中编辑错误页面。手机上的搜索和语言可通过标题中的图标进行。

```text
[map]
[map center="55.7558,37.6173" zoom=14]
[maps center="55.7558,37.6173" zoom=11]
[main-menu]
[lang]
[privacy]
[payment]
```

```php
$var = translit("Москва"); // Moskva
```

## 编辑页面数据·1.6.6

在编辑模式下，信息块、表格[formX]、子模板[tel]等带有单独数据的组件有“数据”和“全屏”动作。 “信息块类型”列出了已注册的输出模板。在父节列表中，“根文件夹”将该节移动到顶层。使用 [list-pages] 列出节及其子文件夹的已发布页面。可以通过单击列表外部或单击“退出”来关闭管理面板中的语言菜单。

## 移动菜单1.6.7

- 在主菜单中显示
- 在手机菜单中显示
- 隐藏在移动菜单中

## 页面设置·1.6.8

在“编辑”中写入内容。地址、菜单和发布时间表在“页面设置”中配置。标题、元描述、关键字和站点地图包含在 SEO 中。坐标和示例标签可以在地图中找到。

空白日期消除了限制。使用该网站的时区。隐藏页面必须单独发布。

- `[map]` - 当前页面上有一个点的地图。
- `[maps]` - 包含已发布页面的所有点的地图。

## 横幅和图像编辑器·1.6.8

在组件中设置集和框架。您可以从文件夹中拍摄照片，设置标题、带有链接的按钮、表单或回调，并选择显示时间。在编辑模式下，框架按钮可打开其设置。插入图像会打开文件夹、下载、删除并创建旋转或调整大小的副本。要创建副本，您需要 GD。Font Awesome 选择显示图标并支持按名称搜索。

```text
[banners]
[banners set=summer arrows=on numbers=off]
[banners]/images/myfotos/[/banners]
```

## 语言1.6.9

“语言”选项卡列出了页面的语言。 “打开”会打开已保存的版本，“创建翻译”会打开编辑器以进行新翻译。

对于新部分，选择所需的级别。在开放部分内创建子部分，在其旁边创建相邻部分，并在站点的顶层创建根部分。

## PHP 兼容性和导航·1.6.10

最低 PHP 版本为 7.2。该网站和管理面板支持 PHP 8.6。对于您的 PHP 模块和模板，请使用服务器上安装的版本的语法。

当前项目 [bread-crumbs] 扩展了同级别的其他已发布部分（如果它们包含在主菜单中）。页面设置中的 URL 用于菜单、部分列表、面包屑、结果和搜索建议。

回收站从信息块编辑器中删除该行。删除列会删除该列的所有值。保存信息块时会记录编辑，包括拖动后自动保存时。

### 站点备份

ZIP 存储在一个封闭的文件夹中，包括页面、媒体、信息块、设置、自定义模板和 PHP 模块。管理员帐户和传入请求单独保存。为了存档，您需要 PHP Zip 扩展。

将内容和设置替换为所选副本。在替换之前，将创建当前状态的新备份。

### 清理未使用的文件

扫描会查找存储内容中没有链接的媒体。检查列表并标记您需要的文件。清理之前会创建备份。删除组件的代码会保留其文件夹和文件。

### 在地图上选择一个点

在您的 Yandex 地图帐户中，为“地图”部分中的“JavaScript API”产品创建密钥。将密钥限制为 HTTP Referer 域。打开提供程序后，在页面的“地图”选项卡上，单击“在地图上选择”，放置一个点并将其坐标传输到字段。

在可视化编辑器中，选择要对齐或删除格式的文本。单击图像打开其选项。拖动一个角来调整大小或将图像本身拖动到另一个位置。该链接提供 URL、电子邮件、电话和锚点。该按钮可以打开 URL、表单、回调或付款。要付款，请使用提供商的链接支付指定金额。

HTML 和可视化编辑器模式通过选项卡切换。 SUP、SUB 和段落插入适当的元素。这些代码在组件名称旁边可见。如果路径中的段仅包含拉丁字母、数字、连字符和下划线，则在插入时创建媒体文件夹。“语言”选项卡可以选择其他站点语言。

```text
[button action="url" label="Contacts" url="/contacts/"]
[button action="form" label="Write to us" form="form1"]
[button action="callback" label="Call me"]
[button action="payment" label="Pay" amount="1250.00" currency="RUB" yoomoney="410010000000000"]
[map]
[maps]
```

## 销售 · 1.6.11

在“销售”选项卡设置价格和付款方式，也可以按语言单独设置。插入 [item-price] 和 [item-buy-button]。客户前往支付服务前，系统会记录订单。订单状态可通过电子邮件和 Zadarma 短信通知客户。

已受理 · 已确认付款 · 已发货 · 已完成 · 已取消

```text
[item-price]
[item-buy-button]
```

插入图像需要选定的文件或 URL。单击图像即可显示其尺寸、对齐方式、四个边距和 CSS。所选图像的对齐方式与文本分开应用。切换到 HTML 时，块标记会逐行显示。 “[list-pages] 部分的页面列表”位于组件列表中。管理页眉和页脚中的 CMS 徽标使用当前主题的颜色。

## 数据块图表

在页面编辑器中打开“插入组件”，选择表格或图表。绘制图表时，请启用 Chart.js，选择标签列及“数字”或“价格”类型的数值列。饼图、环形图和极区图使用一组非负数据。停用图表库时仍会显示表格。

重新打开编辑器后，已保存的表单、模板、片段和已注册的组件会自动出现在插入列表中。新横幅组的 ID 只允许 A–Z、a–z、连字符和下划线。将图片上传到 [banners] 文件夹后，每个文件旁边都会出现编辑链接。 在网站编辑模式中，“编辑幻灯片”会在弹窗中打开选中的幻灯片，另有链接可查看组件默认设置。轮播、相册和文件列表的保存按钮旁有文件管理器，支持上传、删除、排序和新建子文件夹（A–Z、a–z、0–9、-、_）。幻灯片颜色以方形色样显示。

```text
[iblock=table]/data/myiblock.txt[/iblock]
[iblock=charts type=line labels=month values=sales,orders]/data/myiblock.txt[/iblock]
[banners set=summer-promo]
```

## 后台页眉和页脚 · 1.6.12

桌面端的标志旁显示 Eurowebcart CMS、Light 和已安装的版本。手机端的标志与操作按钮排在同一行。页脚显示仓库地址，可在“设置 → 更新”中检查累积版本。

## 后台页眉和页脚 · 1.6.13

桌面端的标志旁显示 Eurowebcart CMS、Light 和已安装的版本。手机端的标志与操作按钮排在同一行。页脚显示仓库地址，可在“设置 → 更新”中检查累积版本。 页面列表中的默认首页名称随后台语言显示。页脚标识分两行显示 Eurowebcart CMS 和 LIGHT。

## PHP 信息

“维护”中的 phpinfo() 仅向已登录的管理员显示 PHP 版本、模块和配置，隐藏环境变量和请求变量。在“设置 → 常规”中可设置 error_reporting，默认采用服务器设置。

## 隐藏页面树 · 1.6.14

在桌面端，点击箭头可折叠页面树并加宽编辑器。编辑器上方的按钮可恢复页面树。浏览器会记住选择。

## 隐藏页面树 · 1.6.15

在桌面端，点击箭头可折叠页面树并加宽编辑器。编辑器上方的按钮可恢复页面树。浏览器会记住选择。

## 在地图上选点

在 Yandex Maps 控制台为 JavaScript API 产品创建密钥，并通过 HTTP Referer 限制访问域名。在页面的地图标签中选择地点并应用坐标。 本地测试时在 HTTP Referer 中填写不带端口的 localhost。密钥激活后，使用 localhost 打开后台。

## 菜单中的搜索 · 1.6.16

[search] 在桌面端与 [main-menu] 的链接并排显示，在手机端显示在 [mobile-menu] 内。搜索模式在常规设置中选择。页面正文中的 [search] 优先。

`[search]`
