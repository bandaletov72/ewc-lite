<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_COMPONENTS_FILE = SITE_ROOT . '/admin/.components.php';
const SITE_COMPONENT_SIZE_OPTIONS = '(?:[\x20\t]+(?:width|height|mobile-height|height-mobile)=[a-z0-9_-]+%?)*';

function site_component_size_fields(): array
{
    $heights = ['auto' => 'Авто'];
    foreach ([160, 240, 320, 400, 520, 640, 800, 1000] as $height) $heights[$height] = $height . ' px';
    return [
        'width' => ['label' => 'Ширина блока', 'default' => 'auto', 'options' => [
            'auto' => 'Авто', 'page' => '100% ширины страницы', 'content' => '100% ширины контента',
            'parent' => '100% ширины родительского блока', '50' => '50%', '33' => '33%', '25' => '25%',
        ]],
        'height' => ['label' => 'Высота на компьютере', 'default' => 'auto', 'options' => $heights],
        'mobile-height' => ['label' => 'Высота на телефоне', 'default' => 'auto', 'options' => $heights],
    ];
}

function site_component_size_text(string $text, string $language): string
{
    static $catalog;
    if ($catalog === null) $catalog = require __DIR__ . '/help-component-sizes.php';
    $keys = ['Ширина блока', 'Высота на компьютере', 'Высота на телефоне', 'Авто',
        '100% ширины страницы', '100% ширины контента', '100% ширины родительского блока'];
    $index = array_search($text, $keys, true);
    return $index === false ? site_translation($text, $language) : ($catalog[$language] ?? $catalog['ru'])[$index];
}

function site_component_schema(): array
{
    static $cached;
    if ($cached !== null) return $cached;
    $toggle = ['on' => 'Показывать', 'off' => 'Скрывать'];
    $schema = ['gal' => [
        'label' => 'Карусель [gal]',
        'examplePath' => '/images/myfotos/',
        'settings' => [
            'arrows' => ['label' => 'Стрелки', 'default' => 'on', 'options' => $toggle],
            'numbers' => ['label' => 'Номер слайда', 'default' => 'on', 'options' => $toggle],
            'effect' => ['label' => 'Переход', 'default' => 'slide',
                'options' => ['slide' => 'Плавная прокрутка', 'fade' => 'Плавное затухание', 'none' => 'Мгновенно']],
            'fit' => ['label' => 'Заполнение кадра', 'default' => 'contain',
                'options' => ['contain' => 'Вместить целиком (contain)', 'cover' => 'Заполнить кадр (cover)']],
        ],
    ], 'fotos' => [
        'label' => 'Фотогалерея [fotos]',
        'examplePath' => '/images/myfotos/',
        'settings' => [
            'columns' => ['label' => 'Колонки на широком экране', 'default' => 'auto',
                'options' => ['auto' => 'Автоматически', 1 => '1', 2 => '2', 3 => '3', 4 => '4', 5 => '5', 6 => '6']],
            'ratio' => ['label' => 'Пропорции фотографии', 'default' => '4x3',
                'options' => ['4x3' => '4:3', '1x1' => '1:1', '16x9' => '16:9', 'original' => 'Исходные']],
            'fit' => ['label' => 'Заполнение кадра', 'default' => 'cover',
                'options' => ['cover' => 'Заполнить кадр (cover)', 'contain' => 'Вместить целиком (contain)']],
            'captions' => ['label' => 'Подписи из имён файлов', 'default' => 'off', 'options' => $toggle],
            'links' => ['label' => 'Ссылки на оригиналы', 'default' => 'on', 'options' => $toggle],
        ],
    ], 'files' => [
        'label' => 'Список файлов [files]',
        'examplePath' => '/files/myfiles/',
        'settings' => [
            'icons' => ['label' => 'Иконки файлов', 'default' => 'on', 'options' => $toggle],
            'size' => ['label' => 'Размер файла', 'default' => 'off', 'options' => $toggle],
            'order' => ['label' => 'Сортировка по имени', 'default' => 'asc', 'options' => ['asc' => 'От А до Я', 'desc' => 'От Я до А']],
            'download' => ['label' => 'При нажатии', 'default' => 'off', 'options' => ['off' => 'Открыть', 'on' => 'Скачать']],
        ],
    ]];
    $schema['banners'] = ['label' => 'Баннеры [banners]', 'settings' => $schema['gal']['settings']];
    $schema['banners']['settings']['fit']['default'] = 'cover';
    foreach (['form' => 'Формы', 'callback' => 'Обратный звонок', 'map' => 'Карта', 'maps' => 'Карты', 'maplist' => '[maplist]', 'points' => '[points]',
        'iblock' => 'Инфоблоки', 'include' => '[include]', 'php' => 'PHP-модули', 'button' => 'Кнопка',
        'list-pages' => 'Список страниц', 'sections' => '[sections]', 'payment' => '[payment]',
        'item-price' => '[item-price]', 'item-buy-button' => '[item-buy-button]', 'cities' => 'Города', 'phones' => 'Телефоны'] as $kind => $label) {
        $schema[$kind] = ['label' => $label, 'settings' => []];
    }
    foreach (site_extensions() as $name => $component) {
        $settings = [];
        foreach (is_array($component['settings'] ?? null) ? $component['settings'] : [] as $key => $field) {
            if (is_string($key) && site_valid_snippet($key) && is_array($field)
                && is_string($field['label'] ?? null) && is_string($field['default'] ?? null)
                && is_array($field['options'] ?? null) && isset($field['options'][$field['default']])) {
                $settings[$key] = $field;
            }
        }
        if (!isset($schema[$name])) {
            $schema[$name] = ['label' => is_string($component['label'] ?? null) ? $component['label'] : $name,
                'settings' => $settings];
        }
    }
    $dimensions = site_component_size_fields();
    foreach ($schema as $id => &$component) {
        $size = $dimensions;
        if (in_array($id, ['gal', 'fotos', 'files', 'banners'], true)) $size['width']['default'] = 'parent';
        $component['settings'] = $size + $component['settings'];
    }
    unset($component);
    return $cached = $schema;
}

function site_component_settings(): array
{
    try {
        $saved = site_read_record(SITE_COMPONENTS_FILE);
    } catch (RuntimeException $exception) {
        $saved = [];
    }
    $settings = [];
    foreach (site_component_schema() as $id => $component) {
        foreach ($component['settings'] as $name => $field) {
            $value = $saved[$id][$name] ?? $field['default'];
            if ($name === 'width' && $value === '100') $value = 'parent';
            $settings[$id][$name] = is_string($value) && isset($field['options'][$value]) ? $value : $field['default'];
        }
    }
    return $settings;
}

function site_component_options(string $component, string $overrides): array
{
    static $defaults;
    if ($defaults === null) {
        $defaults = site_component_settings();
    }
    $settings = $defaults[$component] ?? [];
    $fields = site_component_schema()[$component]['settings'] ?? [];
    foreach (site_shortcode_options($overrides) as $name => $value) {
        if ($name === 'height-mobile') $name = 'mobile-height';
        if ($name === 'width') {
            $value = rtrim($value, '%');
            if ($value === '100') $value = $component === 'banners' ? 'page' : 'parent';
        }
        if (in_array($name, ['height', 'mobile-height'], true) && preg_match('/\A[0-9]{2,4}(?:px)?\z/', $value)) {
            $pixels = (int) $value;
            if ($pixels >= 80 && $pixels <= 1600) $settings[$name] = (string) $pixels;
        } elseif (isset($fields[$name]['options'][$value])) {
            $settings[$name] = $value;
        }
    }
    return $settings;
}

function site_component_match_size(array $match): array
{
    if (strtolower($match['map'] ?? '') === 'route') return ['', ''];
    foreach (['galleryTag' => 'galleryOptions', 'banners' => 'bannerOptions', 'form' => 'formOptions',
        'callback' => 'callbackOptions', 'map' => 'mapOptions', 'sectionMap' => 'sectionMapOptions', 'extensionTag' => 'extensionOptions',
        'actionButton' => 'actionButtonOptions', 'sizeTag' => 'sizeOptions'] as $key => $options) {
        if (!empty($match[$key])) {
            $kind = $key === 'form' ? 'form' : strtolower($match[$key]);
            return [$kind, $match[$options] ?? ''];
        }
    }
    foreach (['files' => 'fileOptions', 'include' => 'includeOptions', 'iblock' => 'iblockOptions', 'phpModule' => 'phpOptions'] as $key => $options) {
        if (!empty($match[$key])) return [$key === 'phpModule' ? 'php' : $key, $match[$options] ?? ''];
    }
    $name = strtolower($match['snippet'] ?? '');
    return $name !== '' && isset(site_component_schema()[$name]) ? [$name, ''] : ['', ''];
}

function site_component_size_markup(string $html, string $kind, string $overrides): string
{
    if ($html === '' || $kind === '') return $html;
    $settings = site_component_options($kind, $overrides);
    $width = $settings['width'] ?? 'auto';
    $height = $settings['height'] ?? 'auto';
    $mobile = $settings['mobile-height'] ?? 'auto';
    if ($width === 'auto' && $height === 'auto' && $mobile === 'auto') return $html;

    $class = 'component-width component-width-' . ($width === 'parent' ? '100' : $width);
    if ($kind === 'banners' && $width === 'page') $class .= ' banner-full-width';
    $expanded = in_array($width, ['page', 'content'], true) ? ' data-component-width="' . $width . '"' : '';
    $style = ($height !== 'auto' ? '--component-height-desktop:' . (int) $height . 'px;' : '')
        . ($mobile !== 'auto' ? '--component-height-mobile:' . (int) $mobile . 'px;' : '');
    $attrs = $style === '' ? '' : ' data-component-height="' . (in_array($kind, ['gal', 'banners'], true) ? 'gallery' : 'box')
        . '" style="' . $style . '"';
    return '<div class="' . $class . '"' . $expanded . $attrs . '>' . $html . '</div>';
}
