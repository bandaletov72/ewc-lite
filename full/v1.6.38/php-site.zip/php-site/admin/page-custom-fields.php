<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_page_custom_labels(): array
{
    static $labels;
    $labels = $labels ?? (require SITE_ROOT . '/app/help-page-custom-fields.php');
    return $labels[$GLOBALS['adminLanguage'] ?? 'ru'] ?? $labels['ru'];
}

function admin_save_page_custom_definitions(array $input)
{
    $labels = admin_page_custom_labels();
    $rows = $input['custom_definitions'] ?? null;
    if (!is_array($rows) || count($rows) > SITE_PAGE_CUSTOM_FIELD_COUNT + 1) throw new RuntimeException($labels[5]);
    $lock = admin_lock();
    try {
        $current = site_page_custom_definitions(true);
        if (!hash_equals(admin_settings_revision($current), admin_input($input, 'schema_revision'))) {
            throw new RuntimeException($labels[7]);
        }
        $schema = [];
        $used = array_fill_keys(site_page_reserved_field_ids(), true);
        $types = site_iblock_types();
        foreach ($rows as $key => $row) {
            if (!is_array($row) || ($key !== 'new' && !isset($current[$key]))) throw new RuntimeException($labels[5]);
            $id = trim(admin_input($row, 'id'));
            $description = trim(admin_input($row, 'description'));
            $type = admin_input($row, 'type');
            if ($key === 'new' && $id === '' && $description === '') continue;
            if (!preg_match('/\A' . SITE_IDENTIFIER_PATTERN . '\z/', $id) || isset($used[strtolower($id)])) {
                throw new RuntimeException($labels[5] . ' ' . $id);
            }
            if (!isset($types[$type]) || strlen($description) > 1500 || preg_match('//u', $description) !== 1
                || preg_match('/[\x00-\x1F\x7F]/', $description)) {
                throw new RuntimeException($labels[6] . ' ' . $id);
            }
            $used[strtolower($id)] = true;
            if ($key === 'new') $key = 'f-' . bin2hex(random_bytes(8));
            $schema[$key] = ['id' => $id, 'description' => $description, 'type' => $type];
        }
        if (count($schema) > SITE_PAGE_CUSTOM_FIELD_COUNT || array_diff_key($current, $schema)) throw new RuntimeException($labels[5]);
        admin_write_record(SITE_PAGE_CUSTOM_SCHEMA, $schema, SITE_PAGE_CUSTOM_SCHEMA_LIMIT);
    } finally {
        fclose($lock);
    }
}

function admin_encode_page_custom_values(array $input, array $previous): string
{
    $labels = admin_page_custom_labels();
    $schema = site_page_custom_definitions(true);
    if (!hash_equals(admin_settings_revision($schema), admin_input($input, 'custom_schema_revision'))) {
        throw new RuntimeException($labels[7]);
    }
    $values = site_decode_page_custom_values($previous['CustomFields'] ?? '') ?? [];
    $submitted = $input['custom_values'] ?? [];
    if (!is_array($submitted) || array_diff_key($schema, $submitted) || array_diff_key($submitted, $schema)) {
        throw new RuntimeException($labels[7]);
    }
    foreach ($schema as $key => $field) {
        if (!is_string($submitted[$key])) throw new RuntimeException($labels[6] . ' ' . $field['id']);
        $value = $field['type'] === 'textarea' ? $submitted[$key] : trim($submitted[$key]);
        if (($values[$key] ?? '') !== $value && !admin_validate_cell($value, $field['type'])) {
            throw new RuntimeException($labels[6] . ' ' . $field['id']);
        }
        if ($value === '') unset($values[$key]);
        else $values[$key] = $value;
    }
    if (!$values) return '';
    $json = json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false || strlen($json) > SITE_ASSET_LIMIT) throw new RuntimeException($labels[6]);
    return base64_encode($json);
}
