<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<details class="page-code" data-page-tab-panel="custom-fields"<?= ($error !== '' && admin_input($_POST, 'action') === 'save-page-custom-definitions') ? ' open' : '' ?>>
    <summary><?= site_escape($customLabels[2]) ?></summary>
    <form class="form-stack" method="post" action="<?= site_escape(admin_page_edit_url($adminUrl, $page['path']) . '#page-custom-fields') ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="action" value="save-page-custom-definitions">
        <input type="hidden" name="path" value="<?= site_escape($page['path']) ?>">
        <input type="hidden" name="schema_revision" value="<?= site_escape(admin_settings_revision($customDefs)) ?>">
        <p class="hint"><?= site_escape($customLabels[4]) ?></p>
        <details><summary><?= site_escape($customLabels[3]) ?></summary><p class="hint"><code><?= site_escape(implode(', ', site_page_reserved_field_ids())) ?></code></p></details>
        <div class="iblock-table-wrap">
            <table class="iblock-table iblock-editor-table">
                <thead><tr>
                    <th scope="col">ID</th><th scope="col"><?= site_escape($customLabels[1]) ?></th><th scope="col"><?= admin_l('Тип') ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ($customDefs + ['new' => ['id' => '', 'description' => '', 'type' => 'text']] as $key => $field): ?>
                    <?php
                    if ($key === 'new' && count($customDefs) >= SITE_PAGE_CUSTOM_FIELD_COUNT) continue;
                    $draft = $_POST['custom_definitions'][$key] ?? null;
                    if ($error !== '' && is_array($draft)) {
                        foreach (array_keys($field) as $part) $field[$part] = admin_input($draft, $part);
                    }
                    $prefix = 'custom_definitions[' . site_escape($key) . ']';
                    ?>
                    <tr>
                        <td><input name="<?= $prefix ?>[id]" value="<?= site_escape($field['id']) ?>" aria-label="ID"
                            pattern="[A-Za-z0-9_\x2D]{1,64}" maxlength="64"<?= $key === 'new' ? ' placeholder="event-id"' : ' required' ?>></td>
                        <td><input name="<?= $prefix ?>[description]" value="<?= site_escape($field['description']) ?>"
                            aria-label="<?= site_escape($customLabels[1]) ?>" maxlength="375"></td>
                        <td><select name="<?= $prefix ?>[type]" aria-label="<?= admin_l('Тип') ?>">
                            <?php foreach (site_iblock_types() as $type => $label): ?>
                                <option value="<?= $type ?>"<?= $field['type'] === $type ? ' selected' : '' ?>><?= admin_l($label) ?></option>
                            <?php endforeach; ?>
                        </select></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div><button class="button-primary"><?= site_escape($customLabels[9]) ?></button></div>
    </form>
</details>
