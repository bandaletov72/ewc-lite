<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'В последней хлебной крошке доступны опубликованные соседние разделы, включая те, которые убраны из основного меню. Если у раздела указан URL, ссылка ведёт по этому адресу.',
    'en' => 'The final breadcrumb lists published sibling sections, including sections hidden from the main menu. A configured section URL is used for its link.',
    'uk' => 'Остання хлібна крихта показує опубліковані сусідні розділи, зокрема прибрані з головного меню. Для посилання використовується вказаний URL.',
    'ja' => '最後のパンくずにはメインメニューにない公開済みの同階層セクションも表示されます。URL が設定されている場合はそのリンクを使います。',
    'vi' => 'Mục cuối của đường dẫn hiển thị các chuyên mục cùng cấp đã xuất bản, kể cả mục ẩn khỏi menu chính. Liên kết dùng URL đã cấu hình.',
    'fr' => 'Le dernier élément du fil d’Ariane liste les rubriques de même niveau publiées, y compris celles absentes du menu principal. Les liens utilisent les URL configurées.',
    'de' => 'Das letzte Element der Brotkrumennavigation listet veröffentlichte gleichrangige Bereiche, auch wenn sie im Hauptmenü fehlen. Links verwenden die eingestellte URL.',
    'es' => 'El último elemento de la ruta muestra las secciones hermanas publicadas, incluidas las ocultas en el menú principal. Los enlaces usan la URL configurada.',
    'pt' => 'O último item do percurso mostra as secções publicadas do mesmo nível, incluindo as ocultas no menu principal. Os links usam o URL configurado.',
    'ko' => '마지막 탐색 경로에 메인 메뉴에서 숨긴 공개 형제 섹션도 표시됩니다. 링크는 설정된 URL을 사용합니다.',
    'zh' => '面包屑的最后一项列出已发布的同级栏目，包括从主菜单隐藏的栏目。链接使用栏目设置的 URL。',
];
