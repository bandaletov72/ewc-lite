<?php
return [
    'ru' => ['Цвета сайта', 'Шрифты', 'Библиотеки', 'Основной текст', 'Заголовки', 'Меню и кнопки', 'Сделать локальным', 'Локальный', 'Подключите нужные шрифты галочками и назначьте их для текста, заголовков и интерфейса. Локальные файлы загружаются с вашего сайта.', 'Встроенный'],
    'en' => ['Site colors', 'Fonts', 'Libraries', 'Body text', 'Headings', 'Menu and buttons', 'Make local', 'Local', 'Enable fonts with checkboxes and assign them to body text, headings or controls. Local files are served by your site.', 'Bundled'],
    'uk' => ['Кольори сайту', 'Шрифти', 'Бібліотеки', 'Основний текст', 'Заголовки', 'Меню й кнопки', 'Зробити локальним', 'Локальний', 'Позначте потрібні шрифти й призначте їх для тексту, заголовків або елементів керування. Локальні файли завантажуються з вашого сайту.', 'Вбудований'],
    'de' => ['Websitefarben', 'Schriften', 'Bibliotheken', 'Fließtext', 'Überschriften', 'Menüs und Schaltflächen', 'Lokal speichern', 'Lokal', 'Aktivieren Sie Schriften per Kontrollkästchen und weisen Sie sie Texten, Überschriften oder Bedienelementen zu. Lokale Dateien lädt Ihre Website.', 'Mitgeliefert'],
    'fr' => ['Couleurs du site', 'Polices', 'Bibliothèques', 'Texte courant', 'Titres', 'Menus et boutons', 'Héberger localement', 'Local', 'Cochez les polices à activer, puis attribuez-les au texte, aux titres ou aux commandes. Votre site héberge les fichiers locaux.', 'Intégré'],
    'es' => ['Colores del sitio', 'Fuentes', 'Bibliotecas', 'Texto principal', 'Títulos', 'Menús y botones', 'Alojar localmente', 'Local', 'Marca las fuentes que quieras activar y asígnalas al texto, títulos o controles. Tu sitio aloja los archivos locales.', 'Integrado'],
    'pt' => ['Cores do site', 'Fontes', 'Bibliotecas', 'Corpo do texto', 'Títulos', 'Menus e botões', 'Hospedar localmente', 'Local', 'Marque as fontes a ativar e atribua-as ao texto, aos títulos ou aos controlos. O seu site aloja os ficheiros locais.', 'Integrado'],
    'ja' => ['サイトの色', 'フォント', 'ライブラリ', '本文', '見出し', 'メニューとボタン', 'ローカルに保存', 'ローカル', 'チェックボックスでフォントを有効にし、本文、見出し、操作要素に割り当てます。ローカルファイルはサイトから配信されます。', '同梱'],
    'ko' => ['사이트 색상', '글꼴', '라이브러리', '본문', '제목', '메뉴와 버튼', '로컬에 저장', '로컬', '체크박스로 글꼴을 활성화한 뒤 본문, 제목, 조작 요소에 지정하세요. 로컬 파일은 현재 사이트에서 제공됩니다.', '내장'],
    'vi' => ['Màu trang web', 'Phông chữ', 'Thư viện', 'Văn bản chính', 'Tiêu đề', 'Menu và nút', 'Lưu cục bộ', 'Cục bộ', 'Tích chọn phông chữ rồi gán cho văn bản, tiêu đề hoặc nút. Tệp cục bộ do chính trang web cung cấp.', 'Tích hợp'],
    'zh' => ['网站配色', '字体', '库', '正文', '标题', '菜单与按钮', '保存到本地', '本地', '勾选启用字体，然后分配给正文、标题或界面控件。本地文件由网站自身提供。', '内置'],
];
