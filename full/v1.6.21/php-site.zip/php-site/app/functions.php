<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const EW_FUNCTIONS_FILE = SITE_ROOT . '/functions.php';
const EW_FUNCTIONS_LIMIT = 65536;
const EW_FUNCTIONS_HEADER = "<?php\nif (!defined('SITE_ROOT')) {\n    http_response_code(404);\n    exit;\n}\n\n";

function ew_default_functions(): string
{
    return <<<'PHP'
return [
    'translit' => static function (string $text): string {
        return ew_translit($text);
    },
];
PHP;
}

function ew_install_functions_file(): bool
{
    if (is_link(EW_FUNCTIONS_FILE)) {
        return false;
    }
    if (is_file(EW_FUNCTIONS_FILE)) {
        return true;
    }
    $handle = @fopen(EW_FUNCTIONS_FILE, 'xb');
    if ($handle === false) {
        return is_file(EW_FUNCTIONS_FILE) && !is_link(EW_FUNCTIONS_FILE);
    }
    $bytes = EW_FUNCTIONS_HEADER . ew_default_functions() . "\n";
    try {
        $written = @fwrite($handle, $bytes) === strlen($bytes);
    } finally {
        fclose($handle);
    }
    if (!$written) {
        @unlink(EW_FUNCTIONS_FILE);
    }
    return $written;
}

function ew_function_source(): array
{
    if (!is_file(EW_FUNCTIONS_FILE) || is_link(EW_FUNCTIONS_FILE)) {
        return [ew_default_functions(), ''];
    }
    $bytes = @file_get_contents(EW_FUNCTIONS_FILE, false, null, 0, EW_FUNCTIONS_LIMIT + 1);
    $header = is_string($bytes) && strpos($bytes, EW_FUNCTIONS_HEADER) === 0
        ? EW_FUNCTIONS_HEADER : str_replace("\n", "\r\n", EW_FUNCTIONS_HEADER);
    if (!is_string($bytes) || strlen($bytes) > EW_FUNCTIONS_LIMIT || strpos($bytes, $header) !== 0) {
        throw new RuntimeException('Не удалось открыть functions.php в редакторе.');
    }
    return [substr($bytes, strlen($header)), hash('sha256', $bytes)];
}

function ew_functions(): array
{
    static $functions;
    if ($functions === null) {
        $functions = ['translit' => 'ew_translit'];
        if (is_file(EW_FUNCTIONS_FILE) && !is_link(EW_FUNCTIONS_FILE)) {
            try {
                list(, $revision) = ew_function_source();
                if ($revision !== '') {
                    $custom = require EW_FUNCTIONS_FILE;
                    if (is_array($custom)) {
                        $functions = array_filter($custom, static function ($callback): bool {
                            return $callback instanceof Closure;
                        }) + $functions;
                    }
                }
            } catch (Throwable $exception) {
                error_log('functions.php: ' . $exception->getMessage());
            }
        }
    }
    return $functions;
}

function ew_call(string $name, ...$args)
{
    $callback = ew_functions()[$name] ?? null;
    return is_callable($callback) ? $callback(...$args) : null;
}

function ew_escape(string $text): string
{
    return site_escape($text);
}

function translit(string $text): string
{
    return (string) ew_call('translit', $text);
}

function ew_translit(string $text): string
{
    return strtr($text, [
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'Yo',
        'Ж' => 'Zh', 'З' => 'Z', 'И' => 'I', 'Й' => 'Y', 'К' => 'K', 'Л' => 'L', 'М' => 'M',
        'Н' => 'N', 'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T', 'У' => 'U',
        'Ф' => 'F', 'Х' => 'Kh', 'Ц' => 'Ts', 'Ч' => 'Ch', 'Ш' => 'Sh', 'Щ' => 'Shch',
        'Ъ' => '', 'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'Yu', 'Я' => 'Ya',
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo',
        'ж' => 'zh', 'з' => 'z', 'и' => 'i', 'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm',
        'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u',
        'ф' => 'f', 'х' => 'kh', 'ц' => 'ts', 'ч' => 'ch', 'ш' => 'sh', 'щ' => 'shch',
        'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
        'Є' => 'Ye', 'є' => 'ye', 'І' => 'I', 'і' => 'i', 'Ї' => 'Yi', 'ї' => 'yi',
        'Ґ' => 'G', 'ґ' => 'g', 'Ў' => 'U', 'ў' => 'u',
        'Ä' => 'Ae', 'Ö' => 'Oe', 'Ü' => 'Ue', 'ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue', 'ß' => 'ss', 'ẞ' => 'SS',
    ]);
}
