<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'jquery' => ['label' => 'jQuery 4.0.0',
        'js' => ['https://code.jquery.com/jquery-4.0.0.min.js', 'fgGyf7Mo7DURSOMnOy7ed+dkq5Job205Gnzu6QIg0BOHKaqt4D76Dt8VlDCzcMHV']],
    'bootstrap' => ['label' => 'Bootstrap 5.3.7',
        'js' => ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js', 'ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q'],
        'css' => ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css', 'LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr']],
    'alpine' => ['label' => 'Alpine.js 3.15.8',
        'js' => ['https://cdn.jsdelivr.net/npm/alpinejs@3.15.8/dist/cdn.min.js', 'LXWjKwDZz29o7TduNe+r/UxaolHh5FsSvy2W7bDHSZ8jJeGgDeuNnsDNHoxpSgDi']],
    'htmx' => ['label' => 'htmx 2.0.4',
        'js' => ['https://cdn.jsdelivr.net/npm/htmx.org@2.0.4/dist/htmx.min.js', 'HGfztofotfshcF7+8n44JQL2oJmowVChPTg48S+jvZoztPfvwD79OC/LTtG6dMp+']],
    'chartjs' => ['label' => 'Chart.js 4.5.1',
        'js' => ['https://cdn.jsdelivr.net/npm/chart.js@4.5.1/dist/chart.umd.min.js', 'jb8JQMbMoBUzgWatfe6COACi2ljcDdZQ2OxczGA3bGNeWe+6DChMTBJemed7ZnvJ']],
    'glightbox' => ['label' => 'GLightbox 3.3.0',
        'js' => ['https://cdn.jsdelivr.net/npm/glightbox@3.3.0/dist/js/glightbox.min.js', '/+Fc1LD6ksHYZ+2MChiSfjEXBcl4q2axUWhs6/CdnfqY5aLmrPwtysVzyeP0s60b'],
        'css' => ['https://cdn.jsdelivr.net/npm/glightbox@3.3.0/dist/css/glightbox.min.css', 'GPAzSuZc0kFvdIev6wm9zg8gnafE8tLso7rsAYQfc9hAdWCpOcpcNI5W9lWkYcsd']],
    'fontawesome' => ['label' => 'Font Awesome Free 7.0.1',
        'css' => ['https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.0.1/css/all.min.css', 'rWj9FmWWt3OMqd9vBkWRhFavvVUYalYqGPoMdL1brs/qvvqz88gvLShYa4hKNyqb']],
    'mui' => ['label' => 'Material UI 7.3.6',
        'react' => '19.2.4',
        'mui' => '7.3.6'],
    'codemirror' => ['label' => 'CodeMirror 5.65.20'],
];
