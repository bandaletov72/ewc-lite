<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Скрыть дерево страниц', 'Показать дерево страниц', 'На компьютере стрелка в углу дерева страниц сворачивает его и расширяет редактор. Кнопка над редактором возвращает дерево. Браузер запоминает выбор.'],
    'en' => ['Hide page tree', 'Show page tree', 'On desktop, the arrow in the page tree collapses it and widens the editor. The button above the editor restores it. The browser remembers your choice.'],
    'uk' => ['Сховати дерево сторінок', 'Показати дерево сторінок', 'На комп’ютері стрілка згортає дерево сторінок і розширює редактор. Кнопка над редактором повертає дерево. Браузер запам’ятовує вибір.'],
    'ja' => ['ページツリーを隠す', 'ページツリーを表示', 'デスクトップでは矢印でページツリーを折りたたみ、編集領域を広げられます。編集領域の上のボタンで元に戻せます。ブラウザーが選択を記憶します。'],
    'vi' => ['Ẩn cây trang', 'Hiện cây trang', 'Trên máy tính, mũi tên thu gọn cây trang và mở rộng trình sửa. Nút phía trên trình sửa khôi phục cây trang. Trình duyệt ghi nhớ lựa chọn.'],
    'fr' => ['Masquer l’arborescence', 'Afficher l’arborescence', 'Sur ordinateur, la flèche replie l’arborescence et agrandit l’éditeur. Le bouton au-dessus de l’éditeur la rétablit. Le navigateur mémorise votre choix.'],
    'de' => ['Seitenbaum ausblenden', 'Seitenbaum anzeigen', 'Am Desktop klappt der Pfeil den Seitenbaum ein und verbreitert den Editor. Die Schaltfläche über dem Editor blendet ihn wieder ein. Der Browser merkt sich die Auswahl.'],
    'es' => ['Ocultar el árbol de páginas', 'Mostrar el árbol de páginas', 'En escritorio, la flecha pliega el árbol de páginas y amplía el editor. El botón encima del editor lo restaura. El navegador recuerda la elección.'],
    'pt' => ['Ocultar a árvore de páginas', 'Mostrar a árvore de páginas', 'No computador, a seta recolhe a árvore de páginas e amplia o editor. O botão acima do editor restaura a árvore. O navegador guarda a escolha.'],
    'ko' => ['페이지 트리 숨기기', '페이지 트리 표시', '데스크톱에서는 화살표로 페이지 트리를 접어 편집 영역을 넓힐 수 있습니다. 편집기 위 버튼으로 다시 표시합니다. 브라우저가 선택을 기억합니다.'],
    'zh' => ['隐藏页面树', '显示页面树', '在桌面端，点击箭头可折叠页面树并加宽编辑器。编辑器上方的按钮可恢复页面树。浏览器会记住选择。'],
];
