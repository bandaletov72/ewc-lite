<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PHP_MODULES_FILE = SITE_ROOT . '/admin/.php-modules.php';
const SITE_PHP_MODULE_SOURCE_LIMIT = 65536;
const SITE_PHP_EDITOR_DIR = SITE_ROOT . '/extensions/editor-modules';

function site_php_module_source_prefix(string $name): string
{
    return "<?php\nif (!defined('SITE_ROOT')) { http_response_code(404); exit; }\n"
        . 'return [' . var_export($name, true) . " => ['kind' => 'single', 'render' => static function (string \$argument, array \$context) {\n";
}

function site_php_module_source(string $name): array
{
    $prefix = site_php_module_source_prefix($name);
    foreach (is_link(SITE_PHP_EDITOR_DIR) ? [] : (glob(SITE_PHP_EDITOR_DIR . '/*.php') ?: []) as $file) {
        if (is_link($file) || !preg_match('/\A[A-Za-z0-9_-]{1,64}\.php\z/', basename($file))
            || @file_get_contents($file, false, null, 0, strlen($prefix)) !== $prefix) {
            continue;
        }
        $bytes = file_get_contents($file, false, null, 0, SITE_PHP_MODULE_SOURCE_LIMIT + 1024);
        if (is_string($bytes) && strpos($bytes, $prefix) === 0 && substr($bytes, -6) === "\n}]];\n") {
            return [substr($bytes, strlen($prefix), -6), hash('sha256', $bytes), basename($file)];
        }
    }
    if ($name === 'server-date') {
        return ["return '<time datetime=\"' . site_escape(date('Y-m-d')) . '\">'\n"
            . "    . site_escape(date(site_region_settings()['date'])) . '</time>';", '', 'server-date.php'];
    }
    return ['', '', $name . '.php'];
}

function site_php_module_usage(array $extensions): array
{
    $usage = [];
    foreach (site_pages(true) as $entry) {
        $page = site_read_page($entry['path']);
        if ($page === null) {
            continue;
        }
        preg_match_all(site_content_pattern($extensions), $page['html'], $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $name = strtolower(($match['phpModule'] ?? '') ?: (($match['extensionTag'] ?? '') ?: ($match['snippet'] ?? '')));
            if (isset($extensions[$name])) {
                $usage[$name][$page['path']] = $page['fields']['Title'];
            }
        }
    }
    return $usage;
}

function site_php_module_settings(): array
{
    static $settings;
    if ($settings === null) {
        try {
            $settings = site_read_record(SITE_PHP_MODULES_FILE, 262144);
        } catch (RuntimeException $exception) {
            $settings = [];
        }
    }
    return $settings;
}

function site_php_module_enabled(string $name): bool
{
    return (site_php_module_settings()[$name]['enabled'] ?? true) === true;
}
