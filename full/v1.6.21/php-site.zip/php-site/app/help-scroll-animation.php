<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Анимация при прокрутке', 'Выключена', 'Плавное появление', 'Подъём снизу', 'Лёгкое увеличение', 'В разделе «Основные» выберите эффект появления блоков содержимого при прокрутке. По умолчанию эффект выключен. При сокращённом движении в настройках устройства анимация отключается.'],
    'en' => ['Scroll animation', 'Off', 'Fade in', 'Slide up', 'Scale in', 'In General settings, choose how content blocks appear when scrolling. Animation is off by default and respects the device’s reduced-motion setting.'],
    'uk' => ['Анімація під час прокручування', 'Вимкнено', 'Плавна поява', 'Підйом знизу', 'Легке збільшення', 'В основних налаштуваннях виберіть ефект появи блоків під час прокручування. Анімацію типово вимкнено. Вона враховує налаштування зменшення руху.'],
    'ja' => ['スクロール時のアニメーション', 'オフ', 'フェードイン', '下からスライド', '拡大表示', '基本設定で、スクロール時のコンテンツ表示効果を選べます。既定はオフで、端末の視覚効果を減らす設定が優先されます。'],
    'vi' => ['Hiệu ứng khi cuộn', 'Tắt', 'Hiện dần', 'Trượt lên', 'Phóng nhẹ', 'Trong cài đặt chung, chọn hiệu ứng xuất hiện của các khối khi cuộn. Hiệu ứng mặc định tắt và tuân theo tùy chọn giảm chuyển động của thiết bị.'],
    'fr' => ['Animation au défilement', 'Désactivée', 'Fondu', 'Glissement vers le haut', 'Léger agrandissement', 'Dans les réglages généraux, choisissez l’effet d’apparition des blocs au défilement. L’animation est désactivée par défaut et respecte la préférence de réduction des mouvements.'],
    'de' => ['Animation beim Scrollen', 'Aus', 'Einblenden', 'Von unten einschieben', 'Leicht vergrößern', 'Wählen Sie in den allgemeinen Einstellungen den Effekt für Inhaltsblöcke beim Scrollen. Standardmäßig ist die Animation aus und berücksichtigt die Systemeinstellung für reduzierte Bewegung.'],
    'es' => ['Animación al desplazarse', 'Desactivada', 'Aparición gradual', 'Deslizamiento hacia arriba', 'Aumento leve', 'En los ajustes generales, elija el efecto de aparición de los bloques al desplazarse. Está desactivado de forma predeterminada y respeta la opción de reducir movimiento del dispositivo.'],
    'pt' => ['Animação ao deslocar', 'Desativada', 'Aparecimento gradual', 'Deslizar para cima', 'Ampliação ligeira', 'Nas definições gerais, escolha o efeito de entrada dos blocos ao deslocar a página. Está desativado por predefinição e respeita a opção de movimento reduzido do dispositivo.'],
    'ko' => ['스크롤 애니메이션', '끄기', '서서히 나타나기', '위로 밀어 올리기', '살짝 확대', '기본 설정에서 스크롤할 때 콘텐츠가 나타나는 효과를 선택합니다. 기본값은 꺼짐이며 기기의 동작 줄이기 설정이 적용됩니다.'],
    'zh' => ['滚动动画', '关闭', '淡入', '向上滑入', '轻微放大', '在基本设置中选择滚动时内容区块的出现效果。动画默认关闭，并遵循设备的减少动态效果设置。'],
];
