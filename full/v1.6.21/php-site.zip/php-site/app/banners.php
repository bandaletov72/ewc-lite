<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_BANNERS_FILE = SITE_ROOT . '/admin/.banners.php';
const SITE_BANNERS_LIMIT = 2097152;

function site_banner_editor_labels(string $language): array
{
    $labels = [
        'zh' => ['横幅', '横幅组 ID', '留空以使用默认组或所选文件夹对应的组。'],
        'ru' => ['Баннеры', 'ID набора баннеров', 'Оставьте пустым для основного набора или набора указанной папки.'],
        'en' => ['Banners', 'Banner set ID', 'Leave blank for the main set or the set for the selected folder.'],
        'uk' => ['Банери', 'ID набору банерів', 'Залиште порожнім для основного набору або набору вибраної папки.'],
        'de' => ['Banner', 'Banner-Set-ID', 'Leer lassen, um das Hauptset oder das Set des ausgewählten Ordners zu verwenden.'],
        'fr' => ['Bannières', 'ID du groupe de bannières', 'Laissez vide pour le groupe principal ou celui du dossier sélectionné.'],
        'es' => ['Banners', 'ID del conjunto de banners', 'Deja el campo vacío para usar el conjunto principal o el de la carpeta seleccionada.'],
        'pt' => ['Banners', 'ID do conjunto de banners', 'Deixe em branco para usar o conjunto principal ou o da pasta selecionada.'],
        'ja' => ['バナー', 'バナーセット ID', 'メインセットまたは選択したフォルダーのセットを使う場合は空欄にします。'],
        'ko' => ['배너', '배너 세트 ID', '기본 세트나 선택한 폴더의 세트를 사용하려면 비워 두세요.'],
        'vi' => ['Banner', 'ID bộ banner', 'Để trống để dùng bộ chính hoặc bộ của thư mục đã chọn.'],
    ];
    return $labels[$language] ?? $labels['ru'];
}

function site_valid_banner_set_id(string $id): bool
{
    return preg_match('/\A[A-Za-z_\-]{1,64}\z/', $id) === 1;
}

function site_banner_edit_slide_label(string $language): string
{
    $labels = ['ru' => 'Редактировать кадр', 'en' => 'Edit slide', 'uk' => 'Редагувати кадр', 'de' => 'Folie bearbeiten',
        'fr' => 'Modifier la diapositive', 'es' => 'Editar diapositiva', 'pt' => 'Editar slide',
        'ja' => 'スライドを編集', 'ko' => '슬라이드 편집', 'vi' => 'Sửa slide', 'zh' => '编辑幻灯片'];
    return $labels[$language] ?? $labels['ru'];
}

function site_banner_defaults_label(string $language): string
{
    $labels = ['ru' => 'Настройки компонента по умолчанию', 'en' => 'Default component settings',
        'uk' => 'Типові налаштування компонента', 'de' => 'Standardeinstellungen der Komponente',
        'fr' => 'Réglages par défaut du composant', 'es' => 'Ajustes predeterminados del componente',
        'pt' => 'Configurações padrão do componente', 'ja' => 'コンポーネントの既定設定',
        'ko' => '구성 요소 기본 설정', 'vi' => 'Cài đặt mặc định của thành phần', 'zh' => '组件默认设置'];
    return $labels[$language] ?? $labels['ru'];
}

function site_banner_sets(): array
{
    return site_read_record(site_content_record(SITE_BANNERS_FILE), SITE_BANNERS_LIMIT);
}

function site_banner_id(string $name, string $folder): string
{
    return $name !== '' ? $name : ($folder === '' ? 'main' : 'folder-' . substr(hash('sha256', site_asset_path($folder, 'images', false, false)), 0, 20));
}

function site_banner_file_slide_id(string $path, string $file): string
{
    return 'f-' . substr(hash('sha256', $path . '/' . $file), 0, 20);
}

function site_banner_fonts(): array
{
    return ['site' => '', 'sans' => 'system-ui, sans-serif', 'serif' => 'Georgia, serif', 'mono' => 'Consolas, monospace'];
}

function site_banner_slide_defaults(): array
{
    return ['image' => '', 'color' => '#263440', 'textColor' => '#ffffff', 'title' => '', 'subtitle' => '', 'caption' => '', 'font' => 'site',
        'align' => 'left', 'url' => '', 'button' => '', 'action' => 'none', 'buttonUrl' => '', 'form' => '',
        'active' => true, 'from' => '', 'until' => '', 'excluded' => false];
}

function site_banner_slides(array $set, string $folder): array
{
    $slides = [];
    $defaults = site_banner_slide_defaults();
    $stored = $set['slides'] ?? [];
    $inheritedKeys = [];
    if ($folder !== '') {
        $path = site_asset_path($folder, 'images');
        if ($path !== '') {
            $shared = site_asset_path($folder, 'images', false, false);
            foreach (site_asset_files($folder, '', 'images', site_component_asset_extensions('gal')) as $image) {
                $key = site_banner_file_slide_id($path, $image['name']);
                $oldKey = site_banner_file_slide_id($shared, $image['name']);
                $inheritedKeys[$oldKey] = $key;
                $details = $stored[$key] ?? $stored[$oldKey] ?? [];
                if ($oldKey !== $key && !isset($stored[$key])) {
                    $sharedUrl = '/' . implode('/', array_map('rawurlencode', explode('/', $shared))) . '/' . rawurlencode($image['name']);
                    if (($details['image'] ?? '') === $sharedUrl) unset($details['image']);
                }
                $slides[$key] = array_replace($defaults, ['image' => $image['url']], $details);
            }
        }
    }
    foreach ($stored as $key => $slide) {
        if (strpos($key, 's-') === 0) {
            $slides[$key] = array_replace($defaults, $slide);
        }
    }
    $ordered = [];
    foreach ($set['order'] ?? [] as $key) {
        $key = $inheritedKeys[$key] ?? $key;
        if (isset($slides[$key])) {
            $ordered[$key] = $slides[$key];
        }
    }
    return $ordered + $slides;
}

function site_banner_visible(array $slide, string $now): bool
{
    return $slide['active'] && !$slide['excluded'] && ($slide['from'] === '' || $slide['from'] <= $now)
        && ($slide['until'] === '' || $now < $slide['until']);
}

function site_banner_url(string $base, string $url): string
{
    return $url !== '' && $url[0] === '/' ? site_url($base, substr($url, 1)) : $url;
}

function site_banner_admin_url(string $base, string $set, string $folder = '', array $extra = []): string
{
    $query = ['components' => '1', 'banner' => $set] + ($folder !== '' ? ['folder' => $folder] : []) + $extra;
    return site_url($base, 'admin/') . '?' . http_build_query($query);
}

function site_component_banners(string $argument, string $folder, array &$context): string
{
    $params = site_shortcode_options($argument);
    $name = strtolower($params['set'] ?? '');
    $folder = trim($folder);
    if (($name !== '' && !site_valid_banner_set_id($name) && !site_valid_snippet($name))
        || ($folder !== '' && site_asset_path($folder, 'images') === '')) {
        return '';
    }
    $setId = site_banner_id($name, $folder);
    if (!empty($context['activeBanners'][$setId]) || count($context['activeBanners'] ?? []) >= SITE_MAX_INCLUDE_DEPTH) {
        return '';
    }
    try {
        if (!isset($context['bannerSets'])) {
            $context['bannerSets'] = site_banner_sets();
        }
    } catch (RuntimeException $exception) {
        return '';
    }
    $set = $context['bannerSets'][$setId] ?? [];
    $folder = $folder !== '' ? $folder : ($set['folder'] ?? '');
    $now = date('Y-m-d\TH:i');
    $slides = array_filter(site_banner_slides($set, $folder), static function (array $slide) use ($now): bool { return site_banner_visible($slide, $now); });
    $editing = !empty($context['bannerEdit']);
    if (!$slides && !$editing) {
        return '';
    }
    $context['activeBanners'][$setId] = true;
    $options = site_component_options('banners', $argument);
    $base = $context['base'];
    $locale = $context['locale'];
    $instance = 'banners-' . bin2hex(random_bytes(6));
    $bufferLevel = ob_get_level();
    ob_start();
    try {
        require site_template_file('components/banners.php');
        return (string) ob_get_clean();
    } finally {
        while (ob_get_level() > $bufferLevel) ob_end_clean();
        unset($context['activeBanners'][$setId]);
    }
}
