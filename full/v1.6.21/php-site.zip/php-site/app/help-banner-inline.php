<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'Чтобы изменить ширину всей карусели баннеров на странице, включите режим правки, нажмите «Править компонент» рядом с баннерами и выберите «Ширина блока».',
    'en' => 'To resize the whole banner carousel, turn on edit mode, choose Edit component beside the banners, and select Block width.',
    'uk' => 'Щоб змінити ширину всієї каруселі банерів, увімкніть режим редагування, натисніть «Редагувати компонент» і виберіть ширину блока.',
    'ja' => 'バナーカルーセル全体の幅を変えるには、編集モードでバナー横のコンポーネント編集を開き、ブロック幅を選びます。',
    'vi' => 'Để đổi chiều rộng toàn bộ băng chuyền, bật chế độ sửa, mở Chỉnh sửa thành phần cạnh banner và chọn chiều rộng khối.',
    'fr' => 'Pour changer la largeur du carrousel, activez le mode édition, ouvrez Modifier le composant à côté des bannières et choisissez la largeur du bloc.',
    'de' => 'Um die Breite des gesamten Bannerkarussells zu ändern, aktivieren Sie den Bearbeitungsmodus, öffnen Sie Komponente bearbeiten und wählen Sie die Blockbreite.',
    'es' => 'Para cambiar el ancho del carrusel, active el modo de edición, pulse Editar componente junto a los banners y elija el ancho del bloque.',
    'pt' => 'Para alterar a largura do carrossel, ative o modo de edição, abra Editar componente junto dos banners e selecione a largura do bloco.',
    'ko' => '배너 캐러셀 전체 너비를 바꾸려면 편집 모드를 켜고 배너 옆 구성 요소 편집에서 블록 너비를 선택하세요.',
    'zh' => '要调整整个横幅轮播的宽度，请开启编辑模式，点击横幅旁的“编辑组件”，然后选择区块宽度。',
];
