<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_ERROR_PAGES = [403 => 'Доступ запрещён', 410 => 'Страница удалена', 429 => 'Слишком много запросов',
    500 => 'Ошибка сервера', 502 => 'Ошибка шлюза', 503 => 'Сервис временно недоступен', 504 => 'Сервер не ответил вовремя'];

function site_error_static_html(int $status, string $base = ''): string
{
    $title = SITE_ERROR_PAGES[$status];
    return '<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<meta name="robots" content="noindex"><title>' . $status . ' · ' . $title . '</title>'
        . '<style>body{font:1rem/1.6 system-ui,sans-serif;max-width:44rem;margin:10vh auto;padding:1.5rem}a{color:#12634e}</style></head>'
        . '<body><main><h1>' . $status . ' · ' . $title . '</h1><p><a href="' . htmlspecialchars(rtrim($base, '/') . '/', ENT_QUOTES, 'UTF-8') . '">На главную</a></p></main></body></html>' . "\n";
}

function site_error_404_source(): string
{
    return <<<'PAGE'
<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Страница не найдена
Heading: Страница не найдена
MenuVisible: 0
MobileMenu: 0
Sitemap: 0

<p>Проверьте адрес страницы или выберите раздел в меню.</p>
PAGE;
}
