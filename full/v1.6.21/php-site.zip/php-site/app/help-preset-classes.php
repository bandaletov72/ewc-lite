<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['CSS и JavaScript шаблона копируются в поля страницы «CSS и JavaScript». Можно добавить свои классы в HTML и описать их в CSS шаблона.', 'Типовые классы', 'Общий контейнер, адаптивная сетка, акцентная секция, карточка и выделенная цена.', 'Внизу мобильного меню выводятся способы связи и соцсети из раздела «Контакты и соцсети».'],
    'en' => ['Template CSS and JavaScript are copied to the page’s asset fields. Add your own HTML classes and style them in the template’s CSS.', 'Reusable classes', 'Layout wrapper, responsive grid, highlighted section, card, and emphasized price.', 'The bottom of the mobile menu shows the channels configured in Contacts and social media.'],
    'uk' => ['CSS і JavaScript шаблону копіюються в поля сторінки. Власні класи додавайте в HTML, а стилі — у CSS шаблону.', 'Типові класи', 'Контейнер, адаптивна сітка, акцентний блок, картка та виділена ціна.', 'Унизу мобільного меню — способи зв’язку й соцмережі з відповідних налаштувань.'],
    'ja' => ['テンプレートの CSS と JavaScript はページの欄にコピーされます。HTML に独自のクラスを追加し CSS で設定できます。', '共通クラス', 'コンテナー、レスポンシブグリッド、強調セクション、カード、価格表示。', 'モバイルメニューの下部に、設定した連絡先と SNS が表示されます。'],
    'vi' => ['CSS và JavaScript của mẫu được sao chép vào trang. Thêm lớp riêng trong HTML và định kiểu trong CSS của mẫu.', 'Lớp dùng chung', 'Khung bố cục, lưới thích ứng, phần nổi bật, thẻ và giá nhấn mạnh.', 'Cuối menu di động hiển thị các kênh liên hệ và mạng xã hội đã cấu hình.'],
    'fr' => ['Le CSS et le JavaScript du modèle sont copiés dans la page. Ajoutez vos classes dans le HTML et définissez leur style dans le CSS du modèle.', 'Classes réutilisables', 'Conteneur, grille adaptative, section mise en avant, carte et prix mis en valeur.', 'Le bas du menu mobile affiche les coordonnées et les réseaux sociaux configurés.'],
    'de' => ['CSS und JavaScript der Vorlage werden in die Seitenfelder kopiert. Eigene HTML-Klassen können Sie im CSS der Vorlage gestalten.', 'Wiederverwendbare Klassen', 'Container, responsives Raster, hervorgehobener Abschnitt, Karte und betonter Preis.', 'Unten im mobilen Menü erscheinen die konfigurierten Kontaktwege und sozialen Netzwerke.'],
    'es' => ['El CSS y JavaScript de la plantilla se copian a los campos de la página. Añada clases propias en HTML y defínalas en el CSS de la plantilla.', 'Clases reutilizables', 'Contenedor, cuadrícula adaptable, sección destacada, tarjeta y precio destacado.', 'La parte inferior del menú móvil muestra los contactos y las redes sociales configurados.'],
    'pt' => ['O CSS e o JavaScript do modelo são copiados para os campos da página. Adicione classes próprias em HTML e defina-as no CSS do modelo.', 'Classes reutilizáveis', 'Contentor, grelha adaptável, secção em destaque, cartão e preço realçado.', 'O fundo do menu móvel mostra os contactos e as redes sociais configurados.'],
    'ko' => ['템플릿의 CSS와 JavaScript는 페이지 필드로 복사됩니다. HTML에 사용자 클래스를 추가하고 템플릿의 CSS에서 스타일을 지정하세요.', '공통 클래스', '레이아웃 컨테이너, 반응형 그리드, 강조 영역, 카드 및 강조된 가격.', '모바일 메뉴 하단에 설정한 연락처와 소셜 네트워크를 표시합니다.'],
    'zh' => ['模板的 CSS 和 JavaScript 会复制到页面字段。可在 HTML 中添加自定义类，并在模板 CSS 中定义样式。', '通用样式类', '布局容器、响应式网格、重点区域、卡片和突出显示的价格。', '手机菜单底部显示已配置的联系方式和社交网络。'],
];
