<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$buttons = [
    'ru' => ['Кнопки в шапке админки', 'Глобус открывает сайт, стрелка завершает сеанс администратора. На телефоне видны только иконки. Подсказки появляются при наведении или фокусе с клавиатуры.'],
    'en' => ['Admin header buttons', 'The globe opens the site and the arrow signs you out. On mobile, these buttons show icons only. Hover or focus with the keyboard to see their labels.'],
    'uk' => ['Кнопки в шапці адмінпанелі', 'Глобус відкриває сайт, стрілка завершує сеанс адміністратора. На телефоні видно лише іконки. Підказки з’являються при наведенні або фокусі з клавіатури.'],
    'ja' => ['管理画面のヘッダーボタン', '地球のアイコンでサイトを開き、矢印のアイコンでログアウトします。スマートフォンではアイコンのみ表示されます。マウスを乗せるか、キーボードでフォーカスするとラベルを確認できます。'],
    'vi' => ['Các nút trên thanh quản trị', 'Biểu tượng quả địa cầu mở trang web, còn mũi tên dùng để đăng xuất. Trên điện thoại chỉ hiện biểu tượng. Di chuột hoặc dùng bàn phím để xem nhãn.'],
    'fr' => ['Boutons de l’en-tête d’administration', 'Le globe ouvre le site et la flèche ferme la session. Sur mobile, seules les icônes sont visibles. Survolez les boutons ou sélectionnez-les au clavier pour afficher leur libellé.'],
    'de' => ['Schaltflächen im Kopfbereich der Verwaltung', 'Der Globus öffnet die Website, der Pfeil meldet Sie ab. Auf Mobilgeräten sind nur die Symbole zu sehen. Fahren Sie mit der Maus darüber oder fokussieren Sie die Schaltflächen per Tastatur, um die Beschriftung zu sehen.'],
    'es' => ['Botones de la cabecera de administración', 'El globo abre el sitio y la flecha cierra la sesión. En el móvil solo se muestran los iconos. Pasa el cursor o enfoca los botones con el teclado para ver sus etiquetas.'],
    'pt' => ['Botões no cabeçalho da administração', 'O globo abre o site e a seta termina a sessão. No telemóvel, só aparecem os ícones. Passe o cursor ou utilize o teclado para ver os respetivos rótulos.'],
    'ko' => ['관리자 화면 상단 버튼', '지구본 아이콘은 사이트를 열고 화살표 아이콘은 로그아웃합니다. 휴대전화에서는 아이콘만 표시됩니다. 마우스를 올리거나 키보드로 초점을 맞추면 이름을 볼 수 있습니다.'],
];

$navigation = [
    'ru' => '«Содержимое», «Формы и заявки» и «Сайт и сервисы» открываются сразу. Под шапкой выбранного раздела доступны его вкладки.',
    'en' => 'Content, Forms and Requests, and Site and Services open directly. The selected section shows its own tabs under the main menu.',
    'uk' => '«Вміст», «Форми й заявки» та «Сайт і сервіси» відкриваються відразу. Під головним меню відображаються вкладки вибраного розділу.',
    'ja' => '「コンテンツ」「フォームとリクエスト」「サイトとサービス」を選ぶと、各セクションが直接開きます。メインメニューの下に選択したセクションのタブが表示されます。',
    'vi' => 'Nội dung, Biểu mẫu và yêu cầu, và Trang web và dịch vụ mở trực tiếp. Các thẻ của mục đã chọn xuất hiện bên dưới menu chính.',
    'fr' => 'Les rubriques Contenu, Formulaires et demandes, et Site et services s’ouvrent directement. Les onglets de la rubrique choisie apparaissent sous le menu principal.',
    'de' => 'Inhalte, Formulare und Anfragen sowie Website und Dienste öffnen sich direkt. Unter dem Hauptmenü erscheinen die Registerkarten des gewählten Bereichs.',
    'es' => 'Contenido, Formularios y solicitudes, y Sitio y servicios se abren directamente. Las pestañas de la sección elegida aparecen debajo del menú principal.',
    'pt' => 'Conteúdo, Formulários e pedidos, e Site e serviços abrem diretamente. Os separadores da secção escolhida aparecem abaixo do menu principal.',
    'ko' => '콘텐츠, 양식 및 요청, 사이트 및 서비스는 바로 열립니다. 기본 메뉴 아래에 선택한 섹션의 탭이 표시됩니다.',
];

$layout = [
    'ru' => 'Вставьте [bread-crumbs] или [search] в HTML главной страницы (index.php) или шаблона. Блок появится в указанном месте один раз. Галочка хлебных крошек и режим поиска действуют и для вставленных тегов. [privacy] выводит ссылку на /privacy/. Текст политики редактируется в разделе «Страницы».',
    'en' => 'Insert [bread-crumbs] or [search] in the HTML of the home page (index.php) or a layout template. Each block appears once at its chosen position. The breadcrumb and search settings still apply. [privacy] links to /privacy/. Edit the policy under Pages.',
    'uk' => 'Вставте [bread-crumbs] або [search] в HTML головної сторінки (index.php) чи шаблону. Блок з’явиться один раз у вказаному місці. Налаштування навігаційного ланцюжка й пошуку діють для тегів. [privacy] веде на /privacy/. Текст політики редагується в розділі «Сторінки».',
    'ja' => 'ホームページ（index.php）またはテンプレートのHTMLに [bread-crumbs] や [search] を追加すると、指定した位置に一度だけ表示されます。パンくずリストと検索の設定も適用されます。[privacy] は /privacy/ へのリンクです。ポリシーは「ページ」で編集できます。',
    'vi' => 'Chèn [bread-crumbs] hoặc [search] vào HTML của trang chủ (index.php) hoặc mẫu. Mỗi khối xuất hiện một lần tại vị trí đã chọn. Cài đặt đường dẫn điều hướng và tìm kiếm vẫn được áp dụng. [privacy] liên kết đến /privacy/. Chỉnh sửa chính sách trong mục Trang.',
    'fr' => 'Insérez [bread-crumbs] ou [search] dans le HTML de la page d’accueil (index.php) ou du modèle. Chaque bloc apparaît une seule fois à l’emplacement choisi. Les réglages du fil d’Ariane et de la recherche s’appliquent. [privacy] renvoie vers /privacy/. Modifiez la politique dans la rubrique Pages.',
    'de' => 'Fügen Sie [bread-crumbs] oder [search] in das HTML der Startseite (index.php) oder einer Vorlage ein. Jeder Block erscheint einmal an der gewählten Stelle. Die Einstellungen für Brotkrümelnavigation und Suche gelten weiterhin. [privacy] verweist auf /privacy/. Bearbeiten Sie die Datenschutzerklärung unter Seiten.',
    'es' => 'Inserta [bread-crumbs] o [search] en el HTML de la página de inicio (index.php) o de una plantilla. Cada bloque aparece una vez donde lo coloques. Se mantienen los ajustes de navegación y búsqueda. [privacy] enlaza a /privacy/. Edita la política en Páginas.',
    'pt' => 'Insira [bread-crumbs] ou [search] no HTML da página inicial (index.php) ou de um modelo. Cada bloco aparece uma vez na posição escolhida. As definições do caminho de navegação e da pesquisa continuam ativas. [privacy] liga a /privacy/. Edite a política em Páginas.',
    'ko' => '홈 화면(index.php)이나 템플릿의 HTML에 [bread-crumbs] 또는 [search]를 넣으면 지정한 위치에 한 번씩 표시됩니다. 탐색 경로와 검색 설정이 적용됩니다. [privacy]는 /privacy/로 연결됩니다. 정책 문구는 페이지 메뉴에서 편집할 수 있습니다.',
];

return [$buttons, $navigation, $layout];
