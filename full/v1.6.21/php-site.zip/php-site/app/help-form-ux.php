<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'Телефон проверяется во время ввода. Российский номер, начатый с 8, приводится к +7. После успешной отправки форма скрывается, а при повторном открытии окна виден результат отправки.',
    'en' => 'Phone numbers are checked as you type. A Russian number starting with 8 changes to +7. After successful submission the form is hidden, and reopening the dialog shows the confirmation.',
    'uk' => 'Телефон перевіряється під час введення. Російський номер, що починається з 8, перетворюється на +7. Після надсилання форма ховається, а при повторному відкритті видно підтвердження.',
    'ja' => '電話番号は入力中に検証します。8 で始まるロシアの番号は +7 に変わります。送信後はフォームが非表示になり、開き直すと確認が表示されます。',
    'vi' => 'Số điện thoại được kiểm tra khi nhập. Số Nga bắt đầu bằng 8 được đổi thành +7. Sau khi gửi thành công, biểu mẫu được ẩn và khi mở lại sẽ thấy xác nhận.',
    'fr' => 'Le numéro est vérifié pendant la saisie. Un numéro russe commençant par 8 passe à +7. Le formulaire disparaît après l’envoi et la confirmation reste visible en rouvrant la fenêtre.',
    'de' => 'Die Telefonnummer wird bei der Eingabe geprüft. Bei russischen Nummern wird eine führende 8 zu +7. Nach dem Senden wird das Formular ausgeblendet und beim erneuten Öffnen erscheint die Bestätigung.',
    'es' => 'El teléfono se comprueba al escribir. En números rusos, el 8 inicial se convierte en +7. Tras el envío se oculta el formulario y al volver a abrirlo se muestra la confirmación.',
    'pt' => 'O telefone é verificado durante a introdução. Nos números russos, o 8 inicial passa a +7. Após o envio, o formulário é ocultado e a confirmação surge ao reabrir a janela.',
    'ko' => '전화번호는 입력하는 동안 검증합니다. 8로 시작하는 러시아 번호는 +7로 바뀝니다. 전송을 마치면 양식이 숨겨지고 창을 다시 열면 확인 메시지가 표시됩니다.',
    'zh' => '输入时会验证电话号码。以 8 开头的俄罗斯号码会转换为 +7。提交成功后表单隐藏，再次打开弹窗会看到发送确认。',
];
