<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$translations = [
    'ru' => [
        ['Резервные копии сайта', 'Создать бэкап контента', 'Загрузить ZIP', 'Скачать', 'Восстановить',
            'ZIP хранится в закрытой папке и включает страницы, медиа, инфоблоки, настройки, свои шаблоны и PHP-модули. Учётная запись администратора и входящие заявки сохраняются отдельно. Для архивации нужно расширение PHP Zip.',
            'Заменить содержимое и настройки выбранной копией. Перед заменой будет создан новый бэкап текущего состояния.'],
        ['Выровнять влево', 'По центру', 'Выровнять вправо', 'Убрать форматирование'],
        ['Параметры изображения', 'Вставить ссылку', 'Вставить кнопку', 'Текст кнопки', 'Действие', 'Оплата', 'Новая вкладка'],
        'В визуальном редакторе выделите текст для выравнивания или снятия форматирования. Нажмите на изображение, чтобы открыть его параметры. Потяните за угол для изменения размера или перетащите само изображение в другое место. Для ссылки доступны URL, email, телефон и якорь. Кнопка может открыть URL, форму, обратный звонок или оплату. Для оплаты используйте ссылку провайдера на указанную сумму.',
    ],
    'en' => [
        ['Site backups', 'Back up site content', 'Upload ZIP', 'Download', 'Restore',
            'The private ZIP contains pages, media, infoblocks, settings, custom templates and PHP modules. The administrator account and incoming requests are stored separately. Backups require PHP Zip.',
            'Replace content and settings with this backup. A copy of the current site will be created first.'],
        ['Align left', 'Center', 'Align right', 'Clear formatting'],
        ['Image properties', 'Insert link', 'Insert button', 'Button text', 'Action', 'Payment', 'New tab'],
        'Select text in the visual editor to align it or clear formatting. Click an image to edit its properties, drag its corner to resize, or move the image in the text. Links can target URLs, emails, telephone numbers or anchors. Buttons can open a URL, form, callback or payment. Use a provider link for the displayed amount.',
    ],
    'uk' => [
        ['Резервні копії сайту', 'Створити резервну копію', 'Завантажити ZIP', 'Скачати', 'Відновити',
            'Приватний ZIP містить сторінки, медіа, інфоблоки, налаштування, власні шаблони й PHP-модулі. Обліковий запис і вхідні заявки зберігаються окремо. Потрібне розширення PHP Zip.',
            'Замінити вміст і налаштування. Спочатку буде створено копію поточного стану.'],
        ['Вирівняти ліворуч', 'По центру', 'Вирівняти праворуч', 'Очистити форматування'],
        ['Параметри зображення', 'Вставити посилання', 'Вставити кнопку', 'Текст кнопки', 'Дія', 'Оплата', 'Нова вкладка'],
        'Виділіть текст для вирівнювання чи очищення форматування. Клацніть зображення, щоб відкрити параметри. Змініть розмір за кут або перетягніть зображення в тексті. Посилання підтримують URL, email, телефон і якір. Кнопка відкриває URL, форму, зворотний дзвінок або оплату за посиланням провайдера.',
    ],
    'de' => [
        ['Sicherungen der Website', 'Inhalte sichern', 'ZIP hochladen', 'Herunterladen', 'Wiederherstellen',
            'Das private ZIP enthält Seiten, Medien, Infoblöcke, Einstellungen, eigene Vorlagen und PHP-Module. Administratorkonto und Anfragen werden separat gespeichert. PHP Zip wird benötigt.',
            'Inhalte und Einstellungen ersetzen. Zuerst wird der aktuelle Stand gesichert.'],
        ['Linksbündig', 'Zentrieren', 'Rechtsbündig', 'Formatierung entfernen'],
        ['Bildeigenschaften', 'Link einfügen', 'Schaltfläche einfügen', 'Schaltflächentext', 'Aktion', 'Zahlung', 'Neuer Tab'],
        'Markieren Sie Text zum Ausrichten oder zum Entfernen seiner Formatierung. Klicken Sie auf ein Bild, um Eigenschaften zu ändern. Ziehen Sie es zum Verschieben oder ziehen Sie an seiner Ecke. Links unterstützen URL, E-Mail, Telefonnummer und Anker. Schaltflächen öffnen URLs, Formulare, Rückrufe oder Zahlungslinks des Anbieters.',
    ],
    'fr' => [
        ['Sauvegardes du site', 'Sauvegarder le contenu', 'Importer un ZIP', 'Télécharger', 'Restaurer',
            'Le ZIP privé contient pages, médias, infoblocs, réglages, modèles et modules PHP. Le compte administrateur et les demandes sont stockés séparément. PHP Zip est requis.',
            'Remplacer le contenu et les réglages. Une copie de l’état actuel sera créée auparavant.'],
        ['Aligner à gauche', 'Centrer', 'Aligner à droite', 'Effacer la mise en forme'],
        ['Propriétés de l’image', 'Insérer un lien', 'Insérer un bouton', 'Texte du bouton', 'Action', 'Paiement', 'Nouvel onglet'],
        'Sélectionnez le texte à aligner ou à déformater. Cliquez sur une image pour ses réglages, déplacez-la ou redimensionnez-la depuis son coin. Un lien peut viser une URL, un courriel, un téléphone ou une ancre. Un bouton ouvre un lien, un formulaire, un rappel ou un lien de paiement du prestataire.',
    ],
    'es' => [
        ['Copias de seguridad', 'Respaldar contenido', 'Subir ZIP', 'Descargar', 'Restaurar',
            'El ZIP privado contiene páginas, medios, bloques, ajustes, plantillas y módulos PHP. La cuenta y las solicitudes se guardan por separado. Se requiere PHP Zip.',
            'Reemplazar contenido y ajustes. Primero se guardará una copia del sitio actual.'],
        ['Alinear a la izquierda', 'Centrar', 'Alinear a la derecha', 'Quitar formato'],
        ['Propiedades de imagen', 'Insertar enlace', 'Insertar botón', 'Texto del botón', 'Acción', 'Pago', 'Nueva pestaña'],
        'Selecciona texto para alinearlo o quitar el formato. Haz clic en una imagen para editarla y arrastra la imagen o su esquina para moverla o cambiar su tamaño. Los enlaces admiten URL, correo, teléfono y ancla. Los botones abren URL, formularios, devoluciones de llamada o enlaces de pago del proveedor.',
    ],
    'pt' => [
        ['Cópias de segurança', 'Criar cópia do conteúdo', 'Enviar ZIP', 'Baixar', 'Restaurar',
            'O ZIP privado contém páginas, mídias, blocos, configurações, modelos e módulos PHP. A conta e as solicitações ficam separadas. É necessário PHP Zip.',
            'Substituir conteúdo e configurações. Antes disso, será feita uma cópia do estado atual.'],
        ['Alinhar à esquerda', 'Centralizar', 'Alinhar à direita', 'Limpar formatação'],
        ['Propriedades da imagem', 'Inserir link', 'Inserir botão', 'Texto do botão', 'Ação', 'Pagamento', 'Nova aba'],
        'Selecione texto para alinhar ou limpar a formatação. Clique na imagem para editá-la e arraste a imagem ou seu canto para mover ou redimensionar. Links aceitam URL, e-mail, telefone e âncora. Botões abrem URLs, formulários, retornos de chamada ou links de pagamento do fornecedor.',
    ],
    'ja' => [
        ['サイトのバックアップ', 'コンテンツをバックアップ', 'ZIP をアップロード', 'ダウンロード', '復元',
            '非公開の ZIP にページ、メディア、情報ブロック、設定、独自テンプレート、PHP モジュールが含まれます。管理者アカウントと依頼は別に保存されます。PHP Zip が必要です。',
            '内容と設定を置き換えます。先に現在の状態をバックアップします。'],
        ['左揃え', '中央揃え', '右揃え', '書式をクリア'],
        ['画像の設定', 'リンクを挿入', 'ボタンを挿入', 'ボタンのテキスト', '動作', '支払い', '新しいタブ'],
        'テキストを選択して揃え方を変えたり、書式を消したりできます。画像をクリックすると設定が開きます。ドラッグで移動し、角をドラッグするとサイズを変更できます。リンクは URL、メール、電話、アンカーに対応します。ボタンは URL、フォーム、折り返し電話、決済リンクを開けます。',
    ],
    'ko' => [
        ['사이트 백업', '콘텐츠 백업', 'ZIP 업로드', '다운로드', '복원',
            '비공개 ZIP에는 페이지, 미디어, 인포블록, 설정, 템플릿, PHP 모듈이 들어갑니다. 관리자 계정과 요청은 별도로 보관됩니다. PHP Zip이 필요합니다.',
            '콘텐츠와 설정을 교체합니다. 먼저 현재 상태를 백업합니다.'],
        ['왼쪽 정렬', '가운데 정렬', '오른쪽 정렬', '서식 지우기'],
        ['이미지 속성', '링크 삽입', '버튼 삽입', '버튼 텍스트', '동작', '결제', '새 탭'],
        '텍스트를 선택하여 정렬하거나 서식을 지웁니다. 이미지를 클릭해 속성을 열고 끌어서 이동하거나 모서리로 크기를 조절합니다. URL, 이메일, 전화번호, 앵커를 링크할 수 있습니다. 버튼은 URL, 양식, 콜백 또는 결제 링크를 엽니다.',
    ],
    'vi' => [
        ['Sao lưu trang web', 'Sao lưu nội dung', 'Tải ZIP lên', 'Tải xuống', 'Khôi phục',
            'ZIP riêng chứa trang, phương tiện, khối dữ liệu, cài đặt, mẫu và mô-đun PHP. Tài khoản quản trị và yêu cầu đến được lưu riêng. Cần PHP Zip.',
            'Thay thế nội dung và cài đặt. Hệ thống sao lưu trạng thái hiện tại trước.'],
        ['Căn trái', 'Căn giữa', 'Căn phải', 'Xóa định dạng'],
        ['Thuộc tính ảnh', 'Chèn liên kết', 'Chèn nút', 'Văn bản nút', 'Thao tác', 'Thanh toán', 'Thẻ mới'],
        'Chọn văn bản để căn lề hoặc xóa định dạng. Nhấp vào ảnh để sửa thuộc tính rồi kéo ảnh để di chuyển hoặc kéo góc để đổi kích cỡ. Liên kết hỗ trợ URL, email, điện thoại và điểm neo. Nút mở URL, biểu mẫu, gọi lại hoặc liên kết thanh toán.',
    ],
];

return array_map(static function (array $entry): array {
    return ['backup' => $entry[0], 'align' => array_combine(['left', 'center', 'right', 'clear'], $entry[1]),
        'tools' => array_combine(['image', 'link', 'button', 'label', 'action', 'payment', 'new-tab'], $entry[2]), 'help' => $entry[3]];
}, $translations);
