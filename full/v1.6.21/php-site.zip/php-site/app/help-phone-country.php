<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Страна для телефонных номеров', 'Международный формат, код вручную', 'Код выбранной страны добавляется к номеру без «+». Номер с «+» сохраняет введённый международный код.'],
    'en' => ['Country for phone numbers', 'International format, enter the code', 'The selected country code is added to numbers without +. Numbers that start with + keep their international calling code.'],
    'uk' => ['Країна для номерів телефону', 'Міжнародний формат, код вручну', 'До номера без «+» додається код вибраної країни. Номер з «+» зберігає введений міжнародний код.'],
    'ja' => ['電話番号の国', '国際形式、国番号を手入力', '+ がない番号には選択国の国番号が付きます。+ がある番号は入力した国番号を保持します。'],
    'vi' => ['Quốc gia cho số điện thoại', 'Định dạng quốc tế, nhập mã', 'Mã quốc gia đã chọn được thêm vào số không có +. Số bắt đầu bằng + giữ mã quốc tế đã nhập.'],
    'fr' => ['Pays des numéros de téléphone', 'Format international, indicatif manuel', 'L’indicatif du pays choisi est ajouté aux numéros sans +. Les numéros commençant par + gardent leur indicatif.'],
    'de' => ['Land für Telefonnummern', 'Internationales Format, Vorwahl eingeben', 'Bei Nummern ohne + wird die gewählte Ländervorwahl ergänzt. Nummern mit + behalten ihre Vorwahl.'],
    'es' => ['País para los teléfonos', 'Formato internacional, prefijo manual', 'El prefijo elegido se añade a los números sin +. Los números que empiezan por + conservan su prefijo.'],
    'pt' => ['País para números de telefone', 'Formato internacional, indicativo manual', 'O indicativo escolhido é acrescentado a números sem +. Os números com + mantêm o indicativo introduzido.'],
    'ko' => ['전화번호 기본 국가', '국제 형식, 국가 번호 직접 입력', '선택한 국가 번호는 +가 없는 번호에 추가합니다. +로 시작하는 번호는 입력한 국가 번호를 유지합니다.'],
    'zh' => ['电话号码的默认国家', '国际格式，手动输入国家代码', '未输入 + 的号码会添加所选国家代码。以 + 开头的号码保留输入的国际代码。'],
];
