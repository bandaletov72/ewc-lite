<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => [
        'Поиск' => 'В «Настройки → Основные» выберите вид поиска: выключен, компактный с лупой или расширенный. Поле поиска в шапке админки ведёт к нужным настройкам. Индекс обновляется после правок в админке и может перестраиваться по расписанию для изменений по FTP. В индекс входят текст страниц, вложенные страницы и инфоблоки; произвольный PHP при индексации пропускается.',
        'PHP-модули' => 'Раскройте модуль для просмотра настроек и списка страниц с его вставкой. Через «Создать модуль» добавьте имя, имя файла и тело функции PHP. Возвращаемая строка вставляется кодом [php]имя[/php]. При переименовании файла код вставки сохраняется. CodeMirror включается в разделе библиотек.',
        'Шаблоны и переводы' => 'Можно отменить до восьми изменений каждого шаблона и вернуть исходный PHP для общих настроек и каждого домена. Чтобы изменить HTML, выберите «Свой HTML». Пользовательские PHP-шаблоны размещайте в templates/local/. Переключатель языков виден даже при создании перевода, а сохранённые переводы перемещаются вместе со страницей.',
        'Интеграции и обслуживание' => 'В настройках CAPTCHA, карт, телефонии и аналитики есть ссылки на кабинеты и инструкции провайдеров. URL HTTP API обратного звонка и токен можно задать в админке. Подшаблоны зарегистрированного поддомена сохраняются при переходе на основной домен. Планировщик хостинга должен запускать php update.php --scheduled каждые 15 минут.',
    ],
    'en' => [
        'Search' => 'In Settings → General choose Off, Compact with a magnifying glass, or Expanded. The admin header also searches setting names. Admin edits refresh the index automatically; scheduled indexing picks up FTP changes. Text, included pages and data blocks are indexed. The indexer skips arbitrary PHP.',
        'PHP modules' => 'Expand a module to see its settings and the pages that use it. Create a module with an ID, a file name and a PHP function body. It returns the string inserted by [php]id[/php]. You can rename the file without changing the insertion code. Enable CodeMirror under Libraries for syntax highlighting.',
        'Templates and translations' => 'Undo up to eight changes per template or restore the original PHP template. History is separate for each domain and the shared templates. Choose Custom HTML to edit in the browser or put a PHP override in templates/local/. The language switcher stays visible while creating a translation. Saved translations move with the page.',
        'Integrations and maintenance' => 'CAPTCHA, maps, telephony and analytics link to provider consoles or instructions. Enter a callback webhook URL and token in Integrations. A registered subdomain’s snippets follow the visitor to the main domain. Schedule php update.php --scheduled every 15 minutes on the host.',
    ],
    'uk' => [
        'Пошук' => 'В основних налаштуваннях можна вимкнути пошук або вибрати лупу чи розгорнуте поле. У шапці адмінки є пошук налаштувань. Індекс оновлюється після правок; для FTP доступний розклад. Індексуються вкладені сторінки й інфоблоки; PHP-модулі не запускаються.',
        'Модулі PHP' => 'Розкрийте модуль, щоб переглянути налаштування та сторінки, де його вставлено. Створіть модуль, вкажіть ім’я файлу та тіло функції. Зміна імені файлу зберігає код [php]id[/php]. Підсвічування CodeMirror вмикається у бібліотеках.',
        'Шаблони й переклади' => 'Можна скасувати до восьми змін кожного шаблону та відновити початковий PHP. Історія окрема для кожного домену. Власний HTML редагується в адмінці, PHP можна розмістити в templates/local/. Перемикач мов доступний під час створення перекладу. Переклади переносяться разом зі сторінкою.',
        'Інтеграції й обслуговування' => 'Посилання в налаштуваннях ведуть до ключів CAPTCHA, карт, телефонії й аналітики. URL і токен HTTP API задаються в адмінці. Значення зареєстрованого піддомену діють після переходу на основний домен. Заплануйте php update.php --scheduled кожні 15 хвилин.',
    ],
    'ja' => [
        '検索' => '基本設定で無効・虫眼鏡・展開を選べます。管理画面の上部でも設定を検索できます。管理画面での編集後は自動で索引を更新し、FTP での変更は定期実行で反映します。インクルードやデータブロックも検索対象になり、PHP モジュールは実行しません。',
        'PHP モジュール' => 'モジュールを開くと設定と使用ページが表示されます。ID、ファイル名、関数の本体を入力して作成します。ファイル名を変えても [php]id[/php] は共通です。ライブラリで CodeMirror を有効にできます。',
        'テンプレートと翻訳' => 'テンプレートごとに８件の変更を元に戻せます。既定の PHP に復元することもできます。ドメインごとに履歴があり、管理画面ではカスタム HTML、ファイルは templates/local/ を使います。翻訳の作成中も言語を切り替えられ、ページ移動では翻訳も移ります。',
        '連携とメンテナンス' => 'CAPTCHA、地図、電話、分析の設定に公式案内へのリンクを追加しました。コールバックの URL とトークンを入力できます。登録したサブドメインの設定はメインドメインへの遷移後も適用されます。php update.php --scheduled を15分おきに実行します。',
    ],
    'vi' => [
        'Tìm kiếm' => 'Chọn Tắt, Thu gọn hoặc Mở rộng trong cài đặt chung. Thanh quản trị tìm tên cài đặt. Chỉ mục tự cập nhật sau khi lưu; dùng lịch cho thay đổi qua FTP. Nội dung các trang được chèn và khối dữ liệu được lập chỉ mục. PHP động không chạy.',
        'Mô-đun PHP' => 'Mở mô-đun để xem cài đặt và trang sử dụng. Tạo bằng mã, tên tệp và thân hàm PHP. Đổi tên tệp vẫn giữ mã [php]id[/php]. Có thể bật tô sáng CodeMirror ở mục thư viện.',
        'Mẫu và bản dịch' => 'Hoàn tác tối đa tám thay đổi cho mỗi mẫu hoặc khôi phục mẫu PHP gốc. Mỗi miền có lịch sử riêng. HTML tùy chỉnh sửa trong quản trị, PHP tùy chỉnh đặt tại templates/local/. Nút chọn ngôn ngữ có cả khi tạo bản dịch; bản dịch đã lưu di chuyển cùng trang.',
        'Tích hợp và bảo trì' => 'Các liên kết trợ giúp trong mục CAPTCHA, bản đồ, điện thoại và phân tích dẫn tới nhà cung cấp. Có thể nhập URL và mã thông báo HTTP API. Thiết lập miền phụ vẫn có hiệu lực khi chuyển sang miền chính. Lên lịch php update.php --scheduled sau mỗi 15 phút.',
    ],
    'fr' => [
        'Recherche' => 'Dans les réglages généraux, désactivez la recherche ou choisissez une loupe ou un champ visible. La barre d’administration recherche aussi les réglages. L’index se met à jour après les modifications et peut être planifié pour le FTP. Les pages incluses et les blocs de données sont indexés sans exécuter les modules PHP.',
        'Modules PHP' => 'Développez un module pour voir ses réglages et les pages qui l’utilisent. Saisissez un identifiant, un nom de fichier et le corps de la fonction. Le code [php]id[/php] reste le même après un renommage. CodeMirror active la coloration syntaxique.',
        'Modèles et traductions' => 'Annulez jusqu’à huit modifications par modèle ou restaurez le PHP d’origine, par domaine ou pour les modèles partagés. Choisissez HTML personnalisé pour modifier un bloc, ou placez le PHP dans templates/local/. Le choix de langue reste visible et les traductions suivent la page déplacée.',
        'Intégrations et maintenance' => 'Les réglages de CAPTCHA, cartes, téléphonie et statistiques donnent accès aux instructions officielles. Saisissez l’URL et le jeton du rappel HTTP. Les réglages d’un sous-domaine enregistré restent actifs lors du passage au domaine principal. Planifiez php update.php --scheduled toutes les 15 minutes.',
    ],
    'de' => [
        'Suche' => 'Wählen Sie in den Grundeinstellungen Aus, Kompakt mit Lupe oder Erweitert. Die Adminleiste durchsucht Einstellungen. Der Index aktualisiert sich nach Änderungen; für FTP gibt es eine geplante Aktualisierung. Eingebundene Seiten und Datenblöcke werden indexiert, PHP-Module nicht ausgeführt.',
        'PHP-Module' => 'Klappen Sie ein Modul für Einstellungen und verwendende Seiten auf. Geben Sie Modul-ID, Dateiname und PHP-Funktionsrumpf ein. Beim Umbenennen bleibt [php]id[/php] unverändert. CodeMirror lässt sich für Syntaxhervorhebung aktivieren.',
        'Vorlagen und Übersetzungen' => 'Pro Vorlage können Sie bis zu acht Änderungen rückgängig machen oder das ursprüngliche PHP wiederherstellen. Die Historie ist je Domain getrennt. Eigenes HTML ändern Sie in der Verwaltung, PHP liegt in templates/local/. Die Sprachwahl bleibt beim Anlegen verfügbar; Übersetzungen werden mit der Seite verschoben.',
        'Integrationen und Wartung' => 'CAPTCHA, Karten, Telefonie und Analyse verlinken die Anbieter. URL und Token der Rückruf-API sind in der Verwaltung einstellbar. Beim Wechsel auf die Hauptdomain gelten die Platzhalter der registrierten Subdomain weiter. Planen Sie php update.php --scheduled alle 15 Minuten ein.',
    ],
    'es' => [
        'Búsqueda' => 'En General puedes desactivar la búsqueda o elegir lupa o campo ampliado. La cabecera de administración busca ajustes. El índice se actualiza tras editar; para FTP se puede programar. Se indexan páginas incluidas y bloques de datos sin ejecutar módulos PHP.',
        'Módulos PHP' => 'Despliega un módulo para ver ajustes y páginas que lo usan. Indica identificador, nombre del archivo y cuerpo de función. Al renombrar el archivo se mantiene [php]id[/php]. Activa CodeMirror para resaltar sintaxis.',
        'Plantillas y traducciones' => 'Deshaz hasta ocho cambios por plantilla o restablece el PHP original. Cada dominio tiene su propio historial. Usa HTML personalizado en la administración y templates/local/ para PHP. Puedes cambiar de idioma al crear una traducción; las traducciones guardadas se trasladan con la página.',
        'Integraciones y mantenimiento' => 'CAPTCHA, mapas, telefonía y analítica enlazan a la documentación de sus proveedores. Configura URL y token HTTP de la devolución de llamada. Los ajustes de un subdominio registrado se mantienen al pasar al dominio principal. Ejecuta php update.php --scheduled cada 15 minutos.',
    ],
    'pt' => [
        'Pesquisa' => 'Em Geral, escolha desativada, lupa ou campo expandido. O cabeçalho da administração pesquisa configurações. O índice é atualizado após alterações; use o agendamento para FTP. Páginas incluídas e blocos de dados entram no índice sem executar módulos PHP.',
        'Módulos PHP' => 'Expanda um módulo para ver configurações e páginas que o utilizam. Crie um módulo com identificador, nome de arquivo e corpo da função PHP. Renomear o arquivo mantém [php]id[/php]. Ative CodeMirror para destacar a sintaxe.',
        'Modelos e traduções' => 'Desfaça até oito alterações por modelo ou restaure o PHP original. Cada domínio tem histórico separado. Use HTML personalizado no painel e templates/local/ para PHP. O seletor de idioma aparece ao criar uma tradução e as traduções acompanham a página movida.',
        'Integrações e manutenção' => 'CAPTCHA, mapas, telefonia e métricas contêm links oficiais. Informe URL e token HTTP do retorno de chamada. As configurações do subdomínio cadastrado permanecem ao passar para o domínio principal. Agende php update.php --scheduled a cada 15 minutos.',
    ],
    'ko' => [
        '검색' => '기본 설정에서 검색을 끄거나 돋보기 또는 확장 표시를 선택합니다. 관리자 상단에서도 설정을 검색할 수 있습니다. 관리자 편집 후 색인이 갱신되며 FTP 변경에는 예약 갱신을 사용합니다. 포함 페이지와 데이터 블록을 색인하고 PHP 모듈은 실행하지 않습니다.',
        'PHP 모듈' => '모듈을 펼치면 설정과 사용 중인 페이지가 표시됩니다. 모듈 ID, 파일 이름 및 함수 본문을 입력하세요. 파일 이름을 바꿔도 [php]id[/php]는 유지됩니다. CodeMirror를 켜면 구문을 강조합니다.',
        '템플릿과 번역' => '템플릿마다 최대 여덟 번의 변경을 취소하거나 원본 PHP를 복원할 수 있습니다. 도메인별로 기록이 따로 저장됩니다. HTML은 관리자에서 편집하고 PHP는 templates/local/에 둡니다. 번역을 만드는 중에도 언어를 전환할 수 있으며 페이지를 옮기면 번역도 이동합니다.',
        '연동과 유지 관리' => 'CAPTCHA, 지도, 전화, 분석 설정에 공식 링크가 있습니다. 콜백 HTTP URL과 토큰을 입력할 수 있습니다. 등록된 하위 도메인에서 기본 도메인으로 이동해도 기존 설정이 적용됩니다. php update.php --scheduled 명령을 15분마다 실행하세요.',
    ],
];
