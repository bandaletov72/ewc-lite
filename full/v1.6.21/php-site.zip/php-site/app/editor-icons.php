<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$bundle = require SITE_ROOT . '/app/font-awesome-data.php';
$css = base64_decode($bundle['all.min.css'], true);
$brandStart = strpos($css, '.fa-brands,.fa-classic.fa-brands');
$catalog = [];
foreach (['solid' => substr($css, 0, $brandStart), 'brands' => substr($css, $brandStart)] as $style => $definitions) {
    preg_match_all('/((?:\.fa-[a-z0-9-]+,?)+)\{--fa:/', $definitions, $rules);
    $names = [];
    foreach ($rules[1] as $selectors) {
        foreach (explode(',', $selectors) as $selector) {
            $names[substr($selector, 4)] = true;
        }
    }
    ksort($names, SORT_STRING);
    $catalog[$style] = array_keys($names);
}
return $catalog;
