<?php
define('SITE_ROOT', dirname(__DIR__));
require __DIR__ . '/redirect-rules.php';
$suffix = '/app/redirect.php';
$script = $_SERVER['SCRIPT_NAME'] ?? '';
$base = substr($script, -strlen($suffix)) === $suffix ? substr($script, 0, -strlen($suffix)) : '';
if (!site_apply_redirect_rules($base)) {
    http_response_code(404);
}
