<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_INTEGRATIONS_FILE = SITE_ROOT . '/admin/.integrations.php';

function site_integration_catalog(): array
{
    return [
        'metrica' => ['Яндекс Метрика', 'Номер счётчика', '/\A[0-9]{1,16}\z/'],
        'analytics' => ['Google Analytics 4', 'Идентификатор потока G-…', '/\AG-[A-Z0-9]{4,32}\z/'],
        'pixel' => ['Meta Pixel', 'Идентификатор пикселя', '/\A[0-9]{1,24}\z/'],
        'cloudflare' => ['Cloudflare Web Analytics', 'Токен счётчика', '/\A[A-Za-z0-9_-]{8,96}\z/'],
        'jivo' => ['JivoSite', 'Widget ID', '/\A[A-Za-z0-9_-]{5,96}\z/'],
        'clarity' => ['Microsoft Clarity', 'Project ID', '/\A[A-Za-z0-9]{4,48}\z/'],
        'umami' => ['Umami Cloud', 'Website ID', '/\A[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\z/'],
    ];
}

function site_integration_settings(): array
{
    try {
        return site_read_record(SITE_INTEGRATIONS_FILE, 65536);
    } catch (RuntimeException $exception) {
        return [];
    }
}

function site_public_analytics(): array
{
    $stored = site_integration_settings();
    $enabled = [];
    foreach (site_integration_catalog() as $key => $item) {
        if ($key === 'jivo') {
            continue;
        }
        $service = $stored[$key] ?? [];
        if (($service['enabled'] ?? false) === true && is_string($service['id'] ?? null)
            && preg_match($item[2], $service['id'])) {
            $enabled[$key] = $service['id'];
        }
    }
    return $enabled;
}

function site_jivo_widget(): string
{
    $service = site_integration_settings()['jivo'] ?? [];
    return ($service['enabled'] ?? false) === true && is_string($service['id'] ?? null) && preg_match(site_integration_catalog()['jivo'][2], $service['id'])
        ? $service['id'] : '';
}

function site_valid_botfaqtor_code(string $code): bool
{
    return $code !== '' && strlen($code) <= 16384 && preg_match('//u', $code) === 1 && strpos($code, "\0") === false
        && preg_match('~\A\s*(?:<!--(?:(?!-->).)*-->\s*|<script\b[^>]*>(?:(?!</script\s*>).)*</script\s*>\s*)+\z~is', $code) === 1
        && stripos($code, '<script') !== false;
}

function site_slack_webhook(string $url): bool
{
    return preg_match('~\Ahttps://hooks\.slack(?:-gov)?\.com/services/[A-Z0-9]{4,64}/[A-Z0-9]{4,64}/[A-Za-z0-9_-]{8,160}\z~', $url) === 1;
}

function site_notify_slack(array $message)
{
    $settings = site_integration_settings();
    $url = $settings['slack_url'] ?? '';
    if (($settings['slack_enabled'] ?? false) !== true || !is_string($url) || !site_slack_webhook($url)) {
        return;
    }
    $text = 'New website request · ' . $message['form'] . ' · ' . $message['host'] . site_page_url('', $message['page']);
    $body = json_encode(['text' => $text, 'mrkdwn' => false, 'unfurl_links' => false, 'unfurl_media' => false], JSON_UNESCAPED_UNICODE);
    $options = ['http' => ['method' => 'POST', 'header' => 'Content-Type: application/json', 'content' => $body,
        'timeout' => 4, 'follow_location' => 0]];
    @file_get_contents($url, false, stream_context_create($options), 0, 1024);
}

function site_payment_methods(): array
{
    return [
        'yoomoney' => ['ЮMoney', ['yoomoney.ru', 'www.yoomoney.ru'], 'https://yoomoney.ru/document/vizitka-v-yoomoney'],
        'paypal' => ['PayPal', ['paypal.com', 'www.paypal.com', 'paypal.me', 'www.paypal.me'], 'https://developer.paypal.com/payment-links-buttons/overview'],
        'sbp' => ['СБП', ['qr.nspk.ru', 'b2b.cbrpay.ru'], 'https://sbp.nspk.ru/faq/payment'],
    ];
}

function site_valid_payment_url(string $url, array $hosts): bool
{
    $parsed = parse_url($url);
    return strlen($url) <= 2048 && filter_var($url, FILTER_VALIDATE_URL) && ($parsed['scheme'] ?? '') === 'https'
        && in_array(strtolower($parsed['host'] ?? ''), $hosts, true) && ltrim($parsed['path'] ?? '', '/') !== ''
        && !isset($parsed['user']) && !isset($parsed['pass']) && (!isset($parsed['port']) || $parsed['port'] === 443);
}

function site_payment_markup(): string
{
    $settings = site_integration_settings()['payments'] ?? [];
    $links = [];
    foreach (site_payment_methods() as $key => list($name, $hosts)) {
        $url = $settings[$key] ?? '';
        if (is_string($url) && site_valid_payment_url($url, $hosts)) {
            $links[] = '<a class="button" href="' . site_escape($url) . '" rel="noreferrer">' . site_escape($name) . '</a>';
        }
    }
    return $links ? '<div class="payment-links">' . implode(' ', $links) . '</div>' : '';
}

function site_integration_secret(string $key, string $env): string
{
    $value = site_integration_settings()[$key] ?? '';
    return is_string($value) && $value !== '' ? $value : (string) getenv($env);
}

function site_notify_telegram(array $message)
{
    $settings = site_integration_settings();
    $token = $settings['telegram_token'] ?? '';
    $chat = $settings['telegram_chat'] ?? '';
    if (($settings['telegram_enabled'] ?? false) !== true || !is_string($token) || !is_string($chat)
        || !preg_match('/\A[0-9]+:[A-Za-z0-9_-]{16,100}\z/', $token)
        || !preg_match('/\A(?:-?[0-9]{1,20}|@[A-Za-z0-9_]{5,32})\z/', $chat)) {
        return;
    }
    $text = "Новая заявка с сайта\nФорма: " . $message['form'] . "\nСтраница: " . $message['host'] . site_page_url('', $message['page']);
    $options = ['http' => ['method' => 'POST', 'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query(['chat_id' => $chat, 'text' => $text]), 'timeout' => 4, 'follow_location' => 0]];
    @file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage', false, stream_context_create($options), 0, 8192);
}
