<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Языки', 'Сейчас открыта', 'Открыть', 'Создать перевод', 'Сначала сохраните страницу.',
        'Добавить подраздел', 'Новый перевод', 'Во вкладке «Языки» перечислены языки страницы. «Открыть» ведёт к сохранённой версии, «Создать перевод» открывает редактор нового перевода.',
        'Добавить соседний раздел', 'Добавить раздел в корне', 'Для нового раздела выберите нужный уровень. Подраздел создаётся внутри открытого раздела, соседний — рядом с ним, корневой — на верхнем уровне сайта.'],
    'en' => ['Languages', 'Currently open', 'Open', 'Create translation', 'Save the page first.',
        'Add subsection', 'New translation', 'The Languages tab lists the page languages. Open takes you to a saved version. Create translation opens a blank translation editor.',
        'Add sibling section', 'Add root section', 'Choose where to create the section. A subsection goes inside the current section, a sibling goes beside it, and a root section goes at the top level of the site.'],
    'uk' => ['Мови', 'Зараз відкрита', 'Відкрити', 'Створити переклад', 'Спочатку збережіть сторінку.',
        'Додати підрозділ', 'Новий переклад', 'На вкладці «Мови» перелічено мови сторінки. «Відкрити» веде до збереженої версії, а «Створити переклад» відкриває редактор нового перекладу.',
        'Додати сусідній розділ', 'Додати розділ у корені', 'Підрозділ створюється всередині поточного розділу, сусідній — поруч із ним, а кореневий — на верхньому рівні сайту.'],
    'de' => ['Sprachen', 'Derzeit geöffnet', 'Öffnen', 'Übersetzung erstellen', 'Speichern Sie zuerst die Seite.',
        'Unterbereich hinzufügen', 'Neue Übersetzung', 'Der Tab „Sprachen“ listet die Seitensprachen auf. „Öffnen“ führt zur gespeicherten Version. „Übersetzung erstellen“ öffnet einen leeren Editor.',
        'Bereich auf gleicher Ebene hinzufügen', 'Bereich auf oberster Ebene hinzufügen', 'Ein Unterbereich entsteht im aktuellen Bereich, ein gleichrangiger Bereich daneben und ein Hauptbereich auf der obersten Ebene der Website.'],
    'fr' => ['Langues', 'Version ouverte', 'Ouvrir', 'Créer une traduction', 'Enregistrez d’abord la page.',
        'Ajouter une sous-section', 'Nouvelle traduction', 'L’onglet Langues présente les langues de la page. Ouvrir affiche la version enregistrée. Créer une traduction ouvre un éditeur vide.',
        'Ajouter une section au même niveau', 'Ajouter une section à la racine', 'Une sous-section est créée dans la section active, une section de même niveau à côté, et une section racine au premier niveau du site.'],
    'es' => ['Idiomas', 'Versión abierta', 'Abrir', 'Crear traducción', 'Guarda primero la página.',
        'Añadir subsección', 'Nueva traducción', 'La pestaña Idiomas muestra los idiomas de la página. Abrir lleva a la versión guardada. Crear traducción abre un editor vacío.',
        'Añadir sección al mismo nivel', 'Añadir sección en la raíz', 'Una subsección se crea dentro de la sección actual, una sección hermana a su lado y una sección raíz en el nivel superior del sitio.'],
    'pt' => ['Idiomas', 'Versão aberta', 'Abrir', 'Criar tradução', 'Salve a página primeiro.',
        'Adicionar subseção', 'Nova tradução', 'A aba Idiomas lista os idiomas da página. Abrir leva à versão salva. Criar tradução abre um editor vazio.',
        'Adicionar seção no mesmo nível', 'Adicionar seção na raiz', 'Uma subseção fica dentro da seção atual, uma seção no mesmo nível fica ao lado e uma seção na raiz fica no nível superior do site.'],
    'ja' => ['言語', '表示中', '開く', '翻訳を作成', '先にページを保存してください。',
        'サブセクションを追加', '新しい翻訳', '「言語」タブにページの言語が表示されます。「開く」で保存済みの翻訳を編集し、「翻訳を作成」で空のエディターを開きます。',
        '同じ階層にセクションを追加', '最上位にセクションを追加', 'サブセクションは現在のセクション内に、同階層のセクションはその隣に、ルートセクションはサイトの最上位に作成されます。'],
    'ko' => ['언어', '현재 열려 있음', '열기', '번역 만들기', '먼저 페이지를 저장하세요.',
        '하위 섹션 추가', '새 번역', '언어 탭에는 페이지의 언어가 표시됩니다. 열기를 누르면 저장된 버전으로 이동합니다. 번역 만들기는 빈 편집기를 엽니다.',
        '같은 수준에 섹션 추가', '최상위 섹션 추가', '하위 섹션은 현재 섹션 안에, 같은 수준의 섹션은 그 옆에, 최상위 섹션은 사이트의 맨 위 수준에 생성됩니다.'],
    'vi' => ['Ngôn ngữ', 'Đang mở', 'Mở', 'Tạo bản dịch', 'Hãy lưu trang trước.',
        'Thêm mục con', 'Bản dịch mới', 'Thẻ Ngôn ngữ liệt kê các ngôn ngữ của trang. Mở đưa bạn đến bản đã lưu. Tạo bản dịch mở trình soạn thảo trống.',
        'Thêm mục cùng cấp', 'Thêm mục ở cấp gốc', 'Mục con nằm trong mục hiện tại, mục cùng cấp nằm cạnh mục đó, còn mục gốc nằm ở cấp cao nhất của trang web.'],
];
