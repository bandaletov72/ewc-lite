<?php
if (!defined('SITE_ROOT') && !defined('SITE_ROUTER')) {
    http_response_code(404);
    exit;
}

const SITE_REDIRECT_SECTION = '~^# BEGIN EUROWEBCART REDIRECTS\r?\n.*?^# END EUROWEBCART REDIRECTS(?:\r?\n|$)~ms';

function site_redirect_rules(?string $configuration = null): array
{
    $bytes = $configuration ?? (string) @file_get_contents(dirname(__DIR__) . '/.htaccess', false, null, 0, 65537);
    if (!preg_match(SITE_REDIRECT_SECTION, $bytes, $section) || !preg_match('/^# Rules: ([A-Za-z0-9+\/=]+)\r?$/m', $section[0], $match)) {
        return [];
    }
    $decoded = base64_decode($match[1], true);
    $rules = $decoded === false ? null : json_decode($decoded, true);
    return is_array($rules) ? array_filter($rules, 'is_string') : [];
}

function site_redirect_safe_target(string $target): bool
{
    if ($target === '' || strlen($target) > 1500 || preg_match('/[\x00-\x20\x7f\\\\]/', $target)) {
        return false;
    }
    if ($target[0] === '/') {
        return substr($target, 0, 2) !== '//';
    }
    $parsed = parse_url($target);
    return filter_var($target, FILTER_VALIDATE_URL) && in_array(strtolower($parsed['scheme'] ?? ''), ['http', 'https'], true)
        && !isset($parsed['user']) && !isset($parsed['pass']);
}

function site_apply_redirect_rules(string $base): bool
{
    if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
        return false;
    }
    $path = explode('?', $_SERVER['REQUEST_URI'] ?? '/', 2)[0];
    if ($base !== '') {
        if (strpos($path, rtrim($base, '/') . '/') !== 0) {
            return false;
        }
        $path = substr($path, strlen(rtrim($base, '/')));
    }
    $target = site_redirect_rules()[$path] ?? '';
    if (!site_redirect_safe_target($target)) {
        return false;
    }
    header('Location: ' . ($target[0] === '/' ? rtrim($base, '/') . $target : $target), true, 301);
    return true;
}
