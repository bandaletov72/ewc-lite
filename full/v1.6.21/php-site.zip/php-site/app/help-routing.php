<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'Нажмите имя папки слева, чтобы управлять разделом справа. Там можно выбрать родительский раздел, настроить обычное и мобильное меню или указать URL перехода. Пустая страница раздела показывает подразделы. В «Обслуживании» задайте правила вида /contact.html => /contacts/ и редактируйте страницы ошибок в /error/. Поиск и язык на телефоне доступны через иконки в шапке.',
    'en' => 'Click a folder name to manage the section in the right panel. Choose a parent section, set desktop and mobile menu options, or enter a redirect URL. An empty section page lists its children. Under Maintenance, add rules such as /contact.html => /contacts/ and edit error pages in /error/. Mobile search and language use header icons.',
    'uk' => 'Натисніть назву папки, щоб керувати розділом праворуч. Там можна вибрати батьківський розділ, налаштувати звичайне й мобільне меню та вказати URL переходу. Порожня сторінка показує підрозділи. В «Обслуговуванні» задавайте правила /contact.html => /contacts/ і редагуйте сторінки помилок у /error/. Мова й пошук доступні через іконки.',
    'ja' => 'フォルダー名を選ぶと右側でセクションを管理できます。親セクション、モバイルと通常のメニュー、転送先 URL を設定できます。空のページには子セクションが表示されます。メンテナンスで /contact.html => /contacts/ のようなルールを追加し、/error/ のページを編集できます。モバイルの言語選択と検索はヘッダーのアイコンにあります。',
    'vi' => 'Bấm tên thư mục để quản lý ở bên phải. Chọn mục cha, cấu hình menu máy tính và di động, hoặc điền URL chuyển hướng. Trang mục trống sẽ liệt kê các mục con. Trong Bảo trì, thêm quy tắc như /contact.html => /contacts/ và sửa các trang trong /error/. Trên di động, ngôn ngữ và tìm kiếm có nút biểu tượng.',
    'fr' => 'Cliquez sur un dossier pour gérer la rubrique à droite. Choisissez un parent, les menus ordinateur et mobile ou une URL de redirection. Une rubrique vide liste ses sous-rubriques. Dans Maintenance, ajoutez des règles comme /contact.html => /contacts/ et modifiez les pages dans /error/. Sur mobile, la langue et la recherche utilisent des icônes.',
    'de' => 'Klicken Sie auf einen Ordnernamen, um den Bereich rechts zu verwalten. Wählen Sie einen übergeordneten Bereich oder stellen Sie Desktopmenü, Mobilmenü und Weiterleitungs-URL ein. Eine leere Bereichsseite listet Unterbereiche auf. Unter Wartung bearbeiten Sie Regeln wie /contact.html => /contacts/ und Seiten in /error/. Sprache und Suche haben mobile Symbole.',
    'es' => 'Pulsa el nombre de una carpeta para gestionar la sección a la derecha. Elige la sección superior, ajusta los menús de escritorio y móvil o introduce una URL de redirección. Una sección vacía lista sus subsecciones. En Mantenimiento añade reglas como /contact.html => /contacts/ y edita las páginas de /error/. El idioma y la búsqueda tienen iconos en móvil.',
    'pt' => 'Clique no nome da pasta para gerir a secção à direita. Escolha a secção superior, configure os menus ou indique um URL de redirecionamento. Uma secção vazia lista as subsecções. Em Manutenção, acrescente regras como /contact.html => /contacts/ e edite as páginas em /error/. O idioma e a pesquisa têm ícones no telemóvel.',
    'ko' => '폴더 이름을 누르면 오른쪽에서 섹션을 관리할 수 있습니다. 상위 섹션, 데스크톱과 모바일 메뉴 또는 이동 URL을 설정하세요. 빈 섹션은 하위 항목을 표시합니다. 유지 관리에서 /contact.html => /contacts/ 규칙을 추가하고 /error/ 페이지를 수정할 수 있습니다. 모바일에서는 언어와 검색이 아이콘으로 표시됩니다.',
];
