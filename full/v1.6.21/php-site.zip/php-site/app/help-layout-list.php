<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Раскрыть все', 'Свернуть все', 'Шаблоны оформления начинают работу в свёрнутом виде. Откройте нужный шаблон по заголовку или воспользуйтесь кнопкой «Раскрыть все». Повторное нажатие сворачивает список.'],
    'en' => ['Expand all', 'Collapse all', 'Layout templates start collapsed. Open a template by its heading or select Expand all. Press the button again to collapse the list.'],
    'uk' => ['Розгорнути всі', 'Згорнути всі', 'Шаблони оформлення спочатку згорнуті. Відкрийте потрібний шаблон за заголовком або натисніть «Розгорнути всі». Повторне натискання згортає список.'],
    'ja' => ['すべて展開', 'すべて折りたたむ', 'レイアウトテンプレートは折りたたまれています。見出しを選ぶか「すべて展開」を押してください。もう一度押すと折りたたまれます。'],
    'vi' => ['Mở rộng tất cả', 'Thu gọn tất cả', 'Các mẫu bố cục được thu gọn lúc đầu. Bấm tiêu đề hoặc Mở rộng tất cả. Bấm lần nữa để thu gọn danh sách.'],
    'fr' => ['Tout déplier', 'Tout replier', 'Les modèles sont repliés au départ. Ouvrez un modèle depuis son titre ou utilisez Tout déplier. Appuyez de nouveau pour replier la liste.'],
    'de' => ['Alle aufklappen', 'Alle einklappen', 'Die Layoutvorlagen sind anfangs eingeklappt. Öffnen Sie eine Vorlage über ihre Überschrift oder wählen Sie Alle aufklappen. Erneutes Drücken klappt die Liste ein.'],
    'es' => ['Expandir todo', 'Contraer todo', 'Las plantillas de diseño están contraídas al inicio. Pulse un título o seleccione Expandir todo. Pulse de nuevo para contraer la lista.'],
    'pt' => ['Expandir tudo', 'Recolher tudo', 'Os modelos de layout começam recolhidos. Abra um modelo pelo título ou escolha Expandir tudo. Prima novamente para recolher a lista.'],
    'ko' => ['모두 펼치기', '모두 접기', '레이아웃 템플릿은 처음에 접혀 있습니다. 제목을 누르거나 모두 펼치기를 선택하세요. 다시 누르면 목록이 접힙니다.'],
    'zh' => ['全部展开', '全部收起', '布局模板默认折叠。点击标题可打开单个模板，也可点击“全部展开”。再次点击可收起列表。'],
];
