<?php
define('SITE_ROOT', dirname(__DIR__));
require __DIR__ . '/site.php';

$base = rtrim(site_base('app/page-language.php'), '/');
$request = explode('?', $_SERVER['REQUEST_URI'] ?? '', 2)[0];
$relative = substr($request, strlen($base));
$path = rawurldecode(substr($relative, 1));
if ($relative === '' || $relative[0] !== '/' || ($base !== '' && strpos($request, $base . '/') !== 0)
    || !site_valid_path($path) || site_page_translation($path)[1] === '') {
    http_response_code(404);
    exit;
}
unset($_SERVER['PATH_INFO']);
site_render(SITE_ROOT . '/' . $path, $base);
