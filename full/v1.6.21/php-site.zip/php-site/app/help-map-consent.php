<?php
return [
    'ru' => 'Разрешить и показать карту', 'en' => 'Allow and show map', 'uk' => 'Дозволити й показати карту',
    'de' => 'Karte erlauben und anzeigen', 'fr' => 'Autoriser et afficher la carte', 'es' => 'Permitir y mostrar el mapa',
    'pt' => 'Permitir e mostrar o mapa', 'ja' => '地図を許可して表示', 'ko' => '지도 허용 및 표시',
    'vi' => 'Cho phép và hiển thị bản đồ', 'zh' => '允许并显示地图',
];
