<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

$labels = require SITE_ROOT . '/app/help-portfolio.php';
$locale = $GLOBALS['adminLanguage'] ?? site_region_settings()['public'];
return ['portfolio' => [
    'kind' => 'single',
    'label' => ($labels[$locale] ?? $labels['ru'])[0],
    'render' => static function (string $argument, array $context): string {
        return site_component_iblock('portfolio', '/data/kontur-works.txt', [], site_public_language($context['base'], ''), $context['base']);
    },
]];
