<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'server-date' => [
        'kind' => 'single',
        'label' => 'Текущая дата',
        'render' => static function (string $argument, array $context): string {
            $time = $_SERVER['REQUEST_TIME'] ?? time();
            return '<time datetime="' . site_escape(date('Y-m-d', $time)) . '">'
                . site_escape(date(site_region_settings()['date'], $time)) . '</time>';
        },
    ],
];
