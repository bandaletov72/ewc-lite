<?php
if (!defined('SITE_ROOT')) exit;

$insertion = [
    'zh' => '重新打开编辑器后，已保存的表单、模板、片段和已注册的组件会自动出现在插入列表中。新横幅组的 ID 只允许 A–Z、a–z、连字符和下划线。将图片上传到 [banners] 文件夹后，每个文件旁边都会出现编辑链接。',
    'ru' => 'В списках вставки автоматически появляются сохранённые формы, шаблоны, подшаблоны и зарегистрированные компоненты при повторном открытии редактора. ID нового набора баннеров допускает A–Z, a–z, дефис и подчёркивание. После загрузки изображений в папку [banners] рядом с каждым файлом появляется ссылка «Редактировать кадр».',
    'en' => 'Saved forms, templates, snippets and registered components appear automatically when the editor is reopened. The ID of a new banner set accepts A–Z, a–z, hyphens and underscores. After uploading images to a [banners] folder, an Edit slide link appears beside each file.',
    'uk' => 'Збережені форми, шаблони, підшаблони й зареєстровані компоненти з’являються після повторного відкриття редактора. ID нового набору банерів допускає A–Z, a–z, дефіс і підкреслення. Після завантаження зображень до папки [banners] біля кожного файлу є посилання «Редагувати кадр».',
    'ja' => 'エディターを開き直すと、保存したフォーム、テンプレート、スニペット、登録したコンポーネントが挿入一覧に表示されます。新しいバナーセット ID には A–Z、a–z、ハイフン、アンダースコアを使用できます。[banners] のフォルダーに画像をアップロードすると、各ファイルに編集リンクが表示されます。',
    'vi' => 'Biểu mẫu, mẫu, đoạn mã đã lưu và thành phần đã đăng ký tự xuất hiện khi mở lại trình sửa. ID bộ banner mới dùng A–Z, a–z, dấu gạch nối và gạch dưới. Sau khi tải ảnh vào thư mục [banners], liên kết sửa slide xuất hiện cạnh mỗi tệp.',
    'fr' => 'Les formulaires, modèles, fragments enregistrés et composants déclarés apparaissent à la réouverture de l’éditeur. L’ID d’un nouveau groupe de bannières accepte A–Z, a–z, les tirets et les traits de soulignement. Après l’envoi d’images dans un dossier [banners], un lien de modification apparaît près de chaque fichier.',
    'de' => 'Beim erneuten Öffnen des Editors erscheinen gespeicherte Formulare, Vorlagen, Textbausteine und registrierte Komponenten. Die ID eines neuen Banner-Sets erlaubt A–Z, a–z, Bindestriche und Unterstriche. Nach dem Hochladen in einen [banners]-Ordner erscheint neben jeder Datei ein Link zur Folienbearbeitung.',
    'es' => 'Los formularios, plantillas, fragmentos guardados y componentes registrados aparecen al volver a abrir el editor. El ID de un conjunto nuevo admite A–Z, a–z, guiones y guiones bajos. Al subir imágenes a una carpeta [banners], aparece un enlace para editar cada diapositiva.',
    'pt' => 'Formulários, modelos, trechos salvos e componentes registrados aparecem ao reabrir o editor. O ID de um novo conjunto aceita A–Z, a–z, hífens e sublinhados. Após enviar imagens para uma pasta [banners], aparece um link para editar o slide ao lado de cada arquivo.',
    'ko' => '편집기를 다시 열면 저장한 양식, 템플릿, 스니펫과 등록한 구성 요소가 삽입 목록에 표시됩니다. 새 배너 세트 ID에는 A–Z, a–z, 하이픈, 밑줄을 쓸 수 있습니다. [banners] 폴더에 이미지를 올리면 각 파일 옆에 슬라이드 편집 링크가 표시됩니다.',
];
$managers = [
    'ru' => 'На сайте в режиме правки «Редактировать кадр» открывает только выбранный кадр в модальном окне. Общие параметры доступны по отдельной ссылке. В настройках галереи, карусели и списка файлов рядом с сохранением есть файловый менеджер. Он поддерживает загрузку, удаление, сортировку и создание подпапок (A–Z, a–z, 0–9, - и _). Цвета кадра показаны квадратными образцами.',
    'en' => 'In edit mode, Edit slide opens the selected slide in a dialog with a separate link to component defaults. The carousel, gallery and file list have a file manager next to Save for uploads, deletion, sorting and subfolders (A–Z, a–z, 0–9, - and _). Slide colors appear as square swatches.',
    'uk' => 'У режимі редагування вікно відкриває вибраний кадр, а окреме посилання веде до типових налаштувань. Біля збереження каруселі, галереї та списку файлів є файловий менеджер для завантаження, видалення, сортування та підпапок (A–Z, a–z, 0–9, - і _). Кольори кадру показано квадратними зразками.',
    'ja' => '編集モードでは選んだスライドがダイアログで開き、既定設定は別リンクから開けます。カルーセル、ギャラリー、ファイル一覧の保存ボタンの隣には、アップロード・削除・並べ替え・子フォルダー作成用のファイルマネージャーがあります（A–Z、a–z、0–9、-、_）。スライド色は四角い見本に表示されます。',
    'vi' => 'Ở chế độ sửa, cửa sổ chỉ mở slide đã chọn và có liên kết riêng đến cài đặt mặc định. Trình quản lý tệp cạnh nút Lưu của băng chuyền, thư viện ảnh và danh sách tệp cho phép tải lên, xóa, sắp xếp và tạo thư mục con (A–Z, a–z, 0–9, - và _). Màu slide hiển thị trong ô vuông.',
    'fr' => 'En mode édition, seule la diapositive choisie s’ouvre dans une fenêtre. Un lien distinct mène aux réglages par défaut. Le gestionnaire près du bouton Enregistrer du carrousel, de la galerie et de la liste permet les envois, la suppression, le tri et la création de sous-dossiers (A–Z, a–z, 0–9, - et _). Les couleurs sont visibles dans des carrés.',
    'de' => 'Im Bearbeitungsmodus öffnet sich nur die gewählte Folie im Dialog. Die Standardeinstellungen sind separat verlinkt. Neben Speichern öffnen Karussell, Galerie und Dateiliste einen Dateimanager zum Hochladen, Löschen, Sortieren und Anlegen von Unterordnern (A–Z, a–z, 0–9, - und _). Folienfarben werden als Quadrate angezeigt.',
    'es' => 'En modo de edición, se abre la diapositiva elegida en una ventana con un enlace a los ajustes predeterminados. Junto a Guardar, el gestor de carruseles, galerías y listas permite subir, eliminar, ordenar y crear subcarpetas (A–Z, a–z, 0–9, - y _). Los colores se ven en muestras cuadradas.',
    'pt' => 'No modo de edição, a janela exibe o slide escolhido e oferece um link para as configurações padrão. Ao lado de Salvar, o gerenciador de carrosséis, galerias e listas permite enviar, excluir, ordenar e criar subpastas (A–Z, a–z, 0–9, - e _). As cores aparecem em quadrados.',
    'ko' => '편집 모드에서는 선택한 슬라이드만 대화상자에 열리고 기본 설정은 별도 링크로 이동합니다. 캐러셀, 갤러리, 파일 목록의 저장 옆 파일 관리자에서 업로드, 삭제, 정렬, 하위 폴더 생성(A–Z, a–z, 0–9, -, _)을 할 수 있습니다. 슬라이드 색상은 사각형 견본으로 표시됩니다.',
    'zh' => '在网站编辑模式中，“编辑幻灯片”会在弹窗中打开选中的幻灯片，另有链接可查看组件默认设置。轮播、相册和文件列表的保存按钮旁有文件管理器，支持上传、删除、排序和新建子文件夹（A–Z、a–z、0–9、-、_）。幻灯片颜色以方形色样显示。',
];
foreach ($insertion as $language => $paragraph) {
    $insertion[$language] = $paragraph . ' ' . $managers[$language];
}
return $insertion;
