<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'header.php' => <<<'PHP'
<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<div class="demo-theme-header">
    <?php require SITE_ROOT . '/templates/header.php'; ?>
</div>
PHP
    ,
    'css/theme.css' => <<<'CSS'
.demo-theme-header { display: flex; flex: 1; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: .7rem 1rem; }
.demo-theme-header .site-brand { border-inline-start: .25rem solid var(--accent); padding-inline-start: .65rem; }
.page-preset-hero { background: radial-gradient(ellipse at top left, var(--accent-wash), var(--surface) 72%); }
.site-footer { border-block-start: .2rem solid var(--accent); }
CSS
    ,
];
