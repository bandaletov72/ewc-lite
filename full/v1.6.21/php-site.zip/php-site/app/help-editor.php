<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => 'В HTML и визуальном редакторе значки форматируют текст, добавляют H1–H5 и списки. Установите курсор и выберите отдельно шаблон, компонент, изображение или иконку. Для форм доступны сохранённые коды, а для компонентов — их параметры. Вставка Font Awesome доступна при включённой библиотеке.',
    'en' => 'The HTML and visual editors have icon buttons for formatting, H1–H5 headings and lists. Place the cursor and choose a template, component, image or icon. Forms are listed by shortcode and components have their own options. Font Awesome insertion is available when the library is enabled.',
    'uk' => 'У HTML і візуальному редакторі значки форматують текст, додають H1–H5 і списки. Поставте курсор і виберіть шаблон, компонент, зображення або іконку. Доступні збережені форми та параметри компонентів. Іконки Font Awesome доступні, коли бібліотека увімкнена.',
    'ja' => 'HTML とビジュアル編集の各アイコンで文字装飾、見出し H1〜H5、リストを追加できます。カーソル位置を決め、テンプレート、コンポーネント、画像、アイコンを選びます。フォーム一覧とコンポーネントの設定が表示されます。Font Awesome はライブラリ有効時に使えます。',
    'vi' => 'Các nút biểu tượng trong trình soạn HTML và trực quan định dạng văn bản, tiêu đề H1–H5 và danh sách. Đặt con trỏ rồi chọn mẫu, thành phần, ảnh hoặc biểu tượng. Có danh sách biểu mẫu và tùy chọn thành phần. Font Awesome khả dụng khi bật thư viện.',
    'fr' => 'Les éditeurs HTML et visuel proposent des icônes de mise en forme, les titres H1–H5 et des listes. Placez le curseur puis choisissez un modèle, un composant, une image ou une icône. Les formulaires et les options des composants sont disponibles. Activez Font Awesome pour insérer ses icônes.',
    'de' => 'Im HTML- und visuellen Editor finden Sie Symbole für Formatierung, H1–H5 und Listen. Setzen Sie den Cursor und wählen Sie Vorlage, Komponente, Bild oder Symbol. Formulare und Komponentenoptionen stehen zur Auswahl. Font Awesome ist bei aktivierter Bibliothek verfügbar.',
    'es' => 'Los editores HTML y visual tienen iconos de formato, títulos H1–H5 y listas. Sitúa el cursor y elige plantilla, componente, imagen o icono. Puedes seleccionar formularios y parámetros de componentes. Font Awesome está disponible con la biblioteca activada.',
    'pt' => 'Os editores HTML e visual têm ícones para formatação, títulos H1–H5 e listas. Coloque o cursor e selecione um modelo, componente, imagem ou ícone. Pode escolher formulários e opções dos componentes. Font Awesome fica disponível com a biblioteca ativa.',
    'ko' => 'HTML 편집기와 시각적 편집기의 아이콘으로 글자 서식, H1–H5 제목 및 목록을 설정할 수 있습니다. 커서를 놓고 서식, 컴포넌트, 이미지 또는 아이콘을 선택하세요. 저장된 양식과 컴포넌트 옵션을 이용할 수 있습니다. Font Awesome은 라이브러리를 활성화하면 사용할 수 있습니다.',
];
