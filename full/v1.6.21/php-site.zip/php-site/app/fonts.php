<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

const SITE_FONTS_FILE = SITE_ROOT . '/admin/.fonts.php';
const SITE_FONT_ROLES = ['body', 'headings', 'interface'];

function site_appearance_labels(string $language): array
{
    $labels = require __DIR__ . '/help-fonts.php';
    return $labels[$language] ?? $labels['ru'];
}

function site_font_options(): array
{
    return site_google_fonts() + [
        'arial' => ['Arial', '', 'sans-serif'], 'arial-black' => ['Arial Black', '', 'sans-serif'],
        'comic-sans' => ['Comic Sans MS', '', 'cursive'], 'courier' => ['Courier New', '', 'monospace'],
        'georgia' => ['Georgia', '', 'serif'], 'geneva' => ['Geneva', '', 'sans-serif'],
        'tahoma' => ['Tahoma', '', 'sans-serif'], 'times' => ['Times New Roman', '', 'serif'],
        'verdana' => ['Verdana', '', 'sans-serif'],
    ];
}

function site_font_profile(array $stored): array
{
    $catalog = site_font_options();
    $enabled = [];
    foreach (is_array($stored['enabled'] ?? null) ? $stored['enabled'] : [] as $id) {
        if (is_string($id) && isset($catalog[$id])) $enabled[$id] = true;
    }
    $roles = [];
    foreach (SITE_FONT_ROLES as $role) {
        $id = $stored['roles'][$role] ?? '';
        $roles[$role] = is_string($id) && isset($catalog[$id], $enabled[$id]) ? $id : '';
    }
    return ['enabled' => array_keys($enabled), 'roles' => $roles];
}

function site_font_settings(): array
{
    try {
        $file = site_content_record(SITE_FONTS_FILE);
        if (!is_file($file) && $file === SITE_FONTS_FILE) {
            $legacy = site_library_settings(site_read_record(SITE_LIBRARIES_FILE))['font'];
            return site_font_profile(['enabled' => [$legacy], 'roles' => ['body' => $legacy]]);
        }
        return site_font_profile(site_read_record($file));
    } catch (RuntimeException $exception) {
        return site_font_profile([]);
    }
}

function site_font_family(array $font): string
{
    return '"' . ($font[3] ?? $font[0]) . '", ' . $font[2];
}

function site_google_font_query(array $font, bool $preview = false): string
{
    $request = $font[4] ?? (!$preview && $font[1] !== '' ? 'wght@' . $font[1] : '');
    return 'family=' . urlencode($font[3] ?? $font[0]) . ($request !== '' ? ':' . $request : '');
}

function site_local_font(string $base, string $id): string
{
    if (!isset(site_google_fonts()[$id])) return '';
    $relative = 'templates/fonts/local/' . $id . '.css';
    $file = SITE_ROOT . '/' . $relative;
    if (!is_file($file) || realpath($file) !== str_replace('/', DIRECTORY_SEPARATOR, $file)) return '';
    return site_url($base, $relative) . '?v=' . substr((string) hash_file('sha256', $file), 0, 12);
}

function site_font_url(string $base, string $id): string
{
    $google = site_google_fonts();
    return isset($google[$id]) ? (site_local_font($base, $id) ?: 'https://fonts.googleapis.com/css2?' . site_google_font_query($google[$id]) . '&display=swap') : '';
}

function site_font_assets(string $base): string
{
    $settings = site_font_settings();
    $options = site_font_options();
    $markup = '';
    foreach ($settings['enabled'] as $id) {
        $url = site_font_url($base, $id);
        if ($url !== '') $markup .= '<link rel="stylesheet" href="' . site_escape($url) . '">' . "\n";
    }
    $css = '';
    foreach (['body' => '--site-font', 'headings' => '--site-font-heading', 'interface' => '--site-font-ui'] as $role => $property) {
        $id = $settings['roles'][$role];
        if ($id !== '') $css .= $property . ':' . site_font_family($options[$id]) . ';';
    }
    return $markup . ($css === '' ? '' : '<style>:root{' . $css . '}</style>' . "\n");
}
