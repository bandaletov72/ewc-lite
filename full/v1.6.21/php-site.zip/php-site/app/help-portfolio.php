<?php
return [
    'ru' => ['Портфолио', 'Все проекты', 'Раздел портфолио', 'Открыть фотографии', 'Подробнее о проекте', 'Предыдущее фото', 'Следующее фото', 'Закрыть', 'Создать страницу'],
    'en' => ['Portfolio', 'All projects', 'Portfolio category', 'Open photos', 'Project details', 'Previous photo', 'Next photo', 'Close', 'Create page'],
    'uk' => ['Портфоліо', 'Усі проєкти', 'Розділ портфоліо', 'Відкрити фото', 'Детальніше про проєкт', 'Попереднє фото', 'Наступне фото', 'Закрити', 'Створити сторінку'],
    'de' => ['Portfolio', 'Alle Projekte', 'Portfoliokategorie', 'Fotos öffnen', 'Projektdetails', 'Vorheriges Foto', 'Nächstes Foto', 'Schließen', 'Seite erstellen'],
    'fr' => ['Portfolio', 'Tous les projets', 'Catégorie du portfolio', 'Ouvrir les photos', 'Détails du projet', 'Photo précédente', 'Photo suivante', 'Fermer', 'Créer une page'],
    'es' => ['Portafolio', 'Todos los proyectos', 'Categoría del portafolio', 'Abrir fotos', 'Detalles del proyecto', 'Foto anterior', 'Foto siguiente', 'Cerrar', 'Crear página'],
    'pt' => ['Portfólio', 'Todos os projetos', 'Categoria do portfólio', 'Abrir fotos', 'Detalhes do projeto', 'Foto anterior', 'Próxima foto', 'Fechar', 'Criar página'],
    'ja' => ['ポートフォリオ', 'すべてのプロジェクト', 'ポートフォリオの分類', '写真を開く', 'プロジェクトの詳細', '前の写真', '次の写真', '閉じる', 'ページを作成'],
    'ko' => ['포트폴리오', '모든 프로젝트', '포트폴리오 분류', '사진 열기', '프로젝트 상세 정보', '이전 사진', '다음 사진', '닫기', '페이지 만들기'],
    'vi' => ['Danh mục dự án', 'Tất cả dự án', 'Nhóm dự án', 'Mở ảnh', 'Chi tiết dự án', 'Ảnh trước', 'Ảnh tiếp theo', 'Đóng', 'Tạo trang'],
    'zh' => ['作品集', '所有项目', '作品分类', '打开照片', '项目详情', '上一张照片', '下一张照片', '关闭', '创建页面'],
];
