<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'ru' => ['Совместимость PHP и навигация', 'Минимальная версия PHP — 7.2. Сайт и админка поддерживают PHP 8.6. Для своих PHP-модулей и шаблонов используйте синтаксис версии, установленной на сервере.',
        'Текущий пункт [bread-crumbs] раскрывает другие опубликованные разделы того же уровня, если они включены в основное меню. URL из настроек страницы используется в меню, списках разделов, хлебных крошках, результатах и подсказках поиска.',
        'Корзина удаляет строку из редактора инфоблока. Удаление столбца убирает все значения этого столбца. Правки записываются при сохранении инфоблока, в том числе при автосохранении после перетаскивания.'],
    'en' => ['PHP compatibility and navigation', 'The minimum PHP version is 7.2. The site and admin area support PHP 8.6. Use the PHP syntax available on your server when writing custom modules and templates.',
        'The current [bread-crumbs] item opens a list of published sections at the same level that appear in the main menu. The page’s configured URL is used in menus, section lists, breadcrumbs, search results and suggestions.',
        'The trash icon removes a row from the infoblock editor. Removing a column removes all its values. Changes are written when the infoblock is saved, including autosave after reordering.'],
    'uk' => ['Сумісність PHP і навігація', 'Мінімальна версія PHP — 7.2. Сайт і панель адміністратора підтримують PHP 8.6. Для власних модулів і шаблонів використовуйте синтаксис версії, встановленої на сервері.',
        'Поточний пункт [bread-crumbs] розкриває опубліковані розділи того самого рівня, які є в головному меню. URL із налаштувань сторінки використовується в меню, списках розділів, навігаційному ланцюжку, результатах і підказках пошуку.',
        'Кошик видаляє рядок у редакторі інфоблоку. Видалення стовпця прибирає всі його значення. Зміни записуються при збереженні, зокрема й при автозбереженні після перетягування.'],
    'de' => ['PHP-Kompatibilität und Navigation', 'Die Mindestversion ist PHP 7.2. Website und Administration unterstützen PHP 8.6. Verwenden Sie in eigenen Modulen und Vorlagen die Syntax der PHP-Version Ihres Servers.',
        'Der aktuelle Eintrag in [bread-crumbs] zeigt veröffentlichte Bereiche derselben Ebene aus dem Hauptmenü. Die eingestellte Seiten-URL gilt für Menüs, Bereichslisten, Brotkrümelnavigation, Suchergebnisse und Vorschläge.',
        'Der Papierkorb entfernt eine Zeile aus dem Infoblock-Editor. Beim Entfernen einer Spalte gehen alle ihre Werte verloren. Änderungen werden beim Speichern übernommen, auch automatisch nach dem Umsortieren.'],
    'fr' => ['Compatibilité PHP et navigation', 'La version minimale de PHP est 7.2. Le site et l’administration prennent en charge PHP 8.6. Pour les modules et modèles personnalisés, utilisez la syntaxe de la version installée sur le serveur.',
        'L’élément courant de [bread-crumbs] affiche les sections publiées du même niveau qui figurent dans le menu principal. L’URL configurée est utilisée dans les menus, listes de sections, fils d’Ariane, résultats et suggestions de recherche.',
        'La corbeille retire une ligne de l’éditeur d’infobloc. Supprimer une colonne retire toutes ses valeurs. Les changements sont enregistrés à la sauvegarde, y compris automatiquement après un réagencement.'],
    'es' => ['Compatibilidad con PHP y navegación', 'La versión mínima de PHP es 7.2. El sitio y su administración admiten PHP 8.6. Usa la sintaxis de la versión instalada en el servidor para tus módulos y plantillas.',
        'El elemento actual de [bread-crumbs] despliega las secciones publicadas del mismo nivel que aparecen en el menú principal. La URL configurada se usa en menús, listas de secciones, rutas de navegación, resultados y sugerencias de búsqueda.',
        'La papelera elimina una fila del editor del bloque de información. Eliminar una columna quita todos sus valores. Los cambios se escriben al guardar, incluso con el guardado automático al reordenar.'],
    'pt' => ['Compatibilidade com PHP e navegação', 'A versão mínima do PHP é 7.2. O site e a administração suportam PHP 8.6. Use nos seus módulos e modelos a sintaxe da versão instalada no servidor.',
        'O item atual de [bread-crumbs] abre as seções publicadas do mesmo nível que aparecem no menu principal. A URL configurada é usada em menus, listas de seções, trilhas de navegação, resultados e sugestões de pesquisa.',
        'A lixeira remove uma linha do editor de infoblocos. Remover uma coluna apaga todos os seus valores. As alterações são gravadas ao salvar, inclusive automaticamente após a reordenação.'],
    'ja' => ['PHP の互換性とナビゲーション', 'PHP の最低バージョンは 7.2 です。サイトと管理画面は PHP 8.6 に対応しています。独自のモジュールやテンプレートでは、サーバーの PHP バージョンに対応する構文を使用してください。',
        '[bread-crumbs] の現在の項目を展開すると、メインメニューにある同じ階層の公開セクションが表示されます。設定した URL はメニュー、セクション一覧、パンくずリスト、検索結果と候補に使われます。',
        'ごみ箱でインフォブロックの編集画面から行を削除できます。列を削除すると、その列の値もすべて消えます。変更は保存時に記録され、並べ替え後の自動保存も含まれます。'],
    'ko' => ['PHP 호환성과 탐색', '최소 버전은 PHP 7.2입니다. 사이트와 관리자 화면은 PHP 8.6을 지원합니다. 사용자 정의 모듈과 템플릿은 서버에 설치된 버전의 문법을 사용하세요.',
        '[bread-crumbs]의 현재 항목을 펼치면 주 메뉴에 있는 같은 수준의 공개 섹션을 볼 수 있습니다. 설정한 URL은 메뉴, 섹션 목록, 탐색 경로, 검색 결과와 제안에 사용됩니다.',
        '휴지통은 인포블록 편집기에서 행을 제거합니다. 열을 제거하면 해당 열의 값도 모두 사라집니다. 변경 사항은 저장할 때 기록되며 순서 변경 뒤의 자동 저장도 포함됩니다.'],
    'vi' => ['Tương thích PHP và điều hướng', 'Phiên bản PHP tối thiểu là 7.2. Trang web và khu vực quản trị hỗ trợ PHP 8.6. Hãy dùng cú pháp của phiên bản trên máy chủ cho mô-đun và mẫu riêng.',
        'Mục hiện tại của [bread-crumbs] mở danh sách các mục cùng cấp đã xuất bản và có trong menu chính. URL đã cấu hình được dùng trong menu, danh sách mục, đường dẫn điều hướng, kết quả và gợi ý tìm kiếm.',
        'Biểu tượng thùng rác xóa một hàng trong trình sửa khối dữ liệu. Xóa một cột sẽ bỏ toàn bộ giá trị của cột đó. Các thay đổi được ghi khi lưu, kể cả khi tự động lưu sau khi sắp xếp lại.'],
];
