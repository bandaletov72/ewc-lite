<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return <<<'JS'
const adminLanguages = document.querySelector('.admin-language-picker');
if (adminLanguages) {
    document.addEventListener('click', (event) => {
        if (adminLanguages.open && !adminLanguages.contains(event.target)) adminLanguages.open = false;
    });
    adminLanguages.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape' || !adminLanguages.open) return;
        event.preventDefault();
        adminLanguages.open = false;
        adminLanguages.querySelector('summary').focus();
    });
}

document.querySelectorAll('[data-site-search], [data-admin-search]').forEach((form) => {
    const input = form.querySelector('input[type="search"]');
    const list = form.querySelector('.site-search-suggestions');
    const compact = form.closest('.site-search-compact');
    let delay;
    let request;
    const close = () => {
        clearTimeout(delay);
        if (request) request.abort();
        list.hidden = true;
        list.replaceChildren();
    };
    if (compact) {
        const menuLinks = compact.closest('.public-main-menu')?.querySelector(':scope > ul');
        const fitInMenu = () => {
            if (!menuLinks || !compact.open) return;
            const freeSpace = compact.getBoundingClientRect().left - menuLinks.getBoundingClientRect().right - 15;
            const below = freeSpace < 128;
            compact.classList.toggle('search-below-row', below);
            if (below) compact.style.removeProperty('--search-row-space');
            else compact.style.setProperty('--search-row-space', freeSpace + 'px');
        };
        document.addEventListener('click', (event) => {
            if (compact.open && !compact.contains(event.target)) compact.open = false;
        });
        compact.addEventListener('toggle', () => {
            if (compact.open) {
                fitInMenu();
                input.focus({preventScroll: true});
            }
            else close();
        });
        if (menuLinks) window.addEventListener('resize', fitInMenu, { passive: true });
        compact.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && !event.defaultPrevented && compact.open) {
                event.preventDefault();
                compact.open = false;
                compact.querySelector('summary').focus();
            }
        });
    }
    input.addEventListener('input', () => {
        close();
        const query = input.value.trim();
        if (query.length < 2 && !/[\u3000-\uD7AF]/.test(query)) return;
        delay = setTimeout(async () => {
            request = new AbortController();
            const url = new URL(form.action);
            for (const [name, value] of new FormData(form)) {
                url.searchParams.set(name, name === input.name ? query : value);
            }
            url.searchParams.set('suggest', '1');
            try {
                const response = await fetch(url, {signal: request.signal, headers: {Accept: 'application/json'}});
                if (!response.ok) return;
                const payload = await response.json();
                const items = Array.isArray(payload) ? payload : payload.suggestions;
                if (!Array.isArray(items)) return;
                if (input.value.trim() !== query) return;
                items.forEach((item) => {
                    const link = document.createElement('a');
                    link.textContent = item.title;
                    link.href = item.url;
                    const entry = document.createElement('li');
                    entry.appendChild(link);
                    list.appendChild(entry);
                });
                list.hidden = !list.childElementCount;
            } catch (error) {
                // The full search form remains available.
            }
        }, 180);
    });
    form.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !list.hidden) {
            event.preventDefault();
            close();
            input.focus();
        } else if (event.key === 'ArrowDown' && event.target === input && !list.hidden) {
            event.preventDefault();
            list.querySelector('a').focus();
        }
    });
    form.addEventListener('focusout', (event) => {
        if (!form.contains(event.relatedTarget)) close();
    });
});
JS;
