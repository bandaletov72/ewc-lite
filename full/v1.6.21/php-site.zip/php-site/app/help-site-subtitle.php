<?php
if (!defined('SITE_ROOT')) exit;

return [
    'ru' => ['Подзаголовок сайта', 'В основных настройках задайте подзаголовок. Он отображается мелким текстом под названием в шапке. На телефоне название выводится меньшим шрифтом.'],
    'en' => ['Site subtitle', 'Set the subtitle in General settings. It appears in smaller text below the site name in the header. The site name is smaller on phones.'],
    'uk' => ['Підзаголовок сайту', 'Задайте підзаголовок в основних налаштуваннях. Він відображається дрібнішим текстом під назвою в шапці. На телефоні назва менша.'],
    'ja' => ['サイトのサブタイトル', '基本設定のサブタイトルは、ヘッダーのサイト名の下に小さく表示されます。スマートフォンではサイト名も小さく表示されます。'],
    'vi' => ['Phụ đề trang web', 'Đặt phụ đề trong cài đặt chung. Phụ đề hiển thị nhỏ bên dưới tên trang trong phần đầu. Tên trang nhỏ hơn trên điện thoại.'],
    'fr' => ['Sous-titre du site', 'Dans les réglages généraux, renseignez le sous-titre. Il apparaît sous le nom dans l’en-tête. Sur téléphone, le nom est affiché en plus petit.'],
    'de' => ['Untertitel der Website', 'Der Untertitel aus den allgemeinen Einstellungen steht in kleiner Schrift unter dem Namen im Kopfbereich. Auf Handys ist der Name ebenfalls kleiner.'],
    'es' => ['Subtítulo del sitio', 'El subtítulo de los ajustes generales se muestra debajo del nombre en el encabezado. En móviles, el nombre también usa un tamaño menor.'],
    'pt' => ['Subtítulo do site', 'O subtítulo das configurações gerais aparece em tamanho menor abaixo do nome no cabeçalho. No celular, o nome também é menor.'],
    'ko' => ['사이트 부제목', '기본 설정의 부제목은 헤더의 사이트 이름 아래에 작게 표시됩니다. 휴대폰에서는 사이트 이름도 작게 표시됩니다.'],
    'zh' => ['网站副标题', '在常规设置中填写的副标题以小字号显示在页眉的网站名称下方。手机端的网站名称也采用较小字号。'],
];
