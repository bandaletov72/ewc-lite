<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_inline_data_target(array $item, string $base, string $host, array $settings): array
{
    $type = $item['kind'];
    $args = $item['arguments'];
    $query = [];
    $anchor = '';
    if ($type === 'iblock' && ($id = site_iblock_id_from_argument($args['iblock'])) !== '') {
        $query = ['iblocks' => '1', 'id' => $id];
    } elseif (in_array($type, ['gal', 'fotos', 'files'], true)) {
        $folder = trim($args[$type === 'files' ? 'files' : 'gallery']);
        if (site_asset_path($folder, $type === 'files' ? 'files' : 'images') !== '') {
            $query = ['media' => $type, 'folder' => $folder];
        }
    } elseif ($type === 'form' && site_valid_form_id(strtolower($args['form']))) {
        $query = ['forms' => '1', 'id' => strtolower($args['form'])];
    } elseif ($type === 'phpModule' && site_valid_snippet(strtolower($args['phpModule']))) {
        $name = strtolower($args['phpModule']);
        if (isset(site_extensions()[$name])) $query = ['modules' => '1', 'module' => $name];
    } elseif ($type === 'callback') {
        $query = ['callbacks' => '1'];
    } elseif ($type === 'map' || $type === 'maps') {
        $options = site_shortcode_options($args['mapOptions'] ?? '');
        if ($type === 'maps' && site_valid_iblock_name($options['source'] ?? '')) {
            $query = ['iblocks' => '1', 'id' => $options['source']];
        } else {
            $query = ['integrations' => '1'];
            $anchor = '#maps';
        }
    } elseif ($type === 'snippet') {
        $name = strtolower($args['snippet']);
        if (isset(site_contact_tokens()[$name])) {
            $query = ['contacts' => '1'];
        } elseif (site_valid_snippet($name) && !isset(site_layout_blocks()[$name])) {
            try {
                $own = $host !== '' && isset(site_read_snippets($host)[$name]);
                if ($own || isset(site_read_snippets()[$name])) {
                    $query = ['snippets' => '1', 'snippet' => $name] + ($own ? ['domain' => $host] : ['scope' => 'shared']);
                } elseif (isset($settings['variables'][$name])) {
                    $query = ['settings' => '1'];
                    $anchor = '#variables';
                }
            } catch (RuntimeException $exception) {
                return [];
            }
        }
    }
    if (!$query) {
        return [];
    }
    $url = site_url($base, 'admin/') . '?' . http_build_query($query);
    return ['modal' => $url . '&embed=1' . $anchor, 'wide' => $url . '&wide=1' . $anchor];
}

function site_data_editor_labels(string $locale): array
{
    $options = [
        'ru' => ['Данные', 'На весь экран'], 'en' => ['Data', 'Full screen'], 'uk' => ['Дані', 'На весь екран'],
        'ja' => ['データ', '全画面'], 'vi' => ['Dữ liệu', 'Toàn màn hình'], 'fr' => ['Données', 'Plein écran'],
        'de' => ['Daten', 'Vollbild'], 'es' => ['Datos', 'Pantalla completa'], 'pt' => ['Dados', 'Ecrã inteiro'], 'ko' => ['데이터', '전체 화면'],
        'zh' => ['数据', '全屏'],
    ];
    return $options[$locale] ?? $options['ru'];
}

function site_file_manager_labels(string $locale): array
{
    $labels = [
        'zh' => ['文件管理器', '上一级', '新文件夹名称', '创建文件夹', '请使用 A–Z、a–z、0–9、连字符及下划线。'],
        'ru' => ['Файловый менеджер', 'На уровень выше', 'Имя новой папки', 'Создать папку', 'Используйте A–Z, a–z, 0–9, дефис и подчёркивание.'],
        'en' => ['File manager', 'Parent folder', 'New folder name', 'Create folder', 'Use A–Z, a–z, 0–9, hyphens and underscores.'],
        'uk' => ['Менеджер файлів', 'На рівень вище', 'Назва нової папки', 'Створити папку', 'Використовуйте A–Z, a–z, 0–9, дефіс і підкреслення.'],
        'ja' => ['ファイルマネージャー', '親フォルダー', '新しいフォルダー名', 'フォルダーを作成', 'A–Z、a–z、0–9、ハイフン、アンダースコアを使用してください。'],
        'vi' => ['Trình quản lý tệp', 'Thư mục cha', 'Tên thư mục mới', 'Tạo thư mục', 'Dùng A–Z, a–z, 0–9, dấu gạch nối và gạch dưới.'],
        'fr' => ['Gestionnaire de fichiers', 'Dossier parent', 'Nom du nouveau dossier', 'Créer le dossier', 'Utilisez A–Z, a–z, 0–9, le tiret et le trait de soulignement.'],
        'de' => ['Dateimanager', 'Übergeordneter Ordner', 'Name des neuen Ordners', 'Ordner erstellen', 'Verwenden Sie A–Z, a–z, 0–9, Bindestriche und Unterstriche.'],
        'es' => ['Gestor de archivos', 'Carpeta superior', 'Nombre de la carpeta nueva', 'Crear carpeta', 'Usa A–Z, a–z, 0–9, guiones y guiones bajos.'],
        'pt' => ['Gerenciador de arquivos', 'Pasta superior', 'Nome da nova pasta', 'Criar pasta', 'Use A–Z, a–z, 0–9, hífens e sublinhados.'],
        'ko' => ['파일 관리자', '상위 폴더', '새 폴더 이름', '폴더 만들기', 'A–Z, a–z, 0–9, 하이픈, 밑줄을 사용하세요.'],
    ];
    return $labels[$locale] ?? $labels['ru'];
}

function site_media_folder_labels(string $locale): array
{
    static $labels;
    if ($labels === null) $labels = require __DIR__ . '/help-media-folders.php';
    return $labels[$locale] ?? $labels['ru'];
}
