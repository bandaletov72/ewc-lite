<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$help = [
    'zh' => ['在地图上选点', '在 Yandex Maps 控制台为 JavaScript API 产品创建密钥，并通过 HTTP Referer 限制访问域名。在页面的地图标签中选择地点并应用坐标。'],
    'ru' => ['Выбор точки на карте', 'В кабинете Яндекс Карт создайте ключ для продукта «JavaScript API» в разделе «Карты». Ограничьте ключ доменом по HTTP Referer. При включённом провайдере на вкладке «Карты» страницы нажмите «Выбрать на карте», поставьте точку и перенесите её координаты в поля.'],
    'en' => ['Pick a point on a map', 'In the Yandex Maps console create a key for the «JavaScript API» product and restrict it by HTTP Referer. With a provider enabled, open the page’s Maps tab, choose a point and apply its coordinates.'],
    'uk' => ['Вибір точки на карті', 'У кабінеті Яндекс Карт створіть ключ продукту «JavaScript API» та обмежте його доменом через HTTP Referer. У вкладці «Карти» сторінки виберіть точку й застосуйте координати.'],
    'de' => ['Punkt auf der Karte wählen', 'Erstellen Sie in der Yandex-Konsole einen Schlüssel für „JavaScript API“ und begrenzen Sie ihn per HTTP-Referrer. Wählen Sie in der Karten-Registerkarte der Seite einen Punkt und übernehmen Sie seine Koordinaten.'],
    'fr' => ['Choisir un point sur la carte', 'Dans la console Yandex Maps, créez une clé pour « JavaScript API » et limitez-la par référent HTTP. Dans l’onglet Cartes de la page, choisissez un point puis appliquez ses coordonnées.'],
    'es' => ['Elegir un punto en el mapa', 'Crea una clave para «JavaScript API» en la consola de Yandex Maps y restríngela por referente HTTP. En la pestaña Mapas de la página, elige un punto y aplica sus coordenadas.'],
    'pt' => ['Escolher um ponto no mapa', 'Crie uma chave para «JavaScript API» no console do Yandex Maps e restrinja-a por referência HTTP. Na aba Mapas da página, escolha um ponto e aplique as coordenadas.'],
    'ja' => ['地図で地点を選択する', 'Yandex Maps のコンソールで「JavaScript API」のキーを作成し、HTTP Referer で制限してください。ページの「地図」タブで地点を選択し、座標を適用します。'],
    'ko' => ['지도에서 지점 선택', 'Yandex Maps 콘솔에서 «JavaScript API» 키를 만들고 HTTP Referer로 제한하세요. 페이지의 지도 탭에서 지점을 선택한 뒤 좌표를 적용하세요.'],
    'vi' => ['Chọn một điểm trên bản đồ', 'Tạo khóa «JavaScript API» trong bảng điều khiển Yandex Maps và giới hạn theo HTTP Referer. Trong thẻ Bản đồ của trang, hãy chọn điểm và áp dụng tọa độ.'],
];
$local = [
    'ru' => 'Для локального сайта укажите localhost в поле HTTP Referer без порта, дождитесь статуса «Активен» и откройте админку по адресу с localhost.',
    'en' => 'For local testing, enter localhost without a port in HTTP Referer, wait for the key to be active and open the admin panel using localhost.',
    'uk' => 'Для локального сайту вкажіть localhost без порту в полі HTTP Referer, дочекайтеся активації та відкрийте адмінку через localhost.',
    'de' => 'Tragen Sie für lokale Tests localhost ohne Port als HTTP-Referrer ein und öffnen Sie die Verwaltung nach Aktivierung über localhost.',
    'fr' => 'Pour un test local, saisissez localhost sans port comme référent HTTP, attendez l’activation puis ouvrez l’administration via localhost.',
    'es' => 'Para pruebas locales, configura localhost sin puerto como referente HTTP, espera la activación y abre la administración mediante localhost.',
    'pt' => 'Para testes locais, indique localhost sem porta como referência HTTP, aguarde a ativação e abra a administração usando localhost.',
    'ja' => 'ローカル検証では HTTP Referer にポート番号なしの localhost を指定し、有効化後に localhost で管理画面を開きます。',
    'ko' => '로컬 테스트에서는 HTTP Referer에 포트 없이 localhost를 입력하고 키가 활성화되면 localhost로 관리자 화면을 엽니다.',
    'vi' => 'Khi thử nghiệm cục bộ, nhập localhost không kèm cổng vào HTTP Referer, chờ khóa hoạt động rồi mở quản trị qua localhost.',
    'zh' => '本地测试时在 HTTP Referer 中填写不带端口的 localhost。密钥激活后，使用 localhost 打开后台。',
];
foreach ($local as $language => $note) $help[$language][1] .= ' ' . $note;
return $help;
