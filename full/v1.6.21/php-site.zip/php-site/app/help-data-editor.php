<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$help = [
    'ru' => ['Редактирование данных на странице', 'В режиме правки у инфоблока, формы [formX], подшаблона [tel] и других компонентов с отдельными данными есть действия «Данные» и «На весь экран». «Вид инфоблока» перечисляет зарегистрированные шаблоны вывода. В списке родительских разделов «Корневая папка» переносит раздел на верхний уровень.'],
    'en' => ['Editing component data in place', 'In edit mode, infoblocks, [formX] forms, [tel] snippets and other components with data editors offer Data and Full screen. The infoblock view dropdown lists registered display templates. Choose Root folder to move a section to the top level.'],
    'uk' => ['Редагування даних на сторінці', 'У режимі редагування інфоблоки, форми [formX], підшаблон [tel] та інші компоненти з редактором даних мають дії «Дані» й «На весь екран». Список виду інфоблоку містить зареєстровані шаблони. «Коренева папка» переносить розділ на верхній рівень.'],
    'ja' => ['ページ上でデータを編集', '編集モードでは情報ブロック、[formX]、[tel] などのデータをダイアログや全画面で編集できます。表示形式の一覧には登録済みのテンプレートが表示されます。ルートフォルダーを選ぶと、セクションが最上位に移動します。'],
    'vi' => ['Sửa dữ liệu ngay trên trang', 'Trong chế độ sửa, khối dữ liệu, biểu mẫu [formX], đoạn mã [tel] và các thành phần có trình sửa cho phép mở hộp thoại hoặc toàn màn hình. Danh sách kiểu hiển thị chứa các mẫu đã đăng ký. Chọn thư mục gốc để chuyển mục lên cấp cao nhất.'],
    'fr' => ['Modifier les données sur place', 'En mode édition, les blocs de données, les formulaires [formX], les fragments [tel] et les composants associés proposent les actions Données et Plein écran. La liste des vues affiche les modèles enregistrés. Choisissez Dossier racine pour déplacer une rubrique au premier niveau.'],
    'de' => ['Komponentendaten direkt bearbeiten', 'Im Bearbeitungsmodus bieten Infoblöcke, Formulare [formX], Textbausteine [tel] und andere Komponenten mit Dateneditor die Optionen Daten und Vollbild. Die Ansichtsliste enthält registrierte Vorlagen. Wählen Sie Stammordner für die oberste Ebene.'],
    'es' => ['Editar datos desde la página', 'En el modo de edición, los bloques, los formularios [formX], los fragmentos [tel] y otros componentes con editor ofrecen Datos y Pantalla completa. La lista de vistas contiene las plantillas registradas. Elige Carpeta raíz para mover una sección al nivel superior.'],
    'pt' => ['Editar dados na própria página', 'No modo de edição, os blocos, formulários [formX], fragmentos [tel] e outros componentes com editor oferecem Dados e Ecrã inteiro. A lista de vistas contém os modelos registados. Escolha Pasta raiz para mover a secção para o nível superior.'],
    'ko' => ['페이지에서 컴포넌트 데이터 편집', '편집 모드에서 정보 블록, [formX] 양식, [tel] 조각 등은 데이터와 전체 화면 메뉴를 제공합니다. 보기 유형 목록에는 등록된 서식이 표시됩니다. 루트 폴더는 섹션을 최상위로 옮깁니다.'],
];

$extras = [
    'ru' => 'Используйте [list-pages] для списка опубликованных страниц раздела и его подпапок. Меню языков в админке закрывается по клику вне списка или по Escape.',
    'en' => 'Use [list-pages] for published pages in the section and all subfolders. Close the admin language menu by clicking outside or pressing Escape.',
    'uk' => 'Використовуйте [list-pages] для списку опублікованих сторінок розділу та підпапок. Меню мов закривається клацанням поза списком або клавішею Escape.',
    'ja' => '[list-pages] はセクションと子フォルダーの公開ページを一覧にします。言語メニューは外側をクリックするか Escape で閉じます。',
    'vi' => 'Dùng [list-pages] để liệt kê các trang đã xuất bản trong mục và các thư mục con. Đóng menu ngôn ngữ bằng cách bấm bên ngoài hoặc nhấn Escape.',
    'fr' => 'Utilisez [list-pages] pour lister les pages publiées de la rubrique et de ses sous-dossiers. Cliquez à l’extérieur ou appuyez sur Échap pour fermer le menu des langues.',
    'de' => '[list-pages] listet veröffentlichte Seiten im Bereich und seinen Unterordnern. Schließen Sie das Sprachmenü durch einen Klick außerhalb oder mit Escape.',
    'es' => 'Usa [list-pages] para listar las páginas publicadas de la sección y sus subcarpetas. Cierra el menú de idioma haciendo clic fuera o pulsando Escape.',
    'pt' => 'Use [list-pages] para listar as páginas publicadas na secção e nas subpastas. Feche o menu de idiomas clicando fora ou premindo Escape.',
    'ko' => '[list-pages]는 섹션과 하위 폴더의 공개 페이지를 나열합니다. 언어 메뉴는 바깥을 클릭하거나 Escape 키를 누르면 닫힙니다.',
];
foreach ($extras as $language => $note) {
    $help[$language][1] .= ' ' . $note;
}
return $help;
