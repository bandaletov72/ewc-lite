<?php
if (!defined('SITE_ROOT')) exit;

$topics = [
    'ru' => ['Шапка и подвал админки', 'На компьютере рядом с логотипом указаны Eurowebcart CMS и Light с установленной версией. На телефоне знак расположен в одном ряду с кнопками. В подвале указан адрес репозитория, а в «Настройки → Обновления» доступна проверка нового кумулятивного выпуска.'],
    'en' => ['Admin header and footer', 'On desktop, the logo is paired with Eurowebcart CMS and Light, followed by the installed version. On phones, the symbol shares a row with the controls. The footer links to the repository. Check for the latest cumulative release in Settings → Updates.'],
    'uk' => ['Шапка й підвал адмінки', 'На комп’ютері біля логотипа є назва Eurowebcart CMS і Light з установленою версією. На телефоні знак стоїть в одному ряду з кнопками. У підвалі є адреса репозиторію. Кумулятивне оновлення можна перевірити в налаштуваннях.'],
    'ja' => ['管理画面のヘッダーとフッター', 'デスクトップではロゴの横に Eurowebcart CMS と Light、およびインストール済みのバージョンが表示されます。スマートフォンではロゴが操作ボタンと同じ行に並びます。フッターにリポジトリへのリンクがあり、設定の更新画面で累積版を確認できます。'],
    'vi' => ['Đầu trang và chân trang quản trị', 'Trên máy tính, bên cạnh logo có Eurowebcart CMS và Light kèm phiên bản đã cài. Trên điện thoại, biểu tượng nằm cùng hàng với các nút. Chân trang liên kết đến kho mã. Kiểm tra bản cập nhật tích lũy trong phần Cài đặt.'],
    'fr' => ['En-tête et pied de page de l’administration', 'Sur ordinateur, Eurowebcart CMS et Light accompagnent le logo avec la version installée. Sur téléphone, le symbole s’aligne avec les boutons. Le pied de page affiche l’adresse du dépôt. Les paramètres permettent de vérifier la mise à jour cumulative.'],
    'de' => ['Kopf- und Fußzeile der Verwaltung', 'Auf dem Desktop stehen Eurowebcart CMS und Light mit der installierten Version neben dem Logo. Auf dem Handy stehen Logo und Schaltflächen in einer Zeile. Die Fußzeile verlinkt das Repository. Kumulative Updates lassen sich in den Einstellungen prüfen.'],
    'es' => ['Encabezado y pie de la administración', 'En escritorio, el logotipo aparece junto a Eurowebcart CMS y Light con la versión instalada. En teléfonos, el símbolo comparte fila con los botones. El pie enlaza al repositorio. En Ajustes se puede comprobar la actualización acumulativa.'],
    'pt' => ['Cabeçalho e rodapé da administração', 'No computador, Eurowebcart CMS e Light com a versão instalada aparecem junto do logotipo. No celular, o símbolo fica na mesma linha que os botões. O rodapé contém o endereço do repositório. Verifique atualizações cumulativas nas configurações.'],
    'ko' => ['관리자 머리글 및 바닥글', '데스크톱에서는 로고 옆에 Eurowebcart CMS와 Light, 설치 버전이 표시됩니다. 휴대폰에서는 로고와 버튼이 같은 줄에 있습니다. 바닥글에 저장소 주소가 있으며 설정에서 누적 업데이트를 확인할 수 있습니다.'],
    'zh' => ['后台页眉和页脚', '桌面端的标志旁显示 Eurowebcart CMS、Light 和已安装的版本。手机端的标志与操作按钮排在同一行。页脚显示仓库地址，可在“设置 → 更新”中检查累积版本。'],
];
$labels = [
    'ru' => 'В списке страниц стандартная «Главная» отображается на выбранном языке админки. В подвале логотип подписан двумя строками: Eurowebcart CMS и LIGHT.',
    'en' => 'The standard Home label in the page list follows the admin language. The footer logo has two lines: Eurowebcart CMS and LIGHT.',
    'uk' => 'Стандартна «Головна» у списку сторінок відповідає мові адмінки. Підпис логотипа в підвалі має два рядки: Eurowebcart CMS і LIGHT.',
    'ja' => 'ページ一覧の標準ホーム名は管理画面の言語で表示されます。フッターロゴの文字は Eurowebcart CMS と LIGHT の二段です。',
    'vi' => 'Tên Trang chủ mặc định trong danh sách trang theo ngôn ngữ quản trị. Logo chân trang có hai dòng: Eurowebcart CMS và LIGHT.',
    'fr' => 'Le libellé Accueil dans la liste suit la langue de l’administration. Le logo du pied de page affiche Eurowebcart CMS et LIGHT sur deux lignes.',
    'de' => 'Die Standardbezeichnung Startseite in der Seitenliste folgt der Verwaltungssprache. Im Fußzeilenlogo stehen Eurowebcart CMS und LIGHT auf zwei Zeilen.',
    'es' => 'La etiqueta predeterminada Inicio de la lista sigue el idioma de administración. El logotipo del pie muestra Eurowebcart CMS y LIGHT en dos líneas.',
    'pt' => 'O nome padrão Página inicial na lista segue o idioma da administração. O logotipo do rodapé mostra Eurowebcart CMS e LIGHT em duas linhas.',
    'ko' => '페이지 목록의 기본 홈 이름은 관리자 언어로 표시됩니다. 바닥글 로고에는 Eurowebcart CMS와 LIGHT가 두 줄로 표시됩니다.',
    'zh' => '页面列表中的默认首页名称随后台语言显示。页脚标识分两行显示 Eurowebcart CMS 和 LIGHT。',
];
foreach ($labels as $language => $description) {
    $topics[$language][1] .= ' ' . $description;
}
return $topics;
