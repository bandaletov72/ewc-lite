<?php
define('SITE_ROOT', dirname(__DIR__));

$asset = $_GET['asset'] ?? '';
$images = require SITE_ROOT . '/app/kontur-brand.php';
if (!is_string($asset) || !isset($images[$asset]) || !empty($_SERVER['PATH_INFO'])) {
    http_response_code(404);
    exit;
}
header('Content-Type: image/png');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=86400');
echo base64_decode($images[$asset], true);
