<?php
define('SITE_ROOT', dirname(__DIR__));

if (!empty($_SERVER['PATH_INFO'])) {
    http_response_code(404);
    exit;
}
header('Content-Type: application/javascript; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=86400');
$bundle = ($_GET['v'] ?? '') === '5.65.20' ? 'code-editor-baseline.php' : 'code-editor-data.php';
echo base64_decode(require SITE_ROOT . '/app/' . $bundle, true), "\n;\n";
echo require SITE_ROOT . '/app/code-editor-client.php';
