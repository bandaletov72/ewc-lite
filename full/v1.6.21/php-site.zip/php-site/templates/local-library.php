<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/libraries.php';

$pack = $_GET['pack'] ?? '';
$name = $_GET['file'] ?? '';
$file = is_string($pack) && is_string($name) && $name !== 'manifest.json' ? site_local_library_file($pack, $name) : '';
if ($file === '' || !empty($_SERVER['PATH_INFO'])) { http_response_code(404); exit; }
header('Content-Type: ' . (substr($name, -4) === '.css' ? 'text/css' : 'text/javascript') . '; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=31536000, immutable');
readfile($file);
