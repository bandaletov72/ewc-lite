<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<p><?= site_escape(site_translation('Эта страница описывает обработку данных при использовании сайта.', $locale)) ?>
    <?= $snippets['site-name'] ?> · <?= $snippets['site-url'] ?>.</p>
<h2><?= site_escape(site_translation('Сообщения и заявки', $locale)) ?></h2>
<p><?= site_escape(site_translation('Когда вы отправляете форму, сайт сохраняет введённые данные для обработки вашего обращения. Для связи по поводу данных используйте контакты на сайте.', $locale)) ?></p>
<h2><?= site_escape(site_translation('Файлы cookie', $locale)) ?></h2>
<p><?= site_escape(site_translation('Служебные файлы cookie нужны для сеанса, защиты форм и хранения выбранных настроек. Согласие на встроенные карты и аналитику можно изменить в подвале.', $locale)) ?></p>
