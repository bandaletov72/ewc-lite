<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<div class="demo-theme-header">
    <?php require SITE_ROOT . '/templates/header.php'; ?>
</div>
