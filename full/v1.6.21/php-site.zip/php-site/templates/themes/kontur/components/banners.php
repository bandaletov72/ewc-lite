<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php if ($setId === 'kontur-hero'): ?><div class="kt-hero"><?php endif; ?>
<?php require SITE_ROOT . '/templates/components/banners.php'; ?>
<?php if ($setId === 'kontur-hero'): ?></div><?php endif; ?>
