<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

if ($id !== 'kontur-catalog') {
    require SITE_ROOT . '/templates/iblock/table.php';
    return;
}

$keys = array_column($block['columns'], 'key');
?>
<div class="kt-collection">
    <div class="kt-cards kt-catalog">
        <?php foreach ($block['rows'] as $row): ?>
            <?php
            if (count($row) !== count($keys)) continue;
            $record = array_combine($keys, $row);
            if (!$record || empty($record['title'])) continue;
            $image = $record['image'] ?? '';
            $imageUrl = preg_match('/\A[a-z0-9_-]+\.(?:webp|jpe?g|png)\z/i', $image) ? site_design_asset($base, 'images/projects/' . $image) : '';
            $category = $record['category'] ?? '';
            ?>
            <article class="kt-card" data-kt-category="<?= site_escape($category) ?>">
                <?php if ($imageUrl !== ''): ?>
                    <img src="<?= site_escape($imageUrl) ?>" alt="" loading="lazy" decoding="async" width="748" height="500">
                <?php endif; ?>
                <div class="kt-card-content">
                    <p class="kt-eyebrow"><?= site_escape($category) ?></p>
                    <h3><?= site_escape($record['title']) ?></h3>
                    <?php if (!empty($record['description'])): ?><p><?= site_escape($record['description']) ?></p><?php endif; ?>
                    <?php if (isset($record['price'])): ?>
                        <p class="kt-card-price"><?= site_escape(site_format_price($record['price'])) ?></p>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</div>
