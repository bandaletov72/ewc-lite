<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php $konturLogo = site_brand_logo_html($brand, $base); ?>
<div class="kt-header">
    <a class="kt-brand" href="<?= site_escape(site_url($base)) ?>">
        <?= $konturLogo !== '' ? $konturLogo : '<span class="kt-mark" aria-hidden="true"></span>' ?>
        <span><strong><?= site_escape($settings['name']) ?></strong><?php if ($settings['subtitle'] !== ''): ?><small><?= site_escape($settings['subtitle']) ?></small><?php endif; ?></span>
    </a>
    <div class="kt-desktop-nav"><?= site_layout_placeholder('main-menu') ?></div>
</div>
