<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php $konturLogo = site_brand_logo_html($brand, $base); ?>
<footer class="site-footer kt-footer">
    <div class="container">
        <div class="kt-footer-main">
            <a class="kt-brand" href="<?= site_escape(site_url($base)) ?>">
                <?= $konturLogo !== '' ? $konturLogo : '<span class="kt-mark" aria-hidden="true"></span>' ?>
                <span><strong><?= site_escape($settings['name']) ?></strong><?php if ($settings['subtitle'] !== ''): ?><small><?= site_escape($settings['subtitle']) ?></small><?php endif; ?></span>
            </a>
            <div class="kt-footer-contact"><?= site_expand_content('[phones][soc-icons]', $snippets, $context) ?></div>
        </div>
        <div class="kt-footer-bottom">
            <span><?= site_escape($settings['footer'] !== '' ? site_expand_text(str_replace('[author]', '', $settings['footer']), $snippets) : '© ' . ($snippets['year'] ?? date('Y')) . ' ' . $settings['name']) ?></span>
            <nav aria-label="<?= site_escape(site_translation('Подвал', $locale)) ?>"><?= site_layout_block('conf-policy', $context) ?> <?= site_layout_block('cookies', $context) ?> <?= site_layout_block('top', $context) ?></nav>
            <a class="kt-credit" href="<?= site_escape(SITE_PRODUCT_REPOSITORY) ?>" aria-label="<?= site_escape(SITE_PRODUCT_NAME . ' · GitHub') ?>"><?= site_product_logo(true) ?></a>
        </div>
    </div>
</footer>
