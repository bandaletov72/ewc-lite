<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Продажи
Heading: Продажи
Description: Консультации и проектные услуги архитектурного бюро КОНТУР.
Menu: Продажи
MenuVisible: 1
MobileMenu: 1
Order: 50
Sale: eyJlbmFibGVkIjpmYWxzZSwibm90aWNlcyI6Im9mZiIsIm9mZmVycyI6eyJkZWZhdWx0Ijp7ImFtb3VudCI6IjE4MDAwLjAwIiwiY3VycmVuY3kiOiJSVUIiLCJtZXRob2QiOiIiLCJ0YXJnZXQiOiIifX19

<p class="kt-lead">Планируете стройку или обновление интерьера? Начните с отдельной консультации, разбора планировки или подбора материалов.</p>
<section class="kt-section"><h2>Услуги по записи</h2>[iblock=table]/data/kontur-catalog.txt[/iblock]</section>
<section class="kt-section" id="order"><div class="kt-cta"><div><p class="kt-eyebrow">Онлайн или в студии · 60 минут</p><h2>Архитектурная консультация</h2><p>Стоимость встречи · <strong>[item-price]</strong></p></div><div class="kt-order-actions">[item-buy-button] <a class="kt-button" href="/contacts/#brief">Записаться на встречу</a></div></div></section>
