<?php http_response_code(404); exit; __halt_compiler();
{
    "phones": [
        {
            "number": "+7 (495) 000-00-01",
            "text": "+7 (495) 000-00-01"
        }
    ],
    "channels": {}
}
