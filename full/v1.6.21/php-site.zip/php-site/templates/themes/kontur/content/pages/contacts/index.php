<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Контакты
Heading: Контакты
Description: Связаться с КОНТУР и отправить бриф на архитектурный проект.
Menu: Контакты
MenuVisible: 1
MobileMenu: 1
Order: 60

<p class="kt-lead">Напишите, если у вас уже есть участок, план или первая идея. В поле сообщения можно указать площадь объекта и желаемые сроки.</p>
<section class="kt-section kt-contact-grid" id="brief">
    <div><p class="kt-eyebrow">Бюро КОНТУР</p><h2>Связаться с нами</h2><address><p>Москва · встречи по предварительной записи</p>[phones]</address><p>[soc-icons]</p><p>[callback=Заказать обратный звонок]</p></div>
    <div><h2>Бриф проекта</h2>[form84]</div>
</section>
<section class="kt-section kt-directions" id="directions"><h2>Карта проезда</h2><p class="kt-lead">Демонстрационные точки в Москве. Подписи и маршруты можно заменить в настройках сайта.</p>[maps source=kontur-map]</section>
