<?php http_response_code(404); exit; __halt_compiler();
{
    "form84": {
        "title": "Бриф КОНТУР",
        "button": "Отправить запрос",
        "recipient": "",
        "fields": [
            {
                "name": "name",
                "label": "Имя",
                "type": "text",
                "required": true,
                "options": [],
                "maxLength": 90
            },
            {
                "name": "email",
                "label": "Электронная почта",
                "type": "email",
                "required": true,
                "options": [],
                "maxLength": 254
            },
            {
                "name": "phone",
                "label": "Телефон",
                "type": "tel",
                "required": false,
                "options": [],
                "maxLength": 33
            },
            {
                "name": "topic",
                "label": "Что вас интересует",
                "type": "select",
                "required": true,
                "options": [
                    "Архитектура",
                    "Интерьер",
                    "Авторский надзор",
                    "Предметы и продажа"
                ]
            },
            {
                "name": "message",
                "label": "Расскажите о задаче",
                "type": "textarea",
                "required": true,
                "options": [],
                "maxLength": 2000
            }
        ]
    }
}
