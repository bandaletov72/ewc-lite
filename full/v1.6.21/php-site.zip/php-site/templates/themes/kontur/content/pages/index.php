<?php
define('SITE_ROOT', __DIR__);
require SITE_ROOT . '/app/site.php';
site_render(isset($pageFile) ? $pageFile : __FILE__);
__halt_compiler();
Title: Главная
Heading: Архитектура тишины
Description: КОНТУР — архитектурное бюро. Частные дома, интерьеры и авторское сопровождение.
Menu: Главная
MenuVisible: 1
MobileMenu: 1
Order: 10

[banners set=kontur-hero width=page fit=cover arrows=off numbers=off effect=slide]
<section class="kt-section kt-intro">
    <div><p class="kt-eyebrow">Бюро КОНТУР</p><h2>Пространства с характером</h2><p class="kt-lead">Работаем с архитектурой, интерьером и деталями как с единым целым. От первого эскиза до того, как ляжет свет на фактуру стены.</p><a class="kt-link" href="/about/">О компании</a></div>
    <img src="/templates/themes/kontur/images/projects/atelier.jpg" alt="Лестница из травертина в светлом интерьере" width="768" height="512" loading="lazy">
</section>
<section class="kt-section">
    <div class="kt-section-top"><div><p class="kt-eyebrow">Портфолио</p><h2>Избранные работы</h2></div><a href="/works/" class="kt-link">Смотреть портфолио</a></div>
    [iblock=portfolio limit=2]/data/kontur-works.txt[/iblock]
</section>
[kontur-brief]
