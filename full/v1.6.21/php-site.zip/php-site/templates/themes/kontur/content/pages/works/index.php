<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Наши работы
Heading: Наши работы
Description: Портфолио концепций архитектуры и интерьеров бюро КОНТУР.
Menu: Наши работы
MenuVisible: 1
MobileMenu: 1
Order: 30

<p class="kt-lead">Четыре концепции частных пространств. Нажмите на изображение, чтобы рассмотреть проект крупнее.</p>
<section class="kt-section"><h2 class="kt-sr-only">Портфолио</h2>[iblock=portfolio]/data/kontur-works.txt[/iblock]</section>
[kontur-brief]
