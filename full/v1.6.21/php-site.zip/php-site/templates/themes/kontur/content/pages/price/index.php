<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Прейскурант
Heading: Прейскурант
Description: Ориентиры по стоимости проектирования, интерьеров и авторского сопровождения.
Menu: Прейскурант
MenuVisible: 1
MobileMenu: 1
Order: 40

<p class="kt-lead">Стартовые цены на услуги. Итоговая смета зависит от площади, состава документации и графика работ.</p>
<section class="kt-section"><h2>Архитектура и интерьер</h2>[iblock=table]/data/kontur-price.txt[/iblock]</section>
<section class="kt-section kt-intro"><div><h2>Что влияет на смету</h2><p>На стоимость влияют состояние объекта, сложность конструкций и нужный объём выездов. Состав работ фиксируем до начала проектирования.</p></div><div class="kt-detail"><h3>Перед встречей</h3><p>Подготовьте план или адрес участка, примерную площадь и список задач. Этого достаточно для первого разговора.</p></div></section>
[kontur-brief]
