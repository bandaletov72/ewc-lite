<?php http_response_code(404); exit; __halt_compiler();
{
    "kontur-hero": {
        "folder": "",
        "order": [
            "s-hero"
        ],
        "slides": {
            "s-hero": {
                "title": "Архитектура тишины",
                "subtitle": "Проектируем дома и интерьеры, в которых хочется остаться.",
                "caption": "Архитектура и интерьеры",
                "image": "/templates/themes/kontur/images/hero.jpg",
                "color": "#24211d",
                "textColor": "#faf4ec",
                "align": "left",
                "button": "Смотреть работы",
                "action": "url",
                "buttonUrl": "/works/"
            }
        }
    }
}
