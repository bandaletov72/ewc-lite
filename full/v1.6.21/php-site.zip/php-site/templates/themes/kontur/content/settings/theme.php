<?php http_response_code(404); exit; __halt_compiler();
{
    "mode": "dark",
    "dark": {
        "paper": "#151515",
        "surface": "#1d1d1b",
        "ink": "#f4f1eb",
        "muted": "#b7b3a9",
        "accent": "#dfb48b",
        "accent-wash": "#322820",
        "line": "#393735"
    },
    "light": {
        "paper": "#f7f3ed",
        "surface": "#fffdf9",
        "ink": "#221c17",
        "muted": "#6e6256",
        "accent": "#8b4a21",
        "accent-wash": "#efded0",
        "line": "#dbd1c5"
    }
}
