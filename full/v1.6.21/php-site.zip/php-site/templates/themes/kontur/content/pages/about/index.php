<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: О компании
Heading: О компании
Description: Подход архитектурного бюро КОНТУР к проектированию домов и интерьеров.
Menu: О компании
MenuVisible: 1
MobileMenu: 1
Order: 20

<p class="kt-lead">КОНТУР — архитектурное бюро частных пространств. Мы продумываем, как дом вписывается в ландшафт и как внутри него меняются свет, звук и движение в течение дня.</p>
<section class="kt-section kt-intro"><img src="/templates/themes/kontur/images/projects/club.jpg" alt="Гостиная с тёмным деревом и камином" width="768" height="512"><div><p class="kt-eyebrow">Подход</p><h2>Сначала слушаем</h2><p>На первой встрече нам важнее ваши привычки и планы, чем подборка референсов. Из них складываются программа дома, логика помещений и материальная палитра.</p></div></section>
<section class="kt-section"><h2>Как строится проект</h2><div class="kt-detail-grid">
<article class="kt-detail"><h3>Концепция</h3><p>Обмеры и анализ участка, сценарии использования, планировки и первые эскизы.</p></article>
<article class="kt-detail"><h3>Документация</h3><p>Рабочие чертежи, узлы и спецификации для строительной команды.</p></article>
<article class="kt-detail"><h3>Реализация</h3><p>Авторский надзор, согласование образцов материалов и сопровождение закупок.</p></article>
</div></section>
[kontur-brief]
