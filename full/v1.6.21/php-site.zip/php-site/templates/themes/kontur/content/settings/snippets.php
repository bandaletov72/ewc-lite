<?php http_response_code(404); exit; __halt_compiler();
{
    "kontur-brief": {
        "description": "Приглашение заполнить бриф",
        "value": "<section class=\"kt-section\"><div class=\"kt-cta\"><div><h2>Обсудим ваш проект?</h2><p>Расскажите, какое пространство вы хотите создать.</p></div><a class=\"kt-button\" href=\"/contacts/#brief\">Заполнить бриф</a></div></section>"
    }
}
