<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php $konturHome = empty($searchMode) && strpos(ltrim($page['html'] ?? ''), '[banners set=kontur-hero ') === 0; ?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main kt-main<?= $konturHome ? ' kt-home' : '' ?>" id="content" lang="<?= site_escape($page['language'] ?? 'ru') ?>">
    <h1<?= $konturHome ? ' class="kt-sr-only"' : ' class="kt-page-title"' ?>><?= site_escape($heading) ?></h1>
    <div class="page-content"><?= $content ?></div>
</main>
