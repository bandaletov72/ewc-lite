<?php
header('Content-Type: text/html; charset=UTF-8');
header("Content-Security-Policy: default-src 'none'; img-src 'self' https: data:; style-src 'unsafe-inline'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
header('X-Content-Type-Options: nosniff');
?>
<!doctype html>
<html><head><meta charset="UTF-8"><title>Визуальный редактор</title><style>body{margin:.8rem;min-height:calc(100vh - 1.6rem)}img{max-width:100%;cursor:move}</style></head><body></body></html>
