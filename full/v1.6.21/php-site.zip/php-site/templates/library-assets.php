<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
try {
    $libraries = site_library_settings(site_read_record(SITE_LIBRARIES_FILE));
} catch (RuntimeException $exception) {
    $libraries = site_library_settings();
}
foreach (site_active_libraries() as $id => $library) {
    if ($id !== 'codemirror' && $libraries['enabled'][$id]) {
        echo site_library_assets($id, $library, $base);
    }
}
?>
<?= site_font_assets($base) ?>
