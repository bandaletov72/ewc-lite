<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

$language = require SITE_ROOT . '/app/help-portfolio.php';
$labels = $language[$locale] ?? $language['ru'];
$keys = array_column($block['columns'], 'key');
$records = [];
$categories = [];
$limit = isset($options['limit']) && ctype_digit($options['limit']) ? max(1, min(200, (int) $options['limit'])) : null;
foreach ($block['rows'] as $row) {
    if (count($row) !== count($keys)) continue;
    $record = array_combine($keys, $row);
    if (trim($record['title'] ?? '') === '') continue;
    $category = trim($record['category'] ?? '');
    if ($category !== '') $categories[$category] = true;
    $records[] = $record;
    if ($limit !== null && count($records) >= $limit) break;
}
?>
<div class="kt-collection" data-kt-collection data-photo-close="<?= site_escape($labels[7]) ?>" data-photo-prev="<?= site_escape($labels[5]) ?>" data-photo-next="<?= site_escape($labels[6]) ?>">
    <?php if ($limit === null && count($categories) > 1): ?>
        <div class="kt-filters" data-kt-filters hidden aria-label="<?= site_escape($labels[2]) ?>">
            <button type="button" aria-pressed="true" data-kt-filter=""><?= site_escape($labels[1]) ?></button>
            <?php foreach (array_keys($categories) as $category): ?>
                <button type="button" aria-pressed="false" data-kt-filter="<?= site_escape((string) $category) ?>"><?= site_escape((string) $category) ?></button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <div class="photo-grid kt-cards">
        <?php foreach ($records as $record): ?>
            <?php
            $photos = [];
            foreach (array_slice(explode(',', $record['images'] ?? $record['image'] ?? ''), 0, 24) as $reference) {
                $reference = trim($reference);
                if (strpos($reference, '/') === false) $reference = '/images/projects/' . $reference;
                $name = basename($reference);
                $folder = site_asset_path(dirname($reference), 'images');
                if ($folder === '' || !in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), site_component_asset_extensions('fotos'), true)) continue;
                $file = SITE_ROOT . '/' . $folder . '/' . $name;
                if (!is_file($file) || realpath($file) !== str_replace('/', DIRECTORY_SEPARATOR, $file)) continue;
                $photos[] = site_url($base, implode('/', array_map('rawurlencode', explode('/', $folder . '/' . $name))));
            }
            $category = trim($record['category'] ?? '');
            $url = site_page_redirect_url($base, '', trim($record['url'] ?? ''));
            ?>
            <article class="kt-card" data-kt-category="<?= site_escape($category) ?>">
                <?php if ($photos): ?>
                    <a class="kt-card-image" href="<?= site_escape($photos[0]) ?>" data-kt-photo data-photos="<?= site_escape((string) json_encode($photos)) ?>" data-caption="<?= site_escape($record['title']) ?>" aria-label="<?= site_escape($labels[3] . ' · ' . $record['title']) ?>">
                        <img src="<?= site_escape($photos[0]) ?>" alt="<?= site_escape($record['title']) ?>" loading="lazy" decoding="async" width="748" height="500">
                    </a>
                <?php endif; ?>
                <div class="kt-card-content">
                    <?php if ($category !== ''): ?><p class="kt-eyebrow"><?= site_escape($category) ?></p><?php endif; ?>
                    <h3><?= site_escape($record['title']) ?></h3>
                    <?php if (!empty($record['description'])): ?><p><?= nl2br(site_escape($record['description'])) ?></p><?php endif; ?>
                    <?php if ($url !== ''): ?><a class="kt-link" href="<?= site_escape($url) ?>"><?= site_escape($labels[4]) ?></a><?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</div>
