<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
try {
    $enabled = site_library_settings(site_read_record(SITE_LIBRARIES_FILE))['enabled']['chartjs'];
} catch (RuntimeException $exception) {
    $enabled = false;
}
$config = $enabled ? site_iblock_chart_config($block, $options) : [];
$json = $config ? json_encode($config, JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG) : false;
if ($json === false) {
    require site_template_file('iblock/table.php');
    return;
}
$chartText = site_iblock_chart_text($locale);
$title = $options['title'] ?? '';
?>
<figure class="iblock-chart" data-iblock-chart="<?= site_escape($json) ?>">
    <?php if ($title !== ''): ?><figcaption><?= site_escape($title) ?></figcaption><?php endif; ?>
    <div class="iblock-chart-canvas" hidden><canvas role="img" aria-label="<?= site_escape($title !== '' ? $title : $chartText['chart']) ?>"></canvas></div>
    <details open>
        <summary><?= site_escape($chartText['table']) ?></summary>
        <?php require site_template_file('iblock/table.php'); ?>
    </details>
</figure>
