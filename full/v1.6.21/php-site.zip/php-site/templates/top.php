<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<a href="#site-top" data-scroll-top><?= site_escape(site_translation('Наверх', $locale)) ?> <span aria-hidden="true">↑</span></a>
