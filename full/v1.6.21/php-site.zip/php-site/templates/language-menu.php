<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$languages = site_region_settings()['languages'];
$mobile = !empty($context['mobileMenuLayout']);
if ($page['path'] === '' || count($languages) < 2) {
    return;
}
?>
<?php if (!$mobile): ?>
<details class="language-dropdown" data-language-dropdown>
    <summary aria-label="<?= site_escape(site_translation('Язык', $locale) . ' · ' . site_languages()[$locale]) ?>">
        <span class="language-globe" aria-hidden="true"></span><?= site_escape(site_languages()[$locale]) ?><span class="language-chevron" aria-hidden="true"></span>
    </summary>
<?php else: ?>
    <div class="mobile-language-heading"><span class="language-globe" aria-hidden="true"></span><?= site_escape(site_translation('Язык', $locale)) ?></div>
<?php endif; ?>
<nav class="site-menu language-menu" aria-label="<?= site_escape(site_translation('Язык', $locale)) ?>">
    <?php foreach ($languages as $code): ?>
        <a lang="<?= $code ?>" href="<?= site_escape(site_page_url($base, $originalPath) . '?lang=' . $code) ?>"<?= $locale === $code ? ' aria-current="true"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
    <?php endforeach; ?>
</nav>
<?php if (!$mobile): ?></details><?php endif; ?>
