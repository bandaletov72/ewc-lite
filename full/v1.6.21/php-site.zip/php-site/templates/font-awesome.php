<?php
define('SITE_ROOT', dirname(__DIR__));

$asset = $_GET['asset'] ?? 'all.min.css';
if (!is_string($asset) || !empty($_SERVER['PATH_INFO'])) {
    http_response_code(404);
    exit;
}
$bundle = require SITE_ROOT . '/app/font-awesome-data.php';
if (!isset($bundle[$asset])) {
    http_response_code(404);
    exit;
}

$mime = $asset === 'all.min.css' ? 'text/css; charset=UTF-8'
    : ($asset === 'LICENSE.txt' ? 'text/plain; charset=UTF-8' : 'font/woff2');
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: ' . (($_GET['v'] ?? '') === '7.3.1' ? 'public, max-age=31536000, immutable' : 'no-cache'));
echo base64_decode($bundle[$asset], true);
