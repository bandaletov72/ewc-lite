<?php if (!defined('SITE_ROOT')) exit; ?>
<div class="city-picker" data-city-picker data-city-url="<?= site_escape(site_url($context['base'])) ?>">
    <label class="city-picker-field">
        <span class="city-picker-label"><?= site_escape($labels['choose']) ?></span>
        <span class="city-picker-pin" aria-hidden="true"></span>
        <span class="city-picker-current" data-city-current aria-hidden="true"><?= site_escape($context['cities'][$context['cityId']]['name']) ?></span>
        <select data-city-select>
            <?php foreach ($context['cities'] as $id => $city): ?>
                <option value="<?= site_escape($id) ?>"<?= $context['cityId'] === $id ? ' selected' : '' ?>><?= site_escape($city['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <small class="notice error" data-city-error role="alert" hidden><?= site_escape($labels['error']) ?></small>
</div>
