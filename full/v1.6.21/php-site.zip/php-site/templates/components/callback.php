<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<details class="callback-widget">
    <summary class="button button-primary"><?= site_escape($label) ?></summary>
    <?php if (($settings['title'] ?? '') !== ''): ?><p class="callback-title"><?= site_escape($settings['title']) ?></p><?php endif; ?>
    <?php require site_template_file('components/form.php'); ?>
</details>
