<?php if (!defined('SITE_ROOT')) exit; ?>
<p><strong><?= site_escape(site_format_number($amount, 2) . ' ' . $currency) ?></strong></p>
<div class="payment-links header-actions">
    <?php if ($wallet !== ''): ?>
        <form method="post" action="https://yoomoney.ru/quickpay/confirm">
            <input type="hidden" name="receiver" value="<?= site_escape($wallet) ?>">
            <input type="hidden" name="quickpay-form" value="button">
            <input type="hidden" name="sum" value="<?= site_escape($amount) ?>">
            <button type="submit" name="paymentType" value="AC">ЮMoney</button>
        </form>
    <?php endif; ?>
    <?php foreach ($methods as $name => $url): ?>
        <a class="button" href="<?= site_escape($url) ?>" rel="noreferrer"><?= site_escape($name) ?></a>
    <?php endforeach; ?>
</div>
