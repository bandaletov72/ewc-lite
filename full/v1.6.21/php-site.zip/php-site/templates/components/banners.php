<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$dialogs = [];
$fonts = site_google_fonts();
$label = static function (string $text) use ($locale): string { return site_escape(site_translation($text, $locale)); };
foreach (array_unique(array_column($slides, 'font')) as $selectedFont) {
    if (isset($fonts[$selectedFont]) && empty($context['bannerFonts'][$selectedFont])) {
        list($family, $weights) = $fonts[$selectedFont];
        $fontUrl = 'https://fonts.googleapis.com/css2?family=' . urlencode($family) . ($weights !== '' ? ':wght@' . $weights : '') . '&display=swap';
        echo '<link rel="stylesheet" href="' . site_escape($fontUrl) . '">';
        $context['bannerFonts'][$selectedFont] = true;
    }
}
?>
    <?php if ($editing && !$slides): ?>
        <a class="button" href="<?= site_escape(site_banner_admin_url($base, $setId, $folder, ['slide' => 'new'])) ?>">+ <?= $label('Добавить кадр') ?></a>
    <?php endif; ?>
    <?php if ($slides): ?>
    <div class="gallery banner-gallery" data-gallery data-banners data-gallery-effect="<?= site_escape($options['effect']) ?>" data-gallery-fit="<?= site_escape($options['fit']) ?>" role="group" aria-label="<?= $label('Баннеры') ?>">
        <div class="gallery-track" data-gallery-track<?= count($slides) > 1 ? ' tabindex="0"' : '' ?>>
            <?php $first = true; foreach ($slides as $id => $slide): ?>
                <?php
                $font = isset($fonts[$slide['font']]) ? '"' . $fonts[$slide['font']][0] . '", ' . $fonts[$slide['font']][2] : (site_banner_fonts()[$slide['font']] ?? '');
                $title = site_expand_text($slide['title'], $snippets ?? $context['snippets']);
                $subtitle = site_expand_text($slide['subtitle'], $snippets ?? $context['snippets']);
                $button = site_expand_text($slide['button'], $context['snippets']);
                $dialogTitle = $button === '' ? $title : $button;
                $styles = '--banner-background:' . $slide['color'] . ';--banner-foreground:' . $slide['textColor'] . ($font !== '' ? ';--banner-font:' . $font : '');
                $dialogId = $instance . '-' . $id;
                $image = site_banner_url($base, $slide['image']);
                $slideUrl = site_banner_url($base, $slide['url']);
                $action = $slide['action'];
                if ($action === 'form' && $button !== '') {
                    $formHtml = site_component_form($slide['form'], $context);
                    if (strpos($formHtml, '<form') !== false) $dialogs[$dialogId] = [$dialogTitle, $formHtml];
                } elseif ($action === 'callback' && $button !== '') {
                    $formHtml = site_component_callback($button, $context, '', true);
                    if (strpos($formHtml, '<form') !== false) $dialogs[$dialogId] = [$dialogTitle, $formHtml];
                }
                ?>
                <article class="gallery-slide banner-slide<?= $first ? ' is-active' : '' ?>" data-banner-align="<?= site_escape($slide['align']) ?>" style="<?= site_escape($styles) ?>">
                    <?php if ($image !== ''): ?><img class="banner-background" src="<?= site_escape($image) ?>" alt=""<?= $first ? '' : ' loading="lazy"' ?> decoding="async"><?php endif; ?>
                    <?php if ($slideUrl !== ''): ?><a class="banner-hit" href="<?= site_escape($slideUrl) ?>" aria-label="<?= $title !== '' ? site_escape($title) : $label('Открыть страницу') ?>"></a><?php endif; ?>
                    <?php if ($title !== '' || $subtitle !== '' || $slide['caption'] !== '' || ($button !== '' && $action !== 'none')): ?>
                        <div class="banner-copy">
                            <?php if ($title !== ''): ?><strong class="banner-title"><?= site_escape($title) ?></strong><?php endif; ?>
                            <?php if ($subtitle !== ''): ?><p class="banner-subtitle"><?= site_escape($subtitle) ?></p><?php endif; ?>
                            <?php if ($slide['caption'] !== ''): ?><div class="banner-caption"><?= site_expand_content($slide['caption'], $context['snippets'], $context) ?></div><?php endif; ?>
                            <?php if ($button !== '' && $action === 'url'): ?>
                                <a class="button button-primary banner-action" href="<?= site_escape(site_banner_url($base, $slide['buttonUrl'])) ?>"><?= site_escape($button) ?></a>
                            <?php elseif (isset($dialogs[$dialogId])): ?>
                                <button class="button-primary banner-action" type="button" data-banner-open="<?= site_escape($dialogId) ?>" aria-haspopup="dialog"><?= site_escape($button) ?></button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($editing): ?>
                        <div class="banner-edit-tools">
                            <?php $slideEditUrl = site_banner_admin_url($base, $setId, $folder, ['slide' => $id]); ?>
                            <a class="button" href="<?= site_escape($slideEditUrl . '#banner-editor') ?>"
                                data-banner-editor-url="<?= site_escape($slideEditUrl . '&embed=1#banner-editor') ?>"
                                aria-haspopup="dialog"><?= $label('Редактировать кадр') ?></a>
                            <a class="button" href="<?= site_escape(site_banner_admin_url($base, $setId, $folder, ['slide' => 'new'])) ?>">+ <?= $label('Добавить кадр') ?></a>
                            <a class="button" href="<?= site_escape(site_banner_admin_url($base, $setId, $folder, ['slide' => $id, 'remove' => '1'])) ?>"><?= $label('Удалить') ?></a>
                        </div>
                    <?php endif; ?>
                </article>
            <?php $first = false; endforeach; ?>
        </div>
        <?php if (count($slides) > 1 && ($options['arrows'] === 'on' || $options['numbers'] === 'on')): ?>
            <div class="gallery-controls" hidden>
                <?php if ($options['arrows'] === 'on'): ?>
                    <button class="gallery-arrow gallery-prev" type="button" data-gallery-prev aria-label="<?= $label('Предыдущее фото') ?>"></button>
                    <button class="gallery-arrow gallery-next" type="button" data-gallery-next aria-label="<?= $label('Следующее фото') ?>"></button>
                <?php endif; ?>
                <?php if ($options['numbers'] === 'on'): ?><span class="gallery-status" role="status" data-gallery-status></span><?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php foreach ($dialogs as $dialogId => list($dialogTitle, $formHtml)): ?>
        <dialog class="editor-dialog banner-dialog" data-banner-dialog id="<?= site_escape($dialogId) ?>" aria-labelledby="<?= site_escape($dialogId . '-title') ?>">
            <div class="header-actions editor-dialog-heading">
                <h2 id="<?= site_escape($dialogId . '-title') ?>"><?= site_escape($dialogTitle) ?></h2>
                <button type="button" data-banner-close aria-label="<?= $label('Закрыть') ?>">×</button>
            </div>
            <?= $formHtml ?>
        </dialog>
    <?php endforeach; ?>
