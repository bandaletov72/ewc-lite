<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$configured = $data['provider'] !== 'off' && $data['key'] !== '' && ($data['provider'] !== 'google' || $data['mapId'] !== '');
$enabled = $configured && site_cookie_allows('maps');
?>
<div class="site-map"<?= $enabled ? ' data-site-map="' . site_escape((string) json_encode($data, JSON_UNESCAPED_UNICODE)) . '"' : '' ?>>
    <?php if ($enabled): ?>
        <div class="map-canvas" data-map-canvas aria-label="<?= site_escape(site_translation('Карта', $data['locale'])) ?>"></div>
        <p data-map-status role="status" hidden></p>
    <?php elseif ($configured): ?>
        <?php $consent = require SITE_ROOT . '/app/help-map-consent.php'; ?>
        <button class="button-primary" type="button" data-map-consent="<?= site_escape(site_cookie_permissions()) ?>"
            data-cookie-path="<?= site_escape(site_url($base)) ?>"><?= site_escape($consent[$data['locale']] ?? $consent['ru']) ?></button>
    <?php endif; ?>
    <ul class="map-point-list">
        <?php foreach ($data['points'] as $point): ?>
            <li>
                <?php if ($point['url'] !== ''): ?>
                    <a href="<?= site_escape($point['url']) ?>"><?= site_escape($point['title']) ?></a>
                <?php else: ?>
                    <?= site_escape($point['title']) ?>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
