<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

$id = $_GET['id'] ?? '';
$libraries = site_active_libraries();
if (!is_string($id) || !isset($libraries[$id]) || !empty($_SERVER['PATH_INFO'])) {
    http_response_code(404);
    exit;
}
$base = site_base('templates/library-test.php');
$language = $_GET['lang'] ?? 'ru';
$language = is_string($language) ? $language : 'ru';
$label = $libraries[$id]['label'];
header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
$eval = $id === 'alpine' ? " 'unsafe-eval'" : '';
header("Content-Security-Policy: default-src 'none'; script-src 'self' 'unsafe-inline'{$eval} https://cdn.jsdelivr.net https://code.jquery.com https://esm.sh; "
    . "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net; img-src 'self' data:; connect-src https://esm.sh; "
    . "sandbox allow-scripts; frame-ancestors 'self'; base-uri 'none'; form-action 'none'");
?>
<!doctype html>
<html lang="<?= site_escape($language) ?>">
<meta charset="UTF-8">
<title><?= site_escape($label) ?></title>
<link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css')) ?>">
<?= site_library_assets($id, $libraries[$id], $base) ?>
<div class="panel form-stack">
    <strong><?= site_escape($label) ?></strong>
    <p id="library-result" role="status"><?= site_escape(site_translation('Проверяем загрузку…', $language)) ?></p>
    <div id="library-example">
        <?php if ($id === 'fontawesome'): ?><i class="fa-solid fa-star" id="font-test" aria-hidden="true"></i><?php endif; ?>
        <?php if ($id === 'bootstrap'): ?><button class="btn btn-primary" type="button">Bootstrap</button><?php endif; ?>
        <?php if ($id === 'alpine'): ?><div x-data="{count: 0}"><button type="button" @click="count++" x-text="count">0</button></div><?php endif; ?>
        <?php if ($id === 'chartjs'): ?><canvas width="240" height="90"></canvas><?php endif; ?>
        <?php if ($id === 'codemirror'): ?><textarea data-code-mode="javascript" rows="2">const example = "CodeMirror";</textarea><?php endif; ?>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', async () => {
    const id = <?= json_encode($id, JSON_HEX_TAG) ?>;
    const result = document.getElementById('library-result');
    const good = <?= json_encode(site_translation('Тест пройден.', $language), JSON_HEX_TAG) ?>;
    const fail = <?= json_encode(site_translation('Библиотека не прошла проверку. Проверьте загрузку файлов.', $language), JSON_HEX_TAG) ?>;
    const timer = setTimeout(() => { result.textContent = fail; }, 10000);
    try {
        let ok;
        switch (id) {
            case 'jquery': ok = typeof jQuery === 'function' && jQuery('#library-result').length === 1; break;
            case 'bootstrap': ok = typeof window.bootstrap?.Dropdown === 'function'; break;
            case 'fontawesome':
                await document.fonts.ready;
                ok = !['none', 'normal', '""'].includes(getComputedStyle(document.querySelector('#font-test'), '::before').content)
                    && [...document.fonts].some((font) => font.status === 'loaded');
                break;
            case 'mui': ok = Boolean((await import('@mui/material')).Button); break;
            case 'alpine': ok = typeof window.Alpine?.start === 'function'; break;
            case 'htmx': ok = typeof window.htmx?.process === 'function'; break;
            case 'chartjs':
                ok = Boolean(new Chart(document.querySelector('canvas'), {type: 'bar', data: {
                    labels: ['A', 'B'], datasets: [{data: [3, 5]}]
                }, options: {responsive: false}}));
                break;
            case 'glightbox':
                const lightbox = GLightbox({elements: []});
                ok = typeof lightbox.open === 'function';
                lightbox.destroy();
                break;
            case 'codemirror': ok = Boolean(document.querySelector('.editor-code-highlight .cm-keyword')); break;
        }
        result.textContent = ok ? good : fail;
    } catch (error) {
        result.textContent = fail;
    } finally {
        clearTimeout(timer);
    }
});
</script>
