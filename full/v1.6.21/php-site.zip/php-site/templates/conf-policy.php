<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<a href="<?= site_escape(site_url($base, 'privacy/')) ?>"><?= site_escape(site_translation('Политика конфиденциальности', $locale)) ?></a>
