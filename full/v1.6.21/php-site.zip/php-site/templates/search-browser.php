<?php
define('SITE_ROOT', dirname(__DIR__));
header('Content-Type: application/javascript; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-cache');
echo require SITE_ROOT . '/app/search-browser-js.php';
