<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

header('Content-Type: text/css; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-cache');
$base = site_base('templates/font-previews.php');
foreach (site_google_fonts() as $key => $font) {
    $url = site_local_font($base, $key) ?: 'https://fonts.googleapis.com/css2?' . site_google_font_query($font, true) . '&display=swap';
    echo '@import url("' . $url . '");' . "\n";
}
foreach (site_font_options() as $key => $font) {
    echo '.font-preview-' . $key . ' { font-family: ' . site_font_family($font) . '; }' . "\n";
}
