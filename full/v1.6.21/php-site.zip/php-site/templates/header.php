<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<a class="brand site-brand" href="<?= site_escape(site_url($base)) ?>">
    <?= site_brand_logo_html($brand, $base) ?>
    <span class="site-brand-copy">
        <span><?= site_escape($settings['name']) ?></span>
        <?php if ($settings['subtitle'] !== ''): ?><small class="site-brand-subtitle"><?= site_escape($settings['subtitle']) ?></small><?php endif; ?>
    </span>
</a>
<div class="site-city-header">
    <?= site_expand_content('[cities][phones]', $snippets, $context) ?>
</div>
