<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Страница не найдена
Heading: Страница не найдена
MenuVisible: 0
MobileMenu: 0
Sitemap: 0

<p>Проверьте адрес страницы или выберите раздел в меню.</p>
