<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    'translit' => static function (string $text): string {
        return ew_translit($text);
    },
];
