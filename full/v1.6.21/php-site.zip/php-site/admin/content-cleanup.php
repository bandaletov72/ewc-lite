<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_media_cleanup_candidate(string $path): bool
{
    return preg_match('~\A(?:templates/(?:themes/[a-z0-9_-]+/)?)?(?:images|files)/~', $path)
        && !preg_match('~\Atemplates/(?:themes/[a-z0-9_-]+/)?images/branding/~', $path)
        && basename($path) !== '.asset-order.php';
}

function admin_media_usage(array $files, string $directory = '', ?bool &$directoryUsed = null): array
{
    $media = array_filter($files, static function (string $path): bool {
        return admin_media_cleanup_candidate($path);
    }, ARRAY_FILTER_USE_KEY);
    if (!$media && $directory === '') return [];
    $aliases = [];
    if ($directory !== '') {
        $logical = preg_replace('~\Atemplates/(?:themes/[a-z0-9_-]+/)?~', '', $directory);
        $aliases = array_unique([$directory, $logical, 'templates/' . $logical]);
    }
    $directoryUsed = false;

    $folders = [];
    $addFolder = static function (string $path) use (&$folders) {
        $path = trim($path, '/');
        $folders[$path] = true;
        if (strpos($path, 'templates/') === 0) $folders[substr($path, 10)] = true;
        else $folders['templates/' . $path] = true;
    };
    $read = static function (string $text) use (&$media, $addFolder, $aliases, &$directoryUsed) {
        $text = html_entity_decode(rawurldecode(str_replace(['\/', '\\"'], ['/', '"'], $text)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        foreach ($aliases as $alias) {
            if (preg_match('~(?:^|[^a-z0-9_-])' . preg_quote($alias, '~') . '(?=[/?#\s"\x27\[\]<>)]|\z)~i', $text)) $directoryUsed = true;
        }
        foreach ($media as $path => $file) {
            if (stripos($text, basename($path)) !== false) unset($media[$path]);
        }
        if (preg_match_all('~\[(gal|fotos|files|banners)(?:[\t ][^\]\r\n]*)?\]\s*(/[^\[\]\r\n]+)\[/\1\]~i', $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $path = site_asset_path(trim($match[2]), strtolower($match[1]) === 'files' ? 'files' : 'images');
                if ($path !== '') $addFolder($path);
            }
        }
    };
    foreach (site_banner_sets() as $set) {
        $folder = site_asset_path($set['folder'] ?? '', 'images');
        if ($folder !== '') $addFolder($folder);
    }
    foreach (array_diff_key($files, $media) as $path => $file) {
        if (basename($path) === '.asset-order.php' || !preg_match('~(?:\.(?:php|css|js|html|txt|csv|json|xml|config)|/\.htaccess|\A\.htaccess)\z~i', $path)) continue;
        $text = @file_get_contents($file, false, null, 0, 8388609);
        if (!is_string($text) || strlen($text) > 8388608) {
            throw new RuntimeException('Не удалось полностью проверить ссылки на медиа. Очистка недоступна.');
        }
        $read($text);
        if (site_valid_path($path)) {
            $page = site_read_page($path);
            foreach (['CSS','JS'] as $asset) {
                $code = site_asset_decode($page['fields'][$asset] ?? '');
                if ($code !== null && $code !== '') $read($code);
            }
        }
    }
    foreach (site_global_assets() as $asset) {
        $code = site_asset_decode($asset);
        if ($code !== null && $code !== '') $read($code);
    }
    if ($directory !== '') {
        foreach (['templates/*.php', 'templates/components/*.php', 'templates/css/*.css', 'templates/js/*.js'] as $pattern) {
            foreach (glob(SITE_ROOT . '/' . $pattern) ?: [] as $source) {
                $text = @file_get_contents($source, false, null, 0, 8388609);
                if (!is_string($text) || strlen($text) > 8388608) throw new RuntimeException('Не удалось полностью проверить ссылки на медиа. Очистка недоступна.');
                $read($text);
            }
        }
        foreach ($aliases as $alias) {
            if (isset($folders[$alias])) $directoryUsed = true;
        }
    }
    foreach ($media as $path => $file) {
        $folder = dirname($path);
        while ($folder !== '.') {
            if (isset($folders[$folder])) {
                unset($media[$path]);
                continue 2;
            }
            if ($directory !== '') break;
            $folder = dirname($folder);
        }
    }
    return $media;
}

function admin_remove_media_directory(string $path, array $extensions, string $language)
{
    $labels = site_media_folder_labels($language);
    $folder = SITE_ROOT . '/' . $path;
    if (!preg_match('~\A(?:templates/(?:themes/[a-z0-9_-]+/)?)?(?:images|files)/[^/]+(?:/[^/]+)*\z~', $path)
        || preg_match('~\Atemplates/(?:themes/[a-z0-9_-]+/)?images/branding(?:/|$)~', $path)
        || is_link($folder) || !is_dir($folder) || realpath($folder) !== str_replace('/', DIRECTORY_SEPARATOR, $folder)) {
        throw new RuntimeException($labels[3]);
    }
    $count = 0;
    $filePaths = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($folder, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $entry) {
        $absolute = $entry->getPathname();
        $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($absolute, strlen(SITE_ROOT) + 1));
        if (++$count > 10000 || $entry->isLink() || realpath($absolute) !== str_replace('/', DIRECTORY_SEPARATOR, $absolute)
            || $entry->getFilename()[0] === '.' && $entry->getFilename() !== '.asset-order.php'
            || (!$entry->isDir() && (!$entry->isFile() || !admin_backup_allowed($relative)
                || ($entry->getFilename() !== '.asset-order.php' && !in_array(strtolower($entry->getExtension()), $extensions, true))))) {
            throw new RuntimeException($labels[3]);
        }
        if ($entry->isFile() && $entry->getFilename() !== '.asset-order.php') $filePaths[$relative] = $absolute;
    }
    $files = admin_backup_files();
    $used = false;
    $unused = admin_media_usage($files, $path, $used);
    if ($used || array_diff_key($filePaths, $unused)) throw new RuntimeException($labels[2]);
    if ($count === 0) {
        if (!@rmdir($folder)) throw new RuntimeException($labels[3]);
        return;
    }
    admin_backup_capture($files);
    $staged = admin_backup_directory() . '/.removed-media-' . bin2hex(random_bytes(12));
    if (!@rename($folder, $staged)) throw new RuntimeException($labels[3]);
    // Keep the verified backup even if filesystem cleanup is interrupted.
    $children = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($staged, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($children as $entry) {
        if ($entry->isDir() && !$entry->isLink()) @rmdir($entry->getPathname());
        else @unlink($entry->getPathname());
    }
    @rmdir($staged);
}

function admin_remove_unused_media(array $input): int
{
    $selected = $input['media'] ?? null;
    if (!is_array($selected) || !$selected || count($selected) > 100 || admin_input($input, 'confirm') !== '1') {
        throw new RuntimeException('Выберите файлы и подтвердите очистку.');
    }
    $lock = admin_lock();
    $staged = [];
    $directory = '';
    $keepFiles = false;
    try {
        $files = admin_backup_files();
        $unused = admin_media_usage($files);
        foreach ($selected as $path) {
            if (!is_string($path) || !isset($unused[$path])) {
                throw new RuntimeException('Список неиспользуемых файлов изменился. Повторите поиск.');
            }
        }
        admin_backup_capture($files);
        $directory = admin_backup_directory() . '/.cleanup-' . bin2hex(random_bytes(8));
        if (!@mkdir($directory, 0700)) throw new RuntimeException('Не удалось подготовить папку очистки.');
        foreach (array_unique($selected) as $path) {
            $file = $unused[$path];
            $temporary = $directory . '/' . count($staged);
            if (!@rename($file, $temporary)) throw new RuntimeException('Не удалось убрать один из выбранных файлов.');
            $staged[$file] = $temporary;
        }
        return count($staged);
    } catch (Throwable $exception) {
        foreach (array_reverse($staged, true) as $file => $temporary) {
            if (!@rename($temporary, $file)) $keepFiles = true;
        }
        if ($keepFiles) throw new RuntimeException('Очистка прервана. Файлы сохранены в закрытой папке резервных копий.', 0, $exception);
        throw $exception;
    } finally {
        if ($directory !== '' && !$keepFiles) {
            foreach ($staged as $temporary) {
                if (is_file($temporary)) @unlink($temporary);
            }
            @rmdir($directory);
        }
        fclose($lock);
    }
}
