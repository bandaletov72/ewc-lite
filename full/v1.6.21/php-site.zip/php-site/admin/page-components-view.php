<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

(static function (array $page, string $base, string $adminUrl, string $language, string $token) {
    $editor = ['language' => $language, 'edit' => true];
    $editText = static function (string $text) use ($language): string {
        return site_escape(site_translation($text, $language));
    };
    $editAdmin = admin_page_edit_url($adminUrl, $page['path']) . '#page-components';
    $editHidden = '<input type="hidden" name="csrf" value="' . site_escape($token) . '">'
        . '<input type="hidden" name="path" value="' . site_escape($page['path']) . '">'
        . '<input type="hidden" name="revision" value="' . site_escape($page['revision']) . '">';
    $contentHost = site_content_host($base);
    $settings = site_settings();
    $snippets = site_date_snippets() + ['author' => '', 'site-name' => '', 'site-url' => '']
        + site_snippet_values($contentHost) + array_map('site_escape', $settings['variables']);
    $componentItems = site_page_edit_groups($page, site_extensions(), $snippets)['components'];
    list($editDataText, $editWideText) = site_data_editor_labels($language);
    $hasDataTarget = false;
    $editInAdmin = true;
    ?>
    <section id="page-components" class="form-stack" data-page-tab-panel="components" aria-label="<?= $editText('Компоненты страницы') ?>">
        <?php require SITE_ROOT . '/templates/page-component-list.php'; ?>
    </section>
    <?php if ($hasDataTarget): require SITE_ROOT . '/templates/page-component-data.php'; endif; ?>
    <?php
})($page, $base, $adminUrl, $adminLanguage, $token);
