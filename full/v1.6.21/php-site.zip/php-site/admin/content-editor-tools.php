<?php if (!defined('SITE_ROOT')) exit; ?>
<section class="panel form-stack" data-editor-image-properties hidden>
    <h3><?= site_escape($toolsLabel['image']) ?></h3>
    <div class="fields">
        <label class="field field-wide">URL <input type="text" data-image-property="url"></label>
        <label class="field field-wide"><?= admin_l('Альтернативный текст') ?> <input type="text" data-image-property="alt" maxlength="375"></label>
        <label class="field"><?= admin_l('Ширина') ?> <input type="number" data-image-property="width" min="1" max="6000"></label>
        <label class="field"><?= admin_l('Высота') ?> <input type="number" data-image-property="height" min="1" max="6000"></label>
        <label class="field">
            <?= site_escape(admin_localized_label('Выравнивание изображения', 'Image alignment')) ?>
            <select data-image-property="alignment">
                <option value="">—</option>
                <?php foreach (['left','center','right'] as $alignment): ?>
                    <option value="<?= $alignment ?>"><?= site_escape($workflow['align'][$alignment]) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php
        $margins = ['top' => admin_localized_label('Отступ сверху', 'Top margin'), 'right' => admin_localized_label('Отступ справа', 'Right margin'),
            'bottom' => admin_localized_label('Отступ снизу', 'Bottom margin'), 'left' => admin_localized_label('Отступ слева', 'Left margin')];
        foreach ($margins as $side => $label): ?>
            <label class="field"><?= site_escape($label) ?> <input type="text" data-image-property="margin-<?= $side ?>" placeholder="12px" maxlength="80"></label>
        <?php endforeach; ?>
        <label class="field field-wide">CSS <input type="text" data-image-property="style" placeholder="border-radius: 8px" maxlength="2000"></label>
    </div>
    <div class="header-actions">
        <button type="button" data-editor-apply-image><?= admin_l('Применить') ?></button>
        <button type="button" data-editor-close-image><?= admin_l('Закрыть') ?></button>
    </div>
</section>
<dialog class="editor-dialog" data-editor-tool-dialog="link" aria-label="<?= site_escape($toolsLabel['link']) ?>">
    <div class="form-stack">
        <div class="header-actions editor-dialog-heading">
            <h3><?= site_escape($toolsLabel['link']) ?></h3>
            <button type="button" data-editor-tool-close aria-label="<?= admin_l('Закрыть') ?>">×</button>
        </div>
        <div class="fields">
            <label class="field"><?= admin_l('Тип') ?>
                <select data-editor-link-type>
                    <option value="url">URL</option><option value="mailto">Email · mailto</option><option value="tel"><?= admin_l('Телефон') ?> · tel</option><option value="anchor"><?= admin_l('Якорь') ?> · #</option>
                </select>
            </label>
            <label class="field"><?= admin_l('Адрес') ?> <input type="text" data-editor-link-address maxlength="1500"></label>
            <label class="field"><?= admin_l('Текст ссылки') ?> <input type="text" data-editor-link-text maxlength="375"></label>
            <label class="field"><?= admin_l('Подсказка') ?> <input type="text" data-editor-link-title maxlength="375"></label>
            <label class="choice field-wide"><input type="checkbox" data-editor-link-tab> <?= site_escape($toolsLabel['new-tab']) ?></label>
        </div>
        <p class="notice error" data-editor-tool-error role="alert" hidden></p>
        <div><button type="button" class="button-primary" data-editor-insert-link><?= admin_l('Применить') ?></button></div>
    </div>
</dialog>
<dialog class="editor-dialog" data-editor-tool-dialog="button" aria-label="<?= site_escape($toolsLabel['button']) ?>">
    <div class="form-stack">
        <div class="header-actions editor-dialog-heading">
            <h3><?= site_escape($toolsLabel['button']) ?></h3>
            <button type="button" data-editor-tool-close aria-label="<?= admin_l('Закрыть') ?>">×</button>
        </div>
        <div class="fields">
            <label class="field"><?= site_escape($toolsLabel['label']) ?> <input type="text" data-editor-action-field="label" maxlength="90"></label>
            <label class="field"><?= site_escape($toolsLabel['action']) ?>
                <select data-editor-button-action>
                    <option value="url">URL</option><option value="form"><?= admin_l('Форма') ?></option>
                    <option value="callback"><?= admin_l('Обратный звонок') ?></option><option value="payment"><?= site_escape($toolsLabel['payment']) ?></option>
                </select>
            </label>
            <label class="field field-wide" data-editor-button-when="url">URL <input type="text" data-editor-action-field="url" maxlength="500"></label>
            <label class="field field-wide" data-editor-button-when="form" hidden><?= admin_l('Форма') ?>
                <select data-editor-action-field="form">
                    <?php foreach ($editorForms as $formCode => $definition): if (!site_valid_form_id($formCode)) continue; ?>
                        <option value="<?= site_escape($formCode) ?>"><?= site_escape(($definition['title'] ?? $formCode) . ' [' . $formCode . ']') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <div class="fields field-wide" data-editor-button-when="payment" hidden>
                <label class="field"><?= admin_l('Сумма') ?> <input type="text" inputmode="decimal" data-editor-action-field="amount" placeholder="1250.00"></label>
                <label class="field"><?= admin_l('Валюта') ?>
                    <select data-editor-action-field="currency">
                        <?php foreach (site_region_options()['currency'] as $currency => $name): ?>
                            <option value="<?= site_escape($currency) ?>"<?= site_region_settings()['currency'] === $currency ? ' selected' : '' ?>><?= site_escape($name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <?php foreach (site_payment_methods() as $method => list($name, $hosts, $documentation)): ?>
                    <label class="field field-wide"><?= site_escape($name) ?>
                        <input type="text" data-editor-action-field="<?= $method ?>" data-payment-hosts="<?= site_escape(implode(' ', $hosts)) ?>" maxlength="500"
                            placeholder="<?= $method === 'yoomoney' ? site_escape(admin_localized_label('Номер кошелька или ссылка', 'Wallet number or payment link')) : 'https://' ?>">
                        <a href="<?= site_escape($documentation) ?>" target="_blank" rel="noopener noreferrer"><?= admin_l('Документация') ?></a>
                    </label>
                <?php endforeach; ?>
                <p class="hint field-wide"><?= site_escape(admin_localized_label('Для PayPal и СБП укажите готовую ссылку на эту сумму. Для ЮMoney можно указать номер рублёвого кошелька.', 'Use a payment link for this amount for PayPal and SBP. YooMoney also accepts a RUB wallet number.')) ?></p>
            </div>
        </div>
        <p class="notice error" data-editor-tool-error role="alert" hidden></p>
        <div><button type="button" class="button-primary" data-editor-insert-action><?= admin_l('Вставить в текст') ?></button></div>
    </div>
</dialog>
