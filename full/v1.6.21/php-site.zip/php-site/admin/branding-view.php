<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$brand = site_brand_settings();
?>
<section class="panel form-stack theme-presets" id="branding">
    <h2><?= admin_l('Логотипы и иконки сайта') ?></h2>
    <form class="form-stack" method="post" enctype="multipart/form-data" action="<?= site_escape($settingsUrl) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape(admin_brand_revision($brand)) ?>">
        <div class="form-stack">
            <div class="field">
                <label for="site-logo"><?= admin_l('Логотип для светлой темы') ?></label>
                <?php if ($brand['logo'] !== ''): ?>
                    <img class="branding-preview" src="<?= site_escape(site_url($base, $brand['logo'])) ?>" alt="<?= admin_l('Текущий логотип') ?>">
                <?php endif; ?>
                <input type="file" id="site-logo" name="logo" accept="image/png,image/jpeg,image/gif,image/webp">
            </div>
            <div class="field">
                <label for="site-logo-dark"><?= admin_l('Логотип для тёмной темы') ?></label>
                <?php if ($brand['logo_dark'] !== ''): ?>
                    <img class="branding-preview" src="<?= site_escape(site_url($base, $brand['logo_dark'])) ?>" alt="<?= admin_l('Логотип тёмной темы') ?>">
                <?php endif; ?>
                <input type="file" id="site-logo-dark" name="logo_dark" accept="image/png,image/jpeg,image/gif,image/webp">
            </div>
            <div class="field">
                <label for="site-favicon">Favicon</label>
                <img class="branding-icon" src="<?= site_escape(site_url($base, $brand['favicon'] ?: 'templates/icons/site.png')) ?>" alt="<?= admin_l('Текущая иконка') ?>">
                <input type="file" id="site-favicon" name="favicon" accept="image/png,image/jpeg,image/gif,image/webp">
            </div>
        </div>
        <p class="hint"><?= admin_l('PNG, JPEG, GIF или WebP. При загрузке имя транслитерируется и сохраняется без пробелов. Favicon можно создать из логотипа, размер иконки — 64 × 64.') ?></p>
        <div class="header-actions">
            <button type="submit" class="button-primary" name="action" value="save-brand"><?= admin_l('Сохранить изображения') ?></button>
            <button type="submit" name="action" value="generate-favicon"><?= admin_l('Создать favicon из логотипа') ?></button>
        </div>
    </form>
</section>
