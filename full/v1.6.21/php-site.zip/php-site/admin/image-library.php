<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_image_library_path(string $path): string
{
    $path = rtrim($path, '/');
    $theme = site_design_active();
    $root = $theme === '' ? '/(?:templates/)?images' : '/templates/themes/' . preg_quote($theme, '~') . '/images';
    if (!preg_match('~\A' . $root . '(?:/[^/]+)*\z~u', $path) || preg_match('~[\x00-\x1F\x7F\\\\:<>"|?*]~u', $path)) {
        throw new RuntimeException('Выберите папку изображений.');
    }
    foreach (explode('/', ltrim($path, '/')) as $part) {
        if ($part[0] === '.' || substr($part, -1) === '.' || substr($part, -1) === ' ') {
            throw new RuntimeException('Выберите папку изображений.');
        }
    }
    return $path;
}

function admin_image_library_roots(): array
{
    $theme = site_design_active();
    return $theme === '' ? ['/templates/images', '/images'] : ['/templates/themes/' . $theme . '/images'];
}

function admin_image_library_has_directory(string $path): bool
{
    $folder = SITE_ROOT . $path;
    return is_dir($folder) && realpath($folder) === str_replace('/', DIRECTORY_SEPARATOR, $folder);
}

function admin_image_library_url(string $base, string $path, string $name): string
{
    return site_url($base, implode('/', array_map('rawurlencode', explode('/', ltrim($path, '/')))) . '/' . rawurlencode($name));
}

function admin_image_library_items(string $path, string $base): array
{
    $items = [];
    if (!admin_image_library_has_directory($path)) return $items;
    foreach (new FilesystemIterator(SITE_ROOT . $path, FilesystemIterator::SKIP_DOTS) as $file) {
        $name = $file->getFilename();
        if ($file->isLink() || $name[0] === '.' || preg_match('//u', $name) !== 1) continue;
        if ($file->isDir()) {
            try { admin_image_library_path($path . '/' . $name); } catch (RuntimeException $exception) { continue; }
            $items[] = ['name' => $name, 'type' => 'directory'];
        } elseif ($file->isFile() && in_array(strtolower($file->getExtension()), site_component_asset_extensions('gal'), true)) {
            $items[] = ['name' => $name, 'type' => 'image', 'url' => admin_image_library_url($base, $path, $name)];
        }
    }
    usort($items, static function (array $left, array $right): int {
        return strcmp($left['type'], $right['type']) ?: strnatcasecmp($left['name'], $right['name']);
    });
    return $items;
}

function admin_image_library_transform(string $file, array $input): string
{
    if (!function_exists('imagecreatefromstring')) throw new RuntimeException('Для изменения изображения требуется расширение GD.');
    $info = @getimagesize($file);
    $dimension = static function (string $raw): int {
        if ($raw === '') return 0;
        if (!preg_match('/\A[1-9][0-9]{0,3}\z/', $raw) || (int) $raw > 6000) throw new RuntimeException('Укажите размер от 1 до 6000 пикселей.');
        return (int) $raw;
    };
    $width = $dimension(admin_input($input, 'width'));
    $height = $dimension(admin_input($input, 'height'));
    $angle = admin_input($input, 'rotate');
    if (!$info || $info[0] * $info[1] > 12000000 || filesize($file) > 33554432 || !in_array($angle, ['0', '90', '180', '270'], true)) {
        throw new RuntimeException('Проверьте формат, поворот и размер исходного изображения.');
    }
    if ($info[2] === IMAGETYPE_GIF) throw new RuntimeException('GIF можно вставлять без преобразования. Для поворота или изменения размера выберите JPG, PNG или WebP.');
    $raw = @file_get_contents($file);
    $image = is_string($raw) ? @imagecreatefromstring($raw) : false;
    if (!$image) throw new RuntimeException('GD не удалось прочитать выбранный формат.');
    try {
        if ($angle !== '0') {
            $rotated = @imagerotate($image, -(int) $angle, imagecolorallocatealpha($image, 0, 0, 0, 127));
            if (!$rotated) throw new RuntimeException('Не удалось повернуть изображение.');
            $image = $rotated;
            unset($rotated);
        }
        $sourceWidth = imagesx($image);
        $sourceHeight = imagesy($image);
        if ($width || $height) {
            $width = $width ?: max(1, (int) round($height * $sourceWidth / $sourceHeight));
            $height = $height ?: max(1, (int) round($width * $sourceHeight / $sourceWidth));
            if ($width > 6000 || $height > 6000 || $width * $height > 12000000) throw new RuntimeException('Уменьшите размеры новой копии.');
            $resized = imagecreatetruecolor($width, $height);
            if (!$resized) throw new RuntimeException('Не удалось создать изображение.');
            imagealphablending($resized, false);
            imagecopyresampled($resized, $image, 0, 0, 0, 0, $width, $height, $sourceWidth, $sourceHeight);
            $image = $resized;
        }
        imagesavealpha($image, true);
        $jpeg = $info[2] === IMAGETYPE_JPEG;
        $stem = (admin_image_name(basename($file)) ?: 'photo') . '-edit';
        $name = $stem . ($jpeg ? '.jpg' : '.png');
        for ($counter = 2; file_exists(dirname($file) . '/' . $name) || is_link(dirname($file) . '/' . $name); $counter++) {
            $name = $stem . '-' . $counter . ($jpeg ? '.jpg' : '.png');
        }
        $temporary = tempnam(sys_get_temp_dir(), 'ew-image-');
        if ($temporary === false) throw new RuntimeException('Не удалось подготовить копию изображения.');
        try {
            $written = $jpeg ? imagejpeg($image, $temporary, 90) : imagepng($image, $temporary, 5);
            $bytes = $written ? @file_get_contents($temporary) : false;
            if (!is_string($bytes) || $bytes === '' || !admin_replace_file(dirname($file) . '/' . $name, $bytes)) {
                throw new RuntimeException('Не удалось сохранить копию изображения.');
            }
        } finally {
            @unlink($temporary);
        }
        return $name;
    } finally {
        unset($image);
    }
}

function admin_image_library(array $input, string $base)
{
    try {
        $path = admin_image_library_path(admin_input($input, 'path'));
        $operation = admin_input($input, 'operation');
        $name = admin_input($input, 'name');
        $selected = '';
        if ($operation !== 'browse') {
            $lock = admin_lock();
            try {
                if ($operation === 'mkdir' || $operation === 'upload') {
                    if (!admin_image_library_has_directory($path) && !in_array($path, admin_image_library_roots(), true)) throw new RuntimeException('Папка больше недоступна.');
                    admin_make_page_directory(ltrim($path, '/') . '/file.jpg');
                    if ($operation === 'mkdir') {
                        if (!site_valid_part($name) || !@mkdir(SITE_ROOT . $path . '/' . $name, 0755)) throw new RuntimeException('Укажите свободное имя папки из латинских букв, цифр, дефисов и подчёркиваний.');
                    } else {
                        $selected = admin_upload_component_asset($_FILES['upload'] ?? [], SITE_ROOT . $path, site_component_asset_extensions('gal'));
                    }
                } else {
                    $item = array_column(admin_image_library_items($path, $base), 'type', 'name')[$name] ?? null;
                    if ($item === null || !in_array($operation, ['delete', 'transform'], true) || ($operation === 'transform' && $item !== 'image')) {
                        throw new RuntimeException('Выберите доступное изображение или папку.');
                    }
                    $target = SITE_ROOT . $path . '/' . $name;
                    if (realpath($target) !== str_replace('/', DIRECTORY_SEPARATOR, $target)) {
                        throw new RuntimeException('Выберите файл или папку внутри каталога изображений.');
                    }
                    if ($operation === 'transform') {
                        $selected = admin_image_library_transform($target, $input);
                    } elseif ($item === 'directory') {
                        $language = $GLOBALS['adminLanguage'] ?? 'ru';
                        if (admin_input($input, 'confirm') !== '1') throw new RuntimeException(site_media_folder_labels($language)[3]);
                        admin_remove_media_directory(ltrim($path, '/') . '/' . $name, site_component_asset_extensions('gal'), $language);
                    } elseif (!@unlink($target)) {
                        throw new RuntimeException('Не удалось удалить изображение.');
                    }
                }
            } finally {
                fclose($lock);
            }
        }
        admin_json(200, ['path' => $path, 'items' => admin_image_library_items($path, $base), 'selected' => $selected]);
    } catch (RuntimeException $exception) {
        admin_json(422, ['message' => $exception->getMessage()]);
    }
}
