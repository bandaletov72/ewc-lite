<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_php_lint_binary(): string
{
    $configured = getenv('SITE_PHP_LINT_BINARY');
    if (is_string($configured) && $configured !== '') {
        return is_file($configured) ? $configured : '';
    }
    $suffix = DIRECTORY_SEPARATOR === '\\' ? '.exe' : '';
    $candidate = PHP_BINDIR . DIRECTORY_SEPARATOR . 'php' . $suffix;
    if (in_array(PHP_SAPI, ['cli', 'cli-server'], true) && is_file(PHP_BINARY)) {
        return PHP_BINARY;
    }
    return is_file($candidate) ? $candidate : '';
}

function admin_validate_php(string $source): array
{
    try {
        $tokens = token_get_all($source, TOKEN_PARSE);
    } catch (ParseError $exception) {
        throw new RuntimeException('Синтаксическая ошибка PHP. ' . $exception->getMessage(), 0, $exception);
    }
    $binary = admin_php_lint_binary();
    if ($binary === '' || !function_exists('proc_open')) {
        throw new RuntimeException('Для проверки кода настройте путь к PHP CLI в SITE_PHP_LINT_BINARY и включите proc_open.');
    }
    $input = @tempnam(sys_get_temp_dir(), 'ew-php-');
    $output = @tempnam(sys_get_temp_dir(), 'ew-lint-');
    try {
        if ($input === false || $output === false || @file_put_contents($input, $source) !== strlen($source)) {
            throw new RuntimeException('Не удалось создать временный файл для проверки PHP.');
        }
        $quote = static function (string $path): string {
            return DIRECTORY_SEPARATOR === '\\' ? '"' . $path . '"' : escapeshellarg($path);
        };
        $process = @proc_open($quote($binary) . ' -n -l ' . $quote($input),
            [0 => ['pipe', 'r'], 1 => ['file', $output, 'a'], 2 => ['file', $output, 'a']],
            $pipes, null, null, ['bypass_shell' => true]);
        if (!is_resource($process)) {
            throw new RuntimeException('Не удалось запустить проверку PHP.');
        }
        fclose($pipes[0]);
        if (proc_close($process) !== 0) {
            $details = trim(str_replace($input, 'PHP', (string) @file_get_contents($output, false, null, 0, 4096)));
            throw new RuntimeException('Проверка PHP не пройдена. ' . $details);
        }
    } finally {
        foreach ([$input, $output] as $file) {
            if (is_string($file)) {
                @unlink($file);
            }
        }
    }
    return $tokens;
}
