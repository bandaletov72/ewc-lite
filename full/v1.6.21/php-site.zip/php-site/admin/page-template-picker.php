<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$presetLabels = admin_page_template_labels($adminLanguage);
try {
    $pagePresets = admin_page_templates($adminLanguage);
} catch (RuntimeException $exception) {
    $pagePresets = [];
}
?>
<div class="field-wide form-stack" data-page-template-picker data-url="<?= site_escape($adminUrl) ?>"
    data-confirm="<?= site_escape($presetLabels[5]) ?>" data-error="<?= site_escape($presetLabels[6]) ?>" hidden>
    <div class="header-actions">
        <label class="field"><?= site_escape($presetLabels[0]) ?>
            <select data-page-template-select>
                <option value=""><?= site_escape($presetLabels[1]) ?></option>
                <?php foreach ($pagePresets as $presetId => $pagePreset): ?>
                    <option value="<?= site_escape($presetId) ?>"<?= $presetId === admin_input($_GET, 'preset') ? ' selected' : '' ?>><?= site_escape($pagePreset['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <button type="button" data-page-template-apply disabled><?= site_escape($presetLabels[2]) ?></button>
        <a href="<?= site_escape($pageTemplatesUrl) ?>"><?= site_escape($presetLabels[0]) ?></a>
    </div>
    <small class="notice error" data-page-template-status role="alert" hidden></small>
</div>
