<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_maintenance_labels(string $language): array
{
    $keys = ['files', 'generate', 'restore', 'sitemap-page', 'latitude', 'longitude', 'mobile', 'desktop', 'new-template', 'sitemap-error', 'coordinates-error', 'all-maps', 'map-center'];
    $labels = [
        'zh' => ['系统文件', '生成站点地图', '恢复上一版本', '包含在站点地图中', '纬度', '经度', '在移动端显示', '在桌面端显示',
            '添加自定义模板', '请检查 sitemap.xml 中的 XML 和绝对地址。', '请输入两个坐标。纬度为 −90 至 90，经度为 −180 至 180。', '所有地点的地图', '地图中心'],
        'ru' => ['Служебные файлы', 'Сгенерировать карту сайта', 'Восстановить предыдущую версию', 'Показывать в карте сайта', 'Широта', 'Долгота', 'Показывать на мобильных', 'Показывать на компьютерах', 'Добавить свой шаблон', 'Проверьте XML и абсолютные адреса в sitemap.xml.', 'Укажите обе координаты. Широта от −90 до 90, долгота от −180 до 180.', 'Карта всех точек', 'Центр карты'],
        'en' => ['Service files', 'Generate sitemap', 'Restore previous version', 'Include in the sitemap', 'Latitude', 'Longitude', 'Show on mobile', 'Show on desktop', 'Add a custom template', 'Check the XML and the absolute URLs in sitemap.xml.', 'Enter both coordinates. Latitude ranges from −90 to 90 and longitude from −180 to 180.', 'All locations map', 'Map center'],
        'uk' => ['Службові файли', 'Згенерувати карту сайту', 'Відновити попередню версію', 'Показувати в карті сайту', 'Широта', 'Довгота', 'Показувати на мобільних', 'Показувати на комп’ютерах', 'Додати власний шаблон', 'Перевірте XML й абсолютні адреси в sitemap.xml.', 'Вкажіть обидві координати. Широта від −90 до 90, довгота від −180 до 180.', 'Карта всіх точок', 'Центр карти'],
        'ja' => ['設定ファイル', 'サイトマップを生成', '前の版を復元', 'サイトマップに含める', '緯度', '経度', 'モバイルで表示', 'デスクトップで表示', 'カスタムテンプレートを追加', 'sitemap.xml の XML と絶対 URL を確認してください。', '緯度は −90〜90、経度は −180〜180 の範囲で両方入力してください。', '全地点の地図', '地図の中心'],
        'vi' => ['Tệp cấu hình', 'Tạo sơ đồ trang web', 'Khôi phục phiên bản trước', 'Đưa vào sơ đồ trang web', 'Vĩ độ', 'Kinh độ', 'Hiện trên thiết bị di động', 'Hiện trên máy tính', 'Thêm mẫu tùy chỉnh', 'Kiểm tra XML và URL tuyệt đối trong sitemap.xml.', 'Nhập cả hai tọa độ. Vĩ độ từ −90 đến 90 và kinh độ từ −180 đến 180.', 'Bản đồ tất cả địa điểm', 'Tâm bản đồ'],
        'fr' => ['Fichiers de configuration', 'Générer le plan du site', 'Restaurer la version précédente', 'Inclure dans le plan du site', 'Latitude', 'Longitude', 'Afficher sur mobile', 'Afficher sur ordinateur', 'Ajouter un modèle personnalisé', 'Vérifiez le XML et les URL absolues dans sitemap.xml.', 'Saisissez les deux coordonnées. Latitude de −90 à 90 et longitude de −180 à 180.', 'Carte de tous les lieux', 'Centre de la carte'],
        'de' => ['Konfigurationsdateien', 'Sitemap erstellen', 'Vorherige Version wiederherstellen', 'In die Sitemap aufnehmen', 'Breitengrad', 'Längengrad', 'Auf Mobilgeräten anzeigen', 'Auf dem Desktop anzeigen', 'Eigene Vorlage hinzufügen', 'Prüfen Sie das XML und die absoluten URLs in sitemap.xml.', 'Geben Sie beide Koordinaten ein. Breitengrad von −90 bis 90, Längengrad von −180 bis 180.', 'Karte aller Standorte', 'Kartenmittelpunkt'],
        'es' => ['Archivos de configuración', 'Generar mapa del sitio', 'Restaurar la versión anterior', 'Incluir en el mapa del sitio', 'Latitud', 'Longitud', 'Mostrar en móviles', 'Mostrar en ordenadores', 'Añadir una plantilla personalizada', 'Revisa el XML y las URL absolutas de sitemap.xml.', 'Introduce ambas coordenadas. Latitud de −90 a 90 y longitud de −180 a 180.', 'Mapa de todos los puntos', 'Centro del mapa'],
        'pt' => ['Ficheiros de configuração', 'Gerar mapa do site', 'Restaurar a versão anterior', 'Incluir no mapa do site', 'Latitude', 'Longitude', 'Mostrar no telemóvel', 'Mostrar no computador', 'Adicionar modelo personalizado', 'Verifique o XML e os URL absolutos em sitemap.xml.', 'Introduza ambas as coordenadas. Latitude de −90 a 90 e longitude de −180 a 180.', 'Mapa de todos os pontos', 'Centro do mapa'],
        'ko' => ['설정 파일', '사이트맵 생성', '이전 버전 복원', '사이트맵에 포함', '위도', '경도', '모바일에서 표시', '데스크톱에서 표시', '사용자 서식 추가', 'sitemap.xml의 XML과 절대 URL을 확인하세요.', '좌표를 모두 입력하세요. 위도는 −90~90, 경도는 −180~180입니다.', '전체 위치 지도', '지도 중심'],
    ];
    return array_combine($keys, $labels[$language] ?? $labels['ru']);
}
