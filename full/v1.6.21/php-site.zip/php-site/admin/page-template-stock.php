<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

return [
    ['home', 7, 'house', <<<'HTML'
<div class="page-preset">
    <section class="page-preset-hero">
        <h2>[site-name]</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer vitae justo et risus porttitor aliquet.</p>
        [callback]
    </section>
    <div class="page-preset-grid">
        <article class="page-preset-card"><h3>Lorem ipsum</h3><p>Vestibulum ante ipsum primis in faucibus orci luctus.</p></article>
        <article class="page-preset-card"><h3>Dolor sit amet</h3><p>Praesent sed nulla ac neque suscipit fermentum.</p></article>
        <article class="page-preset-card"><h3>Consectetur</h3><p>Donec quis tortor ac mi consequat feugiat.</p></article>
    </div>
    [list-pages]
</div>
HTML
    ],
    ['contact', 8, 'address-card', <<<'HTML'
<div class="page-preset">
    <div class="page-preset-grid">
        <section class="page-preset-card"><h2>[city]</h2><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>[cities][phones][soc-icons]</section>
        <section class="page-preset-card">[form1]</section>
    </div>
    [map]
</div>
HTML
    ],
    ['product', 9, 'tag', <<<'HTML'
<div class="page-preset">
    <div class="page-preset-grid">
        <section class="page-preset-hero">
            <h2>Lorem ipsum</h2><p>Consectetur adipiscing elit. Aliquam erat volutpat.</p>
        </section>
        <section class="page-preset-card">
            <h2>Dolor sit amet</h2>
            <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>
            <div class="page-preset-price">[item-price]</div>
            [item-buy-button]
        </section>
    </div>
</div>
HTML
    ],
    ['about', 10, 'building', <<<'HTML'
<div class="page-preset">
    <section class="page-preset-hero">
        <h2>[site-name]</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis.</p>
    </section>
    <div class="page-preset-grid">
        <section class="page-preset-card"><h3>Vestibulum</h3><p>Nullam id dolor id nibh ultricies vehicula ut id elit.</p></section>
        <section class="page-preset-card"><h3>Phasellus</h3><p>Cras mattis consectetur purus sit amet fermentum.</p>[contacts]</section>
    </div>
</div>
HTML
    ],
    ['section', 11, 'folder-tree', <<<'HTML'
<div class="page-preset">
    <section class="page-preset-card">
        <h2>Lorem ipsum</h2><p>Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
    </section>
    <div class="page-preset-grid">[list-pages]</div>
</div>
HTML
    ],
];
