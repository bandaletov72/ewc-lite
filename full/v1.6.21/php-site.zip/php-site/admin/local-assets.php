<?php
if (!defined('SITE_ROOT')) { http_response_code(404); exit; }

function admin_download_asset(string $url, array $hosts, int $limit, string $agent = 'Eurowebcart-CMS'): string
{
    for ($redirect = 0; $redirect < 4; $redirect++) {
        $parts = parse_url($url);
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || !in_array(strtolower($parts['host'] ?? ''), $hosts, true)
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['port']) || preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
            throw new RuntimeException('Источник файла не входит в список разрешённых CDN.');
        }
        unset($http_response_header);
        $context = stream_context_create(['http' => ['timeout' => 12, 'ignore_errors' => true, 'follow_location' => 0, 'user_agent' => $agent]]);
        $bytes = @file_get_contents($url, false, $context, 0, $limit + 1);
        $headers = $http_response_header ?? [];
        if (preg_match('~\AHTTP/\S+\s+200\b~', $headers[0] ?? '') && is_string($bytes) && strlen($bytes) <= $limit) return $bytes;
        if (!preg_match('~\AHTTP/\S+\s+30[1278]\b~', $headers[0] ?? '')) break;
        $next = '';
        foreach ($headers as $header) {
            if (stripos($header, 'Location:') === 0) { $next = trim(substr($header, 9)); break; }
        }
        $url = isset($next[0]) && $next[0] === '/' && substr($next, 0, 2) !== '//' ? 'https://' . $parts['host'] . $next : $next;
    }
    throw new RuntimeException('Не удалось загрузить файлы. Проверьте HTTPS-соединение сервера.');
}

function admin_localize_font(string $id)
{
    $font = site_google_fonts()[$id] ?? null;
    if ($font === null) throw new RuntimeException('Выберите шрифт Google из списка.');
    $agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
    $css = admin_download_asset('https://fonts.googleapis.com/css2?' . site_google_font_query($font) . '&display=swap', ['fonts.googleapis.com'], 262144, $agent);
    preg_match_all('~@font-face\s*\{([^{}]*)\}~', $css, $matches);
    if (!$matches[1] || count($matches[1]) > 240) throw new RuntimeException('Не удалось прочитать описание шрифта Google.');
    $rules = [];
    $uploads = [];
    $total = 0;
    foreach ($matches[1] as $rule) {
        if (!preg_match('~\burl\((https://fonts\.gstatic\.com/[a-z0-9_./%\-]+\.(woff2?))\)~i', $rule, $src)) continue;
        if (!isset($uploads[$src[1]])) {
            $bytes = admin_download_asset($src[1], ['fonts.gstatic.com'], 2097152, $agent);
            $magic = $src[2] === 'woff2' ? 'wOF2' : 'wOFF';
            if (substr($bytes, 0, 4) !== $magic || ($total += strlen($bytes)) > 12582912) throw new RuntimeException('Проверьте формат и размер файлов шрифта.');
            $uploads[$src[1]] = [hash('sha256', $bytes) . '.' . $src[2], $bytes];
        }
        $declarations = [];
        foreach (['font-weight' => '[1-9][0-9]{2}(?: [1-9][0-9]{2})?', 'font-style' => 'normal|italic',
            'font-stretch' => '[0-9]{1,3}%(?: [0-9]{1,3}%)?', 'unicode-range' => '[Uu][+][0-9A-Fa-f?,+Uu\-\s]+'] as $property => $pattern) {
            if (preg_match('~\b' . $property . ':\s*(' . $pattern . ')\s*;~', $rule, $value)) $declarations[] = $property . ':' . trim($value[1]);
        }
        $rules[] = '@font-face{font-family:"' . ($font[3] ?? $font[0]) . '";font-display:swap;src:url("' . $uploads[$src[1]][0]
            . '") format("' . $src[2] . '");' . implode(';', $declarations) . '}';
    }
    if (!$rules) throw new RuntimeException('Google не вернул файлы WOFF или WOFF2.');
    $lock = admin_lock();
    try {
        admin_make_page_directory('templates/fonts/local/file.css');
        $root = SITE_ROOT . '/templates/fonts/local/';
        foreach ($uploads as list($name, $bytes)) {
            if (is_link($root . $name) || (!is_file($root . $name) && !admin_replace_file($root . $name, $bytes))) {
                throw new RuntimeException('Не удалось сохранить файлы шрифта.');
            }
        }
        if (is_link($root . $id . '.css') || !admin_replace_file($root . $id . '.css', implode("\n", $rules) . "\n")) {
            throw new RuntimeException('Не удалось сохранить локальный шрифт.');
        }
    } finally { fclose($lock); }
}

function admin_save_fonts(array $posted, string $revision)
{
    $profile = site_font_profile($posted);
    $lock = admin_lock();
    try {
        if (!hash_equals(admin_settings_revision(site_font_settings()), $revision)) throw new RuntimeException('Настройки изменились. Откройте раздел заново.');
        admin_write_record(site_content_record(SITE_FONTS_FILE), $profile);
    } finally { fclose($lock); }
}

function admin_local_esm(string $url, string $pack, array &$modules, int &$total): string
{
    $name = hash('sha256', $url) . '.js';
    if (array_key_exists($name, $modules)) return $name;
    if (count($modules) >= 180) throw new RuntimeException('Слишком много зависимостей библиотеки.');
    $source = admin_download_asset($url, ['esm.sh'], 4194304);
    if (($total += strlen($source)) > 20971520 || preg_match('//u', $source) !== 1 || strpos(ltrim($source), '<') === 0) {
        throw new RuntimeException('Проверьте размер и формат модулей библиотеки.');
    }
    $modules[$name] = '';
    $pattern = '~(\bfrom\s*|\bimport\s*(?:\(\s*)?)(["\x27])((?:https://esm\.sh/|/(?!/)|\.{1,2}/)[^"\x27\r\n]+)\2~';
    $source = preg_replace_callback($pattern, static function (array $match) use ($url, $pack, &$modules, &$total): string {
        $specifier = $match[3];
        if ($specifier[0] === '/') $specifier = 'https://esm.sh' . $specifier;
        elseif ($specifier[0] === '.') {
            $requested = explode('?', $specifier, 2);
            $segments = [];
            foreach (explode('/', dirname((string) parse_url($url, PHP_URL_PATH)) . '/' . $requested[0]) as $part) {
                if ($part === '..') array_pop($segments);
                elseif ($part !== '' && $part !== '.') $segments[] = $part;
            }
            $specifier = 'https://esm.sh/' . implode('/', $segments) . (isset($requested[1]) ? '?' . $requested[1] : '');
        }
        $file = admin_local_esm($specifier, $pack, $modules, $total);
        return $match[1] . $match[2] . './local-library.php?pack=' . $pack . '&file=' . $file . $match[2];
    }, $source);
    if (!is_string($source)) throw new RuntimeException('Не удалось обработать зависимости библиотеки.');
    $modules[$name] = preg_replace('~^//[#@] sourceMappingURL=.*$~m', '', $source);
    return $name;
}

function admin_localize_library(string $id)
{
    $library = site_active_libraries()[$id] ?? null;
    if ($library === null || site_library_bundled($id, $library)) throw new RuntimeException('Выберите библиотеку из списка.');
    $pack = site_local_library_pack($id, $library);
    $assets = [];
    $manifest = [];
    foreach (['css', 'js'] as $type) {
        if (!isset($library[$type])) continue;
        list($url, $expected) = $library[$type];
        $bytes = admin_download_asset($url, ['code.jquery.com', 'cdn.jsdelivr.net'], 4194304);
        if (!hash_equals($expected, base64_encode(hash('sha384', $bytes, true)))) throw new RuntimeException('Контрольная сумма файла библиотеки не совпала.');
        $name = hash('sha256', $bytes) . '.' . $type;
        $assets[$name] = $bytes;
        $manifest[$type] = $name;
    }
    if ($id === 'mui') {
        @set_time_limit(180);
        $total = 0;
        foreach (site_material_imports($library)['imports'] as $name => $url) {
            $url .= (strpos($url, '?') === false ? '?' : '&') . 'bundle&target=es2022';
            $manifest['imports'][$name] = admin_local_esm($url, $pack, $assets, $total);
        }
    }
    if (!$assets) throw new RuntimeException('Для этой версии библиотеки нет файлов для скачивания.');
    $lock = admin_lock();
    try {
        $relative = 'templates/vendor/local/' . $pack;
        admin_make_page_directory($relative . '/manifest.json');
        $root = SITE_ROOT . '/' . $relative . '/';
        foreach ($assets as $name => $bytes) {
            if (is_link($root . $name) || !admin_replace_file($root . $name, $bytes)) throw new RuntimeException('Не удалось сохранить файлы библиотеки.');
        }
        if (is_link($root . 'manifest.json') || !admin_replace_file($root . 'manifest.json', (string) json_encode($manifest))) {
            throw new RuntimeException('Не удалось сохранить настройки локальной библиотеки.');
        }
    } finally { fclose($lock); }
}
