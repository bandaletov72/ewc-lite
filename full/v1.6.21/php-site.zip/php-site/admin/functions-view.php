<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1><?= admin_l('Функции') ?></h1>
<?php try { list($code, $revision) = ew_function_source(); } catch (RuntimeException $exception) {
    $code = null;
    echo '<p class="notice error" role="alert">' . admin_l($exception->getMessage()) . '</p>';
} ?>
<?php if ($code !== null): ?>
    <form method="post" action="<?= site_escape($functionsUrl) ?>" class="panel form-stack">
        <h2><code>functions.php</code></h2>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="action" value="save-functions">
        <input type="hidden" name="revision" value="<?= site_escape($revision) ?>">
        <p><?= admin_l('Добавляйте именованные функции в массив. Их можно вызывать из PHP-шаблонов, модулей и содержимого страниц.') ?></p>
        <pre><code><?= site_escape("\$var = translit(\"Москва\"); // Moskva\new_call('translit', 'Москва и München');\n[func=translit value=\"Москва и München\"]") ?></code></pre>
        <label class="field"><?= admin_l('Исходный код') ?>
            <textarea name="code" data-code-mode="php" class="short-editor" rows="18" spellcheck="false" required><?= "\n" . site_escape($error !== '' && isset($_POST['code']) ? admin_input($_POST, 'code') : $code) ?></textarea>
        </label>
        <div><button class="button-primary"><?= admin_l('Сохранить код') ?></button></div>
    </form>
<?php endif; ?>
