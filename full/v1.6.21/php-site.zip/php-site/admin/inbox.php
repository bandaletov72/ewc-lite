<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_inbox_page(string $directory, string $number): array
{
    $ids = [];
    foreach (glob($directory . '/*.php') ?: [] as $file) {
        $id = basename($file, '.php');
        if (preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id)) {
            $ids[$id] = !is_file($directory . '/.read-' . $id . '.php');
        }
    }
    krsort($ids, SORT_STRING);
    $unread = array_filter($ids);
    $sorted = $unread + array_diff_key($ids, $unread);
    $total = max(1, (int) ceil(count($sorted) / 20));
    $page = max(1, min($total, (int) $number));
    return ['all' => $ids, 'rows' => array_slice($sorted, ($page - 1) * 20, 20, true), 'page' => $page, 'total' => $total];
}

function admin_mark_inbox_read(string $directory, string $id)
{
    $file = $directory . '/.read-' . $id . '.php';
    if (!is_file($file)) {
        admin_write_record($file, ['read' => true]);
    }
}

function admin_inbox_pager(array $pagination, string $url)
{
    if ($pagination['total'] <= 1) {
        return;
    }
    $page = $pagination['page'];
    ?>
    <nav class="site-menu" aria-label="<?= admin_l('Страницы заявок') ?>">
        <?php if ($page > 1): ?><a href="<?= site_escape($url . '&inbox_page=' . ($page - 1)) ?>"><?= admin_l('Назад') ?></a><?php endif; ?>
        <span><?= site_escape(strtr(admin_t('Страница {page} из {total}'), [
            '{page}' => (string) $page, '{total}' => (string) $pagination['total'],
        ])) ?></span>
        <?php if ($page < $pagination['total']): ?><a href="<?= site_escape($url . '&inbox_page=' . ($page + 1)) ?>"><?= admin_l('Далее') ?></a><?php endif; ?>
    </nav>
    <?php
}

function admin_inbox_date(string $id): string
{
    $date = DateTimeImmutable::createFromFormat('!YmdHis', substr($id, 0, 14), new DateTimeZone('UTC'));
    $regional = site_region_settings();
    return $date === false ? '' : $date->setTimezone(new DateTimeZone(date_default_timezone_get()))
        ->format($regional['date'] . ' ' . $regional['time']);
}
