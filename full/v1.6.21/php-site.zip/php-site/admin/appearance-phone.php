<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$prefix = 'phones[' . $index . ']';
?>
<fieldset class="field-config form-stack" data-phone-row>
    <legend><?= admin_l('Телефон') ?></legend>
    <div class="fields">
        <label class="field"><?= admin_l('Номер') ?>
            <input type="tel" name="<?= $prefix ?>[number]" maxlength="33" value="<?= site_escape($phone['number']) ?>" placeholder="+7(903)123-45-67">
        </label>
        <label class="field"><?= admin_l('Подпись ссылки') ?>
            <input name="<?= $prefix ?>[text]" maxlength="375" value="<?= site_escape($phone['text']) ?>" placeholder="<?= admin_l('Позвонить') ?>">
        </label>
    </div>
    <div><button type="button" data-remove-phone><?= admin_l('Удалить телефон') ?></button></div>
</fieldset>
