<?php if (!defined('SITE_ROOT')) exit;

function admin_page_sale(array $input, string $path): string
{
    $stored = site_read_page($path);
    $parsed = site_sale_decode($stored['fields']['Sale'] ?? '') ?? ['offers' => []];
    $offers = $parsed['offers'];
    $show = admin_input($input, 'enabled') === '1';
    $notices = admin_input($input, 'notices');
    if (!in_array($notices, SITE_SALE_NOTICES, true)) throw new RuntimeException('Выберите способ отправки статусов заказа.');
    $rows = is_array($input['offers'] ?? null) ? $input['offers'] : [];
    foreach (array_merge(['default'], site_region_settings()['languages']) as $code) {
        if (!is_array($rows[$code] ?? null)) continue;
        unset($offers[$code]);
        $row = $rows[$code];
        $price = admin_input($row, 'amount');
        if (trim($price) === '') continue;
        $amount = site_sale_amount($price);
        $currency = admin_input($row, 'currency');
        if ($code === 'default') $currency = '';
        $method = admin_input($row, 'method');
        $target = trim(admin_input($row, 'target'));
        if ($amount === '' || ($currency !== '' && !isset(site_region_options()['currency'][$currency]))) {
            throw new RuntimeException('Укажите положительную цену с точностью до двух знаков и выберите валюту.');
        }
        $effectiveCurrency = $currency ?: site_region_settings()['currency'];
        if (($show || $target !== '') && !site_sale_target($method, $target, $effectiveCurrency)) {
            throw new RuntimeException('Для каждой цены укажите подходящий адрес оплаты или рублёвый кошелёк ЮMoney.');
        }
        $offers[$code] = compact('amount', 'currency', 'method', 'target');
    }
    if ($show && !$offers) throw new RuntimeException('Чтобы показать кнопку покупки, укажите цену и способ оплаты.');
    if (!$show && $notices === 'off' && !$offers) return '';
    $json = json_encode(['enabled' => $show, 'notices' => $notices, 'offers' => $offers], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) throw new RuntimeException('Проверьте настройки продажи.');
    return base64_encode($json);
}

function admin_change_purchase_status(string $id, string $state, string $revision)
{
    if (!in_array($state, SITE_PURCHASE_STATES, true)) throw new RuntimeException('Выберите статус покупки.');
    $lock = admin_lock();
    try {
        $record = site_read_purchase($id);
        if (!$record || !hash_equals(admin_settings_revision($record), $revision)) {
            throw new RuntimeException('Данные покупки изменились. Обновите список.');
        }
        if ($record['state'] === $state) return;
        $record['state'] = $state;
        $record['updated'] = gmdate('c');
        $record['event'] = bin2hex(random_bytes(8));
        unset($record['delivery']);
        admin_write_record(site_purchase_path($id), $record);
    } finally {
        fclose($lock);
    }
    site_schedule_purchase_notice($id, $record);
}
