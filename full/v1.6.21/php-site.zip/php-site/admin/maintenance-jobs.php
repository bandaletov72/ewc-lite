<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_JOBS_CONFIG = SITE_ROOT . '/admin/.maintenance-jobs.php';
const SITE_JOBS_STATE = SITE_ROOT . '/admin/.maintenance-state.php';

function admin_jobs_settings(): array
{
    try {
        $settings = site_read_record(SITE_JOBS_CONFIG);
    } catch (RuntimeException $exception) {
        $settings = [];
    }
    $hours = (int) ($settings['updates'] ?? 0);
    return ['updates' => in_array($hours, [1, 6, 12, 24], true) ? $hours : 0,
        'index' => ($settings['index'] ?? false) === true];
}

function admin_save_jobs(array $input)
{
    $hours = $input['updates'] ?? '';
    if (!in_array($hours, ['0', '1', '6', '12', '24'], true)) {
        throw new RuntimeException('Выберите период обновления из списка.');
    }
    $lock = admin_lock();
    try {
        admin_write_record(SITE_JOBS_CONFIG, ['updates' => (int) $hours, 'index' => ($input['index'] ?? '') === '1']);
    } finally {
        fclose($lock);
    }
}

function admin_run_scheduled_jobs(): array
{
    $jobs = admin_jobs_settings();
    if ($jobs['updates'] === 0 && !$jobs['index']) {
        return [];
    }
    $path = SITE_ROOT . '/admin/.maintenance-lock.php';
    $lock = !is_link($path) ? @fopen($path, 'c+b') : false;
    if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
        if (is_resource($lock)) {
            fclose($lock);
            return [];
        }
        throw new RuntimeException('Не удалось открыть блокировку обслуживания.');
    }
    try {
        $state = site_read_record(SITE_JOBS_STATE);
        $now = time();
        $messages = [];
        if ($jobs['index'] && $now - ($state['index'] ?? 0) >= 900) {
            $files = admin_lock();
            try {
                $messages[] = 'Страниц в индексе — ' . admin_rebuild_search();
                $state['index'] = $now;
            } finally {
                fclose($files);
            }
            admin_write_record(SITE_JOBS_STATE, $state);
        }
        if ($jobs['updates'] && $now - ($state['update'] ?? 0) >= $jobs['updates'] * 3600) {
            $state['update'] = $now;
            admin_write_record(SITE_JOBS_STATE, $state);
            $messages[] = site_update_from_github();
        }
        return $messages;
    } finally {
        fclose($lock);
    }
}
