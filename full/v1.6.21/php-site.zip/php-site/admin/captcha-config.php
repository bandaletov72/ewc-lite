<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_save_captcha(array $submitted)
{
    $lock = admin_lock();
    try {
        $current = site_global_captcha();
        $settings = ['enabled' => admin_input($submitted, 'enabled') === '1',
            'sitekey' => trim(admin_input($submitted, 'sitekey')),
            'secret' => trim(admin_input($submitted, 'secret')) ?: $current['secret']];
        foreach (['sitekey', 'secret'] as $key) {
            if (($settings['enabled'] || $settings[$key] !== '') && !site_valid_captcha_key($settings[$key])) {
                throw new RuntimeException(admin_l('Проверьте ключ сайта и секретный ключ reCAPTCHA v2.'));
            }
        }
        admin_write_record(SITE_CAPTCHA_FILE, $settings);
    } finally {
        fclose($lock);
    }
}
