<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$editorId = 'html';
$editorName = 'html';
$editorValue = $page['html'];
$editorTitle = admin_t('Содержимое страницы');
$editorWithComponents = true;
$editorWithMedia = true;
require __DIR__ . '/content-editor.php';
