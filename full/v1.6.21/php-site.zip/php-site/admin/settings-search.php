<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$query = site_search_query($_GET['q'] ?? '');
$matches = admin_find_settings($query, $adminUrl, $adminLanguage);
?>
<h1><?= admin_l('Поиск настроек') ?></h1>
<section class="panel" aria-live="polite">
    <?php if ($query === ''): ?>
        <p><?= admin_l('Введите запрос.') ?></p>
    <?php elseif (!$matches): ?>
        <p><?= admin_l('Ничего не найдено.') ?></p>
    <?php else: ?>
        <ul class="page-list">
            <?php foreach ($matches as $item): ?>
                <li><a href="<?= site_escape($item['url']) ?>"><?= site_escape($item['title']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>
