<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_editor_labels(string $language): array
{
    $keys = ['underline', 'strike', 'numbered', 'heading', 'template', 'component', 'image', 'icon', 'alt', 'system-icons'];
    $translations = [
        'zh' => ['下划线', '删除线', '编号列表', '标题', '插入模板', '插入组件', '插入图片', '插入图标', '图片说明', '网站图标'],
        'ru' => ['Подчёркнутый', 'Зачёркнутый', 'Нумерованный список', 'Заголовок', 'Вставить шаблон', 'Вставить компонент', 'Вставить изображение', 'Вставить иконку', 'Описание изображения', 'Иконки сайта'],
        'en' => ['Underline', 'Strikethrough', 'Numbered list', 'Heading', 'Insert template', 'Insert component', 'Insert image', 'Insert icon', 'Image description', 'Site icons'],
        'uk' => ['Підкреслений', 'Закреслений', 'Нумерований список', 'Заголовок', 'Вставити шаблон', 'Вставити компонент', 'Вставити зображення', 'Вставити іконку', 'Опис зображення', 'Іконки сайту'],
        'ja' => ['下線', '取り消し線', '番号付きリスト', '見出し', 'テンプレートを挿入', 'コンポーネントを挿入', '画像を挿入', 'アイコンを挿入', '画像の説明', 'サイトのアイコン'],
        'vi' => ['Gạch dưới', 'Gạch ngang', 'Danh sách đánh số', 'Tiêu đề', 'Chèn mẫu', 'Chèn thành phần', 'Chèn ảnh', 'Chèn biểu tượng', 'Mô tả ảnh', 'Biểu tượng trang web'],
        'fr' => ['Souligné', 'Barré', 'Liste numérotée', 'Titre', 'Insérer un modèle', 'Insérer un composant', 'Insérer une image', 'Insérer une icône', 'Description de l’image', 'Icônes du site'],
        'de' => ['Unterstrichen', 'Durchgestrichen', 'Nummerierte Liste', 'Überschrift', 'Vorlage einfügen', 'Komponente einfügen', 'Bild einfügen', 'Symbol einfügen', 'Bildbeschreibung', 'Website-Symbole'],
        'es' => ['Subrayado', 'Tachado', 'Lista numerada', 'Encabezado', 'Insertar plantilla', 'Insertar componente', 'Insertar imagen', 'Insertar icono', 'Descripción de la imagen', 'Iconos del sitio'],
        'pt' => ['Sublinhado', 'Rasurado', 'Lista numerada', 'Título', 'Inserir modelo', 'Inserir componente', 'Inserir imagem', 'Inserir ícone', 'Descrição da imagem', 'Ícones do site'],
        'ko' => ['밑줄', '취소선', '번호 매기기', '제목', '서식 삽입', '컴포넌트 삽입', '이미지 삽입', '아이콘 삽입', '이미지 설명', '사이트 아이콘'],
    ];
    return array_combine($keys, $translations[$language] ?? $translations['ru']);
}

function admin_page_menu_labels(string $language): array
{
    $labels = [
        'ru' => ['Как в основном меню', 'Укажите родительский раздел', 'URL перехода (необязательно)', 'Укажите другой адрес на сайте или полный URL с http:// или https://.'],
        'en' => ['Same as the main menu', 'Choose a parent section', 'Redirect URL (optional)', 'Enter a different local path or a full HTTP or HTTPS URL.'],
        'uk' => ['Як в основному меню', 'Виберіть батьківський розділ', 'URL переходу (необов’язково)', 'Вкажіть іншу адресу на сайті або повний URL з HTTP чи HTTPS.'],
        'ja' => ['メインメニューと同じ', '親セクションを選択', '転送先 URL（任意）', '別のサイト内パス、または完全な HTTP・HTTPS URL を入力してください。'],
        'vi' => ['Giống menu chính', 'Chọn mục cha', 'URL chuyển hướng (tùy chọn)', 'Nhập đường dẫn nội bộ khác hoặc URL HTTP hoặc HTTPS đầy đủ.'],
        'fr' => ['Comme dans le menu principal', 'Choisissez la section parente', 'URL de redirection (facultative)', 'Saisissez un autre chemin local ou une URL HTTP ou HTTPS complète.'],
        'de' => ['Wie im Hauptmenü', 'Übergeordneten Bereich wählen', 'Weiterleitungs-URL (optional)', 'Geben Sie einen anderen lokalen Pfad oder eine vollständige HTTP- oder HTTPS-URL ein.'],
        'es' => ['Igual que el menú principal', 'Elige la sección superior', 'URL de redirección (opcional)', 'Introduce otra ruta del sitio o una URL HTTP o HTTPS completa.'],
        'pt' => ['Como no menu principal', 'Escolha a secção superior', 'URL de redirecionamento (opcional)', 'Introduza outro caminho local ou um URL HTTP ou HTTPS completo.'],
        'ko' => ['기본 메뉴와 동일', '상위 섹션 선택', '이동할 URL(선택 사항)', '다른 사이트 내부 경로나 전체 HTTP 또는 HTTPS URL을 입력하세요.'],
    ];
    return array_combine(['inherit-menu', 'parent-folder', 'redirect', 'redirect-error'], $labels[$language] ?? $labels['ru']);
}

function admin_route_labels(string $language): array
{
    $labels = [
        'ru' => ['Редиректы', 'Правила по одному на строку', 'Страницы ошибок'],
        'en' => ['Redirects', 'One rule per line', 'Error pages'],
        'uk' => ['Перенаправлення', 'Одне правило на рядок', 'Сторінки помилок'],
        'ja' => ['リダイレクト', '1 行につき 1 ルール', 'エラーページ'],
        'vi' => ['Chuyển hướng', 'Mỗi dòng một quy tắc', 'Trang lỗi'],
        'fr' => ['Redirections', 'Une règle par ligne', 'Pages d’erreur'],
        'de' => ['Weiterleitungen', 'Eine Regel pro Zeile', 'Fehlerseiten'],
        'es' => ['Redirecciones', 'Una regla por línea', 'Páginas de error'],
        'pt' => ['Redirecionamentos', 'Uma regra por linha', 'Páginas de erro'],
        'ko' => ['리디렉션', '한 줄에 규칙 하나', '오류 페이지'],
    ];
    return array_combine(['redirects', 'redirect-rules', 'error-pages'], $labels[$language] ?? $labels['ru']);
}

function admin_root_folder_label(string $language): string
{
    $labels = ['ru' => 'Корневая папка', 'en' => 'Root folder', 'uk' => 'Коренева папка', 'ja' => 'ルートフォルダー', 'vi' => 'Thư mục gốc',
        'fr' => 'Dossier racine', 'de' => 'Stammordner', 'es' => 'Carpeta raíz', 'pt' => 'Pasta raiz', 'ko' => '루트 폴더'];
    return $labels[$language] ?? $labels['ru'];
}

function admin_page_visibility_labels(string $language): array
{
    $labels = [
        'ru' => ['Показывать в основном меню', 'Показывать в мобильном меню', 'Скрыть в мобильном меню'],
        'en' => ['Show in the main menu', 'Show in the mobile menu', 'Hide in the mobile menu'],
        'uk' => ['Показувати в основному меню', 'Показувати в мобільному меню', 'Приховати в мобільному меню'],
        'ja' => ['メインメニューに表示', 'モバイルメニューに表示', 'モバイルメニューで非表示'],
        'vi' => ['Hiện trong menu chính', 'Hiện trong menu di động', 'Ẩn trong menu di động'],
        'fr' => ['Afficher dans le menu principal', 'Afficher dans le menu mobile', 'Masquer dans le menu mobile'],
        'de' => ['Im Hauptmenü anzeigen', 'Im Mobilmenü anzeigen', 'Im Mobilmenü ausblenden'],
        'es' => ['Mostrar en el menú principal', 'Mostrar en el menú móvil', 'Ocultar en el menú móvil'],
        'pt' => ['Mostrar no menu principal', 'Mostrar no menu móvel', 'Ocultar no menu móvel'],
        'ko' => ['기본 메뉴에 표시', '모바일 메뉴에 표시', '모바일 메뉴에서 숨기기'],
    ];
    return $labels[$language] ?? $labels['ru'];
}
