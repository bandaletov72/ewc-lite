<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_iblock_shortcode(string $name): string
{
    $view = $name === 'chart-demo' ? 'charts' : ($name === 'kontur-works' ? 'portfolio' : 'table');
    return '[iblock=' . $view . ']/data/' . $name . '.txt[iblock]';
}

function admin_iblock_names(): array
{
    $names = [];
    foreach (glob(site_content_data_directory() . '/*.txt.php') ?: [] as $file) {
        $name = basename($file, '.txt.php');
        if (site_valid_iblock_name($name)) {
            $names[] = $name;
        }
    }
    return $names;
}

function admin_iblock_draft(array $posted): array
{
    $columns = [];
    $keys = [];
    foreach (is_array($posted['columns'] ?? null) ? $posted['columns'] : [] as $index => $column) {
        if (!is_array($column)) {
            continue;
        }
        $keys[] = $index;
        $columns[] = [
            'key' => admin_input($column, 'key'),
            'label' => trim(admin_input($column, 'label')),
            'type' => admin_input($column, 'type'),
        ];
    }
    $rows = [];
    foreach (is_array($posted['rows'] ?? null) ? $posted['rows'] : [] as $row) {
        if (!is_array($row)) {
            continue;
        }
        $values = [];
        foreach ($keys as $index) {
            $values[] = admin_input($row, (string) $index);
        }
        $rows[] = $values;
    }
    return ['columns' => $columns, 'rows' => $rows];
}

function admin_validate_cell(string $value, string $type): bool
{
    if ($value === '') {
        return true;
    }
    if (strlen($value) > 12000 || preg_match('//u', $value) !== 1
        || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)
        || ($type !== 'textarea' && preg_match('/[\r\n]/', $value))) {
        return false;
    }

    switch ($type) {
        case 'number':
            return preg_match('/\A[+-]?(?:[0-9]+(?:[.,][0-9]+)?|[.,][0-9]+)\z/', $value) === 1;
        case 'price':
            return preg_match('/\A[0-9]{1,15}(?:[.,][0-9]{1,2})?\z/', $value) === 1;
        case 'date':
            return preg_match('/\A([0-9]{4})-([0-9]{2})-([0-9]{2})\z/', $value, $date) === 1
                && checkdate((int) $date[2], (int) $date[3], (int) $date[1]);
        case 'tel':
            return site_valid_phone($value);
        case 'email':
            return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
        case 'url':
            return preg_match('~\Ahttps?://~i', $value) === 1 && filter_var($value, FILTER_VALIDATE_URL) !== false;
        case 'bool':
            return $value === '0' || $value === '1';
    }
    return true;
}

function admin_save_iblock(string $id, array $block, string $revision): string
{
    if (!site_valid_iblock_name($id)) {
        if (preg_match('/\A' . SITE_IDENTIFIER_PATTERN . '\z/', $id) === 1) {
            throw new RuntimeException('Это имя зарезервировано системой. Укажите другое имя инфоблока.');
        }
        throw new RuntimeException('Имя инфоблока должно содержать от 1 до 64 символов A–Z, a–z, 0–9, дефисов или подчёркиваний. Без пробелов.');
    }
    if (!$block['columns']) {
        throw new RuntimeException('Добавьте хотя бы один столбец.');
    }

    $types = site_iblock_types();
    $used = [];
    foreach ($block['columns'] as $column) {
        if (!preg_match('/\A' . SITE_IDENTIFIER_PATTERN . '\z/', $column['key'])) {
            throw new RuntimeException('Ключ столбца должен содержать от 1 до 64 символов A–Z, a–z, 0–9, дефисов или подчёркиваний. Без пробелов.');
        }
        if (isset($used[$column['key']])) {
            throw new RuntimeException('Ключи столбцов должны быть уникальными.');
        }
        if (!admin_valid_form_label($column['label']) || !isset($types[$column['type']])) {
            throw new RuntimeException('Укажите название и тип каждого столбца.');
        }
        $used[$column['key']] = true;
    }
    foreach ($block['rows'] as $rowIndex => &$row) {
        foreach ($block['columns'] as $index => $column) {
            $value = $column['type'] === 'textarea'
                ? str_replace(["\r\n", "\r"], "\n", $row[$index])
                : trim($row[$index]);
            if (!admin_validate_cell($value, $column['type'])) {
                throw new RuntimeException('Проверьте значение. Строка ' . ($rowIndex + 1) . ', столбец «' . $column['label'] . '».');
            }
            $row[$index] = $column['type'] === 'price' ? str_replace(',', '.', $value) : $value;
        }
    }
    unset($row);

    $lock = admin_lock();
    try {
        $file = site_iblock_file($id);
        $current = site_read_iblock($id);
        $expected = file_exists($file) ? admin_settings_revision($current) : '';
        if (!hash_equals($expected, $revision)) {
            throw new RuntimeException('Инфоблок уже существует или был изменён. Скопируйте правки и откройте его заново.');
        }
        admin_write_payload($file, site_iblock_csv($block), SITE_IBLOCK_LIMIT);
        return admin_settings_revision($block);
    } finally {
        fclose($lock);
    }
}
