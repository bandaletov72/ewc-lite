<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }
$fontsUi = site_appearance_labels($adminLanguage);
$selectedFonts = site_font_settings();
$fontOptions = site_font_options();
$googleFonts = site_google_fonts();
$samples = site_language_samples();
?>
<h1><?= site_escape($fontsUi[1]) ?></h1>
<p class="hint"><?= site_escape($fontsUi[8]) ?></p>
<form class="panel form-stack" method="post" action="<?= site_escape($fontsUrl) ?>" data-font-settings>
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($selectedFonts)) ?>">
    <div class="fields" data-font-preview-controls>
        <label class="field"><?= admin_l('Язык') ?>
            <select data-font-preview-language>
                <?php foreach (site_languages() as $code => $language): ?>
                    <option value="<?= $code ?>" data-sample="<?= site_escape($samples[$code]) ?>"<?= $code === $adminLanguage ? ' selected' : '' ?>><?= site_escape($language) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="field"><?= admin_l('Фраза для предпросмотра') ?>
            <input data-font-preview-text maxlength="120" value="<?= site_escape($samples[$adminLanguage]) ?>">
        </label>
    </div>
    <div class="fields">
        <?php foreach (SITE_FONT_ROLES as $index => $role): ?>
            <label class="field"><?= site_escape($fontsUi[$index + 3]) ?>
                <select name="roles[<?= $role ?>]" data-font-role>
                    <option value=""><?= admin_l('Системный') ?></option>
                    <?php foreach ($fontOptions as $id => $font): ?>
                        <option value="<?= $id ?>" class="font-preview-<?= $id ?>"<?= $id === $selectedFonts['roles'][$role] ? ' selected' : '' ?>><?= site_escape($font[0]) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endforeach; ?>
    </div>
    <div><button class="button-primary" name="action" value="save-fonts" type="submit"><?= admin_l('Сохранить') ?></button></div>
    <?php foreach (['Google Fonts' => $googleFonts, admin_t('Системный') => array_diff_key($fontOptions, $googleFonts)] as $sectionName => $fonts): ?>
        <details class="field-config disclosure-panel"<?= $sectionName === 'Google Fonts' ? ' open' : '' ?>>
            <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= site_escape($sectionName) ?></summary>
            <?php foreach ($fonts as $id => $font): ?>
                <div class="font-config-row">
                    <label class="choice">
                        <input type="checkbox" name="enabled[]" value="<?= $id ?>"<?= in_array($id, $selectedFonts['enabled'], true) ? ' checked' : '' ?>>
                        <span class="font-preview-<?= $id ?>"><strong><?= site_escape($font[0]) ?></strong><span class="font-sample" data-font-sample><?= site_escape($samples[$adminLanguage]) ?></span></span>
                    </label>
                    <?php if (isset($googleFonts[$id])): ?>
                        <?php if (site_local_font($base, $id) !== ''): ?>
                            <span class="hint">✓ <?= site_escape($fontsUi[7]) ?></span>
                        <?php else: ?>
                            <button name="action" value="localize-font:<?= $id ?>" type="submit" formnovalidate><?= site_escape($fontsUi[6]) ?></button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </details>
    <?php endforeach; ?>
</form>
