<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PAGE_TEMPLATES_FILE = SITE_ROOT . '/admin/.page-templates.php';
const SITE_PAGE_TEMPLATES_LIMIT = 2097152;

function admin_page_template_labels(string $language): array
{
    static $labels;
    if ($labels === null) $labels = require SITE_ROOT . '/app/help-page-templates.php';
    return $labels[$language] ?? $labels['ru'];
}

function admin_page_templates(string $language): array
{
    $labels = admin_page_template_labels($language);
    $stock = require __DIR__ . '/page-template-stock.php';
    $templates = [];
    foreach ($stock as list($id, $index, $icon, $html)) {
        $templates[$id] = [
            'name' => $labels[$index], 'icon' => $icon, 'html' => $html,
            'Title' => $labels[$index] . ' | [site-name]', 'Heading' => $labels[$index], 'Description' => '',
            'assets' => ['CSS' => '', 'JS' => ''],
        ];
    }
    $saved = site_read_record(SITE_PAGE_TEMPLATES_FILE, SITE_PAGE_TEMPLATES_LIMIT);
    foreach ($saved as $id => $record) {
        if (!is_string($id) || preg_match('/\Acustom-[a-f0-9]{16}\z/', $id) !== 1 || !is_array($record)) continue;
        foreach (['name', 'html', 'Title', 'Heading', 'Description'] as $field) {
            if (!is_string($record[$field] ?? null)) continue 2;
        }
        $assets = [];
        foreach (['CSS', 'JS'] as $kind) {
            $value = $record['assets'][$kind] ?? '';
            $assets[$kind] = is_string($value) ? $value : '';
        }
        $templates[$id] = ['icon' => 'file-code', 'assets' => $assets] + $record;
    }
    return $templates;
}

function admin_page_template_draft(array $input): array
{
    $draft = [];
    foreach (['name', 'Title', 'Heading', 'Description'] as $field) {
        $draft[$field] = trim(admin_input($input, $field));
    }
    $draft['html'] = admin_input($input, 'html');
    foreach (['CSS', 'JS'] as $kind) {
        $draft['assets'][$kind] = is_array($input['assets'] ?? null) ? admin_input($input['assets'], $kind) : '';
    }
    return $draft;
}

function admin_save_page_template(string $id, array $draft, string $revision)
{
    $metadata = $draft;
    unset($metadata['html'], $metadata['assets']);
    foreach ($metadata as $text) {
        if (strlen($text) > 1500 || preg_match('/\A[^\p{Cc}]*\z/u', $text) !== 1) {
            throw new RuntimeException('Проверьте длину и формат полей настроек.');
        }
    }
    if ($draft['name'] === '' || $draft['Title'] === '' || strlen($draft['name']) > 480
        || strlen($draft['html']) > 262144 || strpos($draft['html'], "\0") !== false
        || preg_match('//u', $draft['html']) !== 1 || preg_match('/<\?(?:php|=)?/i', $draft['html'])) {
        throw new RuntimeException('Проверьте длину и формат полей настроек.');
    }
    foreach ($draft['assets'] as $code) admin_encode_asset($code);
    $lock = admin_lock();
    try {
        $templates = site_read_record(SITE_PAGE_TEMPLATES_FILE, SITE_PAGE_TEMPLATES_LIMIT);
        if (!hash_equals(admin_settings_revision($templates), $revision)) {
            throw new RuntimeException('Настройки изменились. Скопируйте правки и откройте раздел заново.');
        }
        if ($id !== 'new' && (preg_match('/\Acustom-[a-f0-9]{16}\z/', $id) !== 1 || !isset($templates[$id]))) {
            throw new RuntimeException('Страница не найдена.');
        }
        $id = $id === 'new' ? 'custom-' . bin2hex(random_bytes(8)) : $id;
        $templates[$id] = $draft;
        admin_write_record(SITE_PAGE_TEMPLATES_FILE, $templates, SITE_PAGE_TEMPLATES_LIMIT);
        return $id;
    } finally {
        fclose($lock);
    }
}
