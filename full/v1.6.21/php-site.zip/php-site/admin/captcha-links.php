<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<p class="hint"><?= admin_l('Зарегистрируйте домен и выберите reCAPTCHA v2 с флажком. Скопируйте ключ сайта и секретный ключ.') ?>
    <a href="https://www.google.com/recaptcha/admin/create" target="_blank" rel="noopener noreferrer"><?= admin_l('Кабинет Google reCAPTCHA') ?></a> ·
    <a href="https://developers.google.com/recaptcha/docs/settings" target="_blank" rel="noopener noreferrer"><?= admin_l('Документация') ?></a>
</p>
