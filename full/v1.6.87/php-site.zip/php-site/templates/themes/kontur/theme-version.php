<?php http_response_code(404); exit; __halt_compiler();
{"version":"1.0.0","pagesVersion":"1.0.0"}
