<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php
$dezItems = site_navigation_menu_tree(site_page_tree($navigation ?? []));
$dezCategoryOrder = array_flip([
    'dezinsekciya', 'dezinfekciya', 'deratizaciya', 'dezinfekciya/dezodoraciya', 'kompleksnye', 'biznes',
    'uhod-za-uchastkom', 'obrabotka-derevev', 'posle-zatopleniya', 'posle-pozhara',
]);
$dezVisible = array_column($navigation ?? [], null, 'path');
$dezLabel = static function (array $entry) use ($snippets): string {
    return site_expand_text($entry['fields']['Menu'] ?: $entry['fields']['Title'], $snippets);
};
$dezLink = static function (array $entry, bool $home = false, bool $icon = false) use ($base, $originalPath, $dezLabel): string {
    $label = $dezLabel($entry);
    $name = $home ? '<i class="fa-solid fa-house" aria-hidden="true"></i><span class="dz-visually-hidden">'
        . site_escape($label) . '</span>' : ($icon ? site_page_menu_label($label, $entry, $base) : site_escape($label));
    return '<a href="' . site_escape(site_page_link($base, $entry)) . '"'
        . ($originalPath === $entry['path'] ? ' aria-current="page"' : '') . '>' . $name . '</a>';
};
$dezLinks = static function (array $entries) use (&$dezLinks, $dezLink): void {
    echo '<ul class="dz-mega-links">';
    foreach ($entries as $entry) {
        echo '<li>' . $dezLink($entry['page']);
        if ($entry['children']) $dezLinks($entry['children']);
        echo '</li>';
    }
    echo '</ul>';
};
?>
<div class="container dz-desktop">
    <nav class="dz-nav" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
        <?php foreach ($dezItems as $dezItem): ?>
            <?php $dezEntry = $dezItem['page']; ?>
            <?php if (!$dezItem['children']): ?>
                <?= $dezLink($dezEntry, $dezEntry['path'] === 'index.php') ?>
            <?php elseif ($dezEntry['path'] === 'services/index.php'): ?>
                <?php
                $dezGroups = $dezItem['children'];
                $dezDeodorization = $dezVisible['services/dezinfekciya/dezodoraciya/index.php'] ?? null;
                if ($dezDeodorization !== null) {
                    $dezDeodorization['fields']['Order'] = '30';
                    if ($dezDeodorization['fields']['AnnouncementIcon'] === '') {
                        $dezDeodorization['fields']['AnnouncementIcon'] = '[fa-icon=wind]';
                    }
                    if (!in_array($dezDeodorization['path'], array_column(array_column($dezGroups, 'page'), 'path'), true)) {
                        $dezGroups[] = ['page' => $dezDeodorization, 'children' => []];
                    }
                }
                usort($dezGroups, static function (array $left, array $right) use ($dezCategoryOrder): int {
                    $byOrder = (int) $left['page']['fields']['Order'] <=> (int) $right['page']['fields']['Order'];
                    if ($byOrder !== 0) return $byOrder;
                    $leftPath = substr(dirname($left['page']['path']), strlen('services/'));
                    $rightPath = substr(dirname($right['page']['path']), strlen('services/'));
                    return ($dezCategoryOrder[$leftPath] ?? PHP_INT_MAX) <=> ($dezCategoryOrder[$rightPath] ?? PHP_INT_MAX)
                        ?: strcmp($leftPath, $rightPath);
                });
                ?>
                <details class="dz-nav-disclosure" data-dz-mega>
                    <summary><?= site_escape($dezLabel($dezEntry)) ?></summary>
                    <div class="dz-mega-panel">
                        <?php foreach ($dezGroups as $dezGroup): ?>
                            <?php $dezCategory = $dezGroup['page']; ?>
                            <?php if ($dezGroup['children']): ?>
                                <details class="dz-mega-category">
                                    <summary><?= site_page_menu_label($dezLabel($dezCategory), $dezCategory, $base) ?></summary>
                                    <div class="dz-mega-services">
                                        <div class="dz-mega-overview"><?= $dezLink($dezCategory) ?></div>
                                        <?php $dezLinks($dezGroup['children']); ?>
                                    </div>
                                </details>
                            <?php else: ?>
                                <div class="dz-mega-category"><?= $dezLink($dezCategory, false, true) ?></div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <div class="dz-mega-all"><?= $dezLink($dezEntry) ?> <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></div>
                    </div>
                </details>
            <?php else: ?>
                <details class="dz-nav-disclosure">
                    <summary><?= site_escape($dezLabel($dezEntry)) ?></summary>
                    <div class="dz-nav-panel">
                        <?= $dezLink($dezEntry) ?>
                        <?php $dezLinks($dezItem['children']); ?>
                    </div>
                </details>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>
    <div class="dz-header-tools"><?= site_expand_content('[search][lang]', $snippets, $context) ?></div>
</div>
