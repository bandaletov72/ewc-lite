(() => {
    const form = document.querySelector('#request form[data-contact-form]');
    const message = form?.querySelector('[name="fields[message]"]');
    if (!message || !document.querySelector('[data-dz-request]')) return;

    const topic = form.querySelector('[name="fields[topic]"]');
    let suggestion = '';
    document.addEventListener('click', (event) => {
        const link = event.target.closest('[data-dz-request]');
        if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        if (topic?.value === '' && Array.from(topic.options).some((option) => option.value === 'Дезинсекция')) {
            topic.value = 'Дезинсекция';
        }
        if (message.value.trim() !== '' && message.value !== suggestion) return;
        suggestion = 'Уничтожение клопов. ' + link.dataset.dzRequest + '.\n';
        message.value = suggestion;
    });
})();

document.querySelectorAll('.dz-nav').forEach((nav) => {
    const disclosures = [...nav.querySelectorAll('.dz-nav-disclosure')];
    const mega = nav.querySelector('[data-dz-mega]');
    if (mega) {
        const panel = mega.querySelector('.dz-mega-panel');
        const categories = [...panel.querySelectorAll('details.dz-mega-category')];
        if (categories.length) {
            panel.classList.add('dz-mega-enhanced');
            const activate = (category) => {
                categories.forEach((item) => { item.open = item === category; });
            };
            activate(categories.find((category) => category.querySelector('[aria-current="page"]')) || categories[0]);
            categories.forEach((category) => {
                category.firstElementChild.addEventListener('click', (event) => {
                    event.preventDefault();
                    activate(category);
                });
                category.firstElementChild.addEventListener('pointerenter', (event) => {
                    if (event.pointerType === 'mouse' && !panel.querySelector('.dz-mega-services :focus')) activate(category);
                });
            });
        }
    }
    disclosures.forEach((item) => item.addEventListener('toggle', () => {
        if (item.open) disclosures.forEach((other) => { if (other !== item) other.open = false; });
    }));
    document.addEventListener('click', (event) => {
        disclosures.forEach((item) => { if (!item.contains(event.target)) item.open = false; });
    });
    nav.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        const item = event.target.closest('.dz-nav-disclosure[open]');
        if (!item) return;
        event.preventDefault();
        item.open = false;
        item.firstElementChild.focus();
    });
});
