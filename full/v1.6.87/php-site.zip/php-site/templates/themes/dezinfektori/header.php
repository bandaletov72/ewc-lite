<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php
$dezContactsUrl = site_url($base, 'contacts/');
$dezPriceForm = site_render_action_button(['action' => 'form', 'form' => 'form86', 'label' => 'Узнать цену'], $context);
$dezCallback = site_render_action_button(['action' => 'callback', 'label' => 'Позвоните мне'], $context);
?>
<div class="dz-header">
    <a class="dz-brand" href="<?= site_escape(site_url($base)) ?>">
        <?php $dezLogo = site_brand_logo_html($brand, $base); ?>
        <?= $dezLogo !== '' ? $dezLogo : '<span class="dz-mark" aria-hidden="true"><span></span></span>' ?>
        <span><strong><?= site_escape($settings['name']) ?></strong><small><?= site_escape($settings['subtitle']) ?></small></span>
    </a>
    <div class="dz-header-contacts">
        <div class="dz-header-phones">
            <?= site_expand_content('[phones]', $snippets, $context) ?>
            <div class="dz-phone-fallback"><?= site_contact_markup('phones', $base, site_contact_settings()) ?></div>
        </div>
        <?= site_header_contact_slot('email', $context) ?>
    </div>
    <div class="dz-header-location">
        <?= site_header_contact_slot('address', $context) ?>
        <?= site_header_contact_slot('hours', $context) ?>
    </div>
    <div class="dz-header-actions">
        <?php if ($dezPriceForm !== ''): ?><?= $dezPriceForm ?>
        <?php else: ?><a class="dz-button dz-button-nav" href="<?= site_escape(site_url($base) . '#price') ?>">Узнать цену</a><?php endif; ?>
        <?php if ($dezCallback !== ''): ?><?= $dezCallback ?>
        <?php else: ?><a class="dz-button dz-button-nav" href="<?= site_escape($dezContactsUrl . '#request') ?>">Позвоните мне</a><?php endif; ?>
    </div>
    <div class="dz-header-channels">
        <div class="dz-header-social"><?= site_expand_content('[soc-icons]', $snippets, $context) ?></div>
        <?= site_expand_content('[cities]', $snippets, $context) ?>
    </div>
</div>
