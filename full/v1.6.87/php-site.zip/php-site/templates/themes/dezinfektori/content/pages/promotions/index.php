<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Акции и скидки
Heading: Акции и скидки
Description: Действующие предложения на санитарную обработку и отдельные формы для заявок на скидку.
Menu: Акции
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 26

<section class="dz-section" id="offers" aria-labelledby="dz-offers-title">
    <h2 id="dz-offers-title">Специальные предложения</h2>
    <p>Актуальные условия можно уточнить в заявке.</p>
    <a class="dz-button" href="/contacts/#request">Уточнить условия</a>
</section>
