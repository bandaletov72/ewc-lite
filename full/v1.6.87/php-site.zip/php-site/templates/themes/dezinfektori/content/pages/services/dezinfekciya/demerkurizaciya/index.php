<?php
$pageFile = __FILE__;
require __DIR__ . '/../../../index.php';
__halt_compiler();
Title: Демеркуризация
Heading: Демеркуризация
Description: Принимаем обращения по загрязнению ртутью. Уточняем, где пролилась ртуть и на какие поверхности она могла попасть. По этим сведениям оцениваем объём работ.
Keywords: демеркуризация, обработка при разливе ртути, устранение загрязнения ртутью
Menu: Демеркуризация
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 18

<section class="dz-split dz-category"><div><p class="dz-lead">Принимаем обращения по загрязнению ртутью. Уточняем, где пролилась ртуть и на какие поверхности она могла попасть. По этим сведениям оцениваем объём работ.</p><div class="dz-actions"><div class="dz-service-callback">[callback=Заказать услугу]</div><a class="dz-button dz-button-soft" href="/services/dezinfekciya/">Дезинфекция <span aria-hidden="true">↗</span></a></div></div><figure class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/services/demerkurizaciya.jpg" alt="Демеркуризация" width="880" height="440" fetchpriority="high" decoding="async"></figure></section>
<section class="dz-section dz-service-detail"><h2>Когда нужна услуга</h2><p>Демеркуризация нужна при загрязнении ртутью. Капли могут разойтись по щелям, а пары ртути нельзя надёжно оценить по запаху или фотографии. Для специалиста важны обстоятельства разлива, покрытие пола, доступ и возможное распространение загрязнения.</p><p>Изолируйте зону и избегайте контакта с ртутью. Пылесос использовать нельзя. При угрозе здоровью требуется связь с экстренными службами. Допуск в помещение зависит от оценки ситуации, а не от внешней чистоты.</p><h3>Что отметить до разговора со специалистом</h3><p>Для оценки назовите время, помещение, покрытие пола и места, куда могли попасть капли. Скажите, если там есть щели, ковёр или стык у порога. Ограничьте доступ в загрязнённую зону.</p><p class="dz-article-sources"><a href="https://www.epa.gov/mercury/what-do-if-mercury-thermometer-breaks">Чего нельзя делать при разливе ртути — EPA</a></p></section><section class="dz-section dz-compare" id="before-after" aria-label="До и после"><h2>До и после</h2><p>Иллюстрация типичной ситуации и видимых изменений на объекте.</p><div class="dz-compare-grid"><figure><img src="/templates/themes/dezinfektori/images/comparisons/demerkurizaciya-before.jpg" alt="Доступ к помещению ограничен" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>До</b> Доступ к помещению ограничен</figcaption></figure><figure><img src="/templates/themes/dezinfektori/images/comparisons/demerkurizaciya-after.jpg" alt="Зона освобождена после завершения и контроля работ" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>После</b> Зона освобождена после завершения и контроля работ</figcaption></figure></div></section><section class="dz-section dz-service-story" id="story"><div><p class="dz-kicker">Истории с выезда · художественная зарисовка</p><h2>У порога оказалась щель</h2><p>После разлива хозяин сначала назвал комнату и тип пола. Потом вспомнил, что капли могли уйти к порогу, где есть щель. Мы записали это отдельно: внешний вид остального пола ничего не говорил о том, что могло остаться под стыком.</p><p>Попросили ограничить доступ и привязали осмотр к конкретным местам. При обращении важны время разлива, покрытие и возможные щели. Фотография чистого пола сама по себе ничего не подтверждает.</p></div></section>
<section class="dz-section"><h2>Как проходит услуга</h2><ol class="dz-steps"><li><h3>Осмотр</h3><p>Выясняем, что произошло, и оцениваем, какие поверхности могли быть затронуты.</p></li><li><h3>План и выполнение работ</h3><p>Согласуем доступ и необходимый объём работ. Рекомендации по пользованию помещением даём по результату оценки.</p></li><li><h3>После выезда</h3><p>Объясняем, как оценить результат, какие изменения важно отслеживать и когда стоит связаться с нами снова.</p></li></ol></section>
<section class="dz-section dz-faq-block"><h2>Частые вопросы</h2><div class="dz-faq"><details><summary>Что делать, пока ждём консультацию?</summary><p>Ограничьте доступ в загрязнённую зону, не трогайте ртуть и не используйте пылесос. При непосредственной угрозе звоните 112.</p></details>
<details><summary>Какие сведения понадобятся?</summary><p>Что произошло, когда, в каком помещении и какие поверхности затронуты. Сообщите, если ртуть могла попасть в щели.</p></details>
<details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details></div></section>
<section class="dz-section"><h2>Услуги этого направления</h2><ul class="dz-service-links"><li><a href="/services/dezinfekciya/pomeshcheniya/">Дезинфекция квартир, домов и офисов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/virusy-i-bakterii/">Дезинфекция от вирусов и бактерий <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/plesen-i-gribok/">Дезинфекция от плесени и грибка <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section dz-price" id="price" aria-labelledby="dez-price-title">
    <h2 id="dez-price-title">Ориентировочные цены</h2>
    <p>Окончательная стоимость зависит от площади, условий на объекте и объёма работ.</p>
    [iblock=table]/data/dez-price-demerkurizaciya.txt[/iblock]
    <a class="dz-button dz-button-soft" href="#request">Уточнить стоимость</a>
</section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>

[reviews page=current]
