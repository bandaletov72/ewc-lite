<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Оплата услуг
Heading: Оплата услуг
Description: Как согласовать стоимость, способы оплаты и документы по заказу санитарной обработки.
Menu: Оплата
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 35

<p class="dz-lead">Стоимость и условия оплаты согласуются до начала работ. При оформлении заказа уточните доступный для вашего объекта способ оплаты.</p>
<section class="dz-section">
    <h2>Счёт и закрывающие документы</h2>
    <p>Если заказ оформляет организация, укажите это в заявке и перечислите нужные документы. Для вопроса об оформленном заказе сообщите номер заявки или дату выезда.</p>
    <div class="dz-actions"><a class="dz-button" href="/contacts/#request">Уточнить оплату</a><a class="dz-button dz-button-soft" href="/prices/">Посмотреть цены</a></div>
</section>
