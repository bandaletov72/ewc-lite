<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Цены на санитарную обработку
Heading: Цены на санитарную обработку
Description: Ориентировочные цены на санитарную обработку и заявка на расчёт стоимости.
Menu: Цены
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 22

<section class="dz-section" id="price">
    <p class="dz-lead">Стоимость зависит от площади, вида вредителя и объёма работ. Ориентиры по услугам собраны в таблице. Для точной цены укажите тип объекта и площадь.</p>
    [iblock=table]/data/dez-price-services.txt[/iblock]
    <a class="dz-button" href="#request">Запросить расчёт</a>
</section>
<section class="dz-request" id="request"><div><h2>Рассчитать стоимость</h2><p>Укажите адрес или район, что нужно обработать и когда удобно принять специалиста.</p></div><div>[form86]</div></section>
