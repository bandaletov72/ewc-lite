<?php
$pageFile = __FILE__;
require __DIR__ . '/../../../index.php';
__halt_compiler();
Title: Дезинфекция после смерти
Heading: Дезинфекция после смерти
Description: Помогаем согласовать санитарную обработку затронутых зон после завершения необходимых процедур и получения доступа к помещению.
Keywords: дезинфекция после смерти, санитарная обработка после смерти, дезинфекция квартиры
Menu: Дезинфекция после смерти
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 13

<section class="dz-split dz-category"><div><p class="dz-lead">Помогаем согласовать санитарную обработку затронутых зон после завершения необходимых процедур и получения доступа к помещению.</p><div class="dz-actions"><div class="dz-service-callback">[callback=Заказать услугу]</div><a class="dz-button dz-button-soft" href="/services/dezinfekciya/">Дезинфекция <span aria-hidden="true">↗</span></a></div></div><figure class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/services/posle-smerti.jpg" alt="Дезинфекция после смерти" width="880" height="440" fetchpriority="high" decoding="async"></figure></section>
<section class="dz-section dz-service-detail"><h2>Когда нужна услуга</h2><p>Обработка после смерти касается конкретных зон, которые могли быть загрязнены. Объём зависит от состояния помещения, наличия пористых материалов и времени до получения доступа. Работы согласуют после завершения необходимых процедур.</p><p>Во время обращения достаточно описать тип объекта и доступные сведения. Отдельно обсуждают обращение с вещами, вывоз и дальнейший ремонт. Важны деликатная связь и ясный порядок действий для близких.</p><h3>Что отметить до разговора со специалистом</h3><p>При первом обращении достаточно назвать тип помещения, примерную площадь и доступное время. Сообщите, какие вещи важно сохранить. Вопросы вывоза и ремонта можно обсудить после осмотра.</p></section><section class="dz-section dz-compare" id="before-after" aria-label="До и после"><h2>До и после</h2><p>Иллюстрация типичной ситуации и видимых изменений на объекте.</p><div class="dz-compare-grid"><figure><img src="/templates/themes/dezinfektori/images/comparisons/posle-smerti-before.jpg" alt="Помещение закрыто на время работ" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>До</b> Помещение закрыто на время работ</figcaption></figure><figure><img src="/templates/themes/dezinfektori/images/comparisons/posle-smerti-after.jpg" alt="Проход освобождён после завершения работ" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>После</b> Проход освобождён после завершения работ</figcaption></figure></div></section><section class="dz-section dz-service-story" id="story"><div><p class="dz-kicker">Истории с выезда · художественная зарисовка</p><h2>Разговор, который можно начать с одного вопроса</h2><p>На звонке родственнику было тяжело объяснить, что произошло. Мы начали с простого: кто может открыть квартиру и когда будет доступ. Позже, уже на месте, отдельно обсудили затронутые зоны и вещи, которые семья хотела сохранить.</p><p>В таких обращениях можно дать только нужные для выезда сведения. Вопросы о вещах, вывозе и ремонте спокойно обсуждают после осмотра.</p></div></section>
<section class="dz-section"><h2>Как проходит услуга</h2><ol class="dz-steps"><li><h3>Осмотр</h3><p>Уточняем доступ к помещению и определяем затронутые зоны.</p></li><li><h3>План и выполнение работ</h3><p>Согласуем обработку и отдельно обсуждаем демонтаж или вывоз, если это входит в заявку.</p></li><li><h3>После выезда</h3><p>Объясняем, как оценить результат, какие изменения важно отслеживать и когда стоит связаться с нами снова.</p></li></ol></section>
<section class="dz-section dz-faq-block"><h2>Частые вопросы</h2><div class="dz-faq"><details><summary>Какие данные сообщить при обращении?</summary><p>Достаточно адреса, примерной площади, затронутых зон и сведений о доступе. Подробности можно обсудить в личном разговоре.</p></details>
<details><summary>Входит ли вывоз вещей в обработку?</summary><p>Обращение с вещами, их вывоз и санитарная обработка согласуются отдельно.</p></details>
<details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details></div></section>
<section class="dz-section"><h2>Услуги этого направления</h2><ul class="dz-service-links"><li><a href="/services/dezinfekciya/pomeshcheniya/">Дезинфекция квартир, домов и офисов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/virusy-i-bakterii/">Дезинфекция от вирусов и бактерий <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/plesen-i-gribok/">Дезинфекция от плесени и грибка <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section dz-price" id="price" aria-labelledby="dez-price-title">
    <h2 id="dez-price-title">Ориентировочные цены</h2>
    <p>Окончательная стоимость зависит от площади, условий на объекте и объёма работ.</p>
    [iblock=table]/data/dez-price-posle-smerti.txt[/iblock]
    <a class="dz-button dz-button-soft" href="#request">Уточнить стоимость</a>
</section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>

[reviews page=current]
