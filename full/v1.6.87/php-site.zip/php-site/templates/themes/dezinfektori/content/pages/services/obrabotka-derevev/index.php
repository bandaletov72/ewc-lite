<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Обработка деревьев от вредителей
Heading: Обработка деревьев от вредителей
Description: Осмотр повреждённых деревьев и подбор обработки от вредителей древесины.
Menu: Обработка деревьев
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 62
AnnouncementIcon: [fa-icon=tree]

<p class="dz-lead">Укажите породу и число деревьев и приложите описание повреждений. Отверстия в коре и осыпание хвои могут иметь разные причины. По этим признакам специалист уточнит, нужен ли осмотр и возможна ли обработка.</p>
<section class="dz-section" id="price">
    <h2>Стоимость</h2>
    [iblock=table]/data/dez-price-obrabotka-derevev.txt[/iblock]
</section>
<section class="dz-section">
    <h2>Связанные услуги</h2>
    <ul class="dz-service-links">
    <li><a href="/services/dezinsekciya/koroed/">Уничтожение короеда</a></li>
    </ul>
</section>
<section class="dz-request" id="request"><div><h2>Обсудить объект</h2><p>Оставьте телефон и кратко опишите ситуацию. Уточним возможные работы и стоимость.</p></div><div>[form86]</div></section>

[reviews page=current]
