<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Санитарная обработка для организаций
Heading: Санитарная обработка для организаций
Description: Заявка на разовую обработку или обслуживание коммерческого объекта по графику.
Menu: Юр. лицам
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 24

<p class="dz-lead">Работаем с коммерческими объектами. Чтобы составить предложение, уточним назначение помещений, площадь, режим работы и требования к документам.</p>
<ul class="dz-service-links">
    <li><a href="/services/biznes/">Каталог услуг для бизнеса</a></li>
    <li><a href="/services/biznes/kafe-i-restorany/">Кафе и рестораны</a></li>
    <li><a href="/services/biznes/gostinicy-i-hostely/">Гостиницы и хостелы</a></li>
    <li><a href="/services/kompleksnye/pest-kontrol/">Абонентский пест-контроль</a></li>
</ul>
[dez-business-cta]
<section class="dz-request" id="request"><div><h2>Запросить предложение</h2><p>Укажите число объектов и нужен ли регулярный выезд. Опишите требования к договору и отчётности, если они есть.</p></div><div>[form86]</div></section>
