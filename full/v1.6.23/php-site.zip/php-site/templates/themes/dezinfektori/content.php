<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php $dezHome = empty($searchMode) && $originalPath === 'index.php' && strpos($page['html'], 'id="dez-hero-title"') !== false; ?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main dz-main<?= $dezHome ? ' dz-home' : '' ?>" id="content" lang="<?= site_escape($page['language'] ?? 'ru') ?>">
    <?php if (!$dezHome): ?><h1 class="dz-page-title"><?= site_escape($heading) ?></h1><?php endif; ?>
    <div class="page-content"><?= $content ?></div>
</main>
