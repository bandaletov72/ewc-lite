<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<footer class="site-footer dz-footer">
    <div class="container">
      <div class="dz-footer-main">
        <a class="dz-brand" href="<?= site_escape(site_url($base)) ?>">
          <?php $dezLogo = site_brand_logo_html($brand, $base); ?>
          <?= $dezLogo !== '' ? $dezLogo : '<span class="dz-mark" aria-hidden="true"><span></span></span>' ?>
          <span><strong><?= site_escape($settings['name']) ?></strong><small><?= site_escape($settings['subtitle']) ?></small></span>
        </a>
        <nav class="dz-footer-nav" aria-label="<?= site_escape(site_translation('Подвал', $locale)) ?>"><?php require site_template_file('navigation-links.php'); ?></nav>
        <?= site_expand_content('[phones][soc-icons]', $snippets, $context) ?>
      </div>
      <div class="dz-footer-meta">
        <span><?= site_escape(site_expand_text($settings['footer'], $snippets)) ?></span>
        <div><?= site_expand_content('[privacy][cookies][top]', $snippets, $context) ?></div>
        <a class="dz-credit" href="<?= site_escape(SITE_PRODUCT_REPOSITORY) ?>" aria-label="<?= site_escape(SITE_PRODUCT_NAME . ' · GitHub') ?>"><?= site_product_logo(true) ?></a>
      </div>
    </div>
</footer>
