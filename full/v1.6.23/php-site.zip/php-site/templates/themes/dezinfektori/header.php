<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<div class="dz-header">
    <a class="dz-brand" href="<?= site_escape(site_url($base)) ?>">
      <?php $dezLogo = site_brand_logo_html($brand, $base); ?>
      <?= $dezLogo !== '' ? $dezLogo : '<span class="dz-mark" aria-hidden="true"><span></span></span>' ?>
      <span><strong><?= site_escape($settings['name']) ?></strong><small><?= site_escape($settings['subtitle']) ?></small></span>
    </a>
    <div class="dz-desktop"><?= site_layout_placeholder('main-menu') ?></div>
    <a class="dz-button dz-button-nav" href="<?= site_escape(site_url($base, 'contacts/#request')) ?>">Заказать обработку <span aria-hidden="true">↗</span></a>
</div>
