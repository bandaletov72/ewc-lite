<?php
$pageFile = __FILE__;
require __DIR__ . '/../../../index.php';
__halt_compiler();
Title: Демеркуризация
Heading: Демеркуризация
Description: Принимаем обращения по загрязнению ртутью. Состав работ определяем по месту происшествия и затронутым поверхностям.
Keywords: демеркуризация, обработка при разливе ртути, устранение загрязнения ртутью
Menu: Демеркуризация
MenuVisible: 0
MobileMenu: 0
Sitemap: 1
Order: 18

<section class="dz-split dz-category"><div><p class="dz-lead">Принимаем обращения по загрязнению ртутью. Состав работ определяем по месту происшествия и затронутым поверхностям.</p><div class="dz-actions"><div class="dz-service-callback">[callback=Заказать услугу]</div><a class="dz-button dz-button-soft" href="/services/dezinfekciya/">Дезинфекция <span aria-hidden="true">↗</span></a></div></div><figure class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/services/demerkurizaciya.jpg" alt="Демеркуризация" width="880" height="440" fetchpriority="high" decoding="async"></figure></section>
<section class="dz-section"><h2>Как проходит услуга</h2><ol class="dz-steps"><li><h3>Осмотр</h3><p>Выясняем, что произошло, и оцениваем, какие поверхности могли быть затронуты.</p></li><li><h3>План и выполнение работ</h3><p>Согласуем доступ и необходимый объём работ. Рекомендации по пользованию помещением даём по результату оценки.</p></li><li><h3>После выезда</h3><p>Объясняем, как оценить результат, какие изменения важно отслеживать и когда стоит связаться с нами снова.</p></li></ol></section>
<section class="dz-section dz-faq-block"><h2>Частые вопросы</h2><div class="dz-faq"><details><summary>Что делать, пока ждём консультацию?</summary><p>Ограничьте доступ в загрязнённую зону, не трогайте ртуть и не используйте пылесос. При непосредственной угрозе звоните 112.</p></details>
<details><summary>Какие сведения понадобятся?</summary><p>Что произошло, когда, в каком помещении и какие поверхности затронуты. Сообщите, если ртуть могла попасть в щели.</p></details>
<details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details></div></section>
<section class="dz-section"><h2>Услуги этого направления</h2><ul class="dz-service-links"><li><a href="/services/dezinfekciya/pomeshcheniya/">Дезинфекция квартир, домов и офисов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/virusy-i-bakterii/">Дезинфекция от вирусов и бактерий <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/plesen-i-gribok/">Дезинфекция от плесени и грибка <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>
