<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Услуги
Heading: Услуги
Description: Каталог санитарной службы: уничтожение насекомых и грызунов, дезинфекция, комплексные услуги и обслуживание бизнеса.
Keywords: услуги, Дезинфекторы
Menu: Услуги
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 20

<p class="dz-lead">Выберите направление, чтобы посмотреть отдельные услуги, порядок работ и ответы на вопросы.</p>
<div class="dz-service-callback">[callback=Заказать услугу]</div>
<div class="dz-services"><a class="dz-service-card" href="/services/dezinsekciya/"><img src="/templates/themes/dezinfektori/images/apartment.jpg" alt="" width="880" height="440" loading="lazy" decoding="async"><div><span class="dz-card-count">01</span><h3>Дезинсекция</h3><p>Обработка от насекомых в квартирах, домах, офисах и на участках.</p><span class="dz-card-link">12 услуг <span aria-hidden="true">↗</span></span></div></a>
<a class="dz-service-card" href="/services/deratizaciya/"><img src="/templates/themes/dezinfektori/images/warehouse.jpg" alt="" width="880" height="440" loading="lazy" decoding="async"><div><span class="dz-card-count">02</span><h3>Дератизация</h3><p>Выявление путей проникновения и контроль грызунов в зданиях и на территории.</p><span class="dz-card-link">5 услуг <span aria-hidden="true">↗</span></span></div></a>
<a class="dz-service-card" href="/services/dezinfekciya/"><img src="/templates/themes/dezinfektori/images/interior.jpg" alt="" width="880" height="440" loading="lazy" decoding="async"><div><span class="dz-card-count">03</span><h3>Дезинфекция</h3><p>Санитарная обработка помещений, работа с плесенью, запахами и особыми ситуациями.</p><span class="dz-card-link">9 услуг <span aria-hidden="true">↗</span></span></div></a>
<a class="dz-service-card" href="/services/kompleksnye/"><img src="/templates/themes/dezinfektori/images/equipment.jpg" alt="" width="880" height="440" loading="lazy" decoding="async"><div><span class="dz-card-count">04</span><h3>Комплексные услуги</h3><p>Комплексная обработка, регулярный пест-контроль и специализированные методы.</p><span class="dz-card-link">4 услуги <span aria-hidden="true">↗</span></span></div></a>
<a class="dz-service-card" href="/services/biznes/"><img src="/templates/themes/dezinfektori/images/restaurant.jpg" alt="" width="880" height="440" loading="lazy" decoding="async"><div><span class="dz-card-count">05</span><h3>Услуги для бизнеса</h3><p>Санитарная обработка для общепита, гостиничных и коммерческих объектов.</p><span class="dz-card-link">2 услуги <span aria-hidden="true">↗</span></span></div></a></div>
<div class="dz-all-services"><section class="dz-section"><h2><a href="/services/dezinsekciya/">Дезинсекция</a></h2><ul class="dz-service-links"><li><a href="/services/dezinsekciya/klopy/">Уничтожение клопов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/tarakany/">Уничтожение тараканов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/blohi/">Уничтожение блох <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/muravyi/">Уничтожение муравьёв <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/mol/">Уничтожение моли <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/osy-i-shershni/">Уничтожение ос и шершней <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/komary/">Уничтожение комаров <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/kleshchi/">Обработка участков от клещей <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/koroed/">Уничтожение короеда <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/mokricy-cheshuinicy-senoedy-kozheedy/">Уничтожение мокриц, чешуйниц, сеноедов и кожеедов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/kvartiry/">Дезинсекция квартир <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/ofisy/">Дезинсекция офисов и коммерческих помещений <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section"><h2><a href="/services/deratizaciya/">Дератизация</a></h2><ul class="dz-service-links"><li><a href="/services/deratizaciya/krysy/">Уничтожение крыс <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/myshi/">Уничтожение мышей <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/kroty/">Уничтожение кротов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/podvaly-i-sklady/">Дератизация подвалов и складов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/predpriyatiya-i-obshchepit/">Дератизация предприятий и общепита <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section"><h2><a href="/services/dezinfekciya/">Дезинфекция</a></h2><ul class="dz-service-links"><li><a href="/services/dezinfekciya/pomeshcheniya/">Дезинфекция квартир, домов и офисов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/virusy-i-bakterii/">Дезинфекция от вирусов и бактерий <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/plesen-i-gribok/">Дезинфекция от плесени и грибка <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/posle-smerti/">Дезинфекция после смерти <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/sklady-i-proizvodstva/">Дезинфекция складов и производств <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/ozonirovanie/">Озонирование <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/kvarcevanie/">Кварцевание <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/dezodoraciya/">Дезодорация и устранение запахов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/demerkurizaciya/">Демеркуризация <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section"><h2><a href="/services/kompleksnye/">Комплексные услуги</a></h2><ul class="dz-service-links"><li><a href="/services/kompleksnye/ddd/">Комплексная обработка (ДДД) <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/kompleksnye/pest-kontrol/">Пест-контроль и абонентское обслуживание <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/kompleksnye/tuman/">Обработка холодным и горячим туманом <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/kompleksnye/fumigaciya/">Фумигация <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section"><h2><a href="/services/biznes/">Услуги для бизнеса</a></h2><ul class="dz-service-links"><li><a href="/services/biznes/kafe-i-restorany/">Обработка кафе и ресторанов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/biznes/gostinicy-i-hostely/">Обработка гостиниц и хостелов <span aria-hidden="true">↗</span></a></li></ul></section></div>
[dez-business-cta]
