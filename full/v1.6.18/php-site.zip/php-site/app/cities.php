<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_CITIES_FILE = SITE_ROOT . '/admin/.cities.php';
const SITE_CITIES_LIMIT = 1048576;

function site_city_rows(): array
{
    return array_fill(0, 5, ['label' => '', 'phone' => '']);
}

function site_cities(): array
{
    $stored = site_read_record(SITE_CITIES_FILE, SITE_CITIES_LIMIT);
    if ($stored || is_file(SITE_CITIES_FILE)) {
        foreach ($stored as $id => $city) {
            if (!is_string($id) || !preg_match('/\A[a-z][a-z0-9-]{0,63}\z/', $id)
                || !is_string($city['name'] ?? null) || !is_string($city['domain'] ?? null)
                || !is_array($city['phones'] ?? null) || array_keys($city['phones']) !== range(0, 4)) {
                throw new RuntimeException('Неверный формат файла настроек.');
            }
            foreach ($city['phones'] as $row) {
                if (!is_string($row['label'] ?? null) || !is_string($row['phone'] ?? null)) {
                    throw new RuntimeException('Неверный формат файла настроек.');
                }
            }
        }
        return $stored;
    }
    $phones = site_city_rows();
    $phones[0]['label'] = 'Горячая линия';
    $phones[1]['label'] = 'Сервисная служба';
    return [
        'moscow' => ['name' => 'Москва', 'domain' => '', 'phones' => $phones],
        'saint-petersburg' => ['name' => 'Санкт-Петербург', 'domain' => '', 'phones' => $phones],
    ];
}

function site_city_language(string $language): array
{
    static $packs;
    static $validation;
    if ($packs === null) {
        $packs = require __DIR__ . '/help-cities.php';
        $validation = require __DIR__ . '/help-city-phones.php';
    }
    $labels = array_combine(['cities', 'choose', 'add', 'name', 'domain', 'unbound', 'label', 'phone', 'error', 'help', 'invalid'],
        $packs[$language] ?? $packs['ru']);
    list($labels['invalid'], $labels['phoneFormat'], $labels['optional'], $labels['fallback']) = $validation[$language] ?? $validation['ru'];
    return $labels;
}

function site_selected_city(array $cities, string $host): string
{
    $saved = $_COOKIE['FILE_SITE_CITY'] ?? '';
    if (is_string($saved) && isset($cities[$saved])) return $saved;
    foreach ($cities as $id => $city) {
        if ($host !== '' && $city['domain'] === $host) return $id;
    }
    return key($cities) ?? '';
}

function site_city_contact_labels(string $language): array
{
    static $labels;
    if ($labels === null) $labels = require __DIR__ . '/help-city-contacts.php';
    return $labels[$language] ?? $labels['ru'];
}

function site_request_city(string $base): array
{
    try {
        $cities = site_cities();
        return $cities[site_selected_city($cities, site_content_host($base))] ?? [];
    } catch (RuntimeException $exception) {
        return [];
    }
}

function site_city_phone_rows(array $city, array $snippets): array
{
    foreach ($city['phones'] as $index => $row) {
        $city['phones'][$index] = [
            'label' => trim(site_expand_text($row['label'], $snippets)),
            'phone' => site_normalize_form_phone(trim(site_expand_text($row['phone'], $snippets))),
        ];
    }
    return $city['phones'];
}

function site_city_phone_tokens(): array
{
    return ['tel', 'tel2', 'tel3', 'tel4', 'tel5'];
}

function site_city_live_tokens(): array
{
    $tokens = ['city'];
    foreach (site_city_phone_tokens() as $phone) {
        $tokens[] = $phone;
        $tokens[] = $phone . '-label';
    }
    return $tokens;
}

function site_city_display_phones(string $id, array $phones, string $base, array $snippets): string
{
    if ($id !== '') return site_city_phone_list($phones, $base);
    $markup = site_contact_markup('phones', $base, site_contact_settings());
    return $markup !== '' ? $markup : ($snippets['phones'] ?? '');
}

function site_city_contacts(array $city, array $phones): array
{
    $settings = site_contact_settings();
    $channels = is_array($city['channels'] ?? null) ? $city['channels'] : [];
    foreach (site_channels() as $id => $name) {
        if (!empty($channels[$id]['url'])) $settings['channels'][$id] = $channels[$id];
    }
    $localPhones = [];
    foreach ($phones as $phone) {
        if ($phone['phone'] !== '') $localPhones[] = ['number' => $phone['phone'], 'text' => $phone['label']];
    }
    if ($localPhones) $settings['phones'] = $localPhones;
    return $settings;
}

function site_city_contact_markup(string $token, string $base, array $contacts, array $snippets): string
{
    $markup = site_contact_markup(site_contact_tokens()[$token], $base, $contacts);
    return $markup !== '' ? $markup : ($snippets[$token] ?? '');
}

function site_city_response(string $id, array $phones, array $contacts, array $snippets, string $base)
{
    $cookie = [
        'expires' => time() + 365 * 86400, 'path' => site_url($base), 'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ];
    // The options array for setcookie is available starting with PHP 7.3.
    setcookie('FILE_SITE_CITY', $id, $cookie['expires'], $cookie['path'], '', $cookie['secure'], $cookie['httponly']);
    header('Cache-Control: private, no-store');
    header('Content-Type: application/json; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    $tokens = [];
    foreach (site_city_live_tokens() as $key) $tokens[$key] = $snippets[$key] ?? '';
    $contactMarkup = [];
    foreach (array_keys(site_contact_tokens()) as $key) {
        if ($key !== 'phones') $contactMarkup[$key] = site_city_contact_markup($key, $base, $contacts, $snippets);
    }
    echo json_encode(['city' => $id, 'phones' => site_city_phone_list($phones, $base), 'tokens' => $tokens, 'contacts' => $contactMarkup], JSON_UNESCAPED_UNICODE);
}

function site_city_snippets(array $city, array $phones): array
{
    $values = ['city' => site_escape($city['name'])];
    foreach (site_city_phone_tokens() as $index => $key) {
        $row = $phones[$index];
        if ($row['phone'] !== '') $values[$key] = site_escape($row['phone']);
        if ($row['label'] !== '') $values[$key . '-label'] = site_escape($row['label']);
    }
    return $values;
}

function site_city_phone_list(array $phones, string $base): string
{
    $items = '';
    foreach ($phones as $phone) {
        if ($phone['phone'] === '') continue;
        $label = $phone['label'] === '' ? '' : '<span class="city-phone-label">' . site_escape($phone['label']) . '</span>';
        $number = site_escape($phone['phone']);
        $dial = preg_replace('/[^0-9+]/', '', $number);
        $icon = site_escape(site_url($base, 'templates/icons/contact/phone.png'));
        $items .= '<li><a href="tel:' . $dial . '"><img src="' . $icon . '" width="18" height="18" alt="">'
            . '<span>' . $label . '<span class="city-phone-number">' . $number . '</span></span></a></li>';
    }
    return $items === '' ? '' : '<ul class="city-phone-list">' . $items . '</ul>';
}

function site_city_picker(array $context): string
{
    if (!$context['cities']) return '';
    $labels = site_city_language($context['locale']);
    ob_start();
    require site_template_file('components/city-picker.php');
    return (string) ob_get_clean();
}
