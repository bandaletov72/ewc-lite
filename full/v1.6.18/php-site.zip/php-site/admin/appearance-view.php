<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($section === 'contacts'): ?>
    <h1><?= admin_l('Контакты и соцсети') ?></h1>
    <p class="hint"><?= admin_l('Код') ?> <code>[soc-icons]</code> <?= admin_l('вставляет иконки всех соцсетей, для которых указаны ссылки.') ?></p>
    <form class="panel form-stack" method="post" action="<?= site_escape($contactsUrl) ?>" data-contacts-config>
        <input type="hidden" name="action" value="save-contacts">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <div class="field">
            <label for="contacts-heading"><?= admin_l('Заголовок блока') ?> <code>[contacts]</code></label>
            <input id="contacts-heading" name="heading" value="<?= site_escape($appearanceDraft['heading']) ?>" maxlength="375" placeholder="<?= admin_l('Связаться с нами') ?>">
        </div>
        <h2><?= admin_l('Телефоны') ?> <code>[phones]</code></h2>
        <div class="form-stack" data-phone-rows>
            <?php foreach ($appearanceDraft['phones'] as $index => $phone): ?>
                <?php require __DIR__ . '/appearance-phone.php'; ?>
            <?php endforeach; ?>
        </div>
        <template data-phone-template>
            <?php
            $index = '__INDEX__';
            $phone = ['number' => '', 'text' => ''];
            require __DIR__ . '/appearance-phone.php';
            ?>
        </template>
        <div><button type="button" data-add-phone><?= admin_l('Добавить телефон') ?></button></div>
        <h2><?= admin_l('Соцсети') ?></h2>
        <p class="hint"><?= admin_l('Вставьте код нужной соцсети в HTML страницы. Если подпись пустая, рядом с иконкой появится название сервиса.') ?></p>
        <?php foreach (site_channels() as $id => $name): ?>
            <?php $channel = $appearanceDraft['channels'][$id] ?? ['url' => '', 'text' => '']; ?>
            <fieldset class="field-config">
                <legend class="channel-label">
                    <img src="<?= site_escape(site_url($base, 'templates/icons/contact/' . $id . '.png')) ?>" width="22" height="22" alt="">
                    <?= admin_l($name) ?> <code>[<?= $id ?>]</code>
                </legend>
                <div class="fields">
                    <label class="field"><?= admin_l('Ссылка') ?>
                        <input type="url" name="channels[<?= $id ?>][url]" maxlength="2048" value="<?= site_escape($channel['url']) ?>" placeholder="https://">
                    </label>
                    <label class="field"><?= admin_l('Подпись ссылки') ?>
                        <input name="channels[<?= $id ?>][text]" maxlength="375" value="<?= site_escape($channel['text']) ?>" placeholder="<?= admin_l('Перейти на канал') ?>">
                    </label>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить контакты') ?></button></div>
    </form>
<?php elseif ($section === 'theme'): ?>
    <h1><?= admin_l('Тема и цвета') ?></h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($themeUrl) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <div class="field">
            <label for="theme-mode"><?= admin_l('Режим оформления') ?></label>
            <select id="theme-mode" name="mode">
                <?php foreach (['auto' => admin_t('Автоматически — как в системе'), 'light' => admin_t('Светлый'), 'dark' => admin_t('Тёмный')] as $key => $label): ?>
                    <option value="<?= $key ?>"<?= $appearanceDraft['mode'] === $key ? ' selected' : '' ?>><?= admin_l($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="fields">
            <?php foreach (['light' => admin_t('Светлая палитра'), 'dark' => admin_t('Тёмная палитра')] as $scheme => $label): ?>
                <fieldset class="field-config form-stack">
                    <legend><?= admin_l($label) ?></legend>
                    <?php foreach (site_theme_fields() as $key => $name): ?>
                        <label class="theme-color">
                            <?= admin_l($name) ?>
                            <input type="color" name="<?= $scheme ?>[<?= $key ?>]" value="<?= site_escape($appearanceDraft[$scheme][$key]) ?>">
                        </label>
                    <?php endforeach; ?>
                </fieldset>
            <?php endforeach; ?>
        </div>
        <div><button class="button-primary" type="submit" name="action" value="save-theme"><?= admin_l('Сохранить оформление') ?></button></div>
        <fieldset class="field-config form-stack">
            <legend><?= admin_l('Сохранить тему под названием') ?></legend>
            <div class="field">
                <label for="theme-name"><?= admin_l('Название темы') ?></label>
                <input id="theme-name" name="theme_name" value="<?= site_escape($themeName) ?>" maxlength="80" placeholder="<?= admin_l('Например, Весенняя') ?>">
                <small class="hint"><?= admin_l('Если оставить поле пустым, название подставится автоматически.') ?></small>
            </div>
            <div><button type="submit" name="action" value="save-theme-preset"><?= admin_l('Сохранить в список') ?></button></div>
        </fieldset>
    </form>
    <section class="panel form-stack theme-presets">
        <h2><?= admin_l('Сохранённые темы') ?></h2>
        <?php if (!$themeState['presets']): ?>
            <p class="hint"><?= admin_l('Сохранённых тем пока нет.') ?></p>
        <?php else: ?>
            <?php if ($themeState['default'] !== ''): ?>
                <form method="post" action="<?= site_escape($themeUrl) ?>">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($themeState)) ?>">
                    <button type="submit" name="action" value="restore-default-theme"><?= admin_l('Вернуть тему по умолчанию') ?></button>
                </form>
            <?php endif; ?>
            <ul class="theme-preset-list">
                <?php $factoryThemes = site_starter_themes(); ?>
                <?php foreach ($themeState['presets'] as $id => $preset): ?>
                    <li class="theme-preset">
                        <div>
                            <strong><?= $id === SITE_SYSTEM_THEME || ($factoryThemes[$id]['name'] ?? '') === $preset['name']
                                ? admin_l($preset['name']) : site_escape($preset['name']) ?></strong>
                            <?php if ($themeState['default'] === $id): ?>
                                <small class="hint theme-default-label"><?= admin_l('По умолчанию') ?></small>
                            <?php endif; ?>
                            <div class="theme-swatch-pair">
                                <?php foreach (['light' => admin_t('Светлая палитра'), 'dark' => admin_t('Тёмная палитра')] as $scheme => $schemeLabel): ?>
                                    <div class="theme-swatches" role="group" aria-label="<?= admin_l($schemeLabel) ?>">
                                        <?php foreach (['paper' => admin_t('Фон страницы'), 'surface' => admin_t('Поверхности и поля'), 'ink' => admin_t('Основной текст'), 'accent' => admin_t('Ссылки и кнопки')] as $color => $colorLabel): ?>
                                            <?php $hex = $preset['theme'][$scheme][$color]; ?>
                                            <input type="color" disabled value="<?= site_escape($hex) ?>"
                                                title="<?= site_escape($colorLabel . ' ' . $hex) ?>" aria-label="<?= site_escape($colorLabel . ' ' . $hex) ?>">
                                        <?php endforeach; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <form class="header-actions" method="post" action="<?= site_escape($themeUrl) ?>" data-theme-presets>
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($themeState)) ?>">
                            <input type="hidden" name="preset" value="<?= site_escape($id) ?>">
                            <button type="submit" name="action" value="apply-theme-preset"><?= admin_l('Применить') ?></button>
                            <?php if ($themeState['default'] !== $id): ?>
                                <button type="submit" name="action" value="default-theme-preset"><?= admin_l('Использовать по умолчанию') ?></button>
                            <?php endif; ?>
                            <?php if ($id !== SITE_SYSTEM_THEME): ?>
                                <button class="button-danger" type="submit" name="action" value="delete-theme-preset"><?= admin_l('Удалить') ?></button>
                            <?php endif; ?>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>
<?php else: ?>
    <h1><?= admin_l('Настройки компонентов') ?></h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($componentsUrl) ?>">
        <input type="hidden" name="action" value="save-components">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <?php foreach (site_component_schema() as $id => $component): ?>
            <details class="field-config disclosure-panel"<?= $id === 'banners' ? ' id="banners"' : '' ?><?= isset($component['examplePath']) ? ' data-component-code="' . site_escape($id) . '"' : '' ?>>
                <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= $id === 'banners' ? site_escape(site_banner_editor_labels($adminLanguage)[0] . ' [banners]') : admin_l($component['label']) ?></summary>
                <div class="fields">
                    <?php foreach ($component['settings'] as $key => $field): ?>
                        <label class="field">
                            <?= site_escape(site_component_size_text($field['label'], $adminLanguage)) ?>
                            <select name="<?= site_escape($id . '[' . $key . ']') ?>" data-component-param="<?= site_escape($key) ?>">
                                <?php foreach ($field['options'] as $value => $label): ?>
                                    <option value="<?= site_escape((string) $value) ?>"<?= $appearanceDraft[$id][$key] === (string) $value ? ' selected' : '' ?>><?= site_escape(site_component_size_text($label, $adminLanguage)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php if (isset($component['examplePath'])): ?>
                    <?php
                    $example = '[' . $id;
                    foreach ($component['settings'] as $key => $field) {
                        $value = $appearanceDraft[$id][$key];
                        $example .= ' ' . $key . '=' . (isset($field['options'][$value]) ? $value : $field['default']);
                    }
                    $example .= ']' . $component['examplePath'] . '[/' . $id . ']';
                    ?>
                    <p class="component-example">
                        <?= admin_l('Пример вставки') ?>
                        <code data-component-example="<?= site_escape($component['examplePath']) ?>"><?= site_escape($example) ?></code>
                    </p>
                <?php endif; ?>
            </details>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить настройки компонентов') ?></button></div>
    </form>
    <?php require __DIR__ . '/banners-view.php'; ?>
<?php endif; ?>
