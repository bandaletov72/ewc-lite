<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$labels = admin_page_template_labels($adminLanguage);
try {
    $templates = admin_page_templates($adminLanguage);
    $revision = admin_settings_revision(site_read_record(SITE_PAGE_TEMPLATES_FILE, SITE_PAGE_TEMPLATES_LIMIT));
} catch (RuntimeException $exception) {
    echo '<p class="notice error" role="alert">' . admin_l($exception->getMessage()) . '</p>';
    return;
}
$selected = $pageTemplateDraftId ?? admin_input($_GET, 'template');
$record = $pageTemplateDraft ?? $templates[$selected] ?? ['name' => '', 'Title' => '', 'Heading' => '', 'Description' => '', 'html' => ''];
$stock = isset($templates[$selected]) && strpos($selected, 'custom-') !== 0;
?>
<h1><?= site_escape($labels[0]) ?></h1>
<p><?= site_escape($labels[12]) ?></p>
<div class="header-actions">
    <a class="button button-primary" href="<?= site_escape($pageTemplatesUrl . '&template=new#template-edit') ?>">+ <?= site_escape($labels[3]) ?></a>
</div>
<div class="page-preset-grid">
    <?php foreach ($templates as $id => $item): ?>
        <article class="page-preset-card form-stack">
            <h2><i class="fa-solid fa-<?= site_escape($item['icon']) ?>" aria-hidden="true"></i> <?= site_escape($item['name']) ?></h2>
            <div class="header-actions">
                <a class="button" href="<?= site_escape($adminUrl . '?' . http_build_query(['new' => '1', 'preset' => $id])) ?>"><?= site_escape($labels[2]) ?></a>
                <a class="button" href="<?= site_escape($pageTemplatesUrl . '&template=' . $id . '#template-edit') ?>"><?= admin_l(strpos($id, 'custom-') === 0 ? 'Редактировать' : 'Открыть') ?></a>
            </div>
        </article>
    <?php endforeach; ?>
</div>
<?php if ($selected === 'new' || isset($templates[$selected])): ?>
    <form id="template-edit" class="panel form-stack" method="post" action="<?= site_escape($pageTemplatesUrl) ?>#template-edit">
        <h2><?= site_escape($stock || $selected !== 'new' ? $record['name'] : $labels[3]) ?></h2>
        <?php if (!$stock): ?>
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($revision) ?>">
            <input type="hidden" name="action" value="save-page-template">
            <input type="hidden" name="template" value="<?= site_escape($selected) ?>">
            <label class="field"><?= site_escape($labels[4]) ?>
                <input name="name" maxlength="120" required value="<?= site_escape($record['name']) ?>">
            </label>
            <?php foreach (['Title' => 'Заголовок вкладки', 'Heading' => 'Заголовок H1', 'Description' => 'Метаописание'] as $key => $label): ?>
                <label class="field"><?= admin_l($label) ?>
                    <input name="<?= $key ?>" maxlength="375"<?= $key === 'Title' ? ' required' : '' ?> value="<?= site_escape($record[$key]) ?>">
                </label>
            <?php endforeach; ?>
        <?php endif; ?>
        <label class="field">HTML
            <textarea name="html" rows="12" spellcheck="false" data-code-mode="html"<?= $stock ? ' readonly' : '' ?>><?= "\n" . site_escape($record['html']) ?></textarea>
        </label>
        <?php if (!$stock): ?>
            <details class="field-config disclosure-panel"<?= $error !== '' ? ' open' : '' ?>>
                <summary><span class="disclosure-arrow" aria-hidden="true"></span>CSS · JavaScript</summary>
                <div class="form-stack"><?php admin_asset_editors($record['assets'] ?? []); ?></div>
            </details>
        <?php endif; ?>
        <?php if (!$stock): ?><div><button type="submit" class="button-primary"><?= admin_l('Сохранить') ?></button></div><?php endif; ?>
    </form>
<?php endif; ?>
