<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_design_themes(): array
{
    $themes = ['demo'];
    foreach (glob(SITE_DESIGN_ROOT . '/*', GLOB_ONLYDIR) ?: [] as $directory) {
        $id = basename($directory);
        if ($id !== 'demo' && site_design_directory($id) !== '') $themes[] = $id;
    }
    sort($themes, SORT_NATURAL);
    return $themes;
}

function admin_design_inventory(): array
{
    $relative = array_values(array_filter(site_layout_blocks()));
    $relative = array_merge($relative, ['layout.php', 'content.php', 'editor-bar.php', 'library-assets.php', 'navigation-links.php', 'search-results.php']);
    foreach (['components', 'iblock'] as $folder) {
        foreach (glob(SITE_ROOT . '/templates/' . $folder . '/*.php') ?: [] as $file) {
            $relative[] = $folder . '/' . basename($file);
        }
    }
    $relative = array_values(array_unique($relative));
    sort($relative, SORT_STRING);
    return array_merge($relative, ['css/theme.css', 'js/theme.js']);
}

function admin_design_prepare_directory(string $relative)
{
    $path = SITE_ROOT . '/templates';
    foreach (explode('/', $relative) as $part) {
        $path .= '/' . $part;
        if (is_link($path) || (!is_dir($path) && !@mkdir($path, 0755))
            || realpath($path) !== str_replace('/', DIRECTORY_SEPARATOR, $path)) {
            throw new RuntimeException('Не удалось создать каталог темы дизайна.');
        }
    }
}

function admin_design_protect()
{
    admin_design_prepare_directory('themes');
    $rules = [
        '.htaccess' => "<FilesMatch \"(?i)(?:\\.php(?:[0-9]+)?$|^\\.)\">\n    Require all denied\n</FilesMatch>\n",
        'web.config' => '<?xml version="1.0" encoding="UTF-8"?>'
            . '<configuration><system.webServer><security><requestFiltering><fileExtensions>'
            . '<add fileExtension=".php" allowed="false" /></fileExtensions></requestFiltering></security></system.webServer></configuration>',
    ];
    foreach ($rules as $file => $text) {
        $path = SITE_DESIGN_ROOT . '/' . $file;
        if (is_link($path) || (!is_file($path) && !admin_replace_file($path, $text))) {
            throw new RuntimeException('Не удалось защитить каталог темы дизайна.');
        }
    }
}

function admin_design_write(string $id, string $relative, string $source)
{
    if (strlen($source) > 262144 || strpos($source, "\0") !== false || preg_match('//u', $source) !== 1) {
        throw new RuntimeException('Проверьте длину и формат полей настроек.');
    }
    if (substr($relative, -4) === '.php') {
        $guard = "<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>";
        if (strpos($source, $guard) !== 0) $source = $guard . $source;
        foreach (admin_validate_php($source) as $token) {
            if (is_array($token) && $token[0] === T_HALT_COMPILER) {
                throw new RuntimeException('В шаблонах PHP нельзя использовать __halt_compiler().');
            }
        }
    }
    admin_design_protect();
    $parent = dirname($relative);
    admin_design_prepare_directory('themes/' . $id . ($parent !== '.' ? '/' . $parent : ''));
    $file = SITE_DESIGN_ROOT . '/' . $id . '/' . $relative;
    if (is_link($file) || !admin_replace_file($file, $source)) {
        throw new RuntimeException('Не удалось сохранить файл темы дизайна.');
    }
}

function admin_design_seed_demo()
{
    $new = site_design_directory('demo') === '';
    admin_design_protect();
    if (!$new) return;
    foreach (require SITE_ROOT . '/app/design-theme-demo.php' as $path => $source) {
        admin_design_write('demo', $path, $source);
    }
}

function admin_design_use_file(string $id, string $path)
{
    $keys = array_keys(site_layout_blocks(), $path, true);
    if (!$keys || $path === '') return;
    $name = $keys[0];
    $file = site_design_layout_file($id);
    $layout = site_read_record($file, SITE_SNIPPET_RECORD_LIMIT);
    if (!isset($layout[$name])) return;
    $history = $layout['_layoutHistory'][$name] ?? [];
    $history[] = $layout[$name];
    $layout['_layoutHistory'][$name] = array_slice($history, -8);
    unset($layout[$name]);
    admin_write_record($file, $layout, SITE_SNIPPET_RECORD_LIMIT);
}

function admin_design_action(string $action, array $input, string $language): array
{
    $id = admin_input($input, 'theme');
    $path = admin_input($input, 'file');
    $labels = site_design_labels($language);
    if (($id !== '' && !site_design_id($id)) || ($action !== 'design-apply' && $id === '')) {
        throw new RuntimeException($labels[10]);
    }
    $lock = admin_lock();
    try {
        if ($id === 'demo') admin_design_seed_demo();
        if ($action === 'design-create') {
            if (site_design_directory($id) !== '') throw new RuntimeException($labels[10]);
            admin_design_protect();
            admin_design_prepare_directory('themes/' . $id);
            admin_write_record(SITE_DESIGN_FILE, ['theme' => $id]);
        } elseif ($action === 'design-apply') {
            if ($id !== '' && site_design_directory($id) === '') throw new RuntimeException($labels[10]);
            admin_write_record(SITE_DESIGN_FILE, ['theme' => $id]);
        } else {
            if (site_design_directory($id) === '' || !in_array($path, admin_design_inventory(), true)) throw new RuntimeException($labels[10]);
            $existing = site_design_file($id, $path);
            if ($action === 'design-copy') {
                if ($existing !== '') throw new RuntimeException($labels[10]);
                $source = substr($path, -4) === '.php' ? @file_get_contents(SITE_ROOT . '/templates/' . $path) : '';
            } else {
                $source = admin_input($input, 'source');
                if ($existing === '' || !hash_equals((string) hash_file('sha256', $existing), admin_input($input, 'revision'))) {
                    throw new RuntimeException($labels[10]);
                }
            }
            if (!is_string($source)) throw new RuntimeException($labels[10]);
            admin_design_write($id, $path, $source);
            admin_design_use_file($id, $path);
        }
        return [$id, $path];
    } finally {
        fclose($lock);
    }
}
