<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1>Библиотеки и шрифты</h1>
<?php if ($libraryDraft !== null): ?>
    <form class="panel form-stack" method="post" action="<?= site_escape($librariesUrl) ?>">
        <input type="hidden" name="action" value="save-libraries">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($libraryRevision) ?>">
        <fieldset class="field-config form-stack">
            <legend>Библиотеки сайта</legend>
            <?php foreach (site_library_catalog() as $key => $library): ?>
                <label class="choice">
                    <input type="checkbox" name="enabled[<?= $key ?>]" value="1"<?= $libraryDraft['enabled'][$key] ? ' checked' : '' ?>>
                    <span><?= site_escape($library['label']) ?><br><small class="hint"><?= site_escape($library['hint']) ?></small></span>
                </label>
            <?php endforeach; ?>
        </fieldset>
        <div class="field">
            <?php $fontOptions = ['' => ['Системный']] + site_google_fonts(); ?>
            <span id="site-font-label">Шрифт сайта</span>
            <details class="font-picker" data-font-picker>
                <summary aria-describedby="site-font-label site-font-hint">
                    <span data-font-current class="font-preview-<?= site_escape($libraryDraft['font']) ?>"><?= site_escape($fontOptions[$libraryDraft['font']][0]) ?></span>
                </summary>
                <div class="font-list" role="radiogroup" aria-labelledby="site-font-label">
                    <?php foreach ($fontOptions as $key => $font): ?>
                        <label class="font-option">
                            <input type="radio" name="font" value="<?= site_escape($key) ?>"<?= $libraryDraft['font'] === $key ? ' checked' : '' ?>>
                            <span data-font-name class="font-preview-<?= site_escape($key) ?>"><?= site_escape($font[0]) ?></span>
                            <span aria-hidden="true" class="font-sample font-preview-<?= site_escape($key) ?>">Аа Бб</span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </details>
            <small class="hint" id="site-font-hint">Выбранный шрифт заменяет системный. Все 10 шрифтов Google поддерживают кириллицу.</small>
        </div>
        <button class="button-primary" type="submit">Сохранить</button>
    </form>
<?php endif; ?>
