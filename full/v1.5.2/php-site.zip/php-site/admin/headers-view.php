<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1>Служебные заголовки</h1>
<?php if ($headersDraft !== null): ?>
    <form class="panel form-stack" method="post" action="<?= site_escape($headersUrl) ?>">
        <input type="hidden" name="action" value="save-headers">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($headersRevision) ?>">
        <p class="hint">Общий HTML для всех публичных страниц. Можно вставлять метатеги, счётчики и скрипты. Canonical формируется автоматически.</p>
        <?php foreach (['head' => 'Внутри <head>', 'bodyEnd' => 'Перед </body>'] as $key => $label): ?>
            <div class="field">
                <label for="insert-<?= $key ?>"><?= site_escape($label) ?></label>
                <textarea id="insert-<?= $key ?>" class="code-editor" name="<?= $key ?>" rows="9" spellcheck="false" maxlength="32768"><?= "\n" . site_escape($headersDraft[$key]) ?></textarea>
            </div>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit">Сохранить</button></div>
    </form>
<?php endif; ?>
