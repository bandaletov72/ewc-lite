<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1>Библиотеки и шрифты</h1>
<?php if ($libraryDraft !== null): ?>
    <form class="panel form-stack" method="post" action="<?= site_escape($librariesUrl) ?>">
        <input type="hidden" name="action" value="save-libraries">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($libraryRevision) ?>">
        <fieldset class="field-config form-stack">
            <legend>Библиотеки сайта</legend>
            <?php foreach (site_library_catalog() as $key => $library): ?>
                <label class="choice">
                    <input type="checkbox" name="enabled[<?= $key ?>]" value="1"<?= $libraryDraft['enabled'][$key] ? ' checked' : '' ?>>
                    <span><?= site_escape($library['label']) ?><br><small class="hint"><?= site_escape($library['hint']) ?></small></span>
                </label>
            <?php endforeach; ?>
        </fieldset>
        <div class="field">
            <label for="site-font">Шрифт сайта</label>
            <select id="site-font" name="font" aria-describedby="site-font-hint">
                <option value="">Системный</option>
                <?php foreach (site_google_fonts() as $key => $font): ?>
                    <option value="<?= $key ?>"<?= $libraryDraft['font'] === $key ? ' selected' : '' ?>><?= site_escape($font[0]) ?></option>
                <?php endforeach; ?>
            </select>
            <small class="hint" id="site-font-hint">Выбранный шрифт заменяет системный. Все 10 шрифтов Google поддерживают кириллицу.</small>
        </div>
        <button class="button-primary" type="submit">Сохранить</button>
    </form>
<?php endif; ?>
