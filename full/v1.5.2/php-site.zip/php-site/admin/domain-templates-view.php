<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<section class="panel form-stack theme-presets">
    <h2><?= $layoutHost === '' ? 'Общие шаблоны' : 'Шаблоны · ' . site_escape($layoutHost) ?></h2>
    <form class="form-stack" method="post" action="<?= site_escape($layoutUrl) ?>">
        <input type="hidden" name="action" value="save-domain-templates">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($layoutRevision) ?>">
        <?php foreach (admin_domain_template_labels() as $name => $label): ?>
            <?php $block = $layoutDraft[$name]; ?>
            <fieldset class="field-config form-stack">
                <legend><?= site_escape($label) ?> <code>[<?= site_escape($name) ?>]</code></legend>
                <?php if ($section === 'layout'): ?>
                    <?php
                    $file = site_template_file(site_layout_blocks()[$name]);
                    $relative = substr($file, strlen(SITE_ROOT) + 1);
                    $source = @file_get_contents($file, false, null, 0, 65537);
                    ?>
                    <details class="template-guide">
                        <summary>Исходный файл <code><?= site_escape($relative) ?></code></summary>
                        <?php if ($source === false || strlen($source) > 65536): ?>
                            <p class="hint">Исходный файл недоступен для просмотра.</p>
                        <?php else: ?>
                            <pre><code><?= site_escape($source) ?></code></pre>
                        <?php endif; ?>
                    </details>
                <?php endif; ?>
                <div class="field">
                    <label for="<?= $name ?>-source">Источник шаблона</label>
                    <select id="<?= $name ?>-source" name="blocks[<?= $name ?>][mode]">
                        <option value="inherit"<?= $block['mode'] === 'inherit' ? ' selected' : '' ?>><?= $layoutHost === '' ? 'Штатный шаблон' : 'Общий шаблон' ?></option>
                        <option value="custom"<?= $block['mode'] === 'custom' ? ' selected' : '' ?>>Свой HTML</option>
                    </select>
                </div>
                <div class="field">
                    <label for="<?= $name ?>-code">HTML шаблона</label>
                    <textarea id="<?= $name ?>-code" class="short-editor" rows="6" spellcheck="false" name="blocks[<?= $name ?>][value]"><?= "\n" . site_escape($block['value']) ?></textarea>
                    <small class="hint">Этот HTML применяется при выборе «Свой HTML». Можно вставлять подшаблоны, например [city] или [tg].</small>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit">Сохранить шаблоны</button></div>
    </form>
</section>
