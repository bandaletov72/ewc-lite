<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_LIBRARIES_FILE = SITE_ROOT . '/admin/.libraries.php';

function site_library_catalog(): array
{
    $cdn = 'https://cdn.jsdelivr.net/npm/';
    return [
        'jquery' => ['label' => 'jQuery 4.1.0', 'hint' => 'Работа с DOM, событиями и плагинами.',
            'js' => ['https://code.jquery.com/jquery-4.1.0.min.js', 'UGSi5euAzE1p4sK41+yKs3vtdPcidmaW6fY2NUITZkjIPyMVUUYB/BV4A5Oa8uu2']],
        'bootstrap' => ['label' => 'Bootstrap 5.3.8', 'hint' => 'Сетка, кнопки, модальные окна и другие компоненты.',
            'css' => [$cdn . 'bootstrap@5.3.8/dist/css/bootstrap.min.css', 'sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB'],
            'js' => [$cdn . 'bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js', 'FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI']],
        'fontawesome' => ['label' => 'Font Awesome Free 7.3.1', 'hint' => 'Локальные иконки для классов fa-* и кода [fa-icon=house].'],
        'mui' => ['label' => 'Material UI 9.5.0', 'hint' => 'Компоненты React. Доступны через import из @mui/material.'],
        'alpine' => ['label' => 'Alpine.js 3.17.5', 'hint' => 'Интерактивные элементы через атрибуты x-data и x-on.',
            'js' => [$cdn . 'alpinejs@3.17.5/dist/cdn.min.js', 'FYLKjwG3aohNhNZoVG8sY/5ntunm+MqylL90Q+rT3OM7AwV9/BKFjk/RjoIpIgsI']],
        'htmx' => ['label' => 'htmx 2.0.11', 'hint' => 'Частичная загрузка страниц через атрибуты hx-get и hx-target.',
            'js' => [$cdn . 'htmx.org@2.0.11/dist/htmx.min.js', '2OatzQy1H+Zd/IIrjr1TcuDGqLXeHhbooAyJY1KdQMKnr4LZ22k31GBLdYKHmVjg']],
        'chartjs' => ['label' => 'Chart.js 4.6.1', 'hint' => 'Графики и диаграммы.',
            'js' => [$cdn . 'chart.js@4.6.1/dist/chart.umd.min.js', 'Emf5ZVIUiarAdhkgtqK+5/Z5qIvM6QoVrS+qAVtfyZVuD5lIHrac0me485+Antp0']],
        'glightbox' => ['label' => 'GLightbox 3.3.1', 'hint' => 'Просмотр фотографий и видео в окне поверх страницы.',
            'css' => [$cdn . 'glightbox@3.3.1/dist/css/glightbox.min.css', 'GPAzSuZc0kFvdIev6wm9zg8gnafE8tLso7rsAYQfc9hAdWCpOcpcNI5W9lWkYcsd'],
            'js' => [$cdn . 'glightbox@3.3.1/dist/js/glightbox.min.js', 'MZZbZ6RXJudK43v1qY1zOWKOU2yfeBPatuFoKyHAaAgHTUZhwblRTc9CphTt4IGQ']],
    ];
}

function site_google_fonts(): array
{
    return [
        'golos' => ['Golos Text', '400;500;600;700', 'sans-serif'],
        'manrope' => ['Manrope', '400;500;600;700', 'sans-serif'],
        'inter' => ['Inter', '400;500;600;700', 'sans-serif'],
        'montserrat' => ['Montserrat', '400;500;600;700', 'sans-serif'],
        'raleway' => ['Raleway', '400;500;600;700', 'sans-serif'],
        'pt-serif' => ['PT Serif', '400;700', 'serif'],
        'lora' => ['Lora', '400;500;600;700', 'serif'],
        'playfair' => ['Playfair Display', '400;500;600;700', 'serif'],
        'roboto-slab' => ['Roboto Slab', '400;500;600;700', 'serif'],
        'yeseva' => ['Yeseva One', '', 'serif'],
    ];
}

function site_library_settings(array $stored = []): array
{
    $enabled = [];
    foreach (site_library_catalog() as $key => $library) {
        $enabled[$key] = ($stored['enabled'][$key] ?? ($key === 'fontawesome')) === true;
    }
    $font = $stored['font'] ?? '';
    return ['enabled' => $enabled, 'font' => is_string($font) && isset(site_google_fonts()[$font]) ? $font : ''];
}

function site_material_imports(): array
{
    $cdn = 'https://esm.sh/';
    return ['imports' => [
        'react' => $cdn . 'react@19.3.1',
        'react/jsx-runtime' => $cdn . 'react@19.3.1/jsx-runtime',
        'react-dom' => $cdn . 'react-dom@19.3.1?external=react',
        'react-dom/client' => $cdn . 'react-dom@19.3.1/client?external=react',
        '@mui/material' => $cdn . '@mui/material@9.5.0?external=react,react-dom',
    ]];
}
