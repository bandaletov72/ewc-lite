<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_BRAND_FILE = SITE_ROOT . '/admin/.site-brand.php';

function site_brand_settings(): array
{
    try {
        $saved = site_read_record(SITE_BRAND_FILE);
    } catch (RuntimeException $exception) {
        $saved = [];
    }
    $brand = ['logo' => '', 'favicon' => ''];
    foreach (['logo' => 'images', 'favicon' => 'icons'] as $kind => $directory) {
        $path = $saved[$kind] ?? '';
        if (is_string($path)
            && preg_match('~\Atemplates/' . $directory . '/branding/' . $kind . '-(?:[A-Za-z0-9_-]{1,64}-)?[a-f0-9]{64}\.png\z~', $path)
            && is_file(SITE_ROOT . '/' . $path)) {
            $brand[$kind] = $path;
        }
    }
    return $brand;
}

const SITE_CONTACTS_FILE = SITE_ROOT . '/admin/.contacts.php';
const SITE_THEME_FILE = SITE_ROOT . '/admin/.theme.php';

function site_channels(): array
{
    return ['tg' => 'Telegram', 'vk' => 'ВКонтакте', 'whatsapp' => 'WhatsApp',
        'youtube' => 'YouTube', 'instagram' => 'Instagram', 'max' => 'MAX'];
}

function site_contact_settings(): array
{
    $defaults = ['heading' => 'Связаться с нами', 'phones' => [], 'channels' => []];
    try {
        return array_replace($defaults, site_read_record(SITE_CONTACTS_FILE));
    } catch (RuntimeException $exception) {
        return $defaults;
    }
}

function site_contact_tokens(): array
{
    $codes = array_keys(site_channels());
    return ['wa' => 'whatsapp', 'yt' => 'youtube', 'ig' => 'instagram', 'phones' => 'phones',
        'contacts' => 'contacts', 'soc-icons' => 'soc-icons']
        + array_combine($codes, $codes);
}

function site_contact_markup(string $code, string $base, array $settings): string
{
    $items = [];
    if ($code === 'phones' || $code === 'contacts') {
        foreach ($settings['phones'] as $phone) {
            $href = 'tel:' . preg_replace('/[^0-9+]/', '', $phone['number']);
            $items[] = ['href' => $href, 'icon' => 'phone', 'text' => $phone['text'] !== '' ? $phone['text'] : $phone['number'], 'label' => $phone['number']];
        }
    }
    if ($code !== 'phones') {
        foreach (site_channels() as $id => $name) {
            if (($code === 'contacts' || $code === 'soc-icons' || $id === $code) && !empty($settings['channels'][$id]['url'])) {
                $item = $settings['channels'][$id];
                $items[] = ['href' => $item['url'], 'icon' => $id, 'text' => $item['text'] !== '' ? $item['text'] : $name, 'label' => $name];
            }
        }
    }
    if (!$items) {
        return '';
    }

    ob_start();
    require site_template_file('components/contact-links.php');
    return (string) ob_get_clean();
}

function site_theme_fields(): array
{
    return ['paper' => 'Фон страницы', 'surface' => 'Поверхности и поля', 'ink' => 'Основной текст',
        'muted' => 'Второстепенный текст', 'accent' => 'Ссылки и кнопки',
        'accent-wash' => 'Выделение', 'line' => 'Разделители и обводки'];
}

function site_theme_color(string $value): bool
{
    return preg_match('/\A#[0-9a-fA-F]{6}\z/', $value) === 1;
}

function site_normalize_theme(array $record): array
{
    $defaults = [
        'mode' => 'auto',
        'light' => ['paper' => '#f7f8f6', 'surface' => '#ffffff', 'ink' => '#192823',
            'muted' => '#50645b', 'accent' => '#12634e', 'accent-wash' => '#e5f2eb', 'line' => '#d8e2dc'],
        'dark' => ['paper' => '#141c19', 'surface' => '#1c2822', 'ink' => '#ecf4ee',
            'muted' => '#b0c3b8', 'accent' => '#79d4b1', 'accent-wash' => '#2b4339', 'line' => '#466054'],
    ];
    if (in_array($record['mode'] ?? '', ['auto', 'light', 'dark'], true)) {
        $defaults['mode'] = $record['mode'];
    }
    foreach (['light', 'dark'] as $scheme) {
        foreach ($defaults[$scheme] as $name => $color) {
            $candidate = $record[$scheme][$name] ?? null;
            if (is_string($candidate) && site_theme_color($candidate)) {
                $defaults[$scheme][$name] = strtolower($candidate);
            }
        }
    }
    return $defaults;
}

function site_theme_state(): array
{
    try {
        $record = site_read_record(SITE_THEME_FILE);
    } catch (RuntimeException $exception) {
        $record = [];
    }

    $presets = [];
    foreach (is_array($record['presets'] ?? null) ? $record['presets'] : [] as $id => $preset) {
        if (preg_match('/\Atheme-[a-f0-9]{16}\z/', (string) $id) === 1 && is_array($preset)
            && is_string($preset['name'] ?? null) && is_array($preset['theme'] ?? null)) {
            $presets[$id] = ['name' => $preset['name'], 'theme' => site_normalize_theme($preset['theme'])];
        }
    }
    if (($record['starterThemesAdded'] ?? false) !== true) {
        $usedNames = array_column($presets, 'name');
        foreach (site_starter_themes() as $id => $preset) {
            if (!isset($presets[$id]) && !in_array($preset['name'], $usedNames, true)) {
                $presets[$id] = $preset;
            }
        }
    }
    $default = $record['defaultPreset'] ?? '';
    return [
        'theme' => site_normalize_theme($record),
        'presets' => $presets,
        'default' => is_string($default) && isset($presets[$default]) ? $default : '',
    ];
}

function site_starter_themes(): array
{
    $palettes = [
        ['Северное сияние', '#edf8f6 #ffffff #122e2b #38615c #08685c #cbebe4 #afcdc6',
            '#0e221f #16302c #e6fff8 #a9d3cb #69e1c8 #214944 #42635e'],
        ['Тёплый песок', '#fff7e9 #fffdf7 #3b2616 #72563f #8a440b #f8dfbc #ddc3a5',
            '#241b14 #32251a #fff1dc #e6b994 #ffba72 #523725 #76573b'],
        ['Сумеречная лаванда', '#f7f4ff #fefcff #271b3d #5f517a #6540a1 #ebe0fb #d5c7e6',
            '#1c1729 #29203b #f9eeff #d3bfe9 #cfadff #44315f #645285'],
        ['Киноварь', '#fff4f0 #fffdfb #381c18 #74504c #a32625 #fbded8 #e5c1bb',
            '#2a1918 #382221 #fff1ec #e4b9b1 #ff9b8b #572e29 #7b524a'],
        ['Океанская синь', '#eff7ff #fafdff #112940 #425e78 #135ca3 #d9eaff #b7cde4',
            '#102133 #172d44 #eef7ff #b1cae2 #84c8ff #24496a #466887'],
    ];
    $keys = array_keys(site_theme_fields());
    $themes = [];
    foreach ($palettes as list($name, $light, $dark)) {
        $id = 'theme-' . substr(hash('sha256', 'starter:' . $name), 0, 16);
        $themes[$id] = ['name' => $name, 'theme' => ['mode' => 'auto',
            'light' => array_combine($keys, explode(' ', $light)),
            'dark' => array_combine($keys, explode(' ', $dark))]];
    }
    return $themes;
}

function site_theme_settings(): array
{
    return site_theme_state()['theme'];
}

function site_theme_css(string $scheme, array $palette): string
{
    $channels = [];
    foreach ([1, 3, 5] as $offset) {
        $channel = hexdec(substr($palette['accent'], $offset, 2)) / 255;
        $channels[] = $channel <= 0.04045 ? $channel / 12.92 : pow(($channel + 0.055) / 1.055, 2.4);
    }
    $luminance = 0.2126 * $channels[0] + 0.7152 * $channels[1] + 0.0722 * $channels[2];
    $palette['on-accent'] = $luminance > 0.179 ? '#000000' : '#ffffff';
    $palette['error-surface'] = $scheme === 'dark' ? '#422626' : '#fbe8e6';
    $palette['error-ink'] = $scheme === 'dark' ? '#ffb4aa' : '#782a24';
    $css = ':root { color-scheme: ' . $scheme . ';';
    foreach ($palette as $name => $color) {
        $css .= ' --' . $name . ': ' . $color . ';';
    }
    return $css . " }\n";
}
