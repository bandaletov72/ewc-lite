<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_captcha_settings(array $form): array
{
    $stored = is_array($form['captcha'] ?? null) ? $form['captcha'] : [];
    return [
        'enabled' => ($stored['enabled'] ?? false) === true,
        'sitekey' => is_string($stored['sitekey'] ?? null) ? $stored['sitekey'] : '',
        'secret' => is_string($stored['secret'] ?? null) ? $stored['secret'] : '',
    ];
}

function site_valid_captcha_key(string $key): bool
{
    return preg_match('/\A[A-Za-z0-9_-]{1,256}\z/', $key) === 1;
}

function site_verify_captcha(array $captcha, $token, string $hostname): bool
{
    if (!is_string($token) || !preg_match('/\A[A-Za-z0-9_-]{1,4096}\z/', $token)) {
        return false;
    }
    if (!site_valid_captcha_key($captcha['secret'])) {
        throw new RuntimeException('CAPTCHA не настроена.');
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json",
            'content' => http_build_query(['secret' => $captcha['secret'], 'response' => $token]),
            'timeout' => 5,
            'follow_location' => 0,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $reply = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context, 0, 8192);
    $result = $reply === false ? null : json_decode($reply, true);
    if (!is_array($result) || !is_bool($result['success'] ?? null)) {
        throw new RuntimeException('Сервис CAPTCHA недоступен.');
    }
    $errors = $result['error-codes'] ?? [];
    if (is_array($errors) && array_intersect($errors, ['missing-input-secret', 'invalid-input-secret'])) {
        throw new RuntimeException('Проверьте секретный ключ CAPTCHA.');
    }
    $verifiedHost = is_string($result['hostname'] ?? null) ? site_normalize_domain($result['hostname']) : '';
    return $result['success'] === true && $verifiedHost !== '' && $verifiedHost === $hostname;
}
