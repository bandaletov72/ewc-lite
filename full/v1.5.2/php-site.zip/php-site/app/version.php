<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return '1.5.2';
