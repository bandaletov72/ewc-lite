<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
try {
    $libraries = site_library_settings(site_read_record(SITE_LIBRARIES_FILE));
} catch (RuntimeException $exception) {
    $libraries = site_library_settings();
}
foreach (site_library_catalog() as $id => $library):
    if (!$libraries['enabled'][$id]) {
        continue;
    }
    if (isset($library['css'])): ?>
        <link rel="stylesheet" href="<?= site_escape($library['css'][0]) ?>" integrity="sha384-<?= $library['css'][1] ?>" crossorigin="anonymous">
    <?php endif; ?>
    <?php if (isset($library['js'])): ?>
        <script src="<?= site_escape($library['js'][0]) ?>" integrity="sha384-<?= $library['js'][1] ?>" crossorigin="anonymous" defer></script>
    <?php endif; ?>
<?php endforeach; ?>
<?php if ($libraries['enabled']['fontawesome']): ?>
    <link rel="stylesheet" href="<?= site_escape(site_font_awesome_stylesheet($base)) ?>">
<?php endif; ?>
<?php if ($libraries['enabled']['mui']): ?>
    <script type="importmap"><?= json_encode(site_material_imports(), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
<?php endif; ?>
<?php if ($libraries['font'] !== ''): ?>
    <?php
    list($fontName, $fontWeights, $fontFallback) = site_google_fonts()[$libraries['font']];
    $fontUrl = 'https://fonts.googleapis.com/css2?family=' . urlencode($fontName)
        . ($fontWeights !== '' ? ':wght@' . $fontWeights : '') . '&display=swap';
    ?>
    <link rel="stylesheet" href="<?= site_escape($fontUrl) ?>">
    <style>:root { --site-font: "<?= $fontName ?>", <?= $fontFallback ?>; }</style>
<?php endif; ?>
