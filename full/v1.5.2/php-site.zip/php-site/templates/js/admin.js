document.addEventListener('beforeinput', (event) => {
    if (!event.data || !(event.target instanceof HTMLInputElement)) return;
    const field = event.target;
    if ((field.matches('[data-identifier-input]') && /[^A-Za-z0-9_-]/.test(event.data))
        || (field.matches('[data-address-input]') && /[^A-Za-z0-9_./-]/.test(event.data))) {
        event.preventDefault();
    }
});

(() => {
    const admin = document.querySelector('[data-page-admin]');
    if (!admin) return;
    const tree = admin.querySelector('[data-page-tree]');
    const status = document.querySelector('[data-page-feedback]');
    const editor = admin.querySelector('[data-page-editor]');
    const move = admin.querySelector('[data-page-move-form]');
    const folderMove = admin.querySelector('[data-folder-move-form]');
    const folders = () => [...tree.querySelectorAll('[data-page-folder]')].map((node) => node.dataset.pageFolder).sort();
    let dragged = null;
    let saving = false;

    const feedback = (message, error = false) => {
        status.textContent = message;
        status.classList.toggle('error', error);
        status.hidden = false;
    };
    const request = async (fields) => {
        if (saving) return false;
        saving = true;
        admin.setAttribute('aria-busy', 'true');
        const oldPath = editor ? editor.dataset.pagePath : '';
        const body = new URLSearchParams({
            ajax: '1', csrf: admin.dataset.csrf,
            current_path: oldPath, current_revision: oldPath ? editor.elements.revision.value : '',
            ...fields,
        });
        try {
            const response = await fetch(admin.dataset.adminUrl, {
                method: 'POST', body, headers: { Accept: 'application/json' },
            });
            const result = await response.json();
            if (!response.ok || !result.ok) {
                feedback(result.message || 'Действие не выполнено.', true);
                return false;
            }
            const open = new Map([...tree.querySelectorAll('[data-page-folder]')].map((folder) => [
                folder.dataset.pageFolder, folder.open,
            ]));
            tree.innerHTML = result.tree;
            tree.querySelectorAll('[data-page-folder]').forEach((folder) => {
                const path = folder.dataset.pageFolder;
                if (result.openFolder === path || (result.openFolder || '').startsWith(path + '/')) {
                    folder.open = true;
                    return;
                }
                if (result.page && result.page.path !== oldPath && result.page.path.startsWith(path + '/')) return;
                if (open.has(path)) folder.open = open.get(path);
            });
            if (oldPath && result.page === null) {
                editor.closest('[data-page-editor-wrapper]').hidden = true;
                editor.dataset.pagePath = '';
                window.history.replaceState(null, '', admin.dataset.adminUrl);
            } else if (oldPath && result.page) {
                const page = result.page;
                editor.dataset.pagePath = page.path;
                editor.elements.path.value = page.address;
                editor.elements.revision.value = page.revision;
                editor.elements.MenuVisible.checked = page.menu;
                if (editor.elements.Order.value === editor.elements.Order.defaultValue) {
                    editor.elements.Order.value = page.order;
                }
                editor.elements.Order.defaultValue = page.order;
                const link = editor.querySelector('[data-page-open]');
                link.href = page.publicUrl;
                link.hidden = page.hidden;
                if (move) {
                    move.setAttribute('action', page.editUrl);
                    move.elements.path.value = page.path;
                    move.elements.revision.value = page.revision;
                }
                if (oldPath !== page.path) window.history.replaceState(null, '', page.editUrl);
            }
            if (move) {
                const list = move.querySelector('datalist');
                list.replaceChildren(...folders().map((folder) => {
                    const option = document.createElement('option');
                    option.value = '/' + folder + '/';
                    return option;
                }));
            }
            feedback(result.message);
            return true;
        } catch (error) {
            feedback('Не удалось получить ответ. Обновите страницу и проверьте результат.', true);
            return false;
        } finally {
            saving = false;
            admin.removeAttribute('aria-busy');
        }
    };
    const rowOf = (element) => element.closest('li[data-page-node]');
    const targetOf = (row) => ({ path: row.dataset.pagePath, revision: row.dataset.pageRevision });
    const ask = {
        hide: 'Скрыть страницу?',
        show: 'Опубликовать страницу?',
        delete: 'Удалить страницу? Это действие нельзя отменить.',
    };

    admin.addEventListener('click', (event) => {
        if (event.target.closest('[data-page-drag]')) event.preventDefault();
        const moveFolderButton = event.target.closest('[data-page-folder-move]');
        if (moveFolderButton) {
            event.preventDefault();
            if (saving) return;
            const source = moveFolderButton.closest('[data-page-folder]').dataset.pageFolder;
            const parent = source.includes('/') ? source.substring(0, source.lastIndexOf('/')) : '';
            const choices = ['', ...folders()].filter((folder) =>
                folder !== parent && folder !== source && !folder.startsWith(source + '/')
            );
            folderMove.elements.path.value = source;
            folderMove.querySelector('[data-folder-move-label]').textContent = 'Переместить /' + source + '/';
            folderMove.elements.folder.replaceChildren(new Option('Выберите папку', ''), ...choices.map((folder) =>
                folder === '' ? new Option('/ (корень сайта)', '/') : new Option('/' + folder + '/', '/' + folder + '/')
            ));
            folderMove.hidden = false;
            folderMove.elements.folder.focus();
            return;
        }
        if (event.target.closest('[data-folder-move-cancel]')) {
            folderMove.hidden = true;
            return;
        }
        const link = event.target.closest('[data-page-action]');
        if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        const operation = link.dataset.pageAction;
        if (!saving && window.confirm(ask[operation])) {
            request({ action: 'change-page-status', operation, ...targetOf(rowOf(link)) });
        }
    });
    admin.addEventListener('change', async (event) => {
        const box = event.target;
        if (!box.matches('[data-page-menu]')) return;
        const checked = box.checked;
        const target = editor && editor.contains(box)
            ? { path: editor.dataset.pagePath, revision: editor.elements.revision.value }
            : targetOf(rowOf(box));
        box.disabled = true;
        const saved = await request({ action: 'page-menu', ...target, visible: checked ? '1' : '0' });
        if (!saved) box.checked = !checked;
        box.disabled = false;
    });
    admin.addEventListener('submit', async (event) => {
        if (saving) {
            event.preventDefault();
            return;
        }
        if (event.target === folderMove) {
            event.preventDefault();
            if (await request(Object.fromEntries(new FormData(folderMove)))) folderMove.hidden = true;
            return;
        }
        if (event.target !== move) return;
        event.preventDefault();
        const values = Object.fromEntries(new FormData(move));
        if (await request(values)) {
            move.elements.folder.value = '';
            move.closest('[data-page-move]').open = false;
        }
    });

    const siblings = (row) => [...row.parentElement.children].filter((item) =>
        item.dataset.pagePath && item.dataset.pagePath !== 'index.php'
    );
    const reorder = async (row, to) => {
        const items = siblings(row);
        const from = items.indexOf(row);
        if (from === to || to < 0 || to >= items.length) return;
        const folder = row.parentElement.dataset.pageGroup;
        const path = row.dataset.pagePath;
        items.splice(from, 1);
        items.splice(to, 0, row);
        if (await request({ action: 'page-order', folder, items: JSON.stringify(items.map(targetOf)) })) {
            const moved = [...tree.querySelectorAll('[data-page-node]')].find((item) => item.dataset.pagePath === path);
            if (moved) {
                const handle = [...moved.querySelectorAll('[data-page-drag]')].find((item) => rowOf(item) === moved);
                if (handle) handle.focus();
            }
        }
    };
    tree.addEventListener('keydown', (event) => {
        const handle = event.target.closest('[data-page-drag]');
        if (!handle || saving || !['ArrowUp', 'ArrowDown'].includes(event.key)) return;
        event.preventDefault();
        const row = rowOf(handle);
        reorder(row, siblings(row).indexOf(row) + (event.key === 'ArrowUp' ? -1 : 1));
    });
    tree.addEventListener('dragstart', (event) => {
        const handle = event.target.closest('[data-page-drag]');
        if (!handle || saving) {
            event.preventDefault();
            return;
        }
        dragged = rowOf(handle);
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', dragged.dataset.pagePath);
        dragged.classList.add('is-moving');
    });
    tree.addEventListener('dragover', (event) => {
        const row = rowOf(event.target);
        if (!dragged || !siblings(dragged).includes(row)) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
    });
    tree.addEventListener('drop', (event) => {
        if (!dragged) return;
        const to = siblings(dragged).indexOf(rowOf(event.target));
        if (to === -1) return;
        event.preventDefault();
        reorder(dragged, to);
    });
    tree.addEventListener('dragend', () => {
        if (dragged) dragged.classList.remove('is-moving');
        dragged = null;
    });
})();

document.querySelectorAll('[data-theme-presets]').forEach((form) => {
    form.addEventListener('submit', (event) => {
        if (event.submitter && event.submitter.value === 'delete-theme-preset' && !window.confirm('Удалить сохранённую тему?')) {
            event.preventDefault();
        }
    });
});

document.querySelectorAll('[data-component-code]').forEach((component) => {
    const example = component.querySelector('[data-component-example]');
    const fields = [...component.querySelectorAll('[data-component-param]')];
    const updateExample = () => {
        const name = component.dataset.componentCode;
        const params = fields.map((field) => field.dataset.componentParam + '=' + field.value).join(' ');
        example.textContent = '[' + name + ' ' + params + ']' + example.dataset.componentExample + '[/' + name + ']';
    };
    component.addEventListener('change', updateExample);
});

(() => {
    const form = document.querySelector('[data-form-config]');
    if (!form) return;

    const rows = form.querySelector('[data-form-rows]');
    const template = form.querySelector('[data-empty-field]');
    let nextIndex = rows.children.length;
    const updateOptions = (row) => {
        const select = row.querySelector('[data-field-type]');
        const option = select.selectedOptions[0];
        const type = select.value;
        const length = row.querySelector('[data-field-length]');
        length.max = option.dataset.maxLength;
        length.placeholder = option.dataset.defaultLength;
        row.querySelector('[data-field-options]').hidden = type !== 'radio' && type !== 'select';
    };
    [...rows.children].forEach(updateOptions);

    form.querySelector('[data-add-field]').addEventListener('click', () => {
        const row = template.content.firstElementChild.cloneNode(true);
        row.querySelectorAll('[name]').forEach((field) => {
            field.name = field.name.replace('__INDEX__', String(nextIndex));
        });
        nextIndex += 1;
        rows.append(row);
        updateOptions(row);
        row.querySelector('input').focus();
    });
    rows.addEventListener('change', (event) => {
        if (event.target.matches('[data-field-type]')) updateOptions(event.target.closest('[data-form-row]'));
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-field]')) event.target.closest('[data-form-row]').remove();
    });
})();

(() => {
    const form = document.querySelector('[data-contacts-config]');
    if (!form) return;

    const rows = form.querySelector('[data-phone-rows]');
    const template = form.querySelector('[data-phone-template]');
    let nextIndex = rows.children.length;
    form.querySelector('[data-add-phone]').addEventListener('click', () => {
        const row = template.content.firstElementChild.cloneNode(true);
        row.querySelectorAll('[name]').forEach((input) => {
            input.name = input.name.replace('__INDEX__', String(nextIndex));
        });
        nextIndex += 1;
        rows.append(row);
        row.querySelector('input').focus();
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-phone]')) event.target.closest('[data-phone-row]').remove();
    });
})();

(() => {
    const copy = document.querySelector('[data-copy-iblock]');
    if (!copy) return;

    const csv = document.getElementById('iblock-csv');
    const status = document.querySelector('[data-copy-status]');
    copy.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(csv.value);
            status.textContent = 'CSV скопирован.';
        } catch (error) {
            csv.focus();
            csv.select();
            status.textContent = 'Текст выделен. Нажмите Ctrl+C.';
        }
    });
})();

(() => {
    const form = document.querySelector('[data-iblock-editor]');
    if (!form) return;
    const status = form.querySelector('[data-iblock-status]');
    const submit = form.querySelector('[type="submit"]');
    let saving = false;
    let queued = false;
    const feedback = (message, error = false) => {
        status.textContent = message;
        status.classList.toggle('error', error);
        status.hidden = false;
    };
    const save = async () => {
        if (saving) {
            queued = true;
            return;
        }
        if (!form.reportValidity()) return;

        saving = true;
        submit.disabled = true;
        feedback('Сохраняем инфоблок…');
        const values = new URLSearchParams({ ajax: '1' });
        for (const [name, value] of new FormData(form)) {
            values.append(name, value);
        }
        try {
            const response = await fetch(form.getAttribute('action'), {
                method: 'POST', body: values, headers: { Accept: 'application/json' },
            });
            if (!response.headers.get('Content-Type')?.includes('application/json')) {
                feedback(response.redirected
                    ? 'Сессия завершена. Войдите снова в отдельной вкладке и повторите сохранение.'
                    : 'Сервер вернул неожиданный ответ (HTTP ' + response.status + '). Правки остались в редакторе.', true);
                queued = false;
                return;
            }
            const result = await response.json();
            if (!result.ok) {
                feedback(result.message, true);
                queued = false;
                return;
            }

            form.elements.revision.value = result.revision;
            if (form.dataset.iblockNew === '1') {
                form.dataset.iblockNew = '0';
                form.setAttribute('action', result.url);
                form.elements.id.value = result.id;
                form.elements.id.readOnly = true;
                form.querySelector('[data-iblock-heading-title]').textContent = 'Редактирование инфоблока';
                form.querySelector('[data-iblock-mode-link]').href = result.modeUrl;
                const shortcode = form.querySelector('[data-iblock-shortcode]');
                shortcode.querySelector('code').textContent = result.shortcode;
                shortcode.hidden = false;
                const list = document.querySelector('[data-iblock-list]');
                list.querySelectorAll('[aria-current]').forEach((link) => link.removeAttribute('aria-current'));
                const item = document.createElement('li');
                const link = document.createElement('a');
                link.href = result.url;
                link.textContent = result.id;
                link.setAttribute('aria-current', 'page');
                item.append(link);
                list.append(item);
                const empty = document.querySelector('[data-iblock-empty]');
                if (empty) empty.hidden = true;
                history.replaceState(null, '', result.url);
            }
            feedback(result.message);
        } catch (error) {
            feedback('Ответ о сохранении не получен. Правки остались в редакторе.', true);
            queued = false;
        } finally {
            saving = false;
            submit.disabled = false;
            if (queued) {
                queued = false;
                save();
            }
        }
    };
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        save();
    });
    if (!form.matches('[data-iblock-config]')) return;

    const columns = form.querySelector('[data-iblock-columns]');
    const heading = form.querySelector('[data-iblock-heading]');
    const rows = form.querySelector('[data-iblock-rows]');
    const template = form.querySelector('[data-iblock-column-template]');
    let nextColumn = columns.children.length;
    let nextRow = rows.children.length;

    const cellInput = (cell, column, value = '') => {
        const type = column.querySelector('[data-column-type]').value;
        const row = cell.closest('tr');
        const input = document.createElement({ bool: 'select', textarea: 'textarea' }[type] || 'input');
        input.dataset.cellType = type;
        input.name = 'rows[' + row.dataset.rowIndex + '][' + column.dataset.columnIndex + ']';
        if (type === 'textarea') {
            input.rows = 3;
        } else if (type === 'bool') {
            [['', '—'], ['1', 'Да'], ['0', 'Нет']].forEach(([id, label]) => {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = label;
                input.append(option);
            });
        } else {
            input.type = type;
            if (type === 'number') {
                input.step = 'any';
                value = value.replace(',', '.');
            }
        }
        input.value = value;
        if (value && input.value === '') {
            input.dataset.previousValue = value;
            input.setCustomValidity('Замените прежнее значение значением нового типа.');
            input.addEventListener('input', () => {
                delete input.dataset.previousValue;
                input.setCustomValidity('');
            }, { once: true });
        }
        cell.replaceChildren(input);
        return input;
    };

    const sync = (column) => {
        const index = column.dataset.columnIndex;
        const label = column.querySelector('[data-column-label]').value || 'Столбец';
        const type = column.querySelector('[data-column-type]').value;
        heading.querySelector('[data-cell-column="' + index + '"]').textContent = label;
        rows.querySelectorAll('[data-cell-column="' + index + '"]').forEach((cell) => {
            let input = cell.firstElementChild;
            if (input.dataset.cellType !== type) {
                input = cellInput(cell, column, input.dataset.previousValue || input.value);
            }
            input.setAttribute('aria-label', label);
        });
    };
    const addCell = (row, column) => {
        const index = column.dataset.columnIndex;
        const cell = document.createElement('td');
        cell.dataset.cellColumn = index;
        row.insertBefore(cell, row.querySelector('[data-iblock-actions]'));
        cellInput(cell, column);
    };

    [...columns.children].forEach(sync);
    form.querySelector('[data-add-column]').addEventListener('click', () => {
        const column = template.content.firstElementChild.cloneNode(true);
        column.dataset.columnIndex = String(nextColumn);
        column.querySelectorAll('[name]').forEach((input) => {
            input.name = input.name.replace('__INDEX__', String(nextColumn));
        });
        const cell = document.createElement('th');
        cell.scope = 'col';
        cell.dataset.cellColumn = String(nextColumn++);
        heading.insertBefore(cell, heading.querySelector('[data-iblock-actions]'));
        columns.append(column);
        [...rows.children].forEach((row) => addCell(row, column));
        sync(column);
        column.querySelector('input').focus();
    });
    form.querySelector('[data-add-row]').addEventListener('click', () => {
        if (!columns.children.length) return;
        const row = document.createElement('tr');
        row.dataset.rowIndex = String(nextRow++);
        const order = document.createElement('td');
        order.className = 'iblock-order';
        const handle = document.createElement('button');
        handle.className = 'iblock-drag';
        handle.type = 'button';
        handle.draggable = true;
        handle.dataset.dragRow = '';
        handle.title = 'Перетащить строку';
        handle.setAttribute('aria-label', 'Переместить строку. Используйте стрелки вверх и вниз');
        handle.textContent = '⠿';
        order.append(handle);
        row.append(order);
        const actions = document.createElement('td');
        actions.dataset.iblockActions = '';
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.dataset.removeRow = '';
        remove.textContent = 'Удалить строку';
        actions.append(remove);
        row.append(actions);
        rows.append(row);
        [...columns.children].forEach((column) => {
            addCell(row, column);
            sync(column);
        });
        row.querySelector('[data-cell-type]').focus();
    });
    columns.addEventListener('input', (event) => {
        if (event.target.matches('[data-column-label], [data-column-type]')) {
            sync(event.target.closest('[data-column-index]'));
        }
    });
    columns.addEventListener('click', (event) => {
        if (!event.target.matches('[data-remove-column]')) return;
        const column = event.target.closest('[data-column-index]');
        const index = column.dataset.columnIndex;
        form.querySelectorAll('[data-cell-column="' + index + '"]').forEach((cell) => cell.remove());
        column.remove();
    });
    rows.addEventListener('click', (event) => {
        if (event.target.matches('[data-remove-row]')) event.target.closest('tr').remove();
    });

    let dragging;
    let startOrder;
    const order = () => [...rows.children].map((row) => row.dataset.rowIndex).join(',');
    const saveOrder = () => {
        if (form.dataset.iblockNew === '0') save();
    };
    rows.addEventListener('dragstart', (event) => {
        const handle = event.target.closest('[data-drag-row]');
        if (!handle) return;
        dragging = handle.closest('tr');
        startOrder = order();
        dragging.classList.add('is-dragging');
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('text/plain', dragging.dataset.rowIndex);
    });
    rows.addEventListener('dragover', (event) => {
        const over = event.target.closest('tr');
        if (!dragging || !over || over === dragging) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = 'move';
        const box = over.getBoundingClientRect();
        if (event.clientY < box.top + box.height / 2) rows.insertBefore(dragging, over);
        else rows.insertBefore(dragging, over.nextElementSibling);
    });
    rows.addEventListener('drop', (event) => {
        if (dragging) event.preventDefault();
    });
    rows.addEventListener('dragend', () => {
        if (!dragging) return;
        dragging.classList.remove('is-dragging');
        dragging = null;
        if (startOrder !== order()) saveOrder();
    });
    rows.addEventListener('keydown', (event) => {
        const handle = event.target.closest('[data-drag-row]');
        if (!handle || !['ArrowDown', 'ArrowUp'].includes(event.key)) return;
        event.preventDefault();
        const row = handle.closest('tr');
        const down = event.key === 'ArrowDown';
        const neighbor = down ? row.nextElementSibling : row.previousElementSibling;
        if (!neighbor) return;
        rows.insertBefore(row, down ? neighbor.nextElementSibling : neighbor);
        handle.focus();
        saveOrder();
    });
})();
