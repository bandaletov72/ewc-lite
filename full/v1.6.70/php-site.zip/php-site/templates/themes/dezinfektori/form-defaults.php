<?php http_response_code(404); exit; __halt_compiler();
{
  "form1641": {
    "title": "Акция: −10% на первый заказ через сайт",
    "button": "Отправить заявку на скидку",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Ваше имя",
        "type": "text",
        "required": true,
        "options": [],
        "maxLength": 100
      },
      {
        "name": "phone",
        "label": "Телефон",
        "type": "tel",
        "required": true,
        "options": [],
        "maxLength": 33
      },
      {
        "name": "message",
        "label": "Какая обработка нужна и где",
        "type": "textarea",
        "required": false,
        "options": [],
        "maxLength": 1500
      }
    ]
  },
  "form1642": {
    "title": "Акция: −15% пенсионерам и людям с инвалидностью",
    "button": "Отправить заявку на скидку",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Ваше имя",
        "type": "text",
        "required": true,
        "options": [],
        "maxLength": 100
      },
      {
        "name": "phone",
        "label": "Телефон",
        "type": "tel",
        "required": true,
        "options": [],
        "maxLength": 33
      },
      {
        "name": "message",
        "label": "Какая обработка нужна и где",
        "type": "textarea",
        "required": false,
        "options": [],
        "maxLength": 1500
      }
    ]
  },
  "form1643": {
    "title": "Акция: до −15% при заказе вместе с соседями",
    "button": "Отправить заявку на скидку",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Ваше имя",
        "type": "text",
        "required": true,
        "options": [],
        "maxLength": 100
      },
      {
        "name": "phone",
        "label": "Телефон",
        "type": "tel",
        "required": true,
        "options": [],
        "maxLength": 33
      },
      {
        "name": "objects",
        "label": "Сколько объектов нужно обработать",
        "type": "text",
        "required": true,
        "options": [],
        "maxLength": 20
      },
      {
        "name": "message",
        "label": "Район и что нужно обработать",
        "type": "textarea",
        "required": false,
        "options": [],
        "maxLength": 1500
      }
    ]
  }
}
