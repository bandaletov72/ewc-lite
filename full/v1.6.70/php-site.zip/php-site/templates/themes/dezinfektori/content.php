<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php
if (empty($searchMode) && $originalPath === 'services/dezinsekciya/klopy/index.php' && !empty($page['path'])) {
    $promotions = [
        ['form1641', 'Скидка 10%', 'на первый заказ через сайт',
            'Оставьте онлайн-заявку в течение суток после посещения сайта. Скидка действует на первый заказ.'],
        ['form1642', 'Скидка 15%', 'пенсионерам и людям с инвалидностью',
            'Скидка для льготных категорий Москвы действует на все услуги. Подтверждающий документ можно показать специалисту при выезде.'],
        ['form1643', 'Скидка до 15%', 'при заказе вместе с соседями',
            'Закажите обработку совместно. При заказе на два объекта скидка 10% для каждого, на три и более объекта — 15%.'],
    ];
    ob_start();
    ?>
    <section class="dz-section" id="offers" aria-labelledby="dz-offers-title">
        <h2 id="dz-offers-title">Акции и скидки</h2>
        <div class="dz-promotions">
            <?php foreach ($promotions as list($promotionForm, $discount, $shortTitle, $terms)): ?>
                <article class="dz-promotion">
                    <h3><span><?= site_escape($discount) ?></span> <?= site_escape($shortTitle) ?></h3>
                    <p><?= site_escape($terms) ?></p>
                    <div class="dz-promotion-action">
                        <?= site_component_action_button('action=form form=' . $promotionForm
                            . ' label="Участвовать" title="' . $discount . ' ' . $shortTitle . '"', $components) ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
    $promotionsHtml = (string) ob_get_clean();
    $content = preg_replace_callback('~<section\b[^>]*\s+id="offers"[^>]*>.*?</section>~s',
        static function () use ($promotionsHtml): string { return $promotionsHtml; }, $content, 1, $replacedOffers) ?? $content;
    if ($replacedOffers === 0 && strpos($content, 'id="offers"') === false) $content .= $promotionsHtml;
}
if (empty($searchMode) && $originalPath === 'index.php' && empty($components['reviewInstances'])) {
    $content = preg_replace_callback('~(<section\b[^>]*\s+id="reviews"[^>]*>)(.*?)(</section>)~s',
        static function (array $section) use (&$components): string {
            $legacyLink = '~<a class="dz-button dz-button-soft" href="/reviews/">.*?</a>~s';
            $hasLink = preg_match($legacyLink, $section[2]) === 1;
            $reviews = site_component_reviews($components, false, !$hasLink);
            if ($reviews === '') return $section[0];

            $button = '<button type="button" class="dz-button dz-button-soft" aria-haspopup="dialog" data-action-open="'
                . site_escape($components['reviewDialogId']) . '">' . site_escape(site_review_labels($components['locale'])[9]) . '</button>';
            $body = preg_replace_callback($legacyLink, static function () use ($button): string { return $button; }, $section[2], 1);
            return $section[1] . $body . '<div id="dez-home-new-review">' . $reviews . '</div>' . $section[3];
        }, $content, 1, $homeReviewSection) ?? $content;
    if ($homeReviewSection === 0) {
        $content .= '<div class="dz-section">' . site_component_reviews($components) . '</div>';
    }
}
if (empty($searchMode) && $originalPath === 'reviews/index.php') {
    $reviews = empty($components['reviewInstances']) ? site_component_reviews($components) : '';
    if (!empty($components['reviewDialogId'])) {
        $content = preg_replace_callback('~<section\b[^>]*\s+id="leave-review"[^>]*>.*?</section>~s',
            static function (array $section) use ($reviews): string {
                $replaced = false;
                $body = preg_replace_callback('~<form\b[^>]*>.*?</form>~s',
                    static function (array $form) use ($reviews, &$replaced): string {
                        if (strpos($form[0], 'name="form" value="form87"') === false) return $form[0];
                        $replaced = true;
                        return $reviews;
                    }, $section[0]) ?? $section[0];
                return $replaced ? str_replace('class="dz-request" id="leave-review"', 'class="dz-section" id="leave-review"', $body)
                    : $section[0] . $reviews;
            }, $content, 1, $legacyReviewSection) ?? $content;
        if ($legacyReviewSection === 0) $content .= $reviews;
    }
}
$dezHome = empty($searchMode) && $originalPath === 'index.php' && strpos($page['html'], 'id="dez-hero-title"') !== false;
$dezReviews = empty($searchMode) && strpos($originalPath, 'services/') === 0 && empty($components['reviewInstances'])
    ? site_component_reviews($components, true, false) : '';
?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main dz-main<?= $dezHome ? ' dz-home' : '' ?>" id="content" lang="<?= site_escape($page['language'] ?? 'ru') ?>">
    <?php if (!$dezHome): ?><h1 class="dz-page-title"><?= site_escape($heading) ?></h1><?php endif; ?>
    <div class="page-content">
        <?php if ($dezReviews !== ''): ?>
            <p><button class="dz-button dz-button-soft" type="button" aria-haspopup="dialog"
                data-action-open="<?= site_escape($components['reviewDialogId']) ?>"><?= site_escape(site_review_labels($locale)[9]) ?></button></p>
        <?php endif; ?>
        <?= $content ?>
        <?php if ($dezReviews !== ''): ?><div class="dz-section" id="dez-service-reviews"><?= $dezReviews ?></div><?php endif; ?>
    </div>
</main>
