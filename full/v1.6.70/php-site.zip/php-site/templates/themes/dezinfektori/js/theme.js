(() => {
    const form = document.querySelector('#request form[data-contact-form]');
    const message = form?.querySelector('[name="fields[message]"]');
    if (!message || !document.querySelector('[data-dz-request]')) return;

    const topic = form.querySelector('[name="fields[topic]"]');
    let suggestion = '';
    document.addEventListener('click', (event) => {
        const link = event.target.closest('[data-dz-request]');
        if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        if (topic?.value === '' && Array.from(topic.options).some((option) => option.value === 'Дезинсекция')) {
            topic.value = 'Дезинсекция';
        }
        if (message.value.trim() !== '' && message.value !== suggestion) return;
        suggestion = 'Уничтожение клопов. ' + link.dataset.dzRequest + '.\n';
        message.value = suggestion;
    });
})();
