<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<div class="container dz-desktop">
    <nav class="dz-nav" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
        <?php require site_template_file('navigation-links.php'); ?>
    </nav>
    <div class="dz-header-tools"><?= site_expand_content('[search][lang]', $snippets, $context) ?></div>
</div>
