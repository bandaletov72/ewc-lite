<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Выезд и оценка объёма работ|3500|осмотр|form86
Обработка отдельной комнаты|8500|комната|form86
Комплексная обработка квартиры|14000|квартира|form86
