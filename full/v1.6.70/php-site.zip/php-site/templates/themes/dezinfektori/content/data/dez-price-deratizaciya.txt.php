<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обследование объекта|2500|осмотр|form86
Дератизация частного дома|5000|дом|form86
Дератизация коммерческого объекта|6500|помещение, бизнес|form86
