<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка квартиры от насекомых|2500|квартира|form86
Дератизация частного дома|5000|дом|form86
Дезинфекция помещения|3500|помещение|form86
