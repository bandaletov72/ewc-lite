<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Отзывы
Heading: Отзывы
Description: Оставьте отзыв о санитарной обработке «Дезинфекторы».
Keywords: отзывы, Дезинфекторы
Menu: Отзывы
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 40

<p class="dz-lead">Заказывали обработку? Расскажите, как прошёл выезд. Имя и текст публикуются с вашего согласия.</p>
[iblock=reviews]/data/dez-reviews.txt[/iblock]
<section class="dz-request" id="leave-review"><div><h2>Оставить отзыв</h2><p>Не указывайте в тексте телефон, точный адрес и другие личные данные.</p></div><div>[form87]</div></section>
