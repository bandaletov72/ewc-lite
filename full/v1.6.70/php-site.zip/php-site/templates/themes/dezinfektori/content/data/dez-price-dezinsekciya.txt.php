<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Дезинсекция квартиры|2500|квартира|form86
Дезинсекция частного дома|4500|дом|form86
Дезинсекция офиса|5000|офис, бизнес|form86
