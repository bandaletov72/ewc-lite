<?php http_response_code(404); exit; __halt_compiler();
{
  "mode": "light",
  "light": {
    "paper": "#f2f5f6",
    "surface": "#ffffff",
    "ink": "#111f30",
    "muted": "#4c5a6c",
    "accent": "#243d57",
    "accent-wash": "#e5edf4",
    "line": "#d4dfe8"
  },
  "dark": {
    "paper": "#131e2c",
    "surface": "#1b2b3c",
    "ink": "#f8fafc",
    "muted": "#aabfd4",
    "accent": "#c9f560",
    "accent-wash": "#283b4c",
    "line": "#3b536b"
  }
}
