<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка одной зоны хранения|2400|локально, хранение|form86
Обработка нескольких шкафов|3600|мебель, хранение|form86
Обработка квартиры|5000|квартира|form86
