<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Дератизация
Heading: Дератизация
Description: Выявление путей проникновения и контроль грызунов в зданиях и на территории.
Keywords: дератизация, Дезинфекторы
Menu: Дератизация
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 30
MenuExpand: 1
AnnouncementIcon: [fa-icon=paw]

<section class="dz-split dz-category"><div><p class="dz-lead">Выявление путей проникновения и контроль грызунов в зданиях и на территории.</p><div class="dz-service-callback">[callback=Заказать услугу]</div></div><div class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/warehouse.jpg" alt="" width="880" height="440" fetchpriority="high" decoding="async"></div></section>
<section class="dz-section"><h2>Услуги раздела</h2><ul class="dz-service-links"><li><a href="/services/deratizaciya/krysy/">Уничтожение крыс <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/myshi/">Уничтожение мышей <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/kroty/">Уничтожение кротов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/podvaly-i-sklady/">Дератизация подвалов и складов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/deratizaciya/predpriyatiya-i-obshchepit/">Дератизация предприятий и общепита <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section dz-faq-block"><h2>Вопросы о работе</h2><div class="dz-faq"><details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details>
<details><summary>Как подготовиться к приезду специалиста?</summary><p>Опишите объект и проблему. Мы скажем, к каким местам нужен доступ и какие вещи потребуется убрать перед конкретной обработкой.</p></details>
<details><summary>Можно ли обслуживать объект регулярно?</summary><p>Да, укажите тип объекта, число помещений и график доступа. Согласуем программу мониторинга и периодичность выездов.</p></details></div></section>
<section class="dz-section dz-price" id="price" aria-labelledby="dez-price-title">
    <h2 id="dez-price-title">Ориентировочные цены</h2>
    <p>Окончательная стоимость зависит от площади, условий на объекте и объёма работ.</p>
    [iblock=table]/data/dez-price-deratizaciya.txt[/iblock]
    <a class="dz-button dz-button-soft" href="#request">Уточнить стоимость</a>
</section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>
