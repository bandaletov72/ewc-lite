<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Дезинфекция квартиры|3500|квартира|form86
Дезинфекция частного дома|5500|дом|form86
Дезинфекция коммерческого помещения|6500|помещение, бизнес|form86
