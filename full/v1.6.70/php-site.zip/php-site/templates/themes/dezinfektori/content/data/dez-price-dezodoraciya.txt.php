<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка отдельной комнаты|3000|комната|form86
Обработка квартиры|5000|квартира|form86
Обработка коммерческого помещения|7500|помещение, бизнес|form86
