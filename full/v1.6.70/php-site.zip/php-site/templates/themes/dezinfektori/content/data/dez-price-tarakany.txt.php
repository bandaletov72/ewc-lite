<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка кухни и санузла|2500|кухня, санузел|form86
Обработка двухкомнатной квартиры|3700|квартира|form86
Обработка частного дома|5500|дом|form86
