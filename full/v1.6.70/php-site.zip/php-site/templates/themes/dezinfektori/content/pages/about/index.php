<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: О компании
Heading: О компании
Description: Дезинфекторы: дезинсекция, дератизация, дезинфекция и санитарное обслуживание бизнеса.
Keywords: о компании, Дезинфекторы
Menu: О компании
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 30

<section class="dz-split dz-category"><div><p class="dz-lead">Санитарная обработка для дома, участка и бизнеса. Состав работ определяем по характеру проблемы и условиям объекта.</p><a class="dz-button" href="/services/">Выбрать услугу <span aria-hidden="true">↗</span></a></div><div class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/equipment.jpg" alt="Оборудование для осмотра объекта" width="880" height="440" fetchpriority="high" decoding="async"></div></section>
<section class="dz-section"><h2>Что обсуждаем до выезда</h2><ul class="dz-checklist"><li>В каких помещениях и когда появились признаки проблемы</li><li>Особенности доступа, работы офиса или заселения номеров</li><li>Что убрать перед обработкой и когда можно вернуться</li></ul></section>
<section class="dz-section dz-team-scene"><div class="dz-team-copy"><h2>Сачок — наготове. План — на первом месте.</h2><p>Сначала выясняем, с чем имеем дело. Затем согласуем зоны работ, способ обработки и время, когда помещением или участком снова можно пользоваться.</p><a class="dz-button" href="/contacts/#request">Обсудить выезд <span aria-hidden="true">↗</span></a></div><div class="dz-team-photo"><img src="/templates/themes/dezinfektori/images/crew-dacha.jpg" alt="Два специалиста в защитных комбинезонах на участке у дачи" width="880" height="440" loading="lazy" decoding="async"></div></section>
[dez-business-cta]
