<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка одной комнаты|2300|комната|form86
Обработка квартиры|3400|квартира|form86
Обработка дома|4800|дом|form86
