<?php http_response_code(404); exit; __halt_compiler();
{
  "name": "Дезинфекторы",
  "subtitle": "Служба санитарной обработки",
  "description": "Дезинсекция, дератизация и дезинфекция помещений и участков. Разовая обработка и обслуживание бизнеса.",
  "footer": "© [year] Дезинфекторы",
  "publicUrl": "http://dezinfektori.ru/",
  "searchMode": "compact",
  "scrollAnimation": "slide"
}
