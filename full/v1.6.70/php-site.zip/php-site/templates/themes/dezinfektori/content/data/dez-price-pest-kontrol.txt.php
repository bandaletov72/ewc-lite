<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Аудит объекта|4500|осмотр|form86
Разовый выезд и мониторинг|6500|выезд, мониторинг|form86
Абонентское обслуживание за месяц|12000|обслуживание|form86
