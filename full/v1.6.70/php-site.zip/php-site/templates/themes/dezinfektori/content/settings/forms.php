<?php http_response_code(404); exit; __halt_compiler();
{
  "form86": {
    "title": "Заявка на санитарную обработку",
    "button": "Получить расчёт",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Ваше имя",
        "type": "text",
        "required": true,
        "maxLength": 100,
        "options": []
      },
      {
        "name": "phone",
        "label": "Телефон",
        "type": "tel",
        "required": true,
        "maxLength": 33,
        "options": []
      },
      {
        "name": "topic",
        "label": "Какую услугу вы ищете",
        "type": "select",
        "required": true,
        "maxLength": null,
        "options": [
          "Дезинсекция",
          "Дератизация",
          "Дезинфекция",
          "Комплексные услуги",
          "Услуги для бизнеса",
          "Нужна консультация"
        ]
      },
      {
        "name": "message",
        "label": "Тип объекта, адрес или район и описание проблемы",
        "type": "textarea",
        "required": true,
        "maxLength": 1800,
        "options": []
      }
    ]
  },
  "form87": {
    "title": "Оставить отзыв",
    "button": "Отправить отзыв",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Имя для публикации",
        "type": "text",
        "required": true,
        "maxLength": 90,
        "options": []
      },
      {
        "name": "rating",
        "label": "Оценка",
        "type": "select",
        "required": true,
        "maxLength": null,
        "options": [
          "5",
          "4",
          "3",
          "2",
          "1"
        ]
      },
      {
        "name": "message",
        "label": "Расскажите о вашем опыте",
        "type": "textarea",
        "required": true,
        "maxLength": 1500,
        "options": []
      },
      {
        "name": "permission",
        "label": "Разрешаете опубликовать имя и текст отзыва?",
        "type": "radio",
        "required": true,
        "maxLength": null,
        "options": [
          "Да",
          "Нет"
        ]
      }
    ]
  }
}
