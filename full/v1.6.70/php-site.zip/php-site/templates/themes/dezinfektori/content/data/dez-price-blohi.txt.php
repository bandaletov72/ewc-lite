<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка одной комнаты|2300|комната|form86
Обработка двухкомнатной квартиры|3600|квартира|form86
Обработка частного дома|5200|дом|form86
