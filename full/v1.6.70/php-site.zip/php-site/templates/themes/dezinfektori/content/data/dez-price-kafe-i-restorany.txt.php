<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Осмотр заведения|3500|осмотр|form86
Обработка кухни и подсобки|6500|кухня, общепит|form86
Комплексная обработка ресторана|10000|ресторан, общепит|form86
