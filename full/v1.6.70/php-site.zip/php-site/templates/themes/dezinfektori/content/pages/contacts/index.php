<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Контакты
Heading: Контакты
Description: Как заказать санитарную обработку или пест-контроль. Оставьте заявку для расчёта стоимости.
Keywords: контакты, Дезинфекторы
Menu: Контакты
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 50

<div class="dz-contact-meta"><p class="dz-lead">Чтобы обсудить выезд, напишите, какая услуга нужна и где расположен объект.</p>[contacts][phones][soc-icons]</div>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>
