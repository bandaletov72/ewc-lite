<?php http_response_code(404); exit; __halt_compiler();
{
  "dez-cover": {
    "folder": "",
    "order": [
      "s-technician"
    ],
    "slides": {
      "s-technician": {
        "image": "/templates/themes/dezinfektori/images/technician.jpg",
        "color": "#22384d"
      }
    }
  }
}
