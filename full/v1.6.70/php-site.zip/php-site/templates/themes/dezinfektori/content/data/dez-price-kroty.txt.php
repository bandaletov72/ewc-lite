<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Осмотр участка|2500|осмотр, участок|form86
Работы на участке до 6 соток|5500|участок, до 6 соток|form86
Работы на участке до 12 соток|8500|участок, до 12 соток|form86
