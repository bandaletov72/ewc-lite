<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Выезд для обследования объекта|5000|осмотр|form86
Работы для партии в отдельной камере|15000|камера|form86
Обработка складской зоны|28000|склад|form86
