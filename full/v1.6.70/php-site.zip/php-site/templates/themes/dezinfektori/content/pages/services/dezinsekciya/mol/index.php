<?php
$pageFile = __FILE__;
require __DIR__ . '/../../../index.php';
__halt_compiler();
Title: Уничтожение моли
Heading: Уничтожение моли
Description: Помогаем определить, связана ли проблема с текстилем, продуктами или общими местами хранения.
Keywords: уничтожение моли, обработка от платяной моли, пищевая моль
Menu: Уничтожение моли
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 14

<section class="dz-split dz-category"><div><p class="dz-lead">Помогаем определить, связана ли проблема с текстилем, продуктами или общими местами хранения.</p><div class="dz-actions"><div class="dz-service-callback">[callback=Заказать услугу]</div><a class="dz-button dz-button-soft" href="/services/dezinsekciya/">Дезинсекция <span aria-hidden="true">↗</span></a></div></div><figure class="dz-split-photo dz-pest-photo"><img src="/templates/themes/dezinfektori/images/services/mol.jpg" alt="Платяная моль" width="880" height="440" fetchpriority="high" decoding="async"><figcaption>Платяная моль</figcaption></figure></section>
<section class="dz-section dz-service-detail"><h2>Чем вредит и когда нужен осмотр</h2><p>Отверстия в шерсти, мехе и других вещах животного происхождения оставляют личинки платяной моли. Пищевая моль повреждает сухие продукты и может выдать себя паутинками в крупе или резервах корма. Для этих двух очагов нужны разные решения.</p><p>Если возле шкафа летает бабочка, осмотр стоит начать с вещей, которые долго лежали в покое. Если подозрительные следы обнаружены в кухонном шкафу, полезнее проверить упаковки и понять, откуда началось заражение.</p><h3>Что отметить до разговора со специалистом</h3><p>В шкафу осматривайте складки шерстяных вещей и места, где долго лежали пледы. В кухне обратите внимание на сухие запасы, паутинку и слипшиеся зёрна. Эти признаки помогают разделить две разные задачи.</p><p class="dz-article-sources"><a href="https://ipm.ucanr.edu/PMG/PESTNOTES/pn7435.html">Платяная моль — University of California IPM</a></p></section><section class="dz-section dz-compare" id="before-after" aria-label="До и после"><h2>До и после</h2><p>Иллюстрация типичной ситуации и видимых изменений на объекте.</p><div class="dz-compare-grid"><figure><img src="/templates/themes/dezinfektori/images/comparisons/mol-before.jpg" alt="Повреждённые волокна шерсти" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>До</b> Повреждённые волокна шерсти</figcaption></figure><figure><img src="/templates/themes/dezinfektori/images/comparisons/mol-after.jpg" alt="Вещи осмотрены и разложены для хранения" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>После</b> Вещи осмотрены и разложены для хранения</figcaption></figure></div></section><section class="dz-section dz-service-story dz-has-comic" id="story"><div><p class="dz-kicker">Истории с выезда · художественная зарисовка</p><h2>Кто съел рукав у пальто</h2><p>Хозяин достал из шкафа шерстяное пальто и нашёл две дырки на рукаве, который был сложен внутрь. На вешалке рядом всё выглядело целым. Осмотрели складки и вещи на нижней полке: рядом с пальто лежал свёрнутый шерстяной плед со следами личинок.</p><p>Открыли и кухонный шкаф, потому что хозяин заметил ещё одну бабочку около крупы. Продукты и шерсть проверили отдельно. «У моли вкус дороже моего», — сказал хозяин, глядя на совершенно целую синтетическую куртку.</p></div><figure><img src="/templates/themes/dezinfektori/images/stories/mol.jpg" alt="Кто съел рукав у пальто" width="880" height="440" loading="lazy" decoding="async"><figcaption>Кто съел рукав у пальто</figcaption></figure></section>
<section class="dz-section"><h2>Как проходит услуга</h2><ol class="dz-steps"><li><h3>Осмотр</h3><p>Определяем, связана ли проблема с одеждой, текстилем или продуктами.</p></li><li><h3>План и выполнение работ</h3><p>Согласуем доступ к месту хранения и обработку зон, для которых подходит выбранный метод.</p></li><li><h3>После выезда</h3><p>Объясняем, как оценить результат, какие изменения важно отслеживать и когда стоит связаться с нами снова.</p></li></ol></section>
<section class="dz-section dz-faq-block"><h2>Частые вопросы</h2><div class="dz-faq"><details><summary>Как понять, какие вещи осматривать?</summary><p>Расскажите, где появились насекомые и где заметны повреждения. По этим признакам определим, какие зоны проверить.</p></details>
<details><summary>Нужно ли обработать содержимое шкафов?</summary><p>Для продуктов и вещей действуют разные ограничения. Специалист расскажет, что убрать и что требует отдельного решения.</p></details>
<details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details></div></section>
<section class="dz-section"><h2>Услуги этого направления</h2><ul class="dz-service-links"><li><a href="/services/dezinsekciya/klopy/">Уничтожение клопов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/tarakany/">Уничтожение тараканов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinsekciya/blohi/">Уничтожение блох <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section dz-price" id="price" aria-labelledby="dez-price-title">
    <h2 id="dez-price-title">Ориентировочные цены</h2>
    <p>Окончательная стоимость зависит от площади, условий на объекте и объёма работ.</p>
    [iblock=table]/data/dez-price-mol.txt[/iblock]
    <a class="dz-button dz-button-soft" href="#request">Уточнить стоимость</a>
</section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>
