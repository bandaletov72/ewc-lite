<?php http_response_code(404); exit; __halt_compiler();
{
  "dez-business-cta": {
    "description": "Предложение для коммерческих объектов",
    "value": "<aside class=\"dz-accent-callout\"><div><p class=\"dz-kicker\">Обслуживание бизнеса</p><h2>Нужен план для нескольких объектов?</h2><p>Укажите адреса, тип помещений и график доступа. Обсудим объём и периодичность работ.</p></div><a class=\"dz-button\" href=\"/contacts/#request\">Обсудить обслуживание <span aria-hidden=\"true\">↗</span></a></aside>"
  },
  "dez-address": {
    "description": "Адрес компании в шапке сайта",
    "value": ""
  }
}
