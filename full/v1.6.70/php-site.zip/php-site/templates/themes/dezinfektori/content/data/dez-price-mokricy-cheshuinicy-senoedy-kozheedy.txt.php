<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка локальной зоны|2400|локально|form86
Обработка двух помещений|3600|помещение|form86
Обработка квартиры|4900|квартира|form86
