<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Обработка квартиры|4500|квартира|form86
Обработка частного дома|7000|дом|form86
Комплекс работ на коммерческом объекте|11000|помещение, бизнес|form86
