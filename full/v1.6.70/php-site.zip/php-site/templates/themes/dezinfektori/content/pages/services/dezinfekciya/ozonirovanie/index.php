<?php
$pageFile = __FILE__;
require __DIR__ . '/../../../index.php';
__halt_compiler();
Title: Озонирование
Heading: Озонирование
Description: Оцениваем, подходит ли озонирование для конкретного помещения и задачи.
Keywords: озонирование, озонирование помещения, обработка запахов
Menu: Озонирование
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 15

<section class="dz-split dz-category"><div><p class="dz-lead">Оцениваем, подходит ли озонирование для конкретного помещения и задачи. До выезда согласуем, кто закроет помещение, когда его проветрить и когда можно вернуться.</p><div class="dz-actions"><div class="dz-service-callback">[callback=Заказать услугу]</div><a class="dz-button dz-button-soft" href="/services/dezinfekciya/">Дезинфекция <span aria-hidden="true">↗</span></a></div></div><figure class="dz-split-photo"><img src="/templates/themes/dezinfektori/images/services/ozonirovanie.jpg" alt="Озонирование" width="880" height="440" fetchpriority="high" decoding="async"></figure></section>
<section class="dz-section dz-service-detail"><h2>Когда нужна услуга</h2><p>Вопрос обычно возникает после стойкого запаха. Нужен осмотр: устранение его источника и оценка материалов важнее самого выбора оборудования. Озон раздражает дыхательные пути, поэтому людей и животных в зоне применения быть не должно.</p><p>При оценке проверяют возможность изоляции и безопасного возобновления доступа. Отсутствие запаха по окончании само по себе не подтверждает безопасную концентрацию. Условия возвращения согласуют отдельно.</p><h3>Что отметить до разговора со специалистом</h3><p>Расскажите, когда появился запах, где он сильнее и что уже пробовали сделать. Сообщите, можно ли освободить помещение и есть ли люди или животные в соседних зонах.</p><p class="dz-article-sources"><a href="https://www.epa.gov/indoor-air-quality-iaq/ozone-generators-are-sold-air-cleaners">Озон и качество воздуха — EPA</a></p></section><section class="dz-section dz-compare" id="before-after" aria-label="До и после"><h2>До и после</h2><p>Иллюстрация типичной ситуации и видимых изменений на объекте.</p><div class="dz-compare-grid"><figure><img src="/templates/themes/dezinfektori/images/comparisons/ozonirovanie-before.jpg" alt="Изолированная зона перед началом" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>До</b> Изолированная зона перед началом</figcaption></figure><figure><img src="/templates/themes/dezinfektori/images/comparisons/ozonirovanie-after.jpg" alt="Открытое помещение на этапе проветривания" width="880" height="440" loading="lazy" decoding="async"><figcaption><b>После</b> Открытое помещение на этапе проветривания</figcaption></figure></div></section><section class="dz-section dz-service-story" id="story"><div><p class="dz-kicker">Истории с выезда · художественная зарисовка</p><h2>Запах шёл из шкафа, хотя пахла вся комната</h2><p>Хозяин попросил озонирование после того, как несколько раз проветрил комнату. Запах ненадолго слабел и возвращался. Мы прошли вдоль стен, открыли шкаф и заметили, что сильнее всего пахнет у старого ковра, лежавшего в глубине.</p><p>Сначала обсудили, что делать с источником. Затем оценили, подходит ли помещение для озонирования и можно ли исключить доступ людей и животных. Исчезновение запаха само по себе не показывает, когда можно входить.</p></div></section>
<section class="dz-section"><h2>Как проходит услуга</h2><ol class="dz-steps"><li><h3>Осмотр</h3><p>Проверяем, можно ли изолировать помещение и устранён ли источник запаха.</p></li><li><h3>План и выполнение работ</h3><p>Согласуем отсутствие людей и животных, порядок проветривания и допуска после работ.</p></li><li><h3>После выезда</h3><p>Объясняем, как оценить результат, какие изменения важно отслеживать и когда стоит связаться с нами снова.</p></li></ol></section>
<section class="dz-section dz-faq-block"><h2>Частые вопросы</h2><div class="dz-faq"><details><summary>Можно ли оставаться в помещении?</summary><p>При озонировании в помещении не должно быть людей и животных. Возвращаться можно после выполнения условий, согласованных со специалистом.</p></details>
<details><summary>Устраняет ли озон источник запаха?</summary><p>Сначала нужно найти и устранить источник. При сохраняющейся причине запах может вернуться.</p></details>
<details><summary>От чего зависит стоимость?</summary><p>От площади и типа объекта, масштаба проблемы, доступности зон и выбранного метода. Сообщите эти данные в заявке, чтобы получить расчёт.</p></details></div></section>
<section class="dz-section"><h2>Услуги этого направления</h2><ul class="dz-service-links"><li><a href="/services/dezinfekciya/pomeshcheniya/">Дезинфекция квартир, домов и офисов <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/virusy-i-bakterii/">Дезинфекция от вирусов и бактерий <span aria-hidden="true">↗</span></a></li>
<li><a href="/services/dezinfekciya/plesen-i-gribok/">Дезинфекция от плесени и грибка <span aria-hidden="true">↗</span></a></li></ul></section>
<section class="dz-section dz-price" id="price" aria-labelledby="dez-price-title">
    <h2 id="dez-price-title">Ориентировочные цены</h2>
    <p>Окончательная стоимость зависит от площади, условий на объекте и объёма работ.</p>
    [iblock=table]/data/dez-price-ozonirovanie.txt[/iblock]
    <a class="dz-button dz-button-soft" href="#request">Уточнить стоимость</a>
</section>
<section class="dz-request" id="request"><div><p class="dz-kicker">Заявка на обработку</p><h2>Обсудим ваш объект</h2><p>Укажите район, тип объекта, примерную площадь и когда появилась проблема. Уточним условия и обсудим выезд.</p>[phones]</div><div>[form86]<small class="dz-form-privacy"><a href="/privacy/">Как обрабатываем данные заявки</a></small></div></section>
