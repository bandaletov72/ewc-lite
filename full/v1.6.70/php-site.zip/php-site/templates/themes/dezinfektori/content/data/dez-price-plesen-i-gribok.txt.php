<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Осмотр проблемной зоны|2300|осмотр|form86
Локальная обработка до 5 м²|3500|локально, до 5 м²|form86
Обработка нескольких зон|6500|несколько зон|form86
