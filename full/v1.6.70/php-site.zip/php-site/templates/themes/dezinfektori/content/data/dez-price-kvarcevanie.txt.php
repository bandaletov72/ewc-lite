<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Оценка условий на объекте|2000|осмотр|form86
Обработка одной комнаты|3000|комната|form86
Обработка нескольких комнат|5000|помещение|form86
