<?php http_response_code(404); exit; __halt_compiler();
author|text|rating|published
Имя для публикации|Текст отзыва|Оценка от 1 до 5|Показывать на сайте
text|textarea|number|bool
