<?php http_response_code(404); exit; __halt_compiler();
service|price|tag|order
Услуга|Ориентировочная цена|Теги|Заказ
text|price|hidden|form
Осмотр и план работ|2200|осмотр|form86
Обработка квартиры|3500|квартира|form86
Обработка частного дома|5000|дом|form86
