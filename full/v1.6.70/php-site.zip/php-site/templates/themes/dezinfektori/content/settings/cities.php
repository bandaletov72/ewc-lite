<?php http_response_code(404); exit; __halt_compiler();
{
  "moscow": {
    "name": "Москва",
    "domain": "",
    "phones": [
      {
        "label": "",
        "phone": ""
      },
      {
        "label": "",
        "phone": ""
      },
      {
        "label": "",
        "phone": ""
      },
      {
        "label": "",
        "phone": ""
      },
      {
        "label": "",
        "phone": ""
      }
    ]
  }
}
