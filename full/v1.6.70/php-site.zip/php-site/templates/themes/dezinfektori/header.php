<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php
$dezAddress = trim(site_expand_text($snippets['dez-address'] ?? '', $snippets));
$dezContactsUrl = site_url($base, 'contacts/');
$dezHasRequest = empty($searchMode) && !empty($page['html']) && strpos($page['html'], 'id="request"') !== false;
$dezPriceUrl = empty($searchMode) && !empty($page['html']) && strpos($page['html'], 'id="price"') !== false ? '#price' : site_url($base) . '#price';
$dezRequestUrl = $dezHasRequest ? '#request' : $dezContactsUrl . '#request';
?>
<div class="dz-header">
    <a class="dz-brand" href="<?= site_escape(site_url($base)) ?>">
      <?php $dezLogo = site_brand_logo_html($brand, $base); ?>
      <?= $dezLogo !== '' ? $dezLogo : '<span class="dz-mark" aria-hidden="true"><span></span></span>' ?>
      <span><strong><?= site_escape($settings['name']) ?></strong><small><?= site_escape($settings['subtitle']) ?></small></span>
    </a>
    <div class="dz-header-contacts">
        <a class="dz-header-address" href="<?= site_escape($dezContactsUrl) ?>"><i class="fa-solid fa-location-dot" aria-hidden="true"></i>
            <?= $dezAddress !== '' ? site_escape($dezAddress) : site_expand_content('[city]', $snippets, $context) ?>
        </a>
        <div class="dz-header-phones">
            <?= site_expand_content('[phones]', $snippets, $context) ?>
            <div class="dz-phone-fallback"><?= site_contact_markup('phones', $base, site_contact_settings()) ?></div>
        </div>
    </div>
    <div class="dz-header-actions">
        <a class="dz-button dz-button-soft" href="<?= site_escape($dezPriceUrl) ?>">Цены</a>
        <a class="dz-button dz-button-nav" href="<?= site_escape($dezRequestUrl) ?>">Оставить заявку</a>
    </div>
</div>
