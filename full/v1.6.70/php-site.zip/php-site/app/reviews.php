<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_REVIEWS_SETTINGS = SITE_ROOT . '/admin/.reviews.php';
const SITE_REVIEW_PREFIX = SITE_ROOT . '/data/.review-';
const SITE_REVIEW_BATCH = 10;

function site_review_labels(string $locale): array
{
    static $catalog;
    if ($catalog === null) $catalog = require __DIR__ . '/help-reviews.php';
    return $catalog[$locale] ?? $catalog['ru'];
}

function site_review_form(string $locale, bool $allowLegacyZero = false): array
{
    $labels = site_review_labels($locale);
    return ['button' => $labels[5], 'showRatingStars' => true, 'fields' => [
        ['name' => 'name', 'label' => $labels[1], 'type' => 'text', 'required' => true, 'maxLength' => 100, 'options' => []],
        ['name' => 'review', 'label' => $labels[2], 'type' => 'textarea', 'required' => true, 'maxLength' => 3000, 'options' => []],
        ['name' => 'rating', 'label' => $labels[3], 'type' => 'radio', 'required' => true, 'maxLength' => 1,
            'options' => $allowLegacyZero ? ['0', '1', '2', '3', '4', '5'] : ['1', '2', '3', '4', '5']],
    ]];
}

function site_review_stars(int $rating): string
{
    return str_repeat('★', $rating) . str_repeat('☆', 5 - $rating);
}

function site_review_id($id): bool
{
    return is_string($id) && preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id) === 1;
}

function site_review_scope(): string
{
    return site_content_root() === SITE_ROOT ? '' : site_design_active();
}

function site_review_read(string $id): array
{
    if (!site_review_id($id)) return [];
    $file = SITE_REVIEW_PREFIX . $id . '.php';
    if (is_link($file)) return [];
    $row = site_read_record($file);
    if (($row['theme'] ?? null) !== site_review_scope() || !is_string($row['page'] ?? null)
        || !site_valid_path($row['page']) || !is_string($row['name'] ?? null) || !is_string($row['review'] ?? null)
        || !is_string($row['rating'] ?? null) || !in_array($row['rating'], ['0', '1', '2', '3', '4', '5'], true)
        || !in_array($row['status'] ?? '', ['pending', 'approved', 'rejected'], true)) return [];
    return $row;
}

function site_review_page($cursor, int $limit, bool $approved, string $filter = ''): array
{
    $ids = glob(SITE_REVIEW_PREFIX . '*.php') ?: [];
    rsort($ids, SORT_STRING);
    $rows = [];
    $previousId = '';
    foreach ($ids as $file) {
        $id = substr(basename($file, '.php'), strlen('.review-'));
        if (site_review_id($cursor) && strcmp($id, $cursor) >= 0) continue;
        try {
            $row = site_review_read($id);
        } catch (RuntimeException $exception) {
            continue;
        }
        if (!$row || ($approved && $row['status'] !== 'approved') || ($filter !== '' && $row['page'] !== $filter)) continue;
        if (count($rows) === $limit) return [$rows, $previousId];
        $rows[$id] = $row;
        $previousId = $id;
    }
    return [$rows, ''];
}

function site_review_filter(): string
{
    $filter = site_read_record(site_content_record(SITE_REVIEWS_SETTINGS))['page'] ?? '';
    return is_string($filter) && site_valid_path($filter) ? $filter : '';
}

function site_review_store(array $fields, string $page)
{
    $lock = admin_lock();
    try {
        $id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
        admin_write_record(SITE_REVIEW_PREFIX . $id . '.php', [
            'theme' => site_review_scope(), 'page' => site_page_translation($page)[0], 'status' => 'pending',
            'name' => $fields['name']['value'], 'review' => $fields['review']['value'], 'rating' => $fields['rating']['value'],
        ]);
    } finally {
        fclose($lock);
    }
}

function site_component_reviews(array &$context, bool $currentPageOnly = false, bool $showButton = true): string
{
    $page = $context['page'] ?? '';
    if (!site_valid_path($page)) return '';
    $locale = $context['locale'] ?? 'ru';
    $labels = site_review_labels($locale);
    $base = $context['base'];
    $number = ($context['reviewInstances'] ?? 0) + 1;
    $context['reviewInstances'] = $number;
    $anchor = 'reviews-' . $number;
    $cursor = ($_GET['review_block'] ?? '') === (string) $number ? ($_GET['reviews_before'] ?? '') : '';
    try {
        $filter = $currentPageOnly ? site_page_translation($page)[0] : site_review_filter();
        list($rows, $next) = site_review_page($cursor, SITE_REVIEW_BATCH, true, $filter);
    } catch (RuntimeException $exception) {
        return '';
    }
    $url = '';
    if ($next !== '') {
        $query = $_GET;
        unset($query['ajax']);
        $query['review_block'] = $number;
        $query['reviews_before'] = $next;
        $url = '?' . http_build_query($query) . '#' . $anchor;
    }
    $id = 'reviews';
    $form = site_review_form($locale);
    $session = $context['formSession'];
    $instance = $anchor . '-form';
    $dialogId = $context['reviewDialogId'] = $anchor . '-dialog';
    ob_start();
    require site_template_file('components/reviews.php');
    return (string) ob_get_clean();
}
