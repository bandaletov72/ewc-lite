<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }
$labels = site_review_labels($adminLanguage);
list($reviews, $nextReview) = site_review_page($_GET['reviews_before'] ?? '', 30, false);
try {
    $reviewFilter = site_review_filter();
} catch (RuntimeException $exception) {
    $reviewFilter = '';
}
$reviewAction = site_escape($reviewsUrl);
?>
<h1><?= site_escape($labels[0]) ?></h1>
<form class="panel form-stack" method="post" action="<?= $reviewAction ?>">
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <label class="field"><?= site_escape($labels[10]) ?>
        <input name="review_page" maxlength="240" placeholder="/contacts/" value="<?= $reviewFilter === '' ? '' : site_escape(site_page_url('', $reviewFilter)) ?>">
    </label>
    <p class="hint"><?= site_escape($labels[11]) ?></p>
    <div><button class="button-primary" name="action" value="reviews-settings"><?= admin_l('Сохранить') ?></button></div>
</form>
<p><?= site_escape($labels[12]) ?></p>
<?php if (!$reviews): ?><p><?= site_escape($labels[7]) ?></p><?php endif; ?>
<?php foreach ($reviews as $reviewId => $row): ?>
    <?php $reviewPageUrl = site_page_url($base, $row['page']); ?>
    <article class="panel form-stack">
        <h2><?= site_escape($row['name']) ?> <small role="img" aria-label="<?= site_escape(sprintf($labels[4], $row['rating'])) ?>"><?= site_review_stars((int) $row['rating']) ?></small></h2>
        <div><a href="<?= site_escape($reviewPageUrl) ?>"><?= site_escape(site_page_url('', $row['page'])) ?></a>
            · <?= site_escape($labels[['pending' => 18, 'approved' => 19, 'rejected' => 20][$row['status']]]) ?></div>
        <p class="review-text"><?= site_escape($row['review']) ?></p>
        <?php ob_start(); ?>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="review_id" value="<?= site_escape($reviewId) ?>">
        <input type="hidden" name="revision" value="<?= hash('sha256', serialize($row)) ?>">
        <?php $reviewHidden = (string) ob_get_clean(); ?>
        <form class="header-actions" action="<?= $reviewAction ?>" method="post">
            <?= $reviewHidden ?>
            <?php if ($row['status'] !== 'approved'): ?><button name="action" value="review-approve"><?= site_escape($labels[21]) ?></button><?php endif; ?>
            <?php if ($row['status'] !== 'rejected'): ?><button name="action" value="review-reject"><?= site_escape($labels[22]) ?></button><?php endif; ?>
        </form>
        <details>
            <summary><?= admin_l('Редактировать') ?></summary>
            <form class="form-stack" action="<?= $reviewAction ?>" method="post">
                <?= $reviewHidden ?>
                <label class="field"><?= site_escape($labels[1]) ?><input name="name" value="<?= site_escape($row['name']) ?>" required maxlength="100"></label>
                <label class="field"><?= site_escape($labels[2]) ?><textarea name="review" rows="4" required maxlength="3000"><?= "\n" . site_escape($row['review']) ?></textarea></label>
                <label class="field"><?= site_escape($labels[3]) ?><select name="rating">
                    <?php foreach (range($row['rating'] === '0' ? 0 : 1, 5) as $rating): ?>
                        <option value="<?= $rating ?>"<?= (string) $rating === $row['rating'] ? ' selected' : '' ?>><?= site_review_stars($rating) ?></option>
                    <?php endforeach; ?>
                </select></label>
                <div><button class="button-primary" name="action" value="review-edit"><?= admin_l('Сохранить') ?></button></div>
            </form>
        </details>
        <details>
            <summary><?= admin_l('Удалить') ?></summary>
            <form class="form-stack" action="<?= $reviewAction ?>" method="post">
                <?= $reviewHidden ?>
                <label class="choice"><input type="checkbox" name="confirm_delete" value="1" required> <?= site_escape($labels[14]) ?></label>
                <div><button class="button-danger" name="action" value="review-delete"><?= admin_l('Удалить') ?></button></div>
            </form>
        </details>
    </article>
<?php endforeach; ?>
<nav class="header-actions" aria-label="<?= site_escape($labels[0]) ?>">
    <?php if (site_review_id($_GET['reviews_before'] ?? null)): ?><a class="button" href="<?= $reviewAction ?>"><?= site_escape($labels[23]) ?></a><?php endif; ?>
    <?php if ($nextReview !== ''): ?><a class="button" href="<?= site_escape($reviewsUrl . '&reviews_before=' . $nextReview) ?>"><?= site_escape($labels[8]) ?></a><?php endif; ?>
</nav>
