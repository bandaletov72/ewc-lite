<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
return [
    'ru' => ['Открыть маршрут', 'Вставьте [route] на странице с координатами. Кнопка откроет маршрут в сервисе, выбранном в «Интеграциях». Параметр provider=yandex или provider=google задаёт сервис явно. Если карты отключены, по умолчанию открывается Яндекс.'],
    'en' => ['Open directions', 'Insert [route] on a page with coordinates. The link uses the maps provider selected in Integrations. Set provider=yandex or provider=google to override it. If maps are disabled, Yandex is used by default.'],
    'uk' => ['Відкрити маршрут', 'Вставте [route] на сторінці з координатами. Кнопка відкриє сервіс, вибраний в інтеграціях. provider=yandex або provider=google задає сервіс явно. Якщо карти вимкнено, використовується Яндекс.'],
    'de' => ['Route öffnen', 'Fügen Sie [route] auf einer Seite mit Koordinaten ein. Der Link verwendet den Anbieter aus den Integrationen. Mit provider=yandex oder provider=google wählen Sie ihn direkt. Sind Karten deaktiviert, wird standardmäßig Yandex verwendet.'],
    'fr' => ['Ouvrir l’itinéraire', 'Insérez [route] sur une page avec des coordonnées. Le lien utilise le service de cartes choisi dans les intégrations. provider=yandex ou provider=google force le service. Si les cartes sont désactivées, Yandex est utilisé par défaut.'],
    'es' => ['Abrir ruta', 'Inserta [route] en una página con coordenadas. El enlace usa el proveedor de mapas elegido en Integraciones. Usa provider=yandex o provider=google para elegirlo. Si los mapas están desactivados, se usa Yandex.'],
    'pt' => ['Abrir trajeto', 'Insira [route] numa página com coordenadas. O link usa o fornecedor de mapas escolhido nas integrações. Use provider=yandex ou provider=google para o escolher explicitamente. Se os mapas estiverem desativados, é usado o Yandex.'],
    'vi' => ['Mở chỉ đường', 'Chèn [route] trên trang có tọa độ. Liên kết dùng dịch vụ bản đồ đã chọn trong phần tích hợp. Dùng provider=yandex hoặc provider=google để chọn trực tiếp. Nếu bản đồ bị tắt, mặc định dùng Yandex.'],
    'ja' => ['経路を開く', '座標のあるページに [route] を挿入します。連携設定で選んだ地図サービスで経路を開きます。provider=yandex または provider=google で明示的に選択できます。地図を無効にした場合は Yandex を使います。'],
    'ko' => ['길찾기 열기', '좌표가 있는 페이지에 [route]를 삽입하세요. 연동 설정에서 선택한 지도 서비스로 연결합니다. provider=yandex 또는 provider=google로 지정할 수도 있습니다. 지도가 꺼져 있으면 Yandex가 기본값입니다.'],
    'zh' => ['打开路线', '在已设置坐标的页面插入 [route]。按钮使用集成设置选定的地图服务。使用 provider=yandex 或 provider=google 可明确指定服务。地图关闭时默认使用 Yandex。'],
];
