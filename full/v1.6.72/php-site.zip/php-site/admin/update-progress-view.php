<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; }
$progressLabels = admin_update_progress_labels($adminLanguage);
?>
<section class="update-progress form-stack" data-update-progress data-start="<?= site_escape($progressLabels[($progressMode ?? '') === 'index' ? 'index-start' : 'start']) ?>"
    data-failure="<?= site_escape($progressLabels['connection']) ?>" hidden>
    <progress max="100" value="0" aria-label="<?= site_escape($progressLabels[($progressMode ?? '') === 'index' ? 'index-progress' : 'progress']) ?>"></progress>
    <p role="status" data-update-current></p>
    <ol data-update-log></ol>
    <div><button type="button" data-update-reload hidden><?= site_escape($progressLabels['reload']) ?></button></div>
</section>
