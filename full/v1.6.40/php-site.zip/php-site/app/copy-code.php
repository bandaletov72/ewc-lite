<?php
if (!defined('SITE_ROOT')) exit;

function site_copy_code(string $code, string $language, string $label = '', string $editId = ''): string
{
    $catalog = [
        'ru' => ['Скопировать', 'Код скопирован.'],
        'en' => ['Copy', 'Code copied.'],
        'uk' => ['Скопіювати', 'Код скопійовано.'],
        'de' => ['Kopieren', 'Code kopiert.'],
        'fr' => ['Copier', 'Code copié.'],
        'es' => ['Copiar', 'Código copiado.'],
        'pt' => ['Copiar', 'Código copiado.'],
        'ja' => ['コピー', 'コードをコピーしました。'],
        'ko' => ['복사', '코드를 복사했습니다.'],
        'vi' => ['Sao chép', 'Đã sao chép mã.'],
        'zh' => ['复制', '代码已复制。'],
    ];
    $editLabels = [
        'ru' => 'Править код вставки',
        'en' => 'Edit insertion code',
        'uk' => 'Редагувати код вставлення',
        'de' => 'Einfügecode bearbeiten',
        'fr' => 'Modifier le code d’insertion',
        'es' => 'Editar código de inserción',
        'pt' => 'Editar código de inserção',
        'ja' => '挿入コードを編集',
        'ko' => '삽입 코드 편집',
        'vi' => 'Sửa mã chèn',
        'zh' => '编辑插入代码',
    ];
    list($copy, $copied) = $catalog[$language] ?? $catalog['en'];
    $edit = site_escape($editLabels[$language] ?? $editLabels['en']);
    $editControl = $editId === '' ? '' : '<button class="copy-code-edit" type="button" data-copy-code-pencil aria-expanded="false"'
        . ' aria-controls="' . site_escape($editId) . '" title="' . $edit . '" aria-label="' . $edit . '">'
        . '<i class="fa-solid fa-pen" aria-hidden="true"></i></button>';
    $editor = $editId === '' ? '' : '<textarea data-copy-code-editor id="' . site_escape($editId) . '" aria-label="' . $edit
        . '" rows="2" spellcheck="false" hidden></textarea>';
    return '<div class="copy-code" data-copy-code>'
        . ($label === '' ? '' : '<strong class="copy-code-label">' . site_escape($label) . '</strong>')
        . '<div class="copy-code-content"><code data-copy-code-text>' . site_escape($code) . '</code>' . $editor . '</div>'
        . '<div class="copy-code-actions"><button type="button" data-copy-code-button data-copy-confirmation="' . site_escape($copied)
        . '" data-copy-fallback="' . site_escape(site_translation('Текст выделен. Нажмите Ctrl+C.', $language)) . '">'
        . '<i class="fa-regular fa-copy" aria-hidden="true"></i> ' . site_escape($copy) . '</button>' . $editControl . '</div>'
        . '<small class="hint" role="status" data-copy-code-status></small></div>';
}
