<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1><?= site_escape(site_appearance_labels($adminLanguage)[2]) ?></h1>
<?php if ($libraryDraft !== null): ?>
    <form class="panel form-stack" method="post" action="<?= site_escape($librariesUrl) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($libraryRevision) ?>">
        <fieldset class="field-config form-stack">
            <legend><?= admin_l('Библиотеки сайта и редактора') ?></legend>
            <?php $activeLibraries = site_active_libraries(); $libraryVersions = site_library_versions(); ?>
            <?php foreach (site_library_catalog() as $key => $library): ?>
                <div class="library-option form-stack">
                    <label class="choice">
                        <input type="checkbox" name="enabled[<?= $key ?>]" value="1"<?= $libraryDraft['enabled'][$key] ? ' checked' : '' ?>>
                        <span><?= site_escape($activeLibraries[$key]['label']) ?><br><small class="hint"><?= admin_l($library['hint']) ?></small></span>
                    </label>
                    <div class="header-actions">
                        <?php $localLabels = site_appearance_labels($adminLanguage); ?>
                        <?php if (site_library_bundled($key, $activeLibraries[$key])): ?>
                            <small class="hint">✓ <?= site_escape($localLabels[9]) ?></small>
                        <?php elseif (site_local_library($key, $activeLibraries[$key])): ?>
                            <small class="hint">✓ <?= site_escape($localLabels[7]) ?></small>
                        <?php else: ?>
                            <button type="submit" name="action" value="localize-library:<?= $key ?>" formnovalidate><?= site_escape($localLabels[6]) ?></button>
                        <?php endif; ?>
                        <button type="submit" name="action" value="library-update:<?= $key ?>"<?= $activeLibraries[$key]['label'] === $library['label'] ? ' disabled' : '' ?> formnovalidate><?= admin_l('Обновить') ?></button>
                        <button type="submit" name="action" value="library-rollback:<?= $key ?>"<?= !site_library_rollback($key, $activeLibraries[$key], $libraryVersions) ? ' disabled' : '' ?> formnovalidate><?= admin_l('Откатить') ?></button>
                        <button type="button" data-library-test="<?= $key ?>"><?= admin_l('Тестировать') ?></button>
                    </div>
                </div>
            <?php endforeach; ?>
        </fieldset>
        <button class="button-primary" type="submit" name="action" value="save-libraries"><?= admin_l('Сохранить') ?></button>
    </form>
    <dialog class="editor-dialog form-stack" data-library-dialog data-interface="<?= site_escape($adminLanguage) ?>"
        data-test-url="<?= site_escape(site_url($base, 'templates/library-test.php')) ?>" aria-labelledby="library-dialog-title">
        <div class="header-actions editor-dialog-heading">
            <h2 id="library-dialog-title"><?= admin_l('Проверка библиотеки') ?></h2>
            <button type="button" data-library-close aria-label="<?= admin_l('Закрыть') ?>">×</button>
        </div>
        <iframe class="library-sandbox" sandbox="allow-scripts" referrerpolicy="no-referrer" title="<?= admin_l('Проверка библиотеки') ?>"></iframe>
        <?php foreach ($activeLibraries as $key => $library): ?>
            <div data-library-code="<?= $key ?>" hidden>
                <?= site_copy_code(site_library_assets($key, $library, $base) . site_library_example($key), $adminLanguage, admin_t('Код вставки')) ?>
            </div>
        <?php endforeach; ?>
    </dialog>
<?php endif; ?>
