# Perguntas frequentes sobre administração

## Primeiros passos no 1.6.60

- Ative um site completo em Modelos de design → Temas. Cores e fontes têm abas próprias. É possível ativar várias famílias e salvá-las localmente.
- Ative bibliotecas em Configurações → Bibliotecas e salve localmente os recursos necessários. Font Awesome já vem incluído.
- No modo de edição, clique duas vezes no conteúdo para abrir o editor em um modal. Clique duas vezes no H1 padrão para abrir seu campo na aba SEO.
- As definições são compartilhadas e os valores são por página. Ao criar um campo, você pode definir o valor da página aberta. O controle de entrada acompanha o tipo.
- Para um domínio novo, gere um ZIP completo com o tema ativo e teste uma instalação limpa. Em um site existente, faça backup e use uma atualização assinada.

## Instalação e login

### Como lançar um site e abrir o painel de administração?

Para iniciar localmente, execute o comando php -S 127.0.0.1:8000 router.php no diretório do projeto e abra http://127.0.0.1:8000/admin/.

`/admin/` → **Baixar o utilitário para FTP**

1. Abra o utilitário e gere um código de instalação. Baixe e extraia o ZIP.
2. Envie `.access.php` para a pasta `admin/` no servidor. O nome do arquivo começa com um ponto.
3. Atualize esta página. Informe o código de uso único, um usuário e uma senha.

### O que você pode configurar ao iniciar?

Primeiro crie um nome de usuário e uma senha. Na segunda etapa, defina o nome do site, meta descrição padrão, texto do rodapé, paleta e modo de tema. Se você possui PHP GD, pode baixar imediatamente o logotipo e criar um favicon a partir dele. Você pode pular a segunda etapa ou continuar na próxima vez que fizer login.

## Páginas e menus

### Como criar uma página e qual endereço inserir?

Vá para Páginas → Nova página. Insira o endereço, por exemplo /Services-1/Repair/ ou /Services-1/Price_2.php, preencha o título e salve. Para o endereço da pasta, o próprio mecanismo criará os diretórios e index.php. A-Z, a-z, 0-9, hífen e sublinhado são permitidos em nomes. A página principal é reservada na raiz e a criação de páginas nos diretórios de serviço é encerrada.

### Qual é a diferença entre a caixa de seleção “No Menu” e o botão “Ocultar”?

Desmarcar a caixa “No menu” remove o link dos menus normais, mantendo o acesso ao endereço direto. Em uma página com endereço de pasta, a caixa de seleção também controla itens em subpáginas. O botão “Ocultar” remove o link e fecha o endereço público da página até que ela seja publicada novamente.

### Como posso alterar a ordem das páginas ou mover uma pasta inteira?

Arraste a alça ⠿ para ordenar páginas no mesmo nível. Mova uma página em suas configurações. O ícone da pasta abre a seleção da seção superior. Escolha outra seção ou a raiz e clique em Mover pasta. As páginas e os arquivos vão junto. Confira links antigos e códigos [include].

### Por que as alterações de página não são imediatamente visíveis?

Clique em "Salvar" no editor. Em seguida, use o link "Abrir página" ou "Ir". Se o link desapareceu, verifique se a página está publicada. Para alterações em um subdomínio, verifique o domínio na barra de endereço.

## Design e subdomínios

### Onde posso alterar o título, rodapé, logotipo e favicon?

Abra Configurações → Geral. O campo Texto do rodapé suporta [year] para o ano atual. No bloco “Logos e ícones de sites”, você pode fazer upload de imagens ou clicar em “Criar um favicon a partir de um logotipo”. O carregamento e a conversão requerem PHP GD.

### Como mudar o tema ou fonte e depois voltar ao antigo?

Ative um site completo em Modelos de design → Temas. Cores e fontes têm abas próprias. É possível ativar várias famílias e salvá-las localmente.

### Onde alterar o cabeçalho e onde inserir um contador, CSS ou JavaScript?

O cabeçalho dos blocos comuns, menu móvel, menu e rodapé são editados na aba “Modelos de Design”. No mesmo local, “Service Headers” insere HTML no cabeçalho ou antes da tag de fechamento do corpo. Para CSS e JavaScript regulares, há uma guia “CSS e JS” separada. O código de uma página é adicionado ao seu editor.

### Como definir diferentes números de telefone e cabeçalhos para subdomínios?

Adicione um subdomínio na seção “Domínios”. Em seguida, defina um valor de submodelo separado na seção Submodelos selecionando o domínio desejado. Altere o cabeçalho e outros blocos usando o botão “Modelos” próximo ao domínio. A versão do domínio tem precedência sobre a versão geral. O DNS e o servidor web devem apontar o subdomínio para o diretório desse site.

### Onde posso alterar os links das redes sociais e as legendas próximas a elas?

Abra “Configurações → Contatos e redes sociais”. Preencha endereços, assinaturas e números de telefone. O código [soc-icons] exibe ícones de todas as redes configuradas. Para um link único, utilize por exemplo [tg] ou [vk].

## Formulários e aplicações

### Como adicionar um formulário a uma página?

Abra Formulários, configure campos, comprimento máximo, obrigatório e texto dos botões. Salve o formulário e cole seu código, por exemplo [form1], no HTML da página.

### Onde posso visualizar as inscrições se não tiver recebido uma notificação por e-mail?

Abra Mensagens. As inscrições são salvas lá após o envio bem-sucedido do formulário. Para notificações, verifique os endereços no campo “Para” do modelo de formulário de email e a funcionalidade da função mail() na hospedagem.

### Como montar uma carta e enviar cópias?

Abra o formulário desejado e encontre o bloco “Mail Template”. Insira os endereços nos campos “Para” e “Cópias (Cc)”, separados por vírgulas. No assunto e no corpo, use chaves de campo entre chaves, por exemplo Olá {name}! Os botões abaixo do texto inserem a variável selecionada. O assunto ou texto em branco usa a notificação padrão.

### Por que o formulário rejeitou a mensagem ou perguntou “Não sou um robô”?

Verifique os campos obrigatórios, comprimento, telefone e formato de e-mail. Os campos de entrada gratuitos usam texto simples, sem HTML ou endereços de sites. As listas de palavras e IPs proibidos estão localizadas na seção Antispam. A caixa de seleção “Usar CAPTCHA” requer uma chave de site e uma chave secreta Google reCAPTCHA v2 para o domínio desejado.

### Onde posso ver as solicitações de retorno de chamada?

Na seção "Retornos de chamada". O componente é adicionado à página com o código [callback] ou [callback=Вызвать мастера]. Com o provedor “Não”, os aplicativos são salvos no painel de administração. Quando a telefonia está configurada, a transmissão manual ou automática está disponível.

## Blocos e componentes de informação

### Como criar um bloco de informações e exibi-lo na página?

Na seção “Infoblocks”, clique em “Novo Infoblock”, configure as colunas e adicione linhas. No nome do infobloco e nas chaves de coluna, use A–Z, a–z, 0–9, hífen ou sublinhado sem espaços. Salve e copie o código incorporado do editor de infoblock. Para obter uma lista de telefones, use o modelo de telefones.

### Como copiar ou substituir todas as linhas de um infoblock?

Abra o bloco de informações e clique em “Editar como texto”. CSV usa o | delimitador. As três primeiras linhas contêm as chaves, nomes e tipos das colunas. Em seguida vêm os dados. Coloque um campo com um delimitador, aspas ou quebra de linha entre aspas duplas e aspas internas duplas.

### O que verificar se a galeria ou lista de arquivos está vazia?

Verifique o caminho no código do componente com a pasta no servidor. Por exemplo, [fotos]/images/myfotos/[/fotos] usa fotos em images/myfotos/ ou templates/images/myfotos/.. Para [files], verifique a extensão do arquivo. Uma lista de extensões e parâmetros suportados pode ser encontrada na ajuda do componente.

### Por que uma solicitação com ?ajax=1 retorna 403?

O fragmento de página requer uma sessão pública válida e um token no mesmo site. Para carregar dentro do site, utilize window.siteFetchContent(), que transfere o token. Para uma transição normal, abra o endereço da página sem o parâmetro ajax.

## Atualizações e backup

### Como atualizar o motor de um site instalado?

Em Configurações → Atualizações, compare a versão instalada com a versão mais recente do GitHub e clique em Mecanismo de atualização. Se o GitHub não estiver disponível, o painel de administração mostrará a última versão verificada. Para atualizar manualmente, passe o arquivo ewc-lite-update.zip para o comando php update.php. O pacote de atualização substitui os arquivos do mecanismo e os modelos padrão. Armazene seus modelos PHP em templates/local/.

### O que devo copiar antes de atualizar ou migrar?

Faça uma cópia de todo o diretório do site junto com os arquivos ocultos. As páginas estão localizadas na raiz e seus diretórios, blocos de informações em data/, configurações e arquivos de conta em admin/.. Salve também seus modelos, imagens enviadas, mensagens e solicitações. A cópia inclui segredos de configuração, portanto mantenha-a fora de um diretório público.

### O que verificar se o painel de administração não consegue salvar as alterações?

Primeiro leia a mensagem ao lado do formulário. Se as alterações entrarem em conflito, copie suas edições e abra o editor novamente. Caso haja erro de gravação, peça à hospedagem para verificar as permissões de gravação do processo PHP na pasta e arquivo desejado admin/write-lock.php.. Caso a atualização falhe, verifique o acesso do servidor ao GitHub e a disponibilidade de PHP Zip e OpenSSL.

## Novo na versão 1.6.3

### Política de casa e privacidade

Abra “Modelos de Design” para editar a página inicial e a página /privacy.php. O código [page-content] exibe o conteúdo da página principal. Na política [site-name] e [site-url] levam o nome e endereço público de “Configurações → Geral”. Complete o texto inicial com informações sobre seu site e tratamento de dados.

### Cookie e voltar ao topo

No rodapé, [conf-policy] fornece um link para a política, [cookies] abre as configurações e [top] rola para o topo da página. Análises e mapas CMS integrados aguardam acordo. Os scripts adicionados manualmente a modelos ou cabeçalhos de serviço requerem configuração própria.

### Editor functions.php

Abra “Modelos de Design → Funções” após a guia “Cabeçalhos de Serviço”. Adicione fechamentos ao array retornado. No seu modelo PHP, chame `translit("Москва")` ou `ew_call("translit", "München")`. Em HTML insira [func=translit value="Москва и München"]. O exemplo produz `Moskva i Muenchen`.

### Editando modelos padrão

No campo “Design Templates” já contém o código fonte PHP e HTML com destaque. Ao editar um modelo padrão, selecione “PHP personalizado”. Salvar cria uma versão personalizada. Usando os botões próximos ao modelo, você pode desfazer a última edição ou restaurar o original.

### Verificação do PHP antes de salvar

Modelo de design, módulo e editores functions.php verificam a sintaxe com o comando `php -l`. Se houver um erro, a versão anterior permanece. Para selecionar a CLI do PHP no servidor, utilize a variável `SITE_PHP_LINT_BINARY`.

### Luz de fundo e pesquisa compacta

CodeMirror é habilitado por padrão em novas instalações. A configuração está localizada em “Bibliotecas e Fontes”. Na pesquisa compacta, o campo se expande para a esquerda, a cruz limpa a linha e a tecla Enter inicia a pesquisa.

### Menu de administração e painel de edição

O menu sob o cabeçalho do painel de administração e o painel de edição do site mostram ícones com legendas. Os ícones permanecem na tela estreita. As dicas de ferramentas são abertas ao passar o mouse e o teclado foca em uma tela estreita. “Ocultar” está localizado próximo ao restante das ações da página. O botão Edit Mode está localizado à direita.

### Descrição e código do módulo PHP

Em "Módulos PHP" a breve descrição é para texto simples. Cole o corpo da função em um campo separado “Código fonte · PHP”.

## Botões no cabeçalho da administração · 1.6.4

O globo abre o site e a seta termina a sessão. No telemóvel, só aparecem os ícones. Passe o cursor ou utilize o teclado para ver os respetivos rótulos.

Conteúdo, Formulários e pedidos, e Site e serviços abrem diretamente. Os separadores da secção escolhida aparecem abaixo do menu principal.

Insira [bread-crumbs] ou [search] no HTML da página inicial (index.php) ou de um modelo. Cada bloco aparece uma vez na posição escolhida. As definições do caminho de navegação e da pesquisa continuam ativas. [privacy] liga a /privacy/. Edite a política em Páginas.

```text
[bread-crumbs]
[search]
[privacy]
```

## Ficheiros de configuração, mapas e modelos · 1.6.5

Abra Manutenção → Ficheiros de configuração para editar .htaccess, robots.txt e sitemap.xml. O gerador usa as páginas publicadas assinaladas para inclusão. A versão anterior de .htaccess pode ser recuperada.

Indique a latitude e a longitude. [map] mostra o ponto da página e [maps] reúne os pontos das páginas publicadas. center e zoom definem o enquadramento. O fornecedor de mapas é escolhido em Integrações.

[main-menu] é o menu sob o cabeçalho, com secções expansíveis. Crie modelos próprios e configure a visibilidade por dispositivo. Nos fragmentos, o botão de adicionar domínio abre o formulário. Use [privacy] para ligar à política.

Em Integrações, introduza os ID do JivoSite, Microsoft Clarity e Umami Cloud, o código Botfaqtor ou o webhook do Slack. As instruções estão junto aos campos. No Zadarma, consulte o saldo ou teste SMS e chamadas. Os testes podem ter custos. Para [payment], indique os links YooMoney, PayPal e SBP. Confirme o estado no painel do prestador.

Os editores HTML e visual têm ícones para formatação, títulos H1–H5 e listas. Coloque o cursor e selecione um modelo, componente, imagem ou ícone. Pode escolher formulários e opções dos componentes. Font Awesome fica disponível com a biblioteca ativa.

Clique no nome da pasta para gerir a secção à direita. Escolha a secção superior, configure os menus ou indique um URL de redirecionamento. Uma secção vazia lista as subsecções. Em Manutenção, acrescente regras como /contact.html => /contacts/ e edite as páginas em /error/. O idioma e a pesquisa têm ícones no telemóvel.

```text
[map]
[map center="55.7558,37.6173" zoom=14]
[maps center="55.7558,37.6173" zoom=11]
[main-menu]
[lang]
[privacy]
[payment]
```

```php
$var = translit("Москва"); // Moskva
```

## Editar dados na própria página · 1.6.6

No modo de edição, os blocos, formulários [formX], fragmentos [tel] e outros componentes com editor oferecem Dados e Ecrã inteiro. A lista de vistas contém os modelos registados. Escolha Pasta raiz para mover a secção para o nível superior. Use [list-pages] para listar as páginas publicadas na secção e nas subpastas. Feche o menu de idiomas clicando fora ou premindo Escape.

## Menu móvel · 1.6.7

- Mostrar no menu principal
- Mostrar no menu móvel
- Ocultar no menu móvel

## Configurações da página · 1.6.8

Escreva o conteúdo em Edição. Configure endereço, menu e calendário de publicação nas configurações da página. SEO reúne títulos, descrição, palavras-chave e inclusão no sitemap. Em Mapas estão as coordenadas e os exemplos.

Deixe as datas em branco para retirar os limites. Vale o fuso horário do site. Uma página oculta deve ser publicada separadamente.

- `[map]` — mapa com o ponto da página atual.
- `[maps]` — mapa com os pontos de todas as páginas publicadas.

## Banners e editor de imagens · 1.6.8

Gerencie conjuntos e slides em Componentes. Use fotos de uma pasta, adicione texto e botões para links, formulários ou chamadas de retorno e programe a exibição. O modo de edição mostra as ações do slide. O seletor permite navegar pelas pastas, enviar, excluir e criar cópias giradas ou redimensionadas com GD. Pesquise ícones do Font Awesome pelo nome.

```text
[banners]
[banners set=summer arrows=on numbers=off]
[banners]/images/myfotos/[/banners]
```

## Idiomas · 1.6.9

A aba Idiomas lista os idiomas da página. Abrir leva à versão salva. Criar tradução abre um editor vazio.

Uma subseção fica dentro da seção atual, uma seção no mesmo nível fica ao lado e uma seção na raiz fica no nível superior do site.

## Compatibilidade com PHP e navegação · 1.6.10

A versão mínima do PHP é 7.2. O site e a administração suportam PHP 8.6. Use nos seus módulos e modelos a sintaxe da versão instalada no servidor.

O item atual de [bread-crumbs] abre as seções publicadas do mesmo nível que aparecem no menu principal. A URL configurada é usada em menus, listas de seções, trilhas de navegação, resultados e sugestões de pesquisa.

A lixeira remove uma linha do editor de infoblocos. Remover uma coluna apaga todos os seus valores. As alterações são gravadas ao salvar, inclusive automaticamente após a reordenação.

### Cópias de segurança

O ZIP privado contém páginas, mídias, blocos, configurações, modelos e módulos PHP. A conta e as solicitações ficam separadas. É necessário PHP Zip.

Substituir conteúdo e configurações. Antes disso, será feita uma cópia do estado atual.

### Limpar arquivos sem uso

A busca encontra mídias sem referências no conteúdo salvo. Revise a lista e selecione os arquivos. Antes é criada uma cópia de segurança. Remover o código de um componente preserva sua pasta e seus arquivos.

### Escolher um ponto no mapa

Crie uma chave para «JavaScript API» no console do Yandex Maps e restrinja-a por referência HTTP. Na aba Mapas da página, escolha um ponto e aplique as coordenadas.

Selecione texto para alinhar ou limpar a formatação. Clique na imagem para editá-la e arraste a imagem ou seu canto para mover ou redimensionar. Links aceitam URL, e-mail, telefone e âncora. Botões abrem URLs, formulários, retornos de chamada ou links de pagamento do fornecedor.

As abas HTML e Editor visual alternam o modo. SUP, SUB e Parágrafo inserem os elementos correspondentes. Os componentes mostram seus códigos. As pastas são criadas na inserção. Os nomes aceitam letras latinas, dígitos, hífens e sublinhados. A aba Idiomas leva às configurações de idioma. Os painéis de inserção abrem acima da área de edição. Clique em «Fechar» no topo ou pressione Esc para fechar o painel e desativar o botão. As setas da barra de ferramentas desfazem e refazem até dez edições de texto através do servidor. O ícone do relógio carrega o último texto salvo. Ao sair com alterações pendentes, é preciso confirmar. O ícone Salvar, antes das setas, fica destacado quando há alterações não salvas. Selecione um trecho e abra Estilo do texto. Defina o tamanho, a cor do texto ou do fundo, ou escolha uma fonte ativada nas configurações do site.

```text
[button action="url" label="Contacts" url="/contacts/"]
[button action="form" label="Write to us" form="form1"]
[button action="callback" label="Call me"]
[button action="payment" label="Pay" amount="1250.00" currency="RUB" yoomoney="410010000000000"]
[map]
[maps]
```

## Venda · 1.6.11

Defina preço e pagamento na aba Venda, com valores opcionais por idioma. Insira [item-price] e [item-buy-button]. O pedido é registrado antes do pagamento. Os status podem ser enviados por email e SMS Zadarma.

Pedido recebido · Pagamento aceito · Enviado · Encerrado · Cancelado

```text
[item-price]
[item-buy-button]
```

Selecione um arquivo ou URL para inserir uma imagem. Clique na imagem para ajustar tamanho, alinhamento, quatro margens e CSS. O alinhamento da imagem é independente do texto. Em HTML, os blocos ficam em linhas separadas. [list-pages] está em Componentes. O logotipo usa as cores do tema.

## Gráfico do bloco de dados

No editor da página, abra a inserção de componentes e escolha uma tabela ou um gráfico. Para gráficos, ative o Chart.js, escolha a coluna de rótulos e colunas do tipo Número ou Preço. Pizza, rosca e área polar usam uma série não negativa. Com a biblioteca desativada, a tabela é exibida.

Formulários, modelos, trechos salvos e componentes registrados aparecem ao reabrir o editor. O ID de um novo conjunto aceita A–Z, a–z, hífens e sublinhados. Após enviar imagens para uma pasta [banners], aparece um link para editar o slide ao lado de cada arquivo. No modo de edição, a janela exibe o slide escolhido e oferece um link para as configurações padrão. Ao lado de Salvar, o gerenciador de carrosséis, galerias e listas permite enviar, excluir, ordenar e criar subpastas (A–Z, a–z, 0–9, - e _). As cores aparecem em quadrados.

```text
[iblock=table]/data/myiblock.txt[/iblock]
[iblock=charts type=line labels=month values=sales,orders]/data/myiblock.txt[/iblock]
[banners set=summer-promo]
```

## Cabeçalho e rodapé da administração · 1.6.12

No computador, Eurowebcart CMS e Light com a versão instalada aparecem junto do logotipo. No celular, o símbolo fica na mesma linha que os botões. O rodapé contém o endereço do repositório. Verifique atualizações cumulativas nas configurações.

## Cabeçalho e rodapé da administração · 1.6.13

No computador, Eurowebcart CMS e Light com a versão instalada aparecem junto do logotipo. No celular, o símbolo fica na mesma linha que os botões. O rodapé contém o endereço do repositório. Verifique atualizações cumulativas nas configurações. O nome padrão Página inicial na lista segue o idioma da administração. O logotipo do rodapé mostra Eurowebcart CMS e LIGHT em duas linhas.

## Informações do PHP

Em Manutenção, phpinfo() mostra a versão, os módulos e a configuração do PHP a administradores autenticados. As variáveis de ambiente e de requisição são ocultadas. Ajuste error_reporting nas configurações gerais. O padrão é o nível do servidor.

## Ocultar a árvore de páginas · 1.6.14

No computador, a seta recolhe a árvore de páginas e amplia o editor. O botão acima do editor restaura a árvore. O navegador guarda a escolha.

## Ocultar a árvore de páginas · 1.6.15

No computador, a seta recolhe a árvore de páginas e amplia o editor. O botão acima do editor restaura a árvore. O navegador guarda a escolha.

## Escolher um ponto no mapa

Crie uma chave para «JavaScript API» no console do Yandex Maps e restrinja-a por referência HTTP. Na aba Mapas da página, escolha um ponto e aplique as coordenadas. Para testes locais, indique localhost sem porta como referência HTTP, aguarde a ativação e abra a administração usando localhost.

## Pesquisa no menu · 1.6.16

[search] apresenta a pesquisa junto às ligações de [main-menu] no computador e dentro de [mobile-menu] no telemóvel. Selecione o modo nas configurações gerais. [search] no conteúdo tem prioridade.

`[search]`

## Pesquisa no menu · 1.6.17

[search] apresenta a pesquisa junto às ligações de [main-menu] no computador e dentro de [mobile-menu] no telemóvel. Selecione o modo nas configurações gerais. [search] no conteúdo tem prioridade. O campo de pesquisa aparece ao abrir o menu móvel. [lang] mostra a seleção de idioma nesse menu e no cabeçalho no computador.

`[search]` · `[lang]`

O fundo do menu móvel mostra os contactos e as redes sociais configurados.

## Subtítulo do site

O subtítulo das configurações gerais aparece em tamanho menor abaixo do nome no cabeçalho. No celular, o nome também é menor.

## Cidades

Em Cidades, associe um domínio registado e configure até cinco números. O campo de telefone aceita códigos como [tel]. [cities] mostra o seletor, [phones] lista os números configurados e [tel], [tel2]–[tel5] mostram os números individuais. O navegador memoriza a escolha e atualiza os números sem recarregar a página.

`[cities]` · `[phones]` · `[tel]`

## Animação ao deslocar

Nas definições gerais, escolha o efeito de entrada dos blocos ao deslocar a página. Está desativado por predefinição e respeita a opção de movimento reduzido do dispositivo.

## Modelos de página

Escolha um modelo ao criar uma página. O conteúdo e os campos SEO são preenchidos e podem ser editados. Adicione os seus modelos em Modelos de página. Mapas, formulários e compras utilizam as definições de cada componente.

O CSS e o JavaScript do modelo são copiados para os campos da página. Adicione classes próprias em HTML e defina-as no CSS do modelo.

### Classes reutilizáveis

Contentor, grelha adaptável, secção em destaque, cartão e preço realçado.

`.page-preset` · `.page-preset-grid` · `.page-preset-hero` · `.page-preset-card` · `.page-preset-price`

Os modelos de layout começam recolhidos. Abra um modelo pelo título ou escolha Expandir tudo. Prima novamente para recolher a lista.

Para alterar a largura do carrossel, ative o modo de edição, abra Editar componente junto dos banners e selecione a largura do bloco.

## Cidades · Telefone · 1.6.18

Só o nome da cidade é obrigatório. O domínio e os telefones são opcionais. Use + e o indicativo do país, por exemplo +7 (900) 000-00-00. Pode usar um código como [tel] como alternativa.

É usada a cidade memorizada, depois a cidade do domínio e por fim a primeira da lista. Sem cidades, são apresentados os telefones gerais.

Os formulários, pedidos de chamada e novas encomendas usam o e-mail da cidade ou o do site se estiver vazio. Se ambos estiverem vazios, os formulários mantêm os seus destinatários. Os links sociais vazios são herdados.

No modo de edição, passe o cursor sobre um modelo para o editar. Para qualquer componente [php] instalado, Editar módulo abre o código e as definições numa janela. O editor de diapositivos mostra o nome e o código do formulário. [banners width=100] ocupa toda a janela como bloco autónomo sem barra lateral. O editor de modelos abre numa janela modal do site.

O gestor verifica referências antes de eliminar e faz uma cópia de segurança de pastas não vazias. Cada banner pode ter título e subtítulo.

O telefone é verificado durante a introdução. Nos números russos, o 8 inicial passa a +7. Após o envio, o formulário é ocultado e a confirmação surge ao reabrir a janela.

O indicativo escolhido é acrescentado a números sem +. Os números com + mantêm o indicativo introduzido.

## Temas de design

Copie o ficheiro para o tema e guarde. Ficheiros em falta usam a versão fornecida. Alterações, novos códigos, histórico e definições de domínio ficam no tema ativo. Use css/theme.css e js/theme.js para estilos e scripts adicionais.

`templates/themes/demo/header.php` · `templates/themes/demo/components/banners.php`

Os idiomas ficam no fundo do menu móvel. No computador, o globo fica junto à pesquisa no menu abaixo do cabeçalho.

Galerias, banners e listas procuram primeiro no tema ativo e, se faltar a pasta, nos ficheiros comuns. Pastas novas, carregamentos, logótipos e favicons ficam no tema. A cópia de segurança inclui a pasta e as definições do tema.

Escolha a largura da janela (width=page), do conteúdo (width=content) ou do bloco principal (width=parent). height define a altura no computador e mobile-height no telemóvel. auto mantém o tamanho natural.

`[banners width=page height=520 mobile-height=240]` · `[form1 width=parent]`

O último item do percurso mostra as secções publicadas do mesmo nível, incluindo as ocultas no menu principal. Os links usam o URL configurado.

## Temas de design · КОНТУР · 1.6.19

Um tema de site completo muda o design, as páginas, os blocos de dados e as configurações. Os demais temas usam as páginas compartilhadas.

Uma marca indica que o ficheiro do tema tem prioridade sobre o ficheiro padrão do CMS. Pode editá-lo ou restaurá-lo.

**Restaurar a versão de fábrica**

### Portfólio

Abra kontur-works em Conteúdo → Blocos de dados. Indique título, categoria, descrição, fotos separadas por vírgulas e um link opcional. A primeira foto será a capa. Use as mesmas colunas para outras coleções.

```text
[portfolio]
[iblock=portfolio limit=2]/data/kontur-works.txt[/iblock]
[maps source=kontur-map]
```

### Cores do site · Fontes

Marque as fontes a ativar e atribua-as ao texto, aos títulos ou aos controlos. O seu site aloja os ficheiros locais.

Bibliotecas → Hospedar localmente

Modelos de página → Criar página

## Recuperar o acesso à administração

Na instalação, indique o e-mail do administrador e o endereço HTTPS completo. Num site existente, abra Configurações → Gerais → E-mail do administrador, informe a senha atual e confirme o endereço pelo link recebido. O envio de e-mail por PHP deve estar ativo na hospedagem.

Clique em «Esqueceu a senha?» e informe o e-mail confirmado. Abra o link e digite a nova senha duas vezes. O link é de uso único e vale 30 minutos.

Se não tiver acesso ao e-mail, baixe a ferramenta HTML e abra-a localmente. Faça uma cópia de `admin/.access.php` via SFTP ou FTPS e mostre arquivos ocultos, se necessário. Substitua o arquivo pelo gerado, abra `/admin/` e informe o código de uso único, o usuário e a nova senha. Na segunda etapa, continue com as configurações atuais. Confirme o e-mail novamente.

Baixar a ferramenta HTML — `/admin/?ftp-reset=1`.


Se o EWC estiver numa subpasta, /images/photo.jpg é resolvido a partir dessa pasta. Em /test/, o caminho será /test/images/photo.jpg. Use a URL completa para imagens externas.
