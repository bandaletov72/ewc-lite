<?php if (!defined('SITE_ROOT')) exit;
$saleLabels = site_sale_label($adminLanguage);
$files = is_link(SITE_PURCHASE_DIR) ? [] : (glob(SITE_PURCHASE_DIR . '/*.php') ?: []);
rsort($files, SORT_STRING);
$pageCount = max(1, (int) ceil(count($files) / 20));
$purchasePage = min($pageCount, max(1, (int) admin_input($_GET, 'p')));
$currentUrl = $purchasesUrl . '&p=' . $purchasePage;
$payments = site_payment_methods();
$deliveryNames = $adminLanguage === 'ru' ? ['sent'=>'Отправлено','failed'=>'Ошибка отправки','missing'=>'Контакт не указан']
    : ['sent'=>'Sent','failed'=>'Delivery failed','missing'=>'No contact provided'];
?>
<h1><?= site_escape($saleLabels['purchases']) ?></h1>
<?php if ($error !== ''): ?><p class="notice error" role="alert"><?= admin_l($error) ?></p><?php endif; ?>
<?php if (!$files): ?><p class="hint"><?= $adminLanguage === 'ru' ? 'Покупок пока нет.' : 'No purchases yet.' ?></p><?php endif; ?>
<div class="form-stack" data-purchases-list>
    <?php foreach (array_slice($files, ($purchasePage - 1) * 20, 20) as $file):
        $id = basename($file, '.php');
        try { $order = site_read_purchase($id); } catch (RuntimeException $exception) { continue; }
        if (!$order || !isset($saleLabels['statuses'][$order['state'] ?? ''])) continue;
        $statusLabel = $saleLabels['statuses'][$order['state']];
    ?>
        <details class="panel purchase-entry" data-purchase-id="<?= site_escape($id) ?>">
            <summary class="header-actions">
                <strong><?= site_escape($saleLabels['order'] . ' ' . $id) ?></strong>
                <span><?= site_escape($order['title']) ?></span>
                <span><?= site_escape(site_format_number($order['amount'], 2) . ' ' . $order['currency']) ?></span>
                <span><?= site_escape($statusLabel) ?></span>
            </summary>
            <div class="form-stack">
                <p><time datetime="<?= site_escape($order['time']) ?>"><?= site_escape($order['time']) ?></time> · <?= site_escape($payments[$order['method']][0] ?? $order['method']) ?></p>
                <p><?= site_escape($order['name']) ?><?= $order['phone'] !== '' ? ' · ' . site_escape($order['phone']) : '' ?><?= $order['email'] !== '' ? ' · ' . site_escape($order['email']) : '' ?></p>
                <?php foreach ($order['delivery'] ?? [] as $channel => $outcome): ?>
                    <small class="hint"><?= site_escape(strtoupper($channel) . ' · ' . ($deliveryNames[$outcome] ?? $outcome)) ?></small>
                <?php endforeach; ?>
                <form class="header-actions" method="post" action="<?= site_escape($currentUrl) ?>">
                    <input type="hidden" name="action" value="purchase-status">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <input type="hidden" name="purchase" value="<?= site_escape($id) ?>">
                    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($order)) ?>">
                    <select name="state" aria-label="<?= $adminLanguage === 'ru' ? 'Статус заказа' : 'Order status' ?>">
                        <?php foreach ($saleLabels['statuses'] as $key => $label): ?>
                            <option value="<?= $key ?>"<?= $order['state'] === $key ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit"><?= admin_l('Сохранить') ?></button>
                </form>
            </div>
        </details>
    <?php endforeach; ?>
</div>
<?php if ($pageCount > 1): ?>
    <nav class="site-menu scope-menu" aria-label="<?= site_escape($saleLabels['purchases']) ?>" data-purchases-pagination>
        <?php if ($purchasePage > 1): ?><a href="<?= site_escape($purchasesUrl . '&p=' . ($purchasePage - 1)) ?>"><?= admin_l('Назад') ?></a><?php endif; ?>
        <span><?= $purchasePage ?> / <?= $pageCount ?></span>
        <?php if ($purchasePage < $pageCount): ?><a href="<?= site_escape($purchasesUrl . '&p=' . ($purchasePage + 1)) ?>"><?= admin_l('Далее') ?></a><?php endif; ?>
    </nav>
<?php endif; ?>
