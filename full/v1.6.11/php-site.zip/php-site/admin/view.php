<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<!doctype html>
<html lang="<?= site_escape($adminLanguage) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= site_escape(SITE_PRODUCT_NAME) ?> | <?= site_escape($siteSettings['name']) ?></title>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, site_brand_settings()['favicon'] ?: 'templates/icons/site.png')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_font_awesome_stylesheet($base)) ?>">
    <?php if ($loggedIn || count($regional['languages']) > 1): ?>
        <script src="<?= site_escape(site_url($base, 'templates/search-browser.php') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css') . '?v=' . site_update_version()) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>" data-admin-theme>
    <?php if ($loggedIn && $section === 'libraries'): ?>
        <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/font-previews.php') . '?v=' . site_update_version()) ?>">
    <?php endif; ?>
    <?php if ($loggedIn && ($dataViewSuffix !== '' || in_array($section, ['pages', 'forms', 'iblocks', 'contacts', 'components', 'theme', 'libraries', 'updates', 'layout', 'domains'], true))): ?>
        <?php
        $messages = [];
        foreach (require SITE_ROOT . '/app/admin-js-keys.php' as $key) {
            $messages[$key] = admin_t($key);
        }
        ?>
        <script id="admin-messages" type="application/json"><?= json_encode($messages, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
        <script src="<?= site_escape(site_url($base, 'templates/js/admin.js') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
    <?php if ($loggedIn && in_array($section, ['pages', 'components'], true)): ?>
        <script src="<?= site_escape(site_url($base, 'templates/content-editor.php') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
    <?php if ($loggedIn && site_code_editor_on()): ?>
        <script src="<?= site_escape(site_code_editor_url($base)) ?>" defer></script>
    <?php endif; ?>
</head>
<body data-code-auto="<?= admin_l('Авто') ?>" data-code-syntax="<?= admin_l('Язык подсветки') ?>">
    <?php if ($loggedIn && $dataViewSuffix !== ''): ?>
        <main class="focused-data-editor"<?= $embeddedData ? ' data-component-data-frame' : '' ?>>
            <?php if ($embeddedData && $notice !== ''): ?><span data-component-data-saved hidden></span><?php endif; ?>
            <?php if ($focusedBanner): ?>
                <?php if ($error !== ''): ?><p class="notice error" role="alert"><?= admin_l($error) ?></p><?php endif; ?>
                <?php if ($notice !== ''): ?><p class="notice success" role="status"><?= admin_l($notice) ?></p><?php endif; ?>
                <?php require __DIR__ . '/banners-view.php'; ?>
            <?php elseif ($focusedMedia): ?>
                <section class="panel form-stack" data-page-admin data-admin-url="<?= site_escape($adminUrl) ?>" data-csrf="<?= site_escape($token) ?>">
                    <div data-media-context>
                        <?php $resolvedMediaFolder = '/' . site_asset_path($mediaFolder, $mediaKind === 'files' ? 'files' : 'images') . '/'; ?>
                        <textarea hidden><?= site_escape('[' . $mediaKind . ']' . $resolvedMediaFolder . '[/' . $mediaKind . ']') ?></textarea>
                        <?php require __DIR__ . '/component-media-view.php'; ?>
                    </div>
                </section>
            <?php else: ?>
                <?php require __DIR__ . '/config-view.php'; ?>
            <?php endif; ?>
        </main>
        </body></html>
        <?php return; ?>
    <?php endif; ?>
    <header class="site-header admin-header">
        <div class="container header-row">
            <a class="brand product-brand" href="<?= site_escape($adminUrl) ?>" aria-label="<?= site_escape(SITE_PRODUCT_NAME) ?>"><?= site_product_logo() ?></a>
            <div class="header-actions admin-header-actions">
                <?php if (count($regional['languages']) > 1): ?>
                    <details class="admin-language-picker">
                        <summary class="admin-header-button button" title="<?= admin_l('Язык') ?>">
                            <i class="fa-solid fa-language" aria-hidden="true"></i><span class="admin-nav-label"><?= site_escape(site_languages()[$adminLanguage]) ?></span>
                        </summary>
                        <nav class="site-menu" aria-label="<?= admin_l('Язык') ?>">
                            <?php foreach ($regional['languages'] as $code): ?>
                                <?php $params = ['ui_lang' => $code] + array_diff_key($_GET, ['check' => true]); ?>
                                <a lang="<?= $code ?>" href="<?= site_escape($adminUrl . '?' . http_build_query($params)) ?>"<?= $code === $adminLanguage ? ' aria-current="true"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
                            <?php endforeach; ?>
                        </nav>
                    </details>
                <?php endif; ?>
                <a class="button admin-header-button" href="<?= site_escape(site_url($base)) ?>" title="<?= admin_l('Открыть сайт') ?>">
                    <i class="fa-solid fa-globe" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Открыть сайт') ?></span>
                </a>
                <?php if ($loggedIn): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>">
                        <input type="hidden" name="action" value="logout">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <button class="admin-header-button" type="submit" title="<?= admin_l('Выйти') ?>">
                            <i class="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Выйти') ?></span>
                        </button>
                    </form>
                    <details class="site-search-compact admin-settings-search"<?= $section === 'find' ? ' open' : '' ?>>
                        <summary class="admin-header-button button" aria-label="<?= admin_l('Поиск настроек') ?>" title="<?= admin_l('Поиск настроек') ?>">
                            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                        </summary>
                        <form method="get" action="<?= site_escape($adminUrl) ?>" class="site-search" role="search" data-admin-search>
                            <input type="hidden" name="find" value="1">
                            <input type="search" name="q" aria-label="<?= admin_l('Поиск настроек') ?>" aria-controls="admin-search-suggestions" autocomplete="off"
                                placeholder="<?= admin_l('Поиск настроек') ?>" maxlength="100" required
                                value="<?= $section === 'find' ? site_escape(site_search_query($_GET['q'] ?? '')) : '' ?>">
                            <ul class="site-search-suggestions" id="admin-search-suggestions" hidden></ul>
                        </form>
                    </details>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main class="container admin-main">
        <?php if ($accessError !== ''): ?>
            <section class="panel login-panel">
                <h1><?= admin_l('Настройка входа') ?></h1>
                <p class="notice error" role="alert"><?= admin_l($accessError) ?></p>
            </section>
        <?php elseif (!$configured): ?>
            <section class="panel login-panel">
                <p class="hint"><?= admin_l('Шаг 1 из 2') ?></p>
                <h1><?= admin_l('Мастер установки') ?></h1>
                <h2><?= admin_l('Создать учётную запись') ?></h2>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                <?php endif; ?>
                <?php if ($setupAvailable): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                        <input type="hidden" name="action" value="setup">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <?php if ($needsCode): ?>
                            <div class="field">
                                <label for="setup-code"><?= admin_l('Одноразовый код установки') ?></label>
                                <input id="setup-code" name="setup_code" autocomplete="off" required>
                            </div>
                        <?php endif; ?>
                        <div class="field">
                            <label for="setup-username"><?= admin_l('Логин') ?></label>
                            <input id="setup-username" name="username" value="<?= site_escape($username) ?>" placeholder="admin" autocomplete="username" maxlength="64" required>
                        </div>
                        <div class="field">
                            <label for="setup-password"><?= admin_l('Пароль') ?></label>
                            <input id="setup-password" type="password" name="password" autocomplete="new-password" minlength="8" aria-describedby="password-hint" required>
                            <small class="hint" id="password-hint"><?= admin_l('От 8 символов, не более 72 байт.') ?></small>
                        </div>
                        <div class="field">
                            <label for="setup-confirmation"><?= admin_l('Повторите пароль') ?></label>
                            <input id="setup-confirmation" type="password" name="confirmation" autocomplete="new-password" required>
                        </div>
                        <div><button class="button-primary" type="submit"><?= admin_l('Создать учётную запись и продолжить') ?></button></div>
                    </form>
                <?php else: ?>
                    <p><?= admin_l('В каталоге сайта выполните') ?> <code>php admin/setup.php</code><?= admin_l(', затем обновите страницу и введите полученный код.') ?></p>
                <?php endif; ?>
            </section>
        <?php elseif (!$loggedIn): ?>
            <section class="panel login-panel">
                <h1><?= admin_l('Вход в админку') ?></h1>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                <?php endif; ?>
                <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                    <input type="hidden" name="action" value="login">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <div class="field">
                            <label for="username"><?= admin_l('Логин') ?></label>
                        <input id="username" name="username" value="<?= site_escape($username) ?>" autocomplete="username" required>
                    </div>
                    <div class="field">
                        <label for="password"><?= admin_l('Пароль') ?></label>
                        <input id="password" type="password" name="password" autocomplete="current-password" required>
                    </div>
                    <div><button class="button-primary" type="submit"><?= admin_l('Войти') ?></button></div>
                </form>
            </section>
        <?php elseif ($section === 'install'): ?>
            <?php require __DIR__ . '/installation-view.php'; ?>
        <?php else: ?>
            <?php if ($installationPending): ?>
                <p class="notice"><a href="<?= site_escape($installationUrl) ?>"><?= admin_l('Завершить первичную настройку сайта') ?></a></p>
            <?php endif; ?>
            <?php require __DIR__ . '/navigation-view.php'; ?>
            <?php if ($section !== 'pages'): ?>
                <?php require __DIR__ . '/config-view.php'; ?>
            <?php else: ?>
            <?php
            $languageLabels = require SITE_ROOT . '/app/help-page-languages.php';
            $languageLabels = $languageLabels[$adminLanguage] ?? $languageLabels['ru'];
            ?>
            <div class="admin-heading">
                <h1><?= admin_l('Страницы') ?></h1>
                <a class="button button-primary" data-new-root-section href="<?= site_escape($adminUrl . '?new=1') ?>"><i class="fa-solid fa-plus" aria-hidden="true"></i> <?= site_escape($languageLabels[9]) ?></a>
            </div>
            <p data-page-feedback class="notice" role="status" hidden></p>
            <div class="editor-grid" data-page-admin data-admin-url="<?= site_escape($adminUrl) ?>" data-csrf="<?= site_escape($token) ?>">
                <nav class="panel" aria-label="<?= admin_l('Папки и страницы') ?>">
                    <div data-page-tree>
                        <?= admin_page_tree_html($tree, $creating ? '' : ($page['path'] ?? ''), $base, $adminUrl) ?>
                    </div>
                </nav>
                <section class="panel">
                    <?php if ($error !== ''): ?>
                        <p class="notice error" role="alert"><?= admin_l($error) ?></p>
                    <?php elseif ($notice !== ''): ?>
                        <p class="notice" role="status"><?= admin_l($notice) ?></p>
                    <?php endif; ?>
                    <?php if ($page !== null && !$creating && in_array($pageOperation, ['hide', 'show', 'delete'], true)
                        && ($pageOperation !== 'delete' || $page['path'] !== 'index.php')): ?>
                        <?php
                        $address = site_page_url('', $page['path']);
                        $editUrl = $adminUrl . '?' . http_build_query(['page' => $address]);
                        $operationLabel = ['hide' => admin_t('Скрыть страницу'), 'show' => admin_t('Опубликовать страницу'), 'delete' => admin_t('Удалить страницу')];
                        ?>
                        <h2><?= $operationLabel[$pageOperation] ?>?</h2>
                        <p><?= site_escape($page['fields']['Title'] . ' · ' . $address) ?></p>
                        <?php if ($pageOperation === 'delete'): ?>
                            <p class="hint"><?= admin_l('Файл страницы будет удалён. Остальные файлы в её папке останутся.') ?></p>
                        <?php elseif ($pageOperation === 'hide'): ?>
                            <p class="hint"><?= admin_l('Страница исчезнет из меню и будет недоступна по прямой ссылке, пока вы её не опубликуете.') ?></p>
                        <?php endif; ?>
                        <form class="header-actions" method="post" action="<?= site_escape($editUrl . '&confirm=' . $pageOperation) ?>">
                            <input type="hidden" name="action" value="change-page-status">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="path" value="<?= site_escape($address) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <input type="hidden" name="operation" value="<?= $pageOperation ?>">
                            <button class="<?= $pageOperation === 'delete' ? 'button-danger' : 'button-primary' ?>" type="submit"><?= $operationLabel[$pageOperation] ?></button>
                            <a class="button" href="<?= site_escape($editUrl) ?>"><?= admin_l('Отмена') ?></a>
                        </form>
                    <?php elseif ($page !== null): ?>
                        <div data-page-editor-wrapper>
                        <?php
                        $addressPath = $creating ? admin_page_path($page['path']) : $page['path'];
                        list($basePage, $pageLanguage) = site_page_translation($addressPath);
                        $directory = dirname($basePage);
                        $sectionDirectory = $directory !== '.' && basename($basePage) === 'index.php' ? $directory : '';
                        $creatingTranslation = $creating && $pageLanguage !== '' && site_read_page($basePage) !== null;
                        if ($sectionDirectory !== '' && (!$creating || admin_input($_GET, 'section') === '1')):
                            $nodes = $tree[$sectionDirectory] ?? [];
                        ?>
                            <div class="page-section-summary form-stack">
                                <div class="admin-heading">
                                    <strong><i class="fa-regular fa-folder" aria-hidden="true"></i> <?= site_escape('/' . $sectionDirectory . '/') ?></strong>
                                    <?php if (!$creating): ?>
                                        <div class="header-actions">
                                            <a class="button" data-new-child-section href="<?= site_escape($adminUrl . '?' . http_build_query(['new' => '1', 'parent' => $sectionDirectory])) ?>"><i class="fa-solid fa-plus" aria-hidden="true"></i> <?= site_escape($languageLabels[5]) ?></a>
                                            <?php if (dirname($sectionDirectory) !== '.'): ?>
                                                <a class="button" data-new-sibling-section href="<?= site_escape($adminUrl . '?' . http_build_query(['new' => '1', 'parent' => dirname($sectionDirectory)])) ?>"><i class="fa-solid fa-plus" aria-hidden="true"></i> <?= site_escape($languageLabels[8]) ?></a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if ($nodes): ?>
                                    <ul class="page-list page-section-children">
                                        <?php foreach ($nodes as $node): ?>
                                            <?php $child = $node['page']; $folder = $node['folder']; ?>
                                            <li><a href="<?= site_escape($folder !== '' ? admin_folder_edit_url($adminUrl, $folder, $child !== null) : admin_page_edit_url($adminUrl, $child['path'])) ?>">
                                                <?= site_escape($folder !== '' ? basename($folder) . '/' : $child['fields']['Title']) ?>
                                            </a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <?php
                        $pageTabs = require SITE_ROOT . '/app/help-page-editor.php';
                        $pageTabs = $pageTabs[$adminLanguage] ?? $pageTabs['ru'];
                        list($editTabLabel, $settingsTabLabel, $keywordsLabel, $activityLabel, $fromLabel, $untilLabel, $activityHint) = $pageTabs;
                        $discoveryLabels = admin_maintenance_labels($adminLanguage);
                        ?>
                        <h2><?= $creatingTranslation ? site_escape($languageLabels[6]) : admin_l($creating ? 'Новая страница' : 'Редактирование страницы') ?></h2>
                        <nav class="site-menu page-editor-tabs" data-page-editor-tabs hidden>
                            <a href="#page-edit"><i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> <?= site_escape($editTabLabel) ?></a>
                            <a href="#page-settings"><i class="fa-solid fa-gear" aria-hidden="true"></i> <?= site_escape($settingsTabLabel) ?></a>
                            <a href="#page-seo"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> SEO</a>
                            <a href="#page-maps"><i class="fa-solid fa-map-location-dot" aria-hidden="true"></i> <?= site_escape($pageTabs[8]) ?></a>
                            <a href="#page-sale"><i class="fa-solid fa-tag" aria-hidden="true"></i> <?= site_escape(site_sale_label($adminLanguage)['tab']) ?></a>
                            <a href="#page-languages"><i class="fa-solid fa-language" aria-hidden="true"></i> <?= site_escape($languageLabels[0]) ?></a>
                        </nav>
                        <?php if ($sectionDirectory !== '' && (!$creating || admin_input($_GET, 'section') === '1')): ?>
                            <div class="page-section-summary form-stack" data-page-tab-panel="settings">
                                <?php
                                $parentDirectory = dirname($sectionDirectory);
                                $parents = array_keys($tree);
                                sort($parents, SORT_STRING);
                                $parents = array_filter($parents, static function (string $folder) use ($sectionDirectory, $parentDirectory): bool {
                                    return $folder === '.' || ($folder !== $parentDirectory && $folder !== $sectionDirectory && strpos($folder, $sectionDirectory . '/') !== 0);
                                });
                                ?>
                                <?php if ($parents): ?>
                                    <form class="form-stack" data-folder-move-form data-has-page="<?= $creating ? '0' : '1' ?>">
                                        <input type="hidden" name="action" value="folder-move">
                                        <input type="hidden" name="path" value="<?= site_escape($sectionDirectory) ?>">
                                        <label class="field"><?= site_escape(admin_page_menu_labels($adminLanguage)['parent-folder']) ?>
                                            <select name="folder" id="section-parent" required>
                                                <option value=""><?= admin_l('Выберите папку') ?></option>
                                                <?php foreach ($parents as $parent): ?>
                                                    <option value="<?= site_escape($parent === '.' ? '/' : '/' . $parent . '/') ?>"<?= $parent === '.' && $parentDirectory === '.' ? ' disabled' : '' ?>><?= $parent === '.' ? site_escape(admin_root_folder_label($adminLanguage)) : site_escape('/' . $parent . '/') ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </label>
                                        <div><button type="submit"><?= admin_l('Переместить папку') ?></button></div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="<?= site_escape($adminUrl) ?>" data-page-editor
                            data-page-path="<?= site_escape($creating ? '' : $page['path']) ?>">
                            <input type="hidden" name="action" value="save">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="new" value="<?= $creating ? '1' : '0' ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <input type="hidden" name="editor_tab" value="<?= in_array(admin_input($_POST, 'editor_tab'), ['settings', 'seo', 'maps', 'sale', 'languages'], true) ? site_escape(admin_input($_POST, 'editor_tab')) : '' ?>">
                            <div class="fields" id="page-edit" data-page-tab-panel="edit">
                                <?php require __DIR__ . '/editor-view.php'; ?>
                            </div>
                            <div class="fields" id="page-settings" data-page-tab-panel="settings">
                                <div class="field field-wide">
                                    <label for="path"><?= admin_l('Адрес страницы') ?></label>
                                    <input id="path" name="path" value="<?= site_escape($creating ? $page['path'] : site_page_url('', $page['path'])) ?>" placeholder="/Services-1/" maxlength="240"
                                        <?php if ($creating): ?>
                                            required data-address-input aria-describedby="path-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*(/|\.php)?') ?>"
                                        <?php else: ?>readonly<?php endif; ?>>
                                    <?php if ($creating): ?>
                                        <small id="path-hint" class="hint"><?= admin_l('В именах файлов и папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Примеры: /Services-1/ и /Services-1/About_2.php.') ?></small>
                                    <?php endif; ?>
                                </div>
                                <?php
                                $labels = [
                                    'Menu' => admin_t('Название в меню'),
                                    'Order' => admin_t('Порядок в меню'),
                                ];
                                ?>
                                <?php foreach ($labels as $name => $label): ?>
                                    <div class="field">
                                        <label for="<?= $name ?>"><?= admin_l($label) ?></label>
                                        <input id="<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($page['fields'][$name] ?? '') ?>"
                                            <?= $name === 'Order' ? 'type="number" min="0" max="99999" required' : 'maxlength="375"' ?>
                                            <?= $name === 'Menu' ? 'aria-describedby="menu-hint"' : '' ?>>
                                        <?php if ($name === 'Menu'): ?>
                                            <small id="menu-hint" class="hint"><?= admin_l('Если поле пустое, в меню используется заголовок вкладки.') ?></small>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                                <?php list($mainMenuLabel, $mobileShowLabel, $mobileHideLabel) = admin_page_visibility_labels($adminLanguage); ?>
                                <label class="choice field-wide">
                                    <input type="hidden" name="menu_visibility" value="1">
                                    <input type="checkbox" name="MenuVisible" value="1"<?= $creating ? '' : ' data-page-menu' ?><?= ($page['fields']['MenuVisible'] ?? '0') === '1' ? ' checked' : '' ?>>
                                    <?= site_escape($mainMenuLabel) ?>
                                </label>
                                <?php $pageMenuLabels = admin_page_menu_labels($adminLanguage); ?>
                                <label class="field field-wide"><?= admin_l('Мобильное меню') ?>
                                    <select name="MobileMenu">
                                        <option value=""><?= site_escape($pageMenuLabels['inherit-menu']) ?></option>
                                        <option value="1"<?= ($page['fields']['MobileMenu'] ?? '') === '1' ? ' selected' : '' ?>><?= site_escape($mobileShowLabel) ?></option>
                                        <option value="0"<?= ($page['fields']['MobileMenu'] ?? '') === '0' ? ' selected' : '' ?>><?= site_escape($mobileHideLabel) ?></option>
                                    </select>
                                </label>
                                <label class="field field-wide"><?= site_escape($pageMenuLabels['redirect']) ?>
                                    <input name="Redirect" value="<?= site_escape($page['fields']['Redirect'] ?? '') ?>" maxlength="375" placeholder="/contacts/">
                                </label>
                                <input type="hidden" name="page_activity" value="1">
                                <label class="choice field-wide">
                                    <input type="checkbox" name="Active" value="1"<?= ($page['fields']['Active'] ?? '1') === '1' ? ' checked' : '' ?>>
                                    <?= site_escape($activityLabel) ?>
                                </label>
                                <label class="field"><?= site_escape($fromLabel) ?>
                                    <input type="datetime-local" name="ActiveFrom" aria-describedby="page-activity-hint" value="<?= site_escape($page['fields']['ActiveFrom'] ?? '') ?>">
                                </label>
                                <label class="field"><?= site_escape($untilLabel) ?>
                                    <input type="datetime-local" name="ActiveUntil" aria-describedby="page-activity-hint" value="<?= site_escape($page['fields']['ActiveUntil'] ?? '') ?>">
                                </label>
                                <small class="hint field-wide" id="page-activity-hint"><?= site_escape($activityHint . ' · ' . date_default_timezone_get()) ?></small>
                                <details class="field-wide page-code">
                                    <summary><?= admin_l('CSS и JavaScript страницы') ?></summary>
                                    <div class="form-stack">
                                        <?php admin_asset_editors($pageAssets ?? [
                                            'CSS' => site_asset_decode($page['fields']['CSS'] ?? '') ?? '',
                                            'JS' => site_asset_decode($page['fields']['JS'] ?? '') ?? '',
                                        ]); ?>
                                    </div>
                                </details>
                            </div>
                            <div class="fields" id="page-seo" data-page-tab-panel="seo">
                                <?php foreach (['Title' => admin_t('Заголовок вкладки'), 'Heading' => admin_t('Заголовок H1'),
                                    'Description' => admin_t('Метаописание'), 'Keywords' => $keywordsLabel] as $key => $label): ?>
                                    <label class="field<?= in_array($key, ['Description', 'Keywords'], true) ? ' field-wide' : '' ?>" for="<?= $key ?>"><?= site_escape($label) ?>
                                        <input id="<?= $key ?>" name="<?= $key ?>" maxlength="375" value="<?= site_escape($page['fields'][$key] ?? '') ?>"<?= $key === 'Title' ? ' required' : '' ?>>
                                    </label>
                                <?php endforeach; ?>
                                <label class="choice field-wide">
                                    <input type="hidden" name="page_discovery" value="1">
                                    <input type="checkbox" name="Sitemap" value="1"<?= ($page['fields']['Sitemap'] ?? '1') === '1' ? ' checked' : '' ?>>
                                    <?= site_escape($discoveryLabels['sitemap-page']) ?>
                                </label>
                            </div>
                            <div class="fields" id="page-maps" data-page-tab-panel="maps">
                                <?php foreach (['Lat' => 'latitude', 'Lng' => 'longitude'] as $key => $label): ?>
                                    <label class="field"><?= site_escape($discoveryLabels[$label]) ?>
                                        <input name="<?= $key ?>" inputmode="decimal" maxlength="15" value="<?= site_escape($page['fields'][$key] ?? '') ?>" placeholder="<?= $key === 'Lat' ? '55.7558' : '37.6173' ?>">
                                    </label>
                                <?php endforeach; ?>
                                <?php $mapsSetup = site_map_settings(); ?>
                                <?php if ($mapsSetup['provider'] === 'off' || ($mapsSetup[$mapsSetup['provider'] . '_key'] ?? '') === ''): ?>
                                    <p class="notice field-wide" data-page-map-notice role="status"<?= ($page['fields']['Lat'] ?? '') === '' && ($page['fields']['Lng'] ?? '') === '' ? ' hidden' : '' ?>>
                                        <?= site_escape($pageTabs[9]) ?> <a href="<?= site_escape($integrationsUrl . '#maps') ?>"><?= site_escape($pageTabs[10]) ?></a>
                                    </p>
                                <?php else: ?>
                                    <?php
                                    $mapPicker = ['provider' => $mapsSetup['provider'], 'key' => $mapsSetup[$mapsSetup['provider'] . '_key'],
                                        'zoom' => (int) $mapsSetup['zoom'], 'mode' => $mapsSetup['mode'], 'mapId' => $mapsSetup['google_map_id'], 'language' => $adminLanguage];
                                    $pickLabel = $adminLanguage === 'ru' ? 'Выбрать на карте' : 'Choose on map';
                                    $pickHelp = $adminLanguage === 'ru' ? 'Нажмите в нужном месте или перетащите метку.' : 'Click a location or drag the marker.';
                                    ?>
                                    <div class="header-actions field-wide">
                                        <button type="button" data-open-map-picker><i class="fa-solid fa-location-dot" aria-hidden="true"></i> <?= site_escape($pickLabel) ?></button>
                                        <a href="<?= site_escape($integrationsUrl . '#maps') ?>"><?= site_escape($pageTabs[10]) ?></a>
                                    </div>
                                    <dialog class="editor-dialog map-picker-dialog" data-map-picker="<?= site_escape((string) json_encode($mapPicker)) ?>"
                                        data-load-error="<?= site_escape($adminLanguage === 'ru' ? 'Не удалось загрузить карту. Проверьте ключ, ограничения домена и соединение.' : 'Could not load the map. Check the key, domain restrictions and connection.') ?>"
                                        aria-label="<?= site_escape($pickLabel) ?>">
                                        <div class="form-stack">
                                            <div class="header-actions editor-dialog-heading">
                                                <h3><?= site_escape($pickLabel) ?></h3>
                                                <button type="button" data-close-map-picker aria-label="<?= admin_l('Закрыть') ?>">×</button>
                                            </div>
                                            <p class="hint"><?= site_escape($pickHelp) ?></p>
                                            <div class="map-picker-canvas" data-map-picker-canvas></div>
                                            <p class="notice error" data-map-picker-error role="alert" hidden></p>
                                            <div class="header-actions">
                                                <output data-map-picker-value></output>
                                                <button type="button" class="button-primary" data-use-map-picker disabled><?= admin_l('Применить') ?></button>
                                            </div>
                                        </div>
                                    </dialog>
                                <?php endif; ?>
                                <div class="hint field-wide">
                                    <p><code>[map]</code> — <?= site_escape($pageTabs[11]) ?></p>
                                    <p><code>[maps]</code> — <?= site_escape($pageTabs[12]) ?></p>
                                    <code>[map center="55.7558,37.6173" zoom=12]</code><br>
                                    <code>[maps center="55.7558,37.6173" zoom=11]</code>
                                </div>
                            </div>
                            <?php require __DIR__ . '/page-sale-view.php'; ?>
                            <section id="page-languages" class="form-stack" data-page-tab-panel="languages" aria-label="<?= admin_l('Переводы страницы') ?>">
                                <?php if ($creating && !$creatingTranslation): ?>
                                    <p class="hint"><?= site_escape($languageLabels[4]) ?></p>
                                <?php else: ?>
                                    <?php
                                    $languages = basename($basePage) === 'index.php' ? $regional['languages'] : ['ru'];
                                    if ($pageLanguage !== '' && !in_array($pageLanguage, $languages, true)) {
                                        $languages[] = $pageLanguage;
                                    }
                                    $languageNames = site_languages();
                                    ?>
                                    <ul class="page-language-list">
                                        <?php foreach ($languages as $code): ?>
                                            <?php $candidate = site_language_page_path($basePage, $code); ?>
                                            <li data-page-language="<?= $code ?>">
                                                <strong lang="<?= $code ?>"><?= site_escape($languageNames[$code]) ?></strong>
                                                <?php if ($candidate === $addressPath): ?>
                                                    <span class="hint" aria-current="true"><?= site_escape($languageLabels[1]) ?></span>
                                                <?php elseif (site_read_page($candidate) !== null): ?>
                                                    <a class="button" href="<?= site_escape(admin_page_edit_url($adminUrl, $candidate)) ?>" aria-label="<?= site_escape($languageLabels[2] . ' · ' . $languageNames[$code]) ?>"><?= site_escape($languageLabels[2]) ?></a>
                                                <?php else: ?>
                                                    <a class="button" href="<?= site_escape($adminUrl . '?' . http_build_query(['new' => '1', 'translation' => site_page_url('', $candidate)])) ?>#page-edit" aria-label="<?= site_escape($languageLabels[3] . ' · ' . $languageNames[$code]) ?>"><i class="fa-solid fa-plus" aria-hidden="true"></i> <?= site_escape($languageLabels[3]) ?></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                                <p class="hint" data-page-language-settings>
                                    <?= site_escape($adminLanguage === 'ru' ? 'Нужен другой язык?' : 'Need another language?') ?>
                                    <a href="<?= site_escape($regionUrl . '#site-languages') ?>"><?= site_escape($adminLanguage === 'ru' ? 'Добавить язык сайта' : 'Add a site language') ?></a>
                                </p>
                            </section>
                            <div class="form-actions page-editor-actions">
                                <button class="button-primary page-editor-action" type="submit"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i><?= admin_l('Сохранить') ?></button>
                                <?php if (!$creating): ?>
                                    <a class="button page-editor-action page-editor-icon-only" title="<?= admin_l('Открыть страницу') ?>" data-page-open href="<?= site_escape(site_page_url($base, $page['path'])) ?>"<?= site_page_is_public($page['fields']) ? '' : ' hidden' ?>><i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Открыть страницу') ?></span></a>
                                    <?php $operation = $page['fields']['Hidden'] === '1' ? 'show' : 'hide'; $editUrl = admin_page_edit_url($adminUrl, $page['path']); ?>
                                    <a class="button page-editor-action page-editor-icon-only" title="<?= admin_l($operation === 'show' ? 'Показать' : 'Скрыть') ?>" href="<?= site_escape($editUrl . '&confirm=' . $operation) ?>" data-current-page-action="visibility" data-page-action="<?= $operation ?>" data-show-text="<?= admin_l('Показать') ?>" data-hide-text="<?= admin_l('Скрыть') ?>"><i class="fa-solid <?= $operation === 'show' ? 'fa-eye' : 'fa-eye-slash' ?>" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l($operation === 'show' ? 'Показать' : 'Скрыть') ?></span></a>
                                    <?php if ($page['path'] !== 'index.php'): ?><a class="button page-editor-action page-editor-icon-only" title="<?= admin_l('Удалить') ?>" href="<?= site_escape($editUrl . '&confirm=delete') ?>" data-current-page-action="delete" data-page-action="delete"><i class="fa-solid fa-trash" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Удалить') ?></span></a><?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </form>
                        <?php if (!$creating && $page['path'] !== 'index.php' && $sectionDirectory === ''): ?>
                            <details class="page-code" data-page-move data-page-tab-panel="settings">
                                <summary><?= admin_l('Переместить страницу') ?></summary>
                                <form class="form-stack" method="post" action="<?= site_escape(admin_page_edit_url($adminUrl, $page['path'])) ?>" data-page-move-form>
                                    <input type="hidden" name="action" value="page-move">
                                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                                    <input type="hidden" name="path" value="<?= site_escape($page['path']) ?>">
                                    <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                                    <label class="field">
                                        <?= admin_l('Папка назначения') ?>
                                        <select name="existing_folder" id="page-folders">
                                            <option value=""><?= admin_l('Выберите папку') ?></option>
                                            <?php $folders = array_keys($tree); sort($folders, SORT_STRING); ?>
                                            <?php foreach ($folders as $folder): ?>
                                                <?php if ($folder !== '.' && $folder !== dirname($page['path'])): ?><option value="<?= site_escape('/' . $folder . '/') ?>"><?= site_escape('/' . $folder . '/') ?></option><?php endif; ?>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                    <label class="field"><?= admin_l('Новая папка') ?>
                                        <input name="folder" placeholder="/Services-1/" maxlength="230"
                                            data-address-input aria-describedby="page-folder-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*/?') ?>">
                                    </label>
                                    <small class="hint" id="page-folder-hint"><?= admin_l('В именах папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Можно указать новую папку. Подпапки страницы останутся по прежним адресам.') ?></small>
                                    <div><button type="submit"><?= admin_l('Переместить') ?></button></div>
                                </form>
                            </details>
                        <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
    <footer class="site-footer admin-footer">
        <div class="container footer-layout"><?= site_author_credit($adminLanguage) ?><span><?= admin_l('Версия') ?> <?= site_escape(site_update_version()) ?></span></div>
    </footer>
</body>
</html>
