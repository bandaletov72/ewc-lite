<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
try {
    $bannerSets = site_banner_sets();
    list($bannerSetId, $bannerFolder, $bannerSet) = admin_banner_selection($_GET);
} catch (RuntimeException $exception) {
    echo '<p class="notice error">' . admin_l($exception->getMessage()) . '</p>';
    return;
}
$slides = site_banner_slides($bannerSet, $bannerFolder);
$bannerSlideId = admin_input($_GET, 'slide');
$bannerUrl = site_banner_admin_url($base, $bannerSetId, $bannerFolder);
$bannerRevision = admin_settings_revision($bannerSet);
$now = date('Y-m-d\TH:i');
list($bannerUiName, $bannerUiSet) = site_banner_editor_labels($adminLanguage);
$bannerLabel = static function (string $ru, string $en) use ($adminLanguage): string {
    return $adminLanguage === 'zh' ? site_translation($ru, $adminLanguage) : ($adminLanguage === 'ru' ? $ru : $en);
};
$bannerText = static function (string $ru, string $en) use ($bannerLabel): string { return site_escape($bannerLabel($ru, $en)); };
?>
<section class="panel form-stack" id="banner-editor">
    <?php if (!$focusedBanner): ?>
    <h2><?= site_escape($bannerUiName) ?> <code>[banners]</code></h2>
    <nav class="site-menu" aria-label="<?= $bannerText('Наборы баннеров', 'Banner sets') ?>">
        <?php foreach (array_keys(['main' => true] + $bannerSets) as $name): ?>
            <a href="<?= site_escape(site_banner_admin_url($base, $name)) ?>#banner-editor"<?= $name === $bannerSetId ? ' aria-current="page"' : '' ?>><?= site_escape($name) ?></a>
        <?php endforeach; ?>
    </nav>
    <form class="form-stack" method="get" action="<?= site_escape(site_url($base, 'admin/')) ?>#banner-editor">
        <input type="hidden" name="components" value="1">
        <div class="fields">
            <label class="field"><?= site_escape($bannerUiSet) ?> <small>A–Z, a–z, -, _</small><input name="banner" placeholder="promotion" maxlength="64" pattern="[A-Za-z_\-]{1,64}"></label>
            <label class="field"><?= $bannerText('Папка изображений (необязательно)', 'Image folder (optional)') ?><input name="folder" placeholder="/images/myfotos/" maxlength="240"></label>
        </div>
        <small class="hint"><?= $bannerText('Укажите только папку, чтобы настроить баннеры из папочного тега. Для отдельного набора укажите ID.', 'Enter only the folder to configure a folder shortcode. Enter an ID to open a separate set.') ?></small>
        <div><button type="submit"><?= admin_l('Открыть') ?></button></div>
    </form>
    <?php
    $folderSet = $bannerFolder !== '' && $bannerSetId === site_banner_id('', $bannerFolder);
    $shortcode = '[banners' . ($bannerSetId !== 'main' && !$folderSet ? ' set=' . $bannerSetId : '') . ']';
    if ($bannerFolder !== '') $shortcode .= $bannerFolder . '[/banners]';
    ?>
    <p><?= admin_l('Код для вставки') ?> <code><?= site_escape($shortcode) ?></code></p>
    <div><a class="button button-primary" href="<?= site_escape($bannerUrl) ?>&amp;slide=new#banner-editor">+ <?= $bannerText('Добавить кадр', 'Add slide') ?></a></div>
    <?php if ($slides): ?>
        <ol class="banner-slide-list">
        <?php foreach ($slides as $id => $slide): ?>
            <li class="header-actions">
                <a href="<?= site_escape($bannerUrl . '&slide=' . $id) ?>#banner-editor"><?= site_escape($slide['title'] ?: (basename($slide['image']) ?: $id)) ?></a>
                <span class="hint"><?= $slide['excluded'] ? $bannerText('Исключён', 'Excluded') : (site_banner_visible($slide, $now) ? $bannerText('Показывается', 'Visible') : $bannerText('Скрыт', 'Hidden')) ?></span>
                <form class="header-actions" method="post" action="<?= site_escape($bannerUrl) ?>#banner-editor">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <input type="hidden" name="revision" value="<?= site_escape($bannerRevision) ?>">
                    <input type="hidden" name="slide" value="<?= site_escape($id) ?>">
                    <?php if ($slide['excluded']): ?>
                        <button name="action" value="restore-banner"><?= $bannerText('Восстановить', 'Restore') ?></button>
                    <?php else: ?>
                        <input type="hidden" name="action" value="move-banner">
                        <button name="direction" value="up" aria-label="<?= $bannerText('Выше', 'Move up') ?>">↑</button>
                        <button name="direction" value="down" aria-label="<?= $bannerText('Ниже', 'Move down') ?>">↓</button>
                        <a href="<?= site_escape($bannerUrl . '&slide=' . $id . '&remove=1') ?>#banner-editor"><?= admin_l('Удалить') ?></a>
                    <?php endif; ?>
                </form>
            </li>
        <?php endforeach; ?>
        </ol>
    <?php endif; ?>
    <?php endif; ?>
    <?php if ($bannerSlideId === 'new' || isset($slides[$bannerSlideId])): ?>
    <?php if (admin_input($_GET, 'remove') === '1' && isset($slides[$bannerSlideId])): ?>
        <form class="form-stack" method="post" action="<?= site_escape($bannerUrl) ?>#banner-editor">
            <p><?= $bannerText('Удалить кадр из баннеров?', 'Remove this slide from the banners?') ?></p>
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($bannerRevision) ?>">
            <input type="hidden" name="slide" value="<?= site_escape($bannerSlideId) ?>">
            <div class="header-actions"><button class="button-danger" name="action" value="delete-banner"><?= admin_l('Удалить') ?></button><a href="<?= site_escape($bannerUrl) ?>#banner-editor"><?= admin_l('Отмена') ?></a></div>
        </form>
    <?php else: ?>
        <?php $slide = $error !== '' && admin_input($_POST, 'action') === 'save-banner' ? admin_banner_slide_draft($_POST) : ($slides[$bannerSlideId] ?? site_banner_slide_defaults()); ?>
        <form class="form-stack" method="post" action="<?= site_escape($bannerUrl . '&slide=' . $bannerSlideId . ($focusedBanner ? '&embed=1' : '')) ?>#banner-editor">
            <h3><?= $bannerSlideId === 'new' ? $bannerText('Новый кадр', 'New slide') : $bannerText('Редактировать кадр', 'Edit slide') ?></h3>
            <input type="hidden" name="action" value="save-banner">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($bannerRevision) ?>">
            <input type="hidden" name="slide" value="<?= site_escape($bannerSlideId) ?>">
            <div class="fields">
                <label class="choice field-wide"><input type="checkbox" name="active" value="1"<?= $slide['active'] ? ' checked' : '' ?>> <?= $bannerText('Кадр активен', 'Slide enabled') ?></label>
                <?php foreach (['from' => $bannerText('Начало активности', 'Active from'), 'until' => $bannerText('Конец активности', 'Active until')] as $key => $label): ?>
                    <label class="field"><?= $label ?><input type="datetime-local" name="<?= $key ?>" value="<?= site_escape($slide[$key]) ?>"></label>
                <?php endforeach; ?>
                <label class="field field-wide"><?= $bannerText('URL изображения подложки', 'Background image URL') ?><input id="banner-image" name="image" value="<?= site_escape($slide['image']) ?>" maxlength="1500" placeholder="/images/banner.jpg"></label>
                <?php foreach (['color' => $bannerText('Цвет подложки', 'Background color'), 'textColor' => $bannerText('Цвет надписи', 'Text color')] as $field => $colorLabel): ?>
                    <label class="field"><?= $colorLabel ?>
                        <span class="banner-color-control"><input type="color" name="<?= $field ?>" value="<?= site_escape($slide[$field]) ?>" data-banner-color>
                            <code><?= site_escape(strtoupper($slide[$field])) ?></code></span>
                    </label>
                <?php endforeach; ?>
                <label class="field"><?= $bannerText('Надпись', 'Headline') ?><input name="title" value="<?= site_escape($slide['title']) ?>" maxlength="100"></label>
                <label class="field"><?= $bannerText('Ссылка кадра', 'Slide link') ?><input name="url" value="<?= site_escape($slide['url']) ?>" maxlength="1500"></label>
                <label class="field"><?= $bannerText('Положение надписи', 'Text placement') ?>
                    <select name="align"><?php foreach (['left' => $bannerText('Слева', 'Left'), 'center' => $bannerText('По центру', 'Center'), 'right' => $bannerText('Справа', 'Right')] as $key => $label): ?><option value="<?= $key ?>"<?= $slide['align'] === $key ? ' selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select>
                </label>
                <label class="field"><?= $bannerText('Шрифт надписи', 'Text font') ?>
                    <?php $fonts = ['site' => $bannerLabel('Шрифт сайта', 'Site font'), 'sans' => 'System UI', 'serif' => 'Georgia', 'mono' => 'Consolas'] + array_map(static function (array $font): string { return $font[0]; }, site_google_fonts()); ?>
                    <select name="font"><?php foreach ($fonts as $key => $label): ?><option value="<?= site_escape($key) ?>"<?= $slide['font'] === $key ? ' selected' : '' ?>><?= site_escape($label) ?></option><?php endforeach; ?></select>
                </label>
            </div>
            <?php
            $editorId = 'banner-caption'; $editorName = 'caption'; $editorValue = $slide['caption']; $editorTitle = $bannerLabel('HTML надписи', 'Caption HTML');
            $editorWithComponents = false; $editorWithMedia = false; $editorImageTarget = 'banner-image';
            require __DIR__ . '/content-editor.php';
            ?>
            <fieldset class="field-config fields">
                <legend><?= $bannerText('Кнопка кадра', 'Slide button') ?></legend>
                <label class="field"><?= admin_l('Текст кнопки') ?><input name="button" value="<?= site_escape($slide['button']) ?>" maxlength="40"></label>
                <label class="field"><?= $bannerText('Действие кнопки', 'Button action') ?>
                    <select name="actionChoice" data-banner-action>
                        <?php foreach (['none' => $bannerText('Без кнопки', 'No button'), 'url' => $bannerText('Открыть ссылку', 'Open a link'), 'callback' => admin_l('Обратный звонок'), 'form' => $bannerText('Открыть форму в окне', 'Open a form dialog')] as $key => $label): ?><option value="<?= $key ?>"<?= $slide['action'] === $key ? ' selected' : '' ?>><?= $label ?></option><?php endforeach; ?>
                    </select>
                </label>
                <label class="field" data-banner-action-field="url">URL <input name="buttonUrl" value="<?= site_escape($slide['buttonUrl']) ?>" maxlength="1500"></label>
                <label class="field" data-banner-action-field="form"><?= admin_l('Форма') ?>
                    <select name="form"><option value="">—</option><?php foreach (array_keys($editorForms) as $formId): ?><?php if (!site_valid_form_id($formId)) continue; ?><option value="<?= site_escape($formId) ?>"<?= $slide['form'] === $formId ? ' selected' : '' ?>>[<?= site_escape($formId) ?>]</option><?php endforeach; ?></select>
                </label>
            </fieldset>
            <div><button class="button-primary" type="submit"><?= admin_l('Сохранить') ?></button></div>
        </form>
    <?php endif; ?>
    <?php endif; ?>
    </section>
