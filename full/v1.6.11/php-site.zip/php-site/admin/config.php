<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const ADMIN_UPDATE_VERSION_FILE = SITE_ROOT . '/admin/.update-version.php';

function admin_t(string $text): string
{
    return site_translation($text, $GLOBALS['adminLanguage'] ?? 'ru');
}

function admin_l(string $text): string
{
    return site_escape(admin_t($text));
}

function admin_save_functions(string $code, string $revision)
{
    $bytes = EW_FUNCTIONS_HEADER . $code;
    if (strlen($bytes) > EW_FUNCTIONS_LIMIT || preg_match('//u', $code) !== 1 || strpos($code, "\0") !== false
        || !preg_match('/\A\s*return\s*\[/', $code)) {
        throw new RuntimeException('В functions.php должен быть массив функций вида return [...];');
    }
    $tokens = admin_validate_php($bytes);
    foreach ($tokens as $index => $token) {
        if ($index && is_array($token) && in_array($token[0], [T_OPEN_TAG, T_OPEN_TAG_WITH_ECHO, T_CLOSE_TAG, T_INLINE_HTML, T_HALT_COMPILER], true)) {
            throw new RuntimeException('Введите PHP-код без открывающего и закрывающего тегов.');
        }
    }
    $lock = admin_lock();
    try {
        if (is_link(EW_FUNCTIONS_FILE) || !hash_equals(ew_function_source()[1], $revision)) {
            throw new RuntimeException('Файл functions.php изменился. Откройте редактор заново.');
        }
        if (!admin_replace_file(EW_FUNCTIONS_FILE, $bytes)) {
            throw new RuntimeException('Не удалось сохранить functions.php.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_save_module(array $submitted)
{
    $name = admin_input($submitted, 'module');
    $label = trim(admin_input($submitted, 'label'));
    $description = trim(admin_input($submitted, 'description'));
    if (!isset(site_extensions()[$name]) || $label === '' || strlen($label) > 480 || strlen($description) > 1600
        || preg_match('//u', $label . $description) !== 1) {
        throw new RuntimeException(admin_l('Проверьте название и описание модуля.'));
    }
    $lock = admin_lock();
    try {
        $settings = site_php_module_settings();
        $settings[$name] = ['label' => $label, 'description' => $description,
            'enabled' => admin_input($submitted, 'enabled') === '1'];
        admin_write_record(SITE_PHP_MODULES_FILE, $settings, 262144);
    } finally {
        fclose($lock);
    }
}

function admin_save_module_source(array $submitted)
{
    $name = admin_input($submitted, 'module');
    $code = admin_input($submitted, 'code');
    $revision = admin_input($submitted, 'revision');
    $filename = trim(admin_input($submitted, 'filename')) ?: $name . '.php';
    if (!preg_match('/\A[A-Za-z0-9_-]{1,64}\.php\z/', $filename) || !site_valid_part(substr($filename, 0, -4))) {
        throw new RuntimeException('Имя файла должно содержать латинские буквы, цифры, дефис или подчёркивание и оканчиваться на .php.');
    }
    if (!site_valid_snippet($name) || isset(site_layout_blocks()[$name]) || isset(site_contact_tokens()[$name])
        || site_valid_form_id($name) || in_array($name, ['gal', 'fotos', 'files', 'banners', 'include', 'iblock', 'callback', 'map', 'php', 'button'], true)
        || trim($code) === '' || strlen($code) > SITE_PHP_MODULE_SOURCE_LIMIT || strpos($code, "\0") !== false || preg_match('//u', $code) !== 1) {
        throw new RuntimeException('Проверьте имя и код PHP-модуля.');
    }
    $bytes = site_php_module_source_prefix($name) . $code . "\n}]];\n";
    $tokens = admin_validate_php($bytes);
    foreach ($tokens as $index => $part) {
        if ($index && is_array($part) && in_array($part[0], [T_OPEN_TAG, T_OPEN_TAG_WITH_ECHO, T_CLOSE_TAG, T_INLINE_HTML, T_HALT_COMPILER], true)) {
            throw new RuntimeException('Введите тело модуля без открывающих и закрывающих тегов PHP.');
        }
    }
    $lock = admin_lock();
    try {
        list(, $current, $oldName) = site_php_module_source($name);
        if (is_link(SITE_PHP_EDITOR_DIR) || !hash_equals($current, $revision)
            || ($revision === '' && !empty($submitted['create']) && isset(site_extensions()[$name]))) {
            throw new RuntimeException('Исходный код изменился или недоступен. Откройте модуль заново.');
        }
        if (!is_dir(SITE_PHP_EDITOR_DIR) && !@mkdir(SITE_PHP_EDITOR_DIR, 0755)) {
            throw new RuntimeException('Не удалось создать защищённую папку PHP-модулей.');
        }
        $path = SITE_PHP_EDITOR_DIR . '/' . $filename;
        $oldPath = $current !== '' ? SITE_PHP_EDITOR_DIR . '/' . $oldName : '';
        $sameFile = $path === $oldPath || (DIRECTORY_SEPARATOR === '\\' && strcasecmp($path, $oldPath) === 0);
        if (is_link($path) || (!$sameFile && file_exists($path))) {
            throw new RuntimeException('Такое имя файла уже занято.');
        }
        if (!admin_replace_file($path, $bytes)) {
            throw new RuntimeException('Не удалось сохранить код PHP-модуля.');
        }
        if (!$sameFile && $oldPath !== '' && !@unlink($oldPath)) {
            @unlink($path);
            throw new RuntimeException('Не удалось удалить прежний файл модуля. Переименование отменено.');
        }
    } finally {
        fclose($lock);
    }
}

function admin_install_language_packs()
{
    $directory = SITE_ROOT . '/admin/languages';
    if (!is_file(SITE_ROOT . '/app/language-ru.php')) {
        return;
    }
    if ((!is_dir($directory) && !@mkdir($directory, 0755)) || is_link($directory)
        || realpath($directory) !== str_replace('/', DIRECTORY_SEPARATOR, $directory)) {
        return;
    }
    foreach (array_keys(site_languages()) as $code) {
        $target = $directory . '/' . $code . '.php';
        $source = SITE_ROOT . '/app/language-' . $code . '.php';
        if (!file_exists($target) && !is_link($target) && is_file($source)) {
            $bytes = @file_get_contents($source);
            if ($bytes !== false) {
                admin_replace_file($target, $bytes);
            }
        }
    }
}

function admin_save_region(array $settings, string $revision)
{
    foreach (site_region_options() as $key => $options) {
        if (!isset($options[$settings[$key]])) {
            throw new RuntimeException('Проверьте региональные настройки.');
        }
    }
    if (!in_array($settings['interface'], $settings['languages'], true)
        || !in_array($settings['public'], $settings['languages'], true)
        || ($settings['timezone'] !== 'auto' && !in_array($settings['timezone'], site_time_zones(), true))
        || $settings['group'] === $settings['decimal']) {
        throw new RuntimeException('Проверьте язык, часовой пояс и разделители. Дробный разделитель должен отличаться от разделителя разрядов.');
    }
    $lock = admin_lock();
    try {
        if (!hash_equals(admin_settings_revision(site_region_settings()), $revision)) {
            throw new RuntimeException('Региональные настройки изменились. Откройте страницу заново.');
        }
        admin_write_record(SITE_REGIONAL_FILE, $settings);
    } finally {
        fclose($lock);
    }
}

function admin_cached_update_version(string $repository): string
{
    try {
        $record = site_read_record(ADMIN_UPDATE_VERSION_FILE);
    } catch (RuntimeException $exception) {
        return '';
    }
    $version = $record['version'] ?? '';
    return ($record['repository'] ?? '') === $repository && is_string($version)
        && preg_match('/\A[0-9]+\.[0-9]+\.[0-9]+\z/', $version) ? $version : '';
}

function admin_remember_update_version(string $repository, string $version)
{
    if (admin_cached_update_version($repository) !== $version) {
        admin_write_record(ADMIN_UPDATE_VERSION_FILE, ['repository' => $repository, 'version' => $version]);
    }
}

function admin_change_library_version(string $id, bool $rollback): string
{
    $catalog = site_library_catalog();
    if (!isset($catalog[$id])) {
        throw new RuntimeException('Выберите библиотеку из списка.');
    }
    $lock = admin_lock();
    try {
        $versions = site_library_versions();
        $active = $versions[$id]['active'] ?? $catalog[$id];
        $target = $rollback ? site_library_rollback($id, $active, $versions) : $catalog[$id];
        if (!$target || $active['label'] === $target['label']) {
            return $active['label'];
        }
        $versions[$id] = ['active' => $target];
        if (!$rollback) {
            $versions[$id]['previous'] = $active;
        }
        admin_write_record(SITE_LIBRARY_VERSIONS_FILE, $versions);
        return $target['label'];
    } finally {
        fclose($lock);
    }
}

function admin_save_library_settings(array $settings, string $revision)
{
    $lock = admin_lock();
    try {
        $current = site_library_settings(site_read_record(SITE_LIBRARIES_FILE));
        if (!hash_equals(admin_settings_revision($current), $revision)) {
            throw new RuntimeException('Настройки библиотек уже изменились. Откройте раздел заново.');
        }
        admin_write_record(SITE_LIBRARIES_FILE, $settings);
    } finally {
        fclose($lock);
    }
}

function admin_settings_revision(array $settings): string
{
    return hash('sha256', json_encode($settings));
}

function admin_variables_text(array $variables): string
{
    $lines = [];
    foreach ($variables as $name => $value) {
        if (is_string($value)) {
            $lines[] = '[' . $name . '] = ' . $value;
        }
    }
    return implode("\n", $lines);
}

function admin_save_settings(array $settings, string $variables, string $revision)
{
    $current = site_settings();
    $breadcrumbs = $settings['breadcrumbs'] ?? $current['breadcrumbs'];
    $searchMode = $settings['searchMode'] ?? $current['searchMode'];
    $publicUrl = $settings['publicUrl'] ?? $current['publicUrl'];
    $address = $publicUrl === '' ? [] : parse_url($publicUrl);
    if ($publicUrl !== '' && (strlen($publicUrl) > 2048 || !filter_var($publicUrl, FILTER_VALIDATE_URL)
        || !in_array($address['scheme'] ?? '', ['http', 'https'], true)
        || isset($address['user']) || isset($address['pass']) || isset($address['query']) || isset($address['fragment']))) {
        throw new RuntimeException('Укажите полный адрес сайта с http:// или https://, без параметров и якоря.');
    }
    if (!in_array($searchMode, ['off', 'compact', 'expanded'], true)) {
        throw new RuntimeException('Выберите вид поиска из списка.');
    }
    $settings = admin_site_text_settings($settings);
    $settings['breadcrumbs'] = $breadcrumbs;
    $settings['searchMode'] = $searchMode;
    $settings['publicUrl'] = $publicUrl;
    $settings['variables'] = [];
    foreach (preg_split('/\r\n|\n|\r/', $variables) as $line) {
        if (trim($line) === '') {
            continue;
        }
        $parts = array_map('trim', explode('=', $line, 2));
        $name = preg_replace('/\A\[([a-z][a-z0-9_]{0,63})\]\z/', '$1', $parts[0]);
        if (count($parts) !== 2 || preg_match('/\A[a-z][a-z0-9_]{0,63}\z/', $name) !== 1) {
            throw new RuntimeException('Запишите каждую переменную отдельной строкой в формате «[ключ] = значение».');
        }
        if (isset($settings['variables'][$name])) {
            throw new RuntimeException('Используйте каждое имя переменной один раз.');
        }
        if (strpos($parts[1], "\0") !== false) {
            throw new RuntimeException('Значение переменной содержит недопустимый символ.');
        }
        $settings['variables'][$name] = $parts[1];
    }

    $lock = admin_lock();
    try {
        site_read_record(SITE_SETTINGS_FILE);
        if (!hash_equals(admin_settings_revision(site_settings()), $revision)) {
            throw new RuntimeException('Настройки изменились. Скопируйте правки и откройте раздел заново.');
        }
        admin_write_record(SITE_SETTINGS_FILE, $settings);
    } finally {
        fclose($lock);
    }
}

function admin_site_text_settings(array $settings): array
{
    if ($settings['name'] === '') {
        throw new RuntimeException('Укажите название сайта.');
    }
    foreach ($settings as $value) {
        if (strlen($value) > 1500 || preg_match('/[\x00-\x1F\x7F]/', $value) || preg_match('//u', $value) !== 1) {
            throw new RuntimeException('Проверьте длину и формат полей настроек.');
        }
    }

    $settings['footer'] = site_footer_pattern($settings['footer']);
    return $settings;
}

function admin_snippet_revision(array $snippet): string
{
    return hash('sha256', json_encode($snippet));
}

function admin_update_snippet(string $host, string $name, array $snippet, string $revision, bool $delete)
{
    if (!site_valid_snippet($name)) {
        throw new RuntimeException('Укажите имя подшаблона строчными латинскими буквами. После первой буквы допустимы цифры, дефисы и подчёркивания.');
    }
    if (in_array($name, ['gal', 'fotos', 'files', 'banners', 'include', 'iblock', 'callback', 'map', 'php', 'button'], true) || site_valid_form_id($name)) {
        throw new RuntimeException('Это имя используется компонентом сайта.');
    }
    if (!$delete && ($snippet['description'] === '' || strlen($snippet['description']) > 1500
            || preg_match('/[\x00-\x1F\x7F]/', $snippet['description']))) {
        throw new RuntimeException('Добавьте краткое описание подшаблона.');
    }
    if (strpos($snippet['value'], "\0") !== false || preg_match('//u', $snippet['value']) !== 1) {
        throw new RuntimeException('Используйте HTML в кодировке UTF-8.');
    }

    $lock = admin_lock();
    try {
        $snippets = site_read_snippets($host);
        $current = $snippets[$name] ?? null;
        if ($revision === '') {
            if ($current !== null || $delete) {
                throw new RuntimeException('Имя подшаблона уже используется или запись была изменена. Откройте её заново.');
            }
        } elseif (!is_array($current) || !hash_equals(admin_snippet_revision($current), $revision)) {
            throw new RuntimeException('Подшаблон изменился. Скопируйте правки и откройте его заново.');
        }

        if ($delete) {
            unset($snippets[$name]);
        } else {
            $snippets[$name] = $snippet;
        }
        ksort($snippets);
        admin_write_record(site_snippet_file($host), $snippets, SITE_SNIPPET_RECORD_LIMIT);
    } finally {
        fclose($lock);
    }
}

function admin_add_domain(string $name)
{
    $domain = site_normalize_domain($name);
    if ($domain === '' || strpos($domain, '.') === false || filter_var($domain, FILTER_VALIDATE_IP)) {
        throw new RuntimeException('Укажите полное имя поддомена, например msk.example.ru.');
    }

    $lock = admin_lock();
    try {
        $domains = site_read_record(SITE_DOMAINS_FILE);
        if (in_array($domain, $domains, true)) {
            throw new RuntimeException('Этот домен уже добавлен.');
        }
        $domains[] = $domain;
        sort($domains, SORT_STRING);
        admin_write_record(SITE_DOMAINS_FILE, $domains);
    } finally {
        fclose($lock);
    }
}

function admin_domain_template_labels(): array
{
    return ['header' => 'Шапка', 'mobile-menu' => 'Мобильное меню', 'menu' => 'Правое меню', 'footer' => 'Подвал',
        'home' => 'Главная страница', 'privacy' => 'Политика конфиденциальности', 'conf-policy' => 'Ссылка на политику',
        'top' => 'Кнопка «Наверх»', 'cookies' => 'Меню согласия на cookie', 'bread-crumbs' => 'Хлебные крошки',
        'search' => 'Поиск по сайту', 'main-menu' => 'Верхнее меню', 'lang' => 'Язык'] + site_custom_layouts();
}

function admin_add_layout_template(string $name, string $label)
{
    $lock = admin_lock();
    try {
        $defs = site_read_record(SITE_LAYOUT_DEFINITIONS);
        $reserved = ['privacy-content', 'page-content', 'site-name', 'site-url', 'author', 'gal', 'fotos', 'files', 'banners', 'include', 'iblock', 'map', 'maps', 'payment', 'sections', 'list-pages', 'php', 'func', 'callback', 'fa-icon', 'button', 'item-price', 'item-buy-button'];
        if (!site_valid_snippet($name) || isset($defs[$name]) || isset(site_layout_blocks()[$name]) || isset(site_read_snippets()[$name])
            || isset(site_contact_tokens()[$name]) || isset(site_date_snippets()[$name]) || isset(site_extensions()[$name])
            || isset(site_settings()['variables'][$name]) || site_valid_form_id($name) || in_array($name, $reserved, true)
            || $label === '' || strlen($label) > 360 || preg_match('//u', $label) !== 1) {
            throw new RuntimeException('Укажите свободный ключ шаблона и его название.');
        }
        foreach (site_read_record(SITE_DOMAINS_FILE) as $host) {
            if (is_string($host) && isset(site_read_snippets($host)[$name])) {
                throw new RuntimeException('Укажите свободный ключ шаблона и его название.');
            }
        }
        $defs[$name] = $label;
        admin_write_record(SITE_LAYOUT_DEFINITIONS, $defs);
    } finally {
        fclose($lock);
    }
}

function admin_domain_template_draft(array $blocks): array
{
    $draft = [];
    foreach (admin_domain_template_labels() as $name => $label) {
        if (!is_array($blocks[$name] ?? null)) {
            continue;
        }
        $block = $blocks[$name];
        $draft[$name] = ['mode' => admin_input($block, 'mode'), 'value' => admin_input($block, 'value')];
        if (admin_input($block, 'visibility') === '1') {
            $draft[$name]['visibility'] = (admin_input($block, 'mobile') === '1' ? 1 : 0)
                | (admin_input($block, 'desktop') === '1' ? 2 : 0);
        }
    }
    return $draft;
}

function admin_layout_editor_value(string $name, string $mode, array $own, array $shared): string
{
    if (in_array($mode, ['php', 'custom'], true)) {
        return $own['value'] ?? '';
    }
    if ($mode === 'inherit' && in_array($shared['mode'] ?? 'custom', ['php', 'custom'], true) && isset($shared['value'])) {
        return $shared['value'];
    }
    $file = site_layout_blocks()[$name];
    if ($file === '') {
        return '';
    }
    $path = $mode === 'stock' || ($shared['mode'] ?? '') === 'stock' ? SITE_ROOT . '/templates/' . $file : site_template_file($file);
    $source = @file_get_contents($path, false, null, 0, 65537);
    return is_string($source) && strlen($source) <= 65536 ? $source : '';
}

function admin_save_domain_templates(string $host, array $draft, string $revision, string $operation = '')
{
    $labels = admin_domain_template_labels();
    if ($operation !== '') {
        $parts = explode(':', $operation, 2);
        if (count($parts) !== 2 || !in_array($parts[0], ['undo', 'reset'], true) || !isset($labels[$parts[1]])) {
            throw new RuntimeException('Выберите шаблон оформления.');
        }
    }
    foreach ($draft as $name => $block) {
        if ($operation !== '') {
            break;
        }
        if (!in_array($block['mode'], ['inherit', 'custom', 'stock', 'php'], true)) {
            throw new RuntimeException('Выберите источник для каждого шаблона.');
        }
        if (in_array($block['mode'], ['custom', 'php'], true)
            && (strlen($block['value']) > 65536 || strpos($block['value'], "\0") !== false || preg_match('//u', $block['value']) !== 1)) {
            throw new RuntimeException('Сохраните HTML в кодировке UTF-8.');
        }
    }

    $lock = admin_lock();
    try {
        $snippets = site_read_snippets($host);
        if (!hash_equals(admin_settings_revision($snippets), $revision)) {
            throw new RuntimeException('Шаблоны уже изменились. Скопируйте правки и откройте раздел заново.');
        }
        $history = is_array($snippets['_layoutHistory'] ?? null) ? $snippets['_layoutHistory'] : [];
        $visibility = is_array($snippets['_layoutVisibility'] ?? null) ? $snippets['_layoutVisibility'] : [];
        $sharedVisibility = $host === '' ? [] : (site_read_snippets()['_layoutVisibility'] ?? []);
        foreach ($labels as $name => $label) {
            if ($operation !== '' && $name !== $parts[1]) {
                continue;
            }
            if ($operation === '' && !isset($draft[$name])) {
                continue;
            }
            if ($operation === '' && isset($draft[$name]['visibility'])) {
                $mask = $draft[$name]['visibility'];
                if ($mask === ($sharedVisibility[$name] ?? site_layout_visibility_default($name))) {
                    unset($visibility[$name]);
                } else {
                    $visibility[$name] = $mask;
                }
            }
            $before = $snippets[$name] ?? null;
            $states = is_array($history[$name] ?? null) ? $history[$name] : [];
            if ($operation !== '' && $parts[0] === 'undo') {
                if (!$states) {
                    throw new RuntimeException('Для этого шаблона пока нет истории.');
                }
                $after = array_pop($states);
            } else {
                $mode = $operation !== '' ? 'stock' : $draft[$name]['mode'];
                $after = $mode === 'inherit' ? null : ['description' => $before['description'] ?? $label,
                    'value' => $mode === 'stock' ? '' : $draft[$name]['value']];
                if ($mode === 'stock' || $mode === 'php') {
                    $after['mode'] = $mode;
                }
                if ($mode === 'php' && $before !== $after) {
                    try {
                        foreach (admin_validate_php($after['value']) as $token) {
                            if (is_array($token) && $token[0] === T_HALT_COMPILER) {
                                throw new RuntimeException('В шаблонах PHP нельзя использовать __halt_compiler().');
                            }
                        }
                    } catch (RuntimeException $exception) {
                        throw new RuntimeException(admin_t($label) . ' — ' . admin_t($exception->getMessage()), 0, $exception);
                    }
                }
                if ($before !== $after) {
                    $states[] = $before;
                    $states = array_slice($states, -8);
                }
            }
            $history[$name] = $states;
            if ($after === null) {
                unset($snippets[$name]);
            } else {
                $snippets[$name] = $after;
            }
        }
        $snippets['_layoutHistory'] = $history;
        $snippets['_layoutVisibility'] = $visibility;
        ksort($snippets);
        admin_write_record(site_snippet_file($host), $snippets, SITE_SNIPPET_RECORD_LIMIT);
    } finally {
        fclose($lock);
    }
}
