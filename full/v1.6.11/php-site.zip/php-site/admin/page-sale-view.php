<?php if (!defined('SITE_ROOT')) exit;
$saleLabels = site_sale_label($adminLanguage);
$saleText = static function (string $ru, string $en) use ($adminLanguage): string {
    return site_escape($adminLanguage === 'ru' ? $ru : $en);
};
?>
<section class="form-stack" id="page-sale" data-page-tab-panel="sale" aria-label="<?= site_escape($saleLabels['tab']) ?>">
    <?php if ($pageLanguage !== ''): ?>
        <p class="hint"><?= $saleText('Цена для каждого языка задаётся в настройках основной страницы.', 'Set language-specific prices on the base page.') ?></p>
        <div><a class="button" href="<?= site_escape(admin_page_edit_url($adminUrl, $basePage)) ?>#page-sale"><?= site_escape($saleLabels['tab']) ?></a></div>
    <?php else: ?>
        <?php
        $savedSale = site_sale_decode($page['fields']['Sale'] ?? '') ?? site_sale_decode('');
        $postedSale = is_array($_POST['sale'] ?? null) ? $_POST['sale'] : null;
        $showBuy = $postedSale !== null ? admin_input($postedSale, 'enabled') === '1' : $savedSale['enabled'];
        $noticeMode = $postedSale !== null ? admin_input($postedSale, 'notices') : $savedSale['notices'];
        $prices = ['default' => $saleText('Основная цена', 'Default price')] + array_intersect_key(site_languages(), array_flip($regional['languages']));
        $currency = $regional['currency'];
        ?>
        <label class="choice"><input type="checkbox" name="sale[enabled]" value="1"<?= $showBuy ? ' checked' : '' ?>> <?= $saleText('Показывать кнопку «Купить»', 'Show the Buy button') ?></label>
        <label class="field"><?= $saleText('Уведомлять о статусе заказа', 'Send order status notifications') ?>
            <select name="sale[notices]">
                <?php foreach (['off' => $saleText('Не отправлять', 'Off'), 'email' => 'Email', 'sms' => 'SMS · Zadarma', 'both' => 'Email + SMS'] as $key => $name): ?>
                    <option value="<?= $key ?>"<?= $noticeMode === $key ? ' selected' : '' ?>><?= $name ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <p class="hint"><?= $saleText('Пустая цена языка использует условия основной цены. Для PayPal и СБП вставьте готовую ссылку на указанную сумму. Для рублёвой оплаты ЮMoney можно указать номер кошелька.', 'If a language price is blank the default offer applies. Use a link for the listed amount for PayPal or SBP. A YooMoney wallet number also works for RUB.') ?>
            <a href="<?= site_escape($integrationsUrl) ?>#payments"><?= $saleText('Настройки платёжных систем', 'Payment settings') ?></a>
        </p>
        <?php foreach ($prices as $code => $title):
            $defaultOffer = ['amount'=>'', 'currency'=>'', 'method'=>'', 'target'=>''];
            $draft = $postedSale['offers'][$code] ?? $savedSale['offers'][$code] ?? [];
            $row = array_replace($defaultOffer, is_array($draft) ? array_filter($draft, 'is_string') : []);
            $prefix = 'sale[offers][' . $code . ']';
        ?>
            <fieldset class="field-config">
                <legend><?= $code === 'default' ? $title : site_escape($title) ?></legend>
                <div class="fields">
                    <label class="field"><?= $saleText('Цена', 'Price') ?><?= $code === 'default' ? ' · ' . site_escape($currency) : '' ?>
                        <input type="text" inputmode="decimal" maxlength="15" name="<?= $prefix ?>[amount]" value="<?= site_escape($row['amount']) ?>" placeholder="1250.00">
                    </label>
                    <?php if ($code !== 'default'): ?>
                        <label class="field"><?= $saleText('Валюта', 'Currency') ?>
                            <select name="<?= $prefix ?>[currency]">
                                <option value=""><?= $saleText('Валюта сайта', 'Site currency') ?> · <?= site_escape($currency) ?></option>
                                <?php foreach (site_region_options()['currency'] as $id => $label): ?>
                                    <option value="<?= site_escape($id) ?>"<?= $row['currency'] === $id ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    <?php endif; ?>
                    <label class="field"><?= $saleText('Способ оплаты', 'Payment method') ?>
                        <select name="<?= $prefix ?>[method]">
                            <option value="">—</option>
                            <?php foreach (site_payment_methods() as $id => list($label)): ?>
                                <option value="<?= $id ?>"<?= $row['method'] === $id ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="field field-wide"><?= $saleText('Ссылка на оплату или кошелёк ЮMoney', 'Payment link or YooMoney wallet') ?>
                        <input name="<?= $prefix ?>[target]" maxlength="500" value="<?= site_escape($row['target']) ?>">
                    </label>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><code>[item-price]</code> <code>[item-buy-button]</code></div>
    <?php endif; ?>
</section>
