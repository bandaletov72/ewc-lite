<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_PERFORMANCE_FILE = SITE_ROOT . '/admin/.performance.php';
const SITE_SEARCH_FILE = SITE_ROOT . '/data/.search-index.php';
const SITE_SEARCH_LIMIT = 67108864;

function site_performance_settings(): array
{
    static $settings;
    if ($settings === null) {
        try {
            $stored = site_read_record(SITE_PERFORMANCE_FILE);
        } catch (RuntimeException $exception) {
            $stored = [];
        }
        $settings = ['cache' => ($stored['cache'] ?? false) === true,
            'generation' => is_string($stored['generation'] ?? null) ? $stored['generation'] : ''];
    }
    return $settings;
}

function site_page_cache_file(string $path): string
{
    return SITE_ROOT . '/data/.page-cache-' . hash('sha256', $path) . '.php';
}

function site_page_cache_write(string $file, array $record)
{
    $encoded = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) {
        return;
    }
    $temporary = SITE_ROOT . '/data/.cache-write-' . bin2hex(random_bytes(12)) . '.php';
    $bytes = SITE_RECORD_HEADER . $encoded;
    try {
        if (@file_put_contents($temporary, $bytes) === strlen($bytes)) {
            @rename($temporary, $file);
        }
    } finally {
        if (is_file($temporary)) {
            @unlink($temporary);
        }
    }
}

function site_remove_search_shortcodes(string $html): string
{
    return preg_replace('~\[(gal|fotos|files|include|php|dir|banners)(?:[ \t=][^\]]*)?\].*?\[/\1\]|\[iblock=[^\]]*\].*?\[/?iblock\]~is', ' ', $html) ?? $html;
}

function site_search_text(string $html, int $limit = 0): string
{
    $html = preg_replace('~<!--.*?-->|<(script|style|template)\b[^>]*>.*?</\1\s*>~is', ' ', $html);
    $html = site_remove_search_shortcodes($html);
    $html = preg_replace('~\[[a-z][a-z0-9_-]*(?:[=\s][^\]]*)?\]|</?(?:p|div|li|br|td|section|h[1-6])\b[^>]*>~i', ' ', $html);
    $plain = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $plain = preg_replace('/[\s\p{Z}\p{Cc}]+/u', ' ', $plain);
    return trim($limit > 0 ? site_search_clip($plain ?? '', $limit) : ($plain ?? ''));
}

function site_search_clip(string $text, int $limit): string
{
    if (strlen($text) <= $limit) {
        return $text;
    }
    $prefix = substr($text, 0, $limit);
    return preg_match('//u', $prefix) === 1 ? $prefix : preg_replace('/[\xC0-\xF7][\x80-\xBF]*\z/', '', $prefix);
}

function site_build_search_index(): array
{
    $paths = [];
    foreach (site_pages(true) as $page) {
        if ($page['fields']['Hidden'] !== '1') {
            $paths[$page['path']] = true;
        }
    }
    $index = ['built' => time(), 'schema' => 2, 'pages' => []];
    $languages = array_keys(site_languages());
    $settings = site_settings();
    $snippets = site_snippet_values('') + array_map('site_escape', array_filter($settings['variables'], 'is_string'));
    foreach (array_keys($paths) as $path) {
        if (site_page_translation($path)[1] !== '') {
            continue;
        }
        foreach ($languages as $language) {
            $variant = site_language_page_path($path, $language);
            if (($variant === $path && $language !== 'ru') || !isset($paths[$variant])) {
                continue;
            }
            $page = site_read_page($variant);
            if ($page === null || $page['fields']['Hidden'] === '1') {
                continue;
            }
            $fields = $page['fields'];
            $title = $fields['Heading'] !== '' ? $fields['Heading'] : $fields['Title'];
            $context = ['searching' => true, 'fragment' => true, 'base' => '', 'locale' => $language,
                'active' => [$path => true], 'extensions' => [], 'contactTokens' => site_contact_tokens(), 'contacts' => null];
            $html = site_expand_content($page['html'], $snippets, $context);
            $index['pages'][$path][$language] = [
                'title' => site_search_text(site_expand_text($title, $snippets), 500) ?: site_page_url('', $path),
                'description' => site_search_text(site_expand_text($fields['Description'], $snippets), 700),
                'announcement' => site_search_text(site_page_announcement($page, $snippets)),
                'text' => site_search_text($html),
                'revision' => $page['revision'],
                'availability' => array_intersect_key($fields, array_flip(['Active', 'ActiveFrom', 'ActiveUntil'])),
            ];
        }
    }
    return $index;
}

function site_search_file(): string
{
    return site_content_root() === SITE_ROOT ? SITE_SEARCH_FILE : SITE_ROOT . '/data/.search-theme-' . site_design_active() . '.php';
}

function site_search_index(): array
{
    try {
        $file = site_search_file();
        $index = site_read_record($file, SITE_SEARCH_LIMIT);
        if ((!$index && $file !== SITE_SEARCH_FILE) || (isset($index['built']) && ($index['schema'] ?? 0) !== 2)) {
            $index = site_build_search_index();
            site_page_cache_write($file, $index);
        }
        return $index;
    } catch (RuntimeException $exception) {
        return [];
    }
}

function site_search_query($raw): string
{
    return is_string($raw) && strlen($raw) <= 320 && preg_match('//u', $raw) === 1 ? trim($raw) : '';
}

function site_search_find(array $index, string $query, string $locale, int $limit, int $offset = 0, string $base = ''): array
{
    if (!preg_match_all('/[\p{L}\p{N}\p{M}]+/u', $query, $matches) || count($matches[0]) > 8
        || (strlen($query) < 2 && !preg_match('/[^\x00-\x7f]/', $query))) {
        return [];
    }
    $words = array_unique($matches[0]);
    $tokens = array_map(static function (string $word): string { return '~' . preg_quote($word, '~') . '~iu'; }, $words);
    $ranked = [];
    foreach (($index['pages'] ?? []) as $path => $variants) {
        if (!site_page_is_public($variants['ru']['availability'] ?? [])) {
            continue;
        }
        $entry = $variants[$locale] ?? $variants['ru'] ?? null;
        if ($entry !== null && !site_page_is_public($entry['availability'] ?? [])) {
            $entry = $variants['ru'] ?? null;
        }
        if ($entry === null) {
            continue;
        }
        $score = 0;
        foreach ($tokens as $pattern) {
            if (preg_match($pattern, $entry['title'])) {
                $score += 10;
            } elseif (preg_match($pattern, $entry['description'])) {
                $score += 5;
            } elseif (preg_match($pattern, $entry['announcement'] ?? '')) {
                $score += 3;
            } elseif (preg_match($pattern, $entry['text'])) {
                $score += 1;
            } else {
                continue 2;
            }
        }
        $ranked[$path] = ['score' => $score, 'entry' => $entry];
    }
    uasort($ranked, static function (array $left, array $right): int { return $right['score'] <=> $left['score']; });
    $results = [];
    foreach ($ranked as $path => $match) {
        $entry = $match['entry'];
        $variant = site_localized_page($path, $locale);
        if ($variant === null || $variant['revision'] !== $entry['revision']) {
            continue;
        }
        if ($offset > 0) {
            $offset--;
            continue;
        }
        $results[] = ['path' => $path, 'url' => site_page_link($base, $variant), 'title' => $entry['title'],
            'description' => ($entry['announcement'] ?? '') !== '' ? site_search_clip($entry['announcement'], 700)
                : ($entry['description'] !== '' ? $entry['description'] : site_search_clip($entry['text'], 300))];
        if (count($results) >= $limit) {
            break;
        }
    }
    return $results;
}
