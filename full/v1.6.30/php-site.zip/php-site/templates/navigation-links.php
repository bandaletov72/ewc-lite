<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php foreach ($navigation as $item): ?>
    <?php $label = $item['fields']['Menu'] !== '' ? $item['fields']['Menu'] : $item['fields']['Title']; ?>
    <a href="<?= site_escape(site_page_link($base, $item)) ?>"<?= $originalPath === $item['path'] ? ' aria-current="page"' : '' ?>><?= site_page_icon($item, $base) ?><?= site_escape(site_expand_text($label, $snippets)) ?></a>
<?php endforeach; ?>
