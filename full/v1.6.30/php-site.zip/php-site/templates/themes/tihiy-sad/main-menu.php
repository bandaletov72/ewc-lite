<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<nav class="gs-nav" aria-label="<?= site_escape(site_translation('Верхнее меню', $locale)) ?>">
    <?php require site_template_file('navigation-links.php'); ?>
</nav>
<div class="gs-header-search"><?= site_expand_content('[search][lang]', $snippets, $context) ?></div>
