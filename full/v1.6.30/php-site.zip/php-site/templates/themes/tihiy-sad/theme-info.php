<?php http_response_code(404); exit; __halt_compiler();
{
  "name": "Тихий сад"
}
