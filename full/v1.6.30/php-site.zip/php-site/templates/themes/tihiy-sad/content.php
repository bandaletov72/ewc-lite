<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php $gardenHome = empty($searchMode) && $originalPath === 'index.php' && strpos($page['html'], 'id="garden-heading"') !== false; ?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main gs-main<?= $gardenHome ? ' gs-home' : '' ?>" id="content" lang="<?= site_escape($page['language'] ?? 'ru') ?>">
    <?php if (!$gardenHome): ?><h1 class="gs-page-title"><?= site_escape($heading) ?></h1><?php endif; ?>
    <div class="page-content"><?= $content ?></div>
</main>
