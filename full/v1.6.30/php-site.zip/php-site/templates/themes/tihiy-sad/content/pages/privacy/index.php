<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Политика конфиденциальности
Heading: Политика конфиденциальности
MenuVisible: 0
MobileMenu: 0
Order: 900

[privacy-content]
