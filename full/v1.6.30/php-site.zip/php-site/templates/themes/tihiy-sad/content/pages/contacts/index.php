<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Контакты
Heading: Обсудим ваш участок
Description: Оставьте заявку на консультацию по ландшафтному дизайну или проектирование сада.
Menu: Контакты
MenuVisible: 1
MobileMenu: 1
Order: 50

<div class="gs-contact">
    <div><p class="gs-lead">Укажите населённый пункт, площадь участка и что вы хотели бы изменить. Этого достаточно для первого разговора.</p>
        [phones]
        [soc-icons]
        <h2>Что будет дальше</h2><p>Уточним детали, предложим следующий шаг и обсудим, нужна ли встреча на участке.</p>
    </div>
    <section id="request" aria-label="Заявка на ландшафтный проект">[form85]</section>
</div>
