<?php http_response_code(404); exit; __halt_compiler();
{
  "mode": "light",
  "light": {
    "paper": "#f6f5ee",
    "surface": "#fbfaf4",
    "ink": "#26372a",
    "muted": "#596456",
    "accent": "#3a523a",
    "accent-wash": "#e8ecdf",
    "line": "#d8ddcf"
  },
  "dark": {
    "paper": "#242e25",
    "surface": "#2a362b",
    "ink": "#f1f1e6",
    "muted": "#c2ccb8",
    "accent": "#bbd1a3",
    "accent-wash": "#364535",
    "line": "#4f614d"
  }
}
