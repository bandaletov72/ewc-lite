<?php
define('SITE_ROOT', __DIR__);
require SITE_ROOT . '/app/site.php';
site_render(isset($pageFile) ? $pageFile : __FILE__);
__halt_compiler();
Title: Главная
Heading: Сад, в котором хочется жить
Description: Ландшафтная студия «Тихий сад». Проектирование частных садов, посадки и сопровождение работ.
Menu: Главная
MenuVisible: 1
MobileMenu: 1
Order: 10

<section class="gs-hero" aria-labelledby="garden-heading">
    <div class="gs-hero-copy">
        <p class="gs-kicker"><span></span> Ландшафтная студия</p>
        <h1 id="garden-heading">Сад, в котором <em>хочется жить</em></h1>
        <p class="gs-lead">Проектируем частные сады, которые подходят вашему участку и становятся красивее с каждым сезоном.</p>
        <div class="gs-hero-actions"><a class="gs-button" href="/works/">Смотреть проекты <span aria-hidden="true">↗</span></a><a class="gs-link" href="/contacts/#request">Обсудить участок</a></div>
    </div>
    <div class="gs-hero-image">
        [banners set=garden-cover width=parent arrows=off numbers=off fit=cover effect=slide]
    </div>
</section>
<ul class="gs-principles" aria-label="Услуги студии">
    <li><a href="/services/#design">Проектирование садов</a></li>
    <li><a href="/services/#planting">Растения и посадки</a></li>
    <li><a href="/services/#support">Сопровождение работ</a></li>
</ul>
<section class="gs-section" aria-labelledby="garden-projects">
    <div class="gs-section-heading"><div><p class="gs-kicker"><span></span> Портфолио</p><h2 id="garden-projects">У каждого сада свой характер</h2></div><a class="gs-link" href="/works/">Все проекты <span aria-hidden="true">↗</span></a></div>
    [iblock=portfolio limit=3]/data/garden-projects.txt[/iblock]
</section>
<section class="gs-section gs-editorial">
    <p class="gs-kicker"><span></span> О студии</p>
    <div><h2>Начинаем с участка</h2><p>Смотрим, где держится тень, куда уходит вода и откуда открывается лучший вид. На этих наблюдениях строится план сада, выбор материалов и растений.</p><a class="gs-link" href="/about/">Как мы работаем <span aria-hidden="true">↗</span></a></div>
</section>
[garden-consult]
