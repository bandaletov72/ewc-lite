<?php http_response_code(404); exit; __halt_compiler();
{
  "form85": {
    "title": "Заявка на ландшафтный проект",
    "button": "Отправить заявку",
    "recipient": "",
    "fields": [
      {
        "name": "name",
        "label": "Имя",
        "type": "text",
        "required": true,
        "maxLength": 100
      },
      {
        "name": "email",
        "label": "Электронная почта",
        "type": "email",
        "required": true,
        "maxLength": 254
      },
      {
        "name": "phone",
        "label": "Телефон",
        "type": "tel",
        "required": false,
        "maxLength": 33
      },
      {
        "name": "topic",
        "label": "Что вас интересует",
        "type": "select",
        "required": true,
        "options": [
          "Ландшафтный проект",
          "Посадки и цветники",
          "Обновление сада",
          "Консультация"
        ]
      },
      {
        "name": "message",
        "label": "Расскажите об участке",
        "type": "textarea",
        "required": true,
        "maxLength": 1800
      }
    ]
  }
}
