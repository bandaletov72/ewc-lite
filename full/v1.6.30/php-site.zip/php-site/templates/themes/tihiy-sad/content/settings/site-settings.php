<?php http_response_code(404); exit; __halt_compiler();
{
  "name": "Тихий сад",
  "subtitle": "Ландшафтная студия",
  "description": "Проектирование частных садов. Планировка участка, посадки и сопровождение работ.",
  "footer": "© [year] Тихий сад",
  "searchMode": "compact",
  "scrollAnimation": "off"
}
