<?php http_response_code(404); exit; __halt_compiler();
{
  "garden-consult": {
    "description": "Приглашение обсудить ландшафтный проект",
    "value": "<section class=\"gs-callout\"><div><h2>Что растёт на вашем участке?</h2><p>Расскажите, где находится сад и как вы хотите проводить в нём время.</p></div><a class=\"gs-button\" href=\"/contacts/#request\">Обсудить проект <span aria-hidden=\"true\">↗</span></a></section>"
  }
}
