<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Проекты
Heading: Сады с разным характером
Description: Портфолио ландшафтной студии «Тихий сад». Частные сады, лесные участки и городские дворы.
Menu: Проекты
MenuVisible: 1
MobileMenu: 1
Order: 30

<p class="gs-lead">Три примера для разных условий: открытая поляна, тенистый березняк и небольшой городской двор.</p>
[iblock=portfolio]/data/garden-projects.txt[/iblock]
[garden-consult]
