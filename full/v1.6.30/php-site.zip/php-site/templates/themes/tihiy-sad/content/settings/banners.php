<?php http_response_code(404); exit; __halt_compiler();
{
  "garden-cover": {
    "folder": "",
    "order": [
      "s-garden"
    ],
    "slides": {
      "s-garden": {
        "image": "/templates/themes/tihiy-sad/images/garden.jpg",
        "color": "#485740"
      }
    }
  }
}
