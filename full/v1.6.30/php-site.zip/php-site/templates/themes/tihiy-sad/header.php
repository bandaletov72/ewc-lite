<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<div class="gs-header">
    <a class="gs-brand" href="<?= site_escape(site_url($base)) ?>">
        <?php $gardenLogo = site_brand_logo_html($brand, $base); ?>
        <?= $gardenLogo !== '' ? $gardenLogo : '<span class="gs-mark" aria-hidden="true"></span>' ?>
        <span><strong><?= site_escape($settings['name']) ?></strong><small><?= site_escape($settings['subtitle']) ?></small></span>
    </a>
    <div class="gs-desktop"><?= site_layout_placeholder('main-menu') ?></div>
    <a class="gs-header-action gs-button" href="<?= site_escape(site_url($base, 'contacts/#request')) ?>">Обсудить проект <span aria-hidden="true">↗</span></a>
</div>
