<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Контакты
Heading: Контакты
Description: Контактная информация.
Menu: Контакты
Order: 20

<p>Укажите здесь электронную почту, телефон или другие способы связи.</p>
