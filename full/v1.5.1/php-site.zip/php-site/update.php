<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
define('SITE_ROOT', __DIR__);
require __DIR__ . '/app/updater.php';

try {
    $action = $argv[1] ?? '';
    if ($action === '--github') {
        echo site_update_from_github(), PHP_EOL;
    } elseif ($action === '--build' && isset($argv[2]) && class_exists('ZipArchive')) {
        site_update_build($argv[2]);
        echo 'ZIP обновления создан.', PHP_EOL;
    } elseif ($action !== '' && substr($action, -4) === '.zip') {
        echo site_update_apply($action), PHP_EOL;
    } else {
        throw new RuntimeException('Использование: php update.php архив.zip | --github | --build архив.zip');
    }
} catch (RuntimeException $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
