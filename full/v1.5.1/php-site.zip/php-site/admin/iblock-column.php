<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$prefix = 'columns[' . $index . ']';
?>
<fieldset class="field-config form-stack" data-column-index="<?= $index ?>">
    <legend>Столбец</legend>
    <div class="fields column-fields">
        <label class="field">Название
            <input name="<?= $prefix ?>[label]" value="<?= site_escape($column['label']) ?>" data-column-label maxlength="375" required>
        </label>
        <label class="field">Ключ
            <input name="<?= $prefix ?>[key]" value="<?= site_escape($column['key']) ?>" maxlength="64" placeholder="phone" required>
        </label>
        <label class="field">Тип
            <select name="<?= $prefix ?>[type]" data-column-type>
                <?php foreach (site_iblock_types() as $type => $label): ?>
                    <option value="<?= $type ?>"<?= $column['type'] === $type ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>
    <div><button type="button" data-remove-column>Удалить столбец</button></div>
</fieldset>
