<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<section class="panel">
    <h1>CSS и JavaScript сайта</h1>
    <p class="hint">Этот код используется на всех страницах сайта. Код отдельной страницы подключается после общего.</p>
    <?php if ($assetsDraft !== null): ?>
        <form class="form-stack" method="post" action="<?= site_escape($assetsUrl) ?>">
            <input type="hidden" name="action" value="save-assets">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($assetsRevision) ?>">
            <?php admin_asset_editors($assetsDraft); ?>
            <div><button class="button-primary" type="submit">Сохранить</button></div>
        </form>
    <?php endif; ?>
</section>
