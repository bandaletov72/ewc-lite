<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="admin-heading">
    <h1>Инфоблоки</h1>
    <a class="button button-primary" href="<?= site_escape($iblocksUrl . '&new=1') ?>">Новый инфоблок</a>
</div>
<?php if ($iblockEditorError !== ''): ?>
    <p class="notice error" role="alert"><?= site_escape($iblockEditorError) ?></p>
<?php endif; ?>
<div class="editor-grid">
    <nav class="panel" aria-label="Список инфоблоков">
        <?php if (!$iblockNames): ?>
            <p data-iblock-empty>Инфоблоков пока нет.</p>
        <?php endif; ?>
            <ul class="page-list" data-iblock-list>
                <?php foreach ($iblockNames as $name): ?>
                    <li><a href="<?= site_escape($iblocksUrl . '&id=' . rawurlencode($name) . ($iblockTextMode ? '&text=1' : '')) ?>"<?= !$iblockIsNew && $iblockId === $name ? ' aria-current="page"' : '' ?>><?= site_escape($name) ?></a></li>
                <?php endforeach; ?>
            </ul>
    </nav>
    <?php if ($iblockDraft !== null): ?>
        <?php $blockUrl = $iblocksUrl . ($iblockIsNew ? '&new=1' : '&id=' . rawurlencode($iblockId)); ?>
        <form class="panel form-stack" method="post" data-iblock-editor data-iblock-new="<?= $iblockIsNew ? '1' : '0' ?>" <?= $iblockTextMode ? '' : 'data-iblock-config' ?> action="<?= site_escape($blockUrl . ($iblockTextMode ? '&text=1' : '')) ?>">
            <div class="header-actions">
                <h2 data-iblock-heading-title><?= $iblockIsNew ? 'Новый инфоблок' : 'Редактирование инфоблока' ?></h2>
                <a class="button" data-iblock-mode-link href="<?= site_escape($blockUrl . ($iblockTextMode ? '' : '&text=1')) ?>">
                    <?php if (!$iblockTextMode): ?><span aria-hidden="true">☰</span><?php endif; ?>
                    <?= $iblockTextMode ? 'Править как таблицу' : 'Править как текст' ?>
                </a>
            </div>
            <input type="hidden" name="action" value="<?= $iblockTextMode ? 'save-iblock-text' : 'save-iblock' ?>">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($iblockRevision) ?>">
            <div class="field">
                <label for="iblock-id">Имя инфоблока</label>
                <input id="iblock-id" name="id" value="<?= site_escape($iblockId) ?>" placeholder="myiblock" maxlength="64" <?= $iblockIsNew ? 'required' : 'readonly' ?>>
            </div>
            <p class="hint" data-iblock-shortcode<?= $iblockIsNew ? ' hidden' : '' ?>>Код для вставки <code>[iblock=table]/data/<?= site_escape($iblockId) ?>.txt[iblock]</code></p>
            <p class="notice" data-iblock-status role="status" hidden></p>
            <?php if ($iblockTextMode): ?>
                <div class="field">
                    <label for="iblock-csv">Содержимое CSV</label>
                    <small class="hint" id="csv-hint">Разделитель |. Первые три строки содержат ключи, названия и типы столбцов. Затем идут данные. Значения с |, кавычками или переносами заключайте в двойные кавычки, а кавычки внутри удваивайте.</small>
                    <textarea id="iblock-csv" name="csv" rows="16" spellcheck="false" aria-describedby="csv-hint"><?= "\n" . site_escape($iblockCsv) ?></textarea>
                </div>
                <div class="header-actions">
                    <button type="button" data-copy-iblock>Скопировать CSV</button>
                    <button class="button-primary" type="submit">Сохранить инфоблок</button>
                    <small class="hint" data-copy-status role="status"></small>
                </div>
            <?php else: ?>
            <h2>Столбцы</h2>
            <div class="form-stack" data-iblock-columns>
                <?php foreach ($iblockDraft['columns'] as $index => $column): ?>
                    <?php require __DIR__ . '/iblock-column.php'; ?>
                <?php endforeach; ?>
            </div>
            <template data-iblock-column-template>
                <?php
                $index = '__INDEX__';
                $column = ['key' => '', 'label' => '', 'type' => 'text'];
                require __DIR__ . '/iblock-column.php';
                ?>
            </template>
            <div><button type="button" data-add-column>Добавить столбец</button></div>
            <h2>Строки</h2>
            <div class="iblock-table-wrap">
                <table class="iblock-table iblock-editor-table">
                    <thead><tr data-iblock-heading>
                        <th scope="col">Порядок</th>
                        <?php foreach ($iblockDraft['columns'] as $index => $column): ?>
                            <th scope="col" data-cell-column="<?= $index ?>"><?= site_escape($column['label']) ?></th>
                        <?php endforeach; ?>
                        <th scope="col" data-iblock-actions>Действия</th>
                    </tr></thead>
                    <tbody data-iblock-rows>
                        <?php foreach ($iblockDraft['rows'] as $rowIndex => $row): ?>
                            <tr data-row-index="<?= $rowIndex ?>">
                                <td class="iblock-order"><button class="iblock-drag" type="button" draggable="true" data-drag-row aria-label="Переместить строку. Используйте стрелки вверх и вниз" title="Перетащить строку">⠿</button></td>
                                <?php foreach ($iblockDraft['columns'] as $index => $column): ?>
                                    <?php require __DIR__ . '/iblock-cell.php'; ?>
                                <?php endforeach; ?>
                                <td data-iblock-actions><button type="button" data-remove-row>Удалить строку</button></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <input type="hidden" name="complete" value="1">
            <div class="header-actions">
                <button type="button" data-add-row>Добавить строку</button>
                <button class="button-primary" type="submit">Сохранить инфоблок</button>
            </div>
            <?php endif; ?>
        </form>
    <?php endif; ?>
</div>
