<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_settings_revision(array $settings): string
{
    return hash('sha256', json_encode($settings));
}

function admin_variables_text(array $variables): string
{
    $lines = [];
    foreach ($variables as $name => $value) {
        if (is_string($value)) {
            $lines[] = '[' . $name . '] = ' . $value;
        }
    }
    return implode("\n", $lines);
}

function admin_save_settings(array $settings, string $variables, string $revision)
{
    if ($settings['name'] === '') {
        throw new RuntimeException('Укажите название сайта.');
    }
    foreach ($settings as $value) {
        if (strlen($value) > 1500 || preg_match('/[\x00-\x1F\x7F]/', $value) || preg_match('//u', $value) !== 1) {
            throw new RuntimeException('Проверьте длину и формат полей настроек.');
        }
    }

    $settings['footer'] = site_footer_pattern($settings['footer']);
    $settings['variables'] = [];
    foreach (preg_split('/\r\n|\n|\r/', $variables) as $line) {
        if (trim($line) === '') {
            continue;
        }
        $parts = array_map('trim', explode('=', $line, 2));
        $name = preg_replace('/\A\[([a-z][a-z0-9_]{0,63})\]\z/', '$1', $parts[0]);
        if (count($parts) !== 2 || preg_match('/\A[a-z][a-z0-9_]{0,63}\z/', $name) !== 1) {
            throw new RuntimeException('Запишите каждую переменную отдельной строкой в формате «[ключ] = значение».');
        }
        if (isset($settings['variables'][$name])) {
            throw new RuntimeException('Используйте каждое имя переменной один раз.');
        }
        if (strpos($parts[1], "\0") !== false) {
            throw new RuntimeException('Значение переменной содержит недопустимый символ.');
        }
        $settings['variables'][$name] = $parts[1];
    }

    $lock = admin_lock();
    try {
        site_read_record(SITE_SETTINGS_FILE);
        if (!hash_equals(admin_settings_revision(site_settings()), $revision)) {
            throw new RuntimeException('Настройки изменились. Скопируйте правки и откройте раздел заново.');
        }
        admin_write_record(SITE_SETTINGS_FILE, $settings);
    } finally {
        fclose($lock);
    }
}

function admin_snippet_revision(array $snippet): string
{
    return hash('sha256', json_encode($snippet));
}

function admin_update_snippet(string $host, string $name, array $snippet, string $revision, bool $delete)
{
    if (!site_valid_snippet($name)) {
        throw new RuntimeException('Укажите имя подшаблона строчными латинскими буквами. После первой буквы допустимы цифры, дефисы и подчёркивания.');
    }
    if (in_array($name, ['gal', 'fotos', 'files', 'include', 'iblock', 'callback'], true) || site_valid_form_id($name)) {
        throw new RuntimeException('Это имя используется компонентом сайта.');
    }
    if (!$delete && ($snippet['description'] === '' || strlen($snippet['description']) > 1500
            || preg_match('/[\x00-\x1F\x7F]/', $snippet['description']))) {
        throw new RuntimeException('Добавьте краткое описание подшаблона.');
    }
    if (strpos($snippet['value'], "\0") !== false || preg_match('//u', $snippet['value']) !== 1) {
        throw new RuntimeException('Используйте HTML в кодировке UTF-8.');
    }

    $lock = admin_lock();
    try {
        $snippets = site_read_snippets($host);
        $current = $snippets[$name] ?? null;
        if ($revision === '') {
            if ($current !== null || $delete) {
                throw new RuntimeException('Имя подшаблона уже используется или запись была изменена. Откройте её заново.');
            }
        } elseif (!is_array($current) || !hash_equals(admin_snippet_revision($current), $revision)) {
            throw new RuntimeException('Подшаблон изменился. Скопируйте правки и откройте его заново.');
        }

        if ($delete) {
            unset($snippets[$name]);
        } else {
            $snippets[$name] = $snippet;
        }
        ksort($snippets);
        admin_write_record(site_snippet_file($host), $snippets);
    } finally {
        fclose($lock);
    }
}

function admin_add_domain(string $name)
{
    $domain = site_normalize_domain($name);
    if ($domain === '' || strpos($domain, '.') === false || filter_var($domain, FILTER_VALIDATE_IP)) {
        throw new RuntimeException('Укажите полное имя поддомена, например msk.example.ru.');
    }

    $lock = admin_lock();
    try {
        $domains = site_read_record(SITE_DOMAINS_FILE);
        if (in_array($domain, $domains, true)) {
            throw new RuntimeException('Этот домен уже добавлен.');
        }
        $domains[] = $domain;
        sort($domains, SORT_STRING);
        admin_write_record(SITE_DOMAINS_FILE, $domains);
    } finally {
        fclose($lock);
    }
}

function admin_domain_template_labels(): array
{
    return ['header' => 'Шапка', 'mobile-menu' => 'Мобильное меню', 'menu' => 'Правое меню', 'footer' => 'Подвал'];
}

function admin_domain_template_draft(array $blocks): array
{
    $draft = [];
    foreach (admin_domain_template_labels() as $name => $label) {
        $block = isset($blocks[$name]) && is_array($blocks[$name]) ? $blocks[$name] : [];
        $draft[$name] = ['mode' => admin_input($block, 'mode'), 'value' => admin_input($block, 'value')];
    }
    return $draft;
}

function admin_save_domain_templates(string $host, array $draft, string $revision)
{
    foreach ($draft as $block) {
        if (!in_array($block['mode'], ['inherit', 'custom'], true)) {
            throw new RuntimeException('Выберите источник для каждого шаблона.');
        }
        if ($block['mode'] === 'custom'
            && (strpos($block['value'], "\0") !== false || preg_match('//u', $block['value']) !== 1)) {
            throw new RuntimeException('Сохраните HTML в кодировке UTF-8.');
        }
    }

    $lock = admin_lock();
    try {
        $snippets = site_read_snippets($host);
        if (!hash_equals(admin_settings_revision($snippets), $revision)) {
            throw new RuntimeException('Шаблоны уже изменились. Скопируйте правки и откройте раздел заново.');
        }
        foreach (admin_domain_template_labels() as $name => $label) {
            if ($draft[$name]['mode'] === 'inherit') {
                unset($snippets[$name]);
            } else {
                $snippets[$name] = [
                    'description' => $snippets[$name]['description'] ?? $label,
                    'value' => $draft[$name]['value'],
                ];
            }
        }
        ksort($snippets);
        admin_write_record(site_snippet_file($host), $snippets);
    } finally {
        fclose($lock);
    }
}
