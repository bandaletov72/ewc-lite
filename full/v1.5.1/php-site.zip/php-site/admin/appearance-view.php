<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($section === 'contacts'): ?>
    <h1>Контакты и соцсети</h1>
    <p class="hint">Код <code>[soc-icons]</code> вставляет иконки всех соцсетей, для которых указаны ссылки.</p>
    <form class="panel form-stack" method="post" action="<?= site_escape($contactsUrl) ?>" data-contacts-config>
        <input type="hidden" name="action" value="save-contacts">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <div class="field">
            <label for="contacts-heading">Заголовок блока <code>[contacts]</code></label>
            <input id="contacts-heading" name="heading" value="<?= site_escape($appearanceDraft['heading']) ?>" maxlength="375" placeholder="Связаться с нами">
        </div>
        <h2>Телефоны <code>[phones]</code></h2>
        <div class="form-stack" data-phone-rows>
            <?php foreach ($appearanceDraft['phones'] as $index => $phone): ?>
                <?php require __DIR__ . '/appearance-phone.php'; ?>
            <?php endforeach; ?>
        </div>
        <template data-phone-template>
            <?php
            $index = '__INDEX__';
            $phone = ['number' => '', 'text' => ''];
            require __DIR__ . '/appearance-phone.php';
            ?>
        </template>
        <div><button type="button" data-add-phone>Добавить телефон</button></div>
        <h2>Соцсети</h2>
        <p class="hint">Вставьте код нужной соцсети в HTML страницы. Если подпись пустая, рядом с иконкой появится название сервиса.</p>
        <?php foreach (site_channels() as $id => $name): ?>
            <?php $channel = $appearanceDraft['channels'][$id] ?? ['url' => '', 'text' => '']; ?>
            <fieldset class="field-config">
                <legend class="channel-label">
                    <img src="<?= site_escape(site_url($base, 'templates/icons/contact/' . $id . '.png')) ?>" width="22" height="22" alt="">
                    <?= site_escape($name) ?> <code>[<?= $id ?>]</code>
                </legend>
                <div class="fields">
                    <label class="field">Ссылка
                        <input type="url" name="channels[<?= $id ?>][url]" maxlength="2048" value="<?= site_escape($channel['url']) ?>" placeholder="https://">
                    </label>
                    <label class="field">Подпись ссылки
                        <input name="channels[<?= $id ?>][text]" maxlength="375" value="<?= site_escape($channel['text']) ?>" placeholder="Перейти на канал">
                    </label>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit">Сохранить контакты</button></div>
    </form>
<?php elseif ($section === 'theme'): ?>
    <h1>Тема и цвета</h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($themeUrl) ?>">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <div class="field">
            <label for="theme-mode">Режим оформления</label>
            <select id="theme-mode" name="mode">
                <?php foreach (['auto' => 'Автоматически — как в системе', 'light' => 'Светлый', 'dark' => 'Тёмный'] as $key => $label): ?>
                    <option value="<?= $key ?>"<?= $appearanceDraft['mode'] === $key ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="fields">
            <?php foreach (['light' => 'Светлая палитра', 'dark' => 'Тёмная палитра'] as $scheme => $label): ?>
                <fieldset class="field-config form-stack">
                    <legend><?= site_escape($label) ?></legend>
                    <?php foreach (site_theme_fields() as $key => $name): ?>
                        <label class="theme-color">
                            <?= site_escape($name) ?>
                            <input type="color" name="<?= $scheme ?>[<?= $key ?>]" value="<?= site_escape($appearanceDraft[$scheme][$key]) ?>">
                        </label>
                    <?php endforeach; ?>
                </fieldset>
            <?php endforeach; ?>
        </div>
        <div><button class="button-primary" type="submit" name="action" value="save-theme">Сохранить оформление</button></div>
        <fieldset class="field-config form-stack">
            <legend>Сохранить тему под названием</legend>
            <div class="field">
                <label for="theme-name">Название темы</label>
                <input id="theme-name" name="theme_name" value="<?= site_escape($themeName) ?>" maxlength="80" placeholder="Например, Весенняя">
                <small class="hint">Если оставить поле пустым, название подставится автоматически.</small>
            </div>
            <div><button type="submit" name="action" value="save-theme-preset">Сохранить в список</button></div>
        </fieldset>
    </form>
    <section class="panel form-stack theme-presets">
        <h2>Сохранённые темы</h2>
        <?php if (!$themeState['presets']): ?>
            <p class="hint">Сохранённых тем пока нет.</p>
        <?php else: ?>
            <?php if ($themeState['default'] !== ''): ?>
                <form method="post" action="<?= site_escape($themeUrl) ?>">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($themeState)) ?>">
                    <button type="submit" name="action" value="restore-default-theme">Вернуть тему по умолчанию</button>
                </form>
            <?php endif; ?>
            <ul class="theme-preset-list">
                <?php foreach ($themeState['presets'] as $id => $preset): ?>
                    <li class="theme-preset">
                        <div>
                            <strong><?= site_escape($preset['name']) ?></strong>
                            <?php if ($themeState['default'] === $id): ?>
                                <small class="hint theme-default-label">По умолчанию</small>
                            <?php endif; ?>
                        </div>
                        <form class="header-actions" method="post" action="<?= site_escape($themeUrl) ?>" data-theme-presets>
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($themeState)) ?>">
                            <input type="hidden" name="preset" value="<?= site_escape($id) ?>">
                            <button type="submit" name="action" value="apply-theme-preset">Применить</button>
                            <?php if ($themeState['default'] !== $id): ?>
                                <button type="submit" name="action" value="default-theme-preset">Использовать по умолчанию</button>
                            <?php endif; ?>
                            <button class="button-danger" type="submit" name="action" value="delete-theme-preset">Удалить</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>
<?php else: ?>
    <h1>Настройки компонентов</h1>
    <form class="panel form-stack" method="post" action="<?= site_escape($componentsUrl) ?>">
        <input type="hidden" name="action" value="save-components">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($appearanceRevision) ?>">
        <?php foreach (site_component_schema() as $id => $component): ?>
            <fieldset class="field-config"<?= isset($component['examplePath']) ? ' data-component-code="' . site_escape($id) . '"' : '' ?>>
                <legend><?= site_escape($component['label']) ?></legend>
                <div class="fields">
                    <?php foreach ($component['settings'] as $key => $field): ?>
                        <label class="field">
                            <?= site_escape($field['label']) ?>
                            <select name="<?= site_escape($id . '[' . $key . ']') ?>" data-component-param="<?= site_escape($key) ?>">
                                <?php foreach ($field['options'] as $value => $label): ?>
                                    <option value="<?= site_escape((string) $value) ?>"<?= $appearanceDraft[$id][$key] === (string) $value ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php if (isset($component['examplePath'])): ?>
                    <?php
                    $example = '[' . $id;
                    foreach ($component['settings'] as $key => $field) {
                        $value = $appearanceDraft[$id][$key];
                        $example .= ' ' . $key . '=' . (isset($field['options'][$value]) ? $value : $field['default']);
                    }
                    $example .= ']' . $component['examplePath'] . '[/' . $id . ']';
                    ?>
                    <p class="component-example">
                        Пример вставки
                        <code data-component-example="<?= site_escape($component['examplePath']) ?>"><?= site_escape($example) ?></code>
                    </p>
                <?php endif; ?>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit">Сохранить настройки компонентов</button></div>
    </form>
<?php endif; ?>
