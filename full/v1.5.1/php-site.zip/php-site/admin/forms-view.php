<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="admin-heading">
    <h1>Формы</h1>
    <a class="button button-primary" href="<?= site_escape($formsUrl . '&id=new') ?>">Новая форма</a>
</div>
<?php if ($formEditorError !== ''): ?>
    <p class="notice error" role="alert"><?= site_escape($formEditorError) ?></p>
<?php endif; ?>
<div class="editor-grid">
    <nav class="panel" aria-label="Список форм">
        <ul class="page-list">
            <?php foreach ($forms as $id => $item): ?>
                <li><a href="<?= site_escape($formsUrl . '&id=' . rawurlencode($id)) ?>"<?= isset($formId) && $formId === $id && !$formIsNew ? ' aria-current="page"' : '' ?>>
                    <code>[<?= site_escape($id) ?>]</code><small><?= site_escape($item['button']) ?></small>
                </a></li>
            <?php endforeach; ?>
        </ul>
    </nav>
    <?php if ($formDraft !== null): ?>
        <form class="panel form-stack" method="post" data-form-config action="<?= site_escape($formsUrl . '&id=' . rawurlencode($formIsNew ? 'new' : $formId)) ?>">
            <h2><?= $formIsNew ? 'Новая форма' : 'Редактировать форму' ?></h2>
            <input type="hidden" name="action" value="save-form">
            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
            <input type="hidden" name="revision" value="<?= site_escape($formRevision) ?>">
            <div class="fields">
                <div class="field">
                    <label for="form-code">Код формы</label>
                    <input id="form-code" name="id" value="<?= site_escape($formId) ?>" maxlength="13" <?= $formIsNew ? 'required' : 'readonly' ?>>
                </div>
                <div class="field">
                    <label for="form-button">Текст кнопки</label>
                    <input id="form-button" name="button" value="<?= site_escape($formDraft['button']) ?>" maxlength="375" required>
                </div>
                <div class="field field-wide">
                    <label for="form-recipient">Email получателя</label>
                    <input id="form-recipient" name="recipient" type="email" value="<?= site_escape($formDraft['recipient']) ?>" maxlength="254" aria-describedby="recipient-hint">
                    <small class="hint" id="recipient-hint">Каждая заявка сохраняется в «Сообщениях». Если указан email, PHP отправит уведомление через почту сервера.</small>
                </div>
            </div>
            <div class="form-stack" data-form-rows>
                <?php foreach ($formDraft['fields'] as $index => $field): ?>
                    <?php require __DIR__ . '/form-field.php'; ?>
                <?php endforeach; ?>
            </div>
            <template data-empty-field>
                <?php
                $index = '__INDEX__';
                $field = ['name' => '', 'label' => '', 'type' => 'text', 'required' => false, 'options' => []];
                require __DIR__ . '/form-field.php';
                ?>
            </template>
            <div class="header-actions">
                <button type="button" data-add-field>Добавить поле</button>
                <button class="button-primary" type="submit">Сохранить форму</button>
            </div>
        </form>
    <?php endif; ?>
</div>
