<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';
require __DIR__ . '/files.php';
require __DIR__ . '/access.php';

try {
    echo admin_make_setup_code(), PHP_EOL;
} catch (RuntimeException $exception) {
    fwrite(STDERR, $exception->getMessage() . PHP_EOL);
    exit(1);
}
