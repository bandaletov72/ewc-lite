<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';
require __DIR__ . '/files.php';
require __DIR__ . '/access.php';
require __DIR__ . '/config.php';
require __DIR__ . '/form-config.php';
require __DIR__ . '/iblock-config.php';
require __DIR__ . '/appearance-config.php';
require __DIR__ . '/branding.php';
require __DIR__ . '/callback-config.php';
require __DIR__ . '/save.php';
require __DIR__ . '/page-tree.php';
require SITE_ROOT . '/app/updater.php';

function admin_input(array $values, string $key): string
{
    return isset($values[$key]) && is_string($values[$key]) ? $values[$key] : '';
}

function admin_json(int $status, array $result)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok' => $status === 200] + $result, JSON_UNESCAPED_UNICODE);
    exit;
}

$base = site_base('admin/index.php');
$adminUrl = site_url($base, 'admin/');
$settingsUrl = $adminUrl . '?settings=1';
$contactsUrl = $adminUrl . '?contacts=1';
$themeUrl = $adminUrl . '?theme=1';
$componentsUrl = $adminUrl . '?components=1';
$updatesUrl = $adminUrl . '?updates=1';
$snippetsUrl = $adminUrl . '?snippets=1';
$domainsUrl = $adminUrl . '?domains=1';
$formsUrl = $adminUrl . '?forms=1';
$spamUrl = $adminUrl . '?spam=1';
$messagesUrl = $adminUrl . '?messages=1';
$callbacksUrl = $adminUrl . '?callbacks=1';
$iblocksUrl = $adminUrl . '?iblocks=1';
$helpUrl = $adminUrl . '?help=1';
$assetsUrl = $adminUrl . '?assets=1';
$section = 'pages';
foreach (['settings', 'contacts', 'theme', 'components', 'updates', 'snippets', 'domains', 'forms', 'spam', 'messages', 'callbacks', 'iblocks', 'help', 'assets'] as $name) {
    if (admin_input($_GET, $name) === '1') {
        $section = $name;
        break;
    }
}
$siteSettings = site_settings();
$settingsDraft = $siteSettings;
$settingsRevision = admin_settings_revision($siteSettings);
$variablesDraft = admin_variables_text($siteSettings['variables']);
$appearanceDraft = null;
$assetsDraft = null;
$pageAssets = null;
$callbackDraft = null;
$error = '';
$accessError = '';
$page = null;
$creating = admin_input($_GET, 'new') === '1';
$pageOperation = admin_input($_GET, 'confirm');
$loggedIn = false;
$username = '';
$auth = null;

try {
    $auth = admin_auth_state();
} catch (RuntimeException $exception) {
    $accessError = $exception->getMessage();
}
$configured = isset($auth['password']);
$localSetup = admin_local_setup() && !isset($auth['setup']);
$needsCode = !$localSetup;
$setupAvailable = $auth !== null && ($localSetup || isset($auth['setup']));
$currentHost = site_host();
$domains = [];
$domainsError = '';
$domainDraft = '';
$layoutSelection = admin_input($_GET, 'templates');
$layoutHost = $layoutSelection === 'current' ? $currentHost : site_normalize_domain($layoutSelection);
$layoutUrl = $domainsUrl . '&templates=' . rawurlencode($layoutSelection);
$layoutDraft = null;
$snippet = null;
$snippetError = '';
$snippetEntries = [];
$formDraft = null;
$formEditorError = '';
$spamDraft = null;
$spamEditorError = '';
$formSelection = admin_input($_GET, 'id');
$iblockDraft = null;
$iblockEditorError = '';
$iblockIsNew = admin_input($_GET, 'new') === '1';
$iblockTextMode = admin_input($_GET, 'text') === '1';
$iblockCsv = null;
$domainSelection = admin_input($_GET, 'domain');
$sharedScope = admin_input($_GET, 'scope') === 'shared';
$scopeHost = $sharedScope ? '' : ($domainSelection !== '' ? site_normalize_domain($domainSelection) : $currentHost);
$scopeUrl = $snippetsUrl;
if ($sharedScope) {
    $scopeUrl .= '&scope=shared';
} elseif ($domainSelection !== '') {
    $scopeUrl .= '&domain=' . rawurlencode($domainSelection);
}

header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; style-src 'self'; img-src 'self'; script-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");

if ($auth !== null) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('FILE_SITE_ADMIN');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params(0, $adminUrl, '', $secure, true);
    if (!session_start()) {
        http_response_code(503);
        exit('Не удалось открыть сессию. Проверьте настройки PHP.');
    }

    $loggedIn = $configured && isset($_SESSION['auth']) && hash_equals(admin_auth_key($auth), $_SESSION['auth']);
    if (!isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    $token = $_SESSION['csrf'];

    if ($loggedIn && ($section === 'domains' || $section === 'snippets')) {
        try {
            $domains = site_read_record(SITE_DOMAINS_FILE);
        } catch (RuntimeException $exception) {
            $domainsError = $exception->getMessage();
        }
    }
    $scopeValid = $sharedScope || ($scopeHost !== ''
        && ($domainSelection === '' || in_array($scopeHost, $domains, true)));
    $layoutValid = $domainsError === '' && ($layoutSelection === 'shared'
        || ($layoutHost !== '' && ($layoutSelection === 'current' || in_array($layoutHost, $domains, true))));
    if ($layoutSelection === 'shared') {
        $layoutHost = '';
    }

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $action = admin_input($_POST, 'action');
        $iblockAjax = $section === 'iblocks' && in_array($action, ['save-iblock', 'save-iblock-text'], true)
            && admin_input($_POST, 'ajax') === '1';
        $pagesAjax = $section === 'pages' && in_array($action, ['page-menu', 'page-order', 'page-move', 'change-page-status'], true)
            && admin_input($_POST, 'ajax') === '1';
        if (($iblockAjax || $pagesAjax) && !$loggedIn) {
            admin_json(403, ['message' => 'Войдите в админку заново.']);
        }
        if (!hash_equals($token, admin_input($_POST, 'csrf'))) {
            if ($iblockAjax || $pagesAjax) {
                admin_json(403, ['message' => 'Сессия формы истекла. Обновите страницу.']);
            }
            http_response_code(403);
            $error = 'Сессия формы истекла. Обновите страницу и повторите действие.';
        } elseif ($action === 'setup' && !$configured && $setupAvailable) {
            $username = trim(admin_input($_POST, 'username'));
            try {
                $auth = admin_install($username, admin_input($_POST, 'password'),
                    admin_input($_POST, 'confirmation'), admin_input($_POST, 'setup_code'), $localSetup);
                admin_sign_in($auth, $adminUrl);
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'login' && $configured && !$loggedIn) {
            $username = trim(admin_input($_POST, 'username'));
            $password = admin_input($_POST, 'password');
            if ($password !== '' && password_verify($password, $auth['password']) && hash_equals($auth['user'], $username)) {
                admin_sign_in($auth, $adminUrl);
            }
            usleep(300000);
            $error = 'Неверный логин или пароль.';
        } elseif ($action === 'logout' && $loggedIn) {
            $_SESSION = [];
            session_regenerate_id(true);
            header('Location: ' . $adminUrl, true, 303);
            exit;
        } elseif ($pagesAjax) {
            admin_pages_ajax($action, $_POST, $base, $adminUrl);
        } elseif ($action === 'save' && $loggedIn && $section === 'pages') {
            $creating = admin_input($_POST, 'new') === '1';
            $enteredPath = trim(admin_input($_POST, 'path'));
            $path = admin_page_path($enteredPath);
            $fields = [];
            foreach (site_page_fields() as $name) {
                $fields[$name] = trim(admin_input($_POST, $name), ' ');
            }
            if (admin_input($_POST, 'menu_visibility') === '1') {
                $fields['MenuVisible'] = admin_input($_POST, 'MenuVisible') === '1' ? '1' : '0';
            }
            $html = admin_input($_POST, 'html');
            $revision = admin_input($_POST, 'revision');
            $page = ['path' => $path, 'fields' => $fields, 'html' => $html, 'revision' => $revision];

            try {
                if (is_array($_POST['assets'] ?? null)) {
                    $pageAssets = ['CSS' => admin_input($_POST['assets'], 'CSS'), 'JS' => admin_input($_POST['assets'], 'JS')];
                    foreach ($pageAssets as $kind => $code) {
                        $fields[$kind] = admin_encode_asset($code);
                    }
                }
                admin_save_page($path, $fields, $html, $revision, $creating);
                $_SESSION['notice'] = 'Страница сохранена.';
                header('Location: ' . $adminUrl . '?' . http_build_query(['page' => site_page_url('', $path)]), true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
                if ($creating) {
                    $page['path'] = $enteredPath;
                }
            }
        } elseif ($action === 'page-move' && $loggedIn && $section === 'pages') {
            try {
                $path = admin_move_page(admin_input($_POST, 'path'), admin_input($_POST, 'revision'), admin_input($_POST, 'folder'));
                $_SESSION['notice'] = 'Страница перемещена.';
                header('Location: ' . admin_page_edit_url($adminUrl, $path), true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'change-page-status' && $loggedIn && $section === 'pages') {
            $path = admin_page_path(trim(admin_input($_POST, 'path')));
            $operation = admin_input($_POST, 'operation');
            try {
                $_SESSION['notice'] = admin_update_page_status($path, admin_input($_POST, 'revision'), $operation);
                $destination = $operation === 'delete' ? $adminUrl : $adminUrl . '?' . http_build_query(['page' => site_page_url('', $path)]);
                header('Location: ' . $destination, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'save-assets' && $loggedIn && $section === 'assets') {
            $values = is_array($_POST['assets'] ?? null) ? $_POST['assets'] : [];
            $assetsDraft = ['CSS' => admin_input($values, 'CSS'), 'JS' => admin_input($values, 'JS')];
            $assetsRevision = admin_input($_POST, 'revision');
            try {
                admin_save_global_assets($assetsDraft, $assetsRevision);
                $_SESSION['notice'] = 'Стили и скрипты сохранены.';
                header('Location: ' . $assetsUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'save-settings' && $loggedIn && $section === 'settings') {
            foreach (['name', 'description', 'footer'] as $name) {
                $settingsDraft[$name] = trim(admin_input($_POST, $name));
            }
            $variablesDraft = admin_input($_POST, 'variables');
            $settingsRevision = admin_input($_POST, 'revision');
            try {
                $fields = array_intersect_key($settingsDraft, ['name' => true, 'description' => true, 'footer' => true]);
                admin_save_settings($fields, $variablesDraft, $settingsRevision);
                $_SESSION['notice'] = 'Настройки сохранены.';
                header('Location: ' . $settingsUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($loggedIn && $section === 'settings' && in_array($action, ['save-brand', 'generate-favicon'], true)) {
            try {
                admin_save_brand($_FILES, $action === 'generate-favicon', admin_input($_POST, 'revision'));
                $_SESSION['notice'] = $action === 'generate-favicon' ? 'Favicon создан и применён.' : 'Изображения сохранены.';
                header('Location: ' . $settingsUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($loggedIn && $section === 'theme' && in_array($action, [
            'save-theme', 'save-theme-preset', 'apply-theme-preset', 'default-theme-preset',
            'delete-theme-preset', 'restore-default-theme',
        ], true)) {
            $appearanceRevision = admin_input($_POST, 'revision');
            $themeName = trim(admin_input($_POST, 'theme_name'));
            if ($action === 'save-theme' || $action === 'save-theme-preset') {
                $appearanceDraft = admin_theme_draft($_POST);
            }
            try {
                $_SESSION['notice'] = admin_update_theme(
                    $action, $appearanceDraft ?? [], $themeName, admin_input($_POST, 'preset'), $appearanceRevision
                );
                header('Location: ' . $themeUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($loggedIn && (($action === 'save-contacts' && $section === 'contacts')
            || ($action === 'save-components' && $section === 'components'))) {
            $appearanceRevision = admin_input($_POST, 'revision');
            try {
                if ($section === 'contacts') {
                    $appearanceDraft = admin_contacts_draft($_POST);
                    admin_save_contacts($appearanceDraft, $appearanceRevision);
                    $redirect = $contactsUrl;
                } else {
                    $appearanceDraft = admin_components_draft($_POST);
                    admin_save_components($appearanceDraft, $appearanceRevision);
                    $redirect = $componentsUrl;
                }
                $_SESSION['notice'] = 'Настройки сохранены.';
                header('Location: ' . $redirect, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($loggedIn && $section === 'callbacks' && in_array($action, ['save-callback-settings', 'send-callback'], true)) {
            try {
                if ($action === 'save-callback-settings') {
                    $callbackDraft = admin_callback_draft($_POST);
                    $callbackRevision = admin_input($_POST, 'revision');
                    admin_save_callback_settings($callbackDraft, $callbackRevision);
                    $_SESSION['notice'] = 'Настройки обратного звонка сохранены.';
                } else {
                    site_callback_dispatch(admin_input($_POST, 'callback_id'), site_callback_settings());
                    $_SESSION['notice'] = 'Заявка передана в телефонию.';
                }
                header('Location: ' . $callbacksUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'update-engine' && $loggedIn && $section === 'updates') {
            try {
                @set_time_limit(90);
                $_SESSION['notice'] = site_update_from_github();
                header('Location: ' . $updatesUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'save-domain-templates' && $loggedIn && $section === 'domains' && $layoutValid) {
            $layoutDraft = admin_domain_template_draft(is_array($_POST['blocks'] ?? null) ? $_POST['blocks'] : []);
            $layoutRevision = admin_input($_POST, 'revision');
            try {
                admin_save_domain_templates($layoutHost, $layoutDraft, $layoutRevision);
                $_SESSION['notice'] = 'Шаблоны сохранены.';
                header('Location: ' . $layoutUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'add-domain' && $loggedIn && $section === 'domains') {
            $domainDraft = trim(admin_input($_POST, 'domain'));
            try {
                admin_add_domain($domainDraft);
                $_SESSION['notice'] = 'Домен добавлен.';
                header('Location: ' . $domainsUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'save-form' && $loggedIn && $section === 'forms') {
            $formId = trim(admin_input($_POST, 'id'));
            $formRevision = admin_input($_POST, 'revision');
            $formDraft = admin_form_draft($_POST);
            try {
                admin_store_form($formId, $formDraft, $formRevision);
                $_SESSION['notice'] = 'Форма сохранена.';
                header('Location: ' . $formsUrl . '&id=' . rawurlencode($formId), true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif ($action === 'save-spam' && $loggedIn && $section === 'spam') {
            $spamDraft = ['words' => admin_input($_POST, 'words'), 'ips' => admin_input($_POST, 'ips')];
            $spamRevision = admin_input($_POST, 'revision');
            try {
                admin_save_spam($spamDraft['words'], $spamDraft['ips'], $spamRevision);
                $_SESSION['notice'] = 'Правила сохранены.';
                header('Location: ' . $spamUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        } elseif (in_array($action, ['save-iblock', 'save-iblock-text'], true) && $loggedIn && $section === 'iblocks') {
            $iblockId = trim(admin_input($_POST, 'id'));
            $iblockRevision = admin_input($_POST, 'revision');
            $iblockTextMode = $action === 'save-iblock-text';
            $iblockDraft = $iblockTextMode ? ['columns' => [], 'rows' => []] : admin_iblock_draft($_POST);
            if ($iblockTextMode) {
                $iblockCsv = admin_input($_POST, 'csv');
            }
            try {
                if ($iblockTextMode) {
                    $iblockDraft = site_iblock_from_csv($iblockCsv);
                } elseif (admin_input($_POST, 'complete') !== '1') {
                    throw new RuntimeException('Получены не все значения. Проверьте лимит max_input_vars в PHP перед сохранением.');
                }
                $savedRevision = admin_save_iblock($iblockId, $iblockDraft, $iblockRevision);
                $blockUrl = $iblocksUrl . '&id=' . rawurlencode($iblockId);
                if ($iblockAjax) {
                    admin_json(200, ['message' => 'Инфоблок сохранён.', 'id' => $iblockId, 'revision' => $savedRevision,
                        'url' => $blockUrl . ($iblockTextMode ? '&text=1' : ''),
                        'modeUrl' => $blockUrl . ($iblockTextMode ? '' : '&text=1'),
                        'shortcode' => '[iblock=table]/data/' . $iblockId . '.txt[iblock]']);
                }
                $_SESSION['notice'] = 'Инфоблок сохранён.';
                header('Location: ' . $blockUrl . ($iblockTextMode ? '&text=1' : ''), true, 303);
                exit;
            } catch (RuntimeException $exception) {
                if ($iblockAjax) {
                    admin_json(422, ['message' => $exception->getMessage()]);
                }
                $error = $exception->getMessage();
            }
        } elseif (in_array($action, ['save-snippet', 'delete-snippet'], true)
            && $loggedIn && $section === 'snippets' && $scopeValid) {
            $snippetName = trim(admin_input($_POST, 'snippet'));
            if (preg_match('/\A\[(.*)\]\z/', $snippetName, $match)) {
                $snippetName = $match[1];
            }
            $revision = admin_input($_POST, 'revision');
            $values = [
                'description' => trim(admin_input($_POST, 'description')),
                'value' => admin_input($_POST, 'value'),
            ];
            $lockedName = admin_input($_POST, 'locked') === '1';
            $snippet = ['name' => $snippetName, 'values' => $values, 'revision' => $revision, 'locked' => $lockedName];
            $deleting = $action === 'delete-snippet';
            try {
                admin_update_snippet($scopeHost, $snippetName, $values, $revision, $deleting);
                $_SESSION['notice'] = $deleting ? 'Значение удалено.' : 'Подшаблон сохранён.';
                $redirect = $deleting ? $scopeUrl : $scopeUrl . '&snippet=' . rawurlencode($snippetName);
                header('Location: ' . $redirect, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        }
    }
} else {
    http_response_code(503);
}

if ($loggedIn) {
    $notice = $_SESSION['notice'] ?? '';
    unset($_SESSION['notice']);
    session_write_close();
    if ($section === 'theme') {
        $themeState = site_theme_state();
        $themeName = $themeName ?? '';
        if ($appearanceDraft === null) {
            $appearanceDraft = $themeState['theme'];
            $appearanceRevision = admin_settings_revision($themeState);
        }
    } elseif ($appearanceDraft === null && in_array($section, ['contacts', 'components'], true)) {
        $appearanceDraft = $section === 'contacts' ? site_contact_settings() : site_component_settings();
        $appearanceRevision = admin_settings_revision($appearanceDraft);
    }
    if ($section === 'pages') {
        $tree = site_page_tree(site_pages());
    }
    if ($section === 'assets' && $assetsDraft === null) {
        try {
            $encodedAssets = site_global_assets();
            $assetsRevision = admin_settings_revision($encodedAssets);
            $assetsDraft = array_map('site_asset_decode', $encodedAssets);
        } catch (RuntimeException $exception) {
            $error = $exception->getMessage();
        }
    }
    if ($section === 'pages' && $page === null) {
        if ($creating) {
            $page = [
                'path' => '',
                'fields' => ['Title' => '', 'Heading' => '', 'Description' => '', 'Menu' => '', 'Order' => '100', 'Hidden' => '0'],
                'html' => '',
                'revision' => '',
            ];
        } else {
            $path = admin_page_path(admin_input($_GET, 'page'));
            $page = site_read_page($path === '' ? 'index.php' : $path);
            if ($page === null && $error === '') {
                http_response_code(404);
                $error = 'Страница не найдена.';
            }
        }
    }
    if ($section === 'domains' && $layoutSelection !== '') {
        if (!$layoutValid) {
            http_response_code(404);
            $layoutError = 'Выберите домен из списка.';
        } else {
            try {
                $ownLayouts = site_read_snippets($layoutHost);
                $sharedLayouts = $layoutHost === '' ? [] : site_read_snippets();
                if ($layoutDraft === null) {
                    $layoutDraft = [];
                    $layoutRevision = admin_settings_revision($ownLayouts);
                    foreach (admin_domain_template_labels() as $name => $label) {
                        $layoutDraft[$name] = [
                            'mode' => isset($ownLayouts[$name]) ? 'custom' : 'inherit',
                            'value' => $ownLayouts[$name]['value'] ?? $sharedLayouts[$name]['value'] ?? '',
                        ];
                    }
                }
            } catch (RuntimeException $exception) {
                $layoutError = $exception->getMessage();
            }
        }
    }
    if ($section === 'snippets') {
        if (!$scopeValid) {
            http_response_code(404);
            $snippetError = 'Выберите домен из списка или откройте общие значения.';
        } else {
            try {
                $shared = site_read_snippets();
                $own = $sharedScope ? $shared : site_read_snippets($scopeHost);
                $snippetEntries = array_replace($shared, $own);
                ksort($snippetEntries, SORT_STRING);
                $selected = admin_input($_GET, 'snippet');
                if ($snippet === null && $selected !== '') {
                    if (site_valid_snippet($selected) && isset($snippetEntries[$selected])) {
                        $snippet = [
                            'name' => $selected,
                            'values' => $snippetEntries[$selected],
                            'revision' => isset($own[$selected]) ? admin_snippet_revision($own[$selected]) : '',
                            'locked' => true,
                        ];
                    } else {
                        http_response_code(404);
                        $snippetError = 'Подшаблон не найден.';
                    }
                }
            } catch (RuntimeException $exception) {
                $snippetError = $exception->getMessage();
            }
        }
    }
    if ($section === 'forms') {
        try {
            $forms = site_forms();
            $formIsNew = $formSelection === 'new';
            if ($formDraft === null) {
                if ($formIsNew) {
                    for ($number = 2; isset($forms['form' . $number]); $number++) {
                        // Use the first free shortcode.
                    }
                    $formId = 'form' . $number;
                    $formRevision = '';
                    $formDraft = ['button' => 'Отправить', 'recipient' => '', 'fields' => [
                        ['name' => '', 'label' => '', 'type' => 'text', 'required' => false, 'options' => []],
                    ]];
                } else {
                    $formId = $formSelection === '' ? 'form1' : $formSelection;
                    if (!isset($forms[$formId])) {
                        http_response_code(404);
                        $formEditorError = 'Форма не найдена.';
                    } else {
                        $formDraft = $forms[$formId];
                        $formRevision = admin_settings_revision($formDraft);
                    }
                }
            }
        } catch (RuntimeException $exception) {
            $forms = [];
            $formEditorError = $exception->getMessage();
        }
    }
    if ($section === 'spam' && $spamDraft === null) {
        try {
            $rules = site_spam_rules();
            $spamDraft = ['words' => implode("\n", $rules['words']), 'ips' => implode("\n", $rules['ips'])];
            $spamRevision = admin_settings_revision($rules);
        } catch (RuntimeException $exception) {
            $spamEditorError = $exception->getMessage();
        }
    }
    if ($section === 'messages') {
        $messageIds = [];
        foreach (glob(SITE_INBOX . '/*.php') ?: [] as $file) {
            $id = basename($file, '.php');
            if (preg_match('/\A[0-9]{14}-[a-f0-9]{16}\z/', $id)) {
                $messageIds[] = $id;
            }
        }
        rsort($messageIds, SORT_STRING);
        $messageId = admin_input($_GET, 'message');
        $messageId = $messageId === '' ? ($messageIds[0] ?? '') : $messageId;
        $message = [];
        if ($messageId !== '' && in_array($messageId, $messageIds, true)) {
            try {
                $message = site_read_record(SITE_INBOX . '/' . $messageId . '.php');
            } catch (RuntimeException $exception) {
                $error = $exception->getMessage();
            }
        }
    }
    if ($section === 'callbacks') {
        $callbackRecords = [];
        $callbackConfig = null;
        try {
            $callbackConfig = site_callback_settings();
            if ($callbackDraft === null) {
                $callbackDraft = $callbackConfig;
                $callbackRevision = admin_settings_revision($callbackDraft);
            }
            foreach (site_callback_ids() as $callbackId) {
                $record = site_callback_read($callbackId);
                if ($record) {
                    $callbackRecords[$callbackId] = $record;
                }
            }
        } catch (RuntimeException $exception) {
            $error = $exception->getMessage();
        }
    }
    if ($section === 'iblocks') {
        $iblockNames = admin_iblock_names();
        if ($iblockDraft === null) {
            $iblockId = admin_input($_GET, 'id');
            if ($iblockIsNew || ($iblockId === '' && !$iblockNames)) {
                $iblockIsNew = true;
                $iblockDraft = ['columns' => [['key' => 'name', 'label' => 'Название', 'type' => 'text']], 'rows' => []];
                $iblockRevision = '';
            } else {
                $iblockId = $iblockId !== '' ? $iblockId : $iblockNames[0];
                try {
                    $record = site_read_iblock($iblockId);
                    if (!isset($record['columns'], $record['rows'])) {
                        http_response_code(404);
                        $iblockEditorError = 'Инфоблок не найден.';
                    } else {
                        $iblockDraft = $record;
                        $iblockRevision = admin_settings_revision($record);
                    }
                } catch (RuntimeException $exception) {
                    $iblockEditorError = $exception->getMessage();
                }
            }
        }
        if ($iblockTextMode && $iblockDraft !== null && $iblockCsv === null) {
            $iblockCsv = site_iblock_csv($iblockDraft);
        }
    }
}

require __DIR__ . '/view.php';
