<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<h1>Сообщения</h1>
<?php if (!$messageIds): ?>
    <p class="panel">Сообщений пока нет.</p>
<?php else: ?>
    <div class="editor-grid">
        <nav class="panel" aria-label="Полученные сообщения">
            <ul class="page-list">
                <?php foreach ($messageIds as $id): ?>
                    <?php $date = substr($id, 6, 2) . '.' . substr($id, 4, 2) . '.' . substr($id, 0, 4) . ' ' . substr($id, 8, 2) . ':' . substr($id, 10, 2) . ':' . substr($id, 12, 2); ?>
                    <li><a href="<?= site_escape($messagesUrl . '&message=' . $id) ?>"<?= $messageId === $id ? ' aria-current="page"' : '' ?>><?= site_escape($date . ' UTC') ?></a></li>
                <?php endforeach; ?>
            </ul>
        </nav>
        <?php if ($message): ?>
            <article class="panel">
                <h2>Сообщение из [<?= site_escape($message['form']) ?>]</h2>
                <p class="hint"><?= site_escape($message['host'] . ' / ' . $message['page']) ?></p>
                <dl class="message-fields">
                    <?php foreach ($message['fields'] as $field): ?>
                        <dt><?= site_escape($field['label']) ?></dt>
                        <dd><?= $field['value'] === '' ? '—' : site_escape($field['value']) ?></dd>
                    <?php endforeach; ?>
                </dl>
            </article>
        <?php endif; ?>
    </div>
<?php endif; ?>
