<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$prefix = 'phones[' . $index . ']';
?>
<fieldset class="field-config form-stack" data-phone-row>
    <legend>Телефон</legend>
    <div class="fields">
        <label class="field">Номер
            <input type="tel" name="<?= $prefix ?>[number]" maxlength="33" value="<?= site_escape($phone['number']) ?>" placeholder="+7(903)123-45-67">
        </label>
        <label class="field">Подпись ссылки
            <input name="<?= $prefix ?>[text]" maxlength="375" value="<?= site_escape($phone['text']) ?>" placeholder="Позвонить">
        </label>
    </div>
    <div><button type="button" data-remove-phone>Удалить телефон</button></div>
</fieldset>
