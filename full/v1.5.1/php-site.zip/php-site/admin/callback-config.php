<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_callback_draft(array $posted): array
{
    $settings = [];
    foreach (['button', 'submit', 'mode', 'provider', 'from'] as $field) {
        $settings[$field] = trim(admin_input($posted, $field));
    }
    return $settings;
}

function admin_save_callback_settings(array $settings, string $revision)
{
    if (!admin_valid_form_label($settings['button']) || !admin_valid_form_label($settings['submit'])) {
        throw new RuntimeException('Укажите текст обеих кнопок обратного звонка.');
    }
    if (!in_array($settings['mode'], ['off', 'manual', 'auto'], true)
        || !in_array($settings['provider'], ['none', 'zadarma', 'webhook'], true)) {
        throw new RuntimeException('Выберите режим и провайдера телефонии.');
    }
    if ($settings['provider'] === 'none') {
        $settings['mode'] = 'off';
    }
    if ($settings['provider'] === 'zadarma' && $settings['mode'] !== 'off'
        && !preg_match('/\A[A-Za-z0-9+_.-]{1,32}\z/', $settings['from'])) {
        throw new RuntimeException('Укажите номер оператора, SIP-номер или добавочный Zadarma.');
    }
    $lock = admin_lock();
    try {
        if (!hash_equals(admin_settings_revision(site_callback_settings()), $revision)) {
            throw new RuntimeException('Настройки обратного звонка уже изменились. Откройте раздел заново.');
        }
        admin_write_record(SITE_CALLBACK_SETTINGS, $settings);
    } finally {
        fclose($lock);
    }
}
