<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$guide = require SITE_ROOT . '/app/template-guide.php';
?>
<h1>Помощь по шаблонам и компонентам</h1>
<nav class="site-menu scope-menu" aria-label="Разделы справки">
    <?php foreach ($guide as $anchor => $group): ?>
        <a href="#help-<?= site_escape($anchor) ?>"><?= site_escape($group['title']) ?></a>
    <?php endforeach; ?>
</nav>
<div class="form-stack template-guide">
    <?php foreach ($guide as $anchor => $group): ?>
        <section class="panel form-stack" id="help-<?= site_escape($anchor) ?>">
            <h2><?= site_escape($group['title']) ?></h2>
            <?php foreach ($group['entries'] as list($title, $description, $examples)): ?>
                <div class="help-entry">
                    <h3><?= site_escape($title) ?></h3>
                    <p><?= site_escape($description) ?></p>
                    <?php foreach ($examples as $example): ?>
                        <pre><code><?= site_escape($example) ?></code></pre>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endforeach; ?>
</div>
