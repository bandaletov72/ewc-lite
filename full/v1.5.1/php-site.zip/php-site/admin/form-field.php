<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$prefix = 'fields[' . $index . ']';
?>
<fieldset class="field-config form-stack" data-form-row>
    <legend>Поле формы</legend>
    <div class="fields">
        <label class="field">Подпись
            <input name="<?= $prefix ?>[label]" value="<?= site_escape($field['label']) ?>" placeholder="Ваш телефон" maxlength="375" required>
        </label>
        <label class="field">Ключ поля
            <input name="<?= $prefix ?>[name]" value="<?= site_escape($field['name']) ?>" placeholder="phone" maxlength="64" required>
        </label>
        <label class="field">Тип
            <select name="<?= $prefix ?>[type]" data-field-type>
                <?php foreach (site_form_types() as $type => $label): ?>
                    <option value="<?= $type ?>"<?= $field['type'] === $type ? ' selected' : '' ?>><?= site_escape($label) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="choice field-required"><input type="checkbox" name="<?= $prefix ?>[required]" value="1"<?= $field['required'] ? ' checked' : '' ?>> Обязательное поле</label>
    </div>
    <label class="field" data-field-options>Варианты для radio и select
        <textarea class="short-editor" name="<?= $prefix ?>[options]" rows="3" placeholder="Один вариант на строку"><?= "\n" . site_escape(implode("\n", $field['options'])) ?></textarea>
    </label>
    <div><button type="button" data-remove-field>Удалить поле</button></div>
</fieldset>
