<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

/** @return resource */
function admin_lock()
{
    $lock = @fopen(__DIR__ . '/write-lock.php', 'r+b');
    if ($lock === false) {
        throw new RuntimeException('Нет доступа к файлу блокировки. Проверьте права записи.');
    }
    if (!flock($lock, LOCK_EX)) {
        fclose($lock);
        throw new RuntimeException('Не удалось получить блокировку файла. Повторите сохранение.');
    }

    clearstatcache(true);
    return $lock;
}

function admin_replace_file(string $file, string $bytes): bool
{
    $temporary = dirname($file) . '/.save-' . bin2hex(random_bytes(12)) . '.php';
    try {
        if (@file_put_contents($temporary, $bytes) !== strlen($bytes) || !@rename($temporary, $file)) {
            return false;
        }
    } finally {
        if (is_file($temporary)) {
            @unlink($temporary);
        }
    }

    clearstatcache(true);
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($file, true);
    }
    return true;
}

function admin_write_record(string $file, array $record, int $limit = 32768)
{
    $json = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false) {
        throw new RuntimeException('Файл настроек слишком большой или содержит недопустимые символы.');
    }
    admin_write_payload($file, $json . "\n", $limit);
}

function admin_write_payload(string $file, string $payload, int $limit)
{
    $bytes = SITE_RECORD_HEADER . $payload;
    if (strlen($bytes) > $limit) {
        throw new RuntimeException('Размер файла превышает допустимый предел.');
    }
    if (!admin_replace_file($file, $bytes)) {
        throw new RuntimeException('Не удалось записать файл. Проверьте права записи в его каталог.');
    }
}
