<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$value = $row[$index] ?? '';
$type = $column['type'];
$attributes = 'name="rows[' . $rowIndex . '][' . $index . ']" aria-label="' . site_escape($column['label']) . '"';
?>
<td data-cell-column="<?= $index ?>">
    <?php if ($type === 'textarea'): ?>
        <textarea rows="3" data-cell-type="textarea" <?= $attributes ?>><?= "\n" . site_escape($value) ?></textarea>
    <?php elseif ($type === 'bool'): ?>
        <select data-cell-type="bool" <?= $attributes ?>>
            <option value="">—</option>
            <option value="1"<?= $value === '1' ? ' selected' : '' ?>>Да</option>
            <option value="0"<?= $value === '0' ? ' selected' : '' ?>>Нет</option>
        </select>
    <?php else: ?>
        <?php
        $inputType = in_array($type, ['date', 'number', 'tel', 'email', 'url'], true) ? $type : 'text';
        if ($type === 'number') {
            $value = str_replace(',', '.', $value);
        }
        ?>
        <input type="<?= $inputType ?>" data-cell-type="<?= $inputType ?>" value="<?= site_escape($value) ?>" <?= $attributes ?> <?= $type === 'number' ? 'step="any"' : '' ?>>
    <?php endif; ?>
</td>
