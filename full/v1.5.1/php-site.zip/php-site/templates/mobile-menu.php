<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="mobile-header-menu">
    <button class="menu-toggle" type="button" data-mobile-toggle aria-expanded="true" hidden>Меню</button>
    <nav class="site-menu" data-mobile-navigation aria-label="Мобильное меню">
        <?php require site_template_file('navigation-links.php'); ?>
    </nav>
</div>
