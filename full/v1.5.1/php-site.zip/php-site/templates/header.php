<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<a class="brand" href="<?= site_escape(site_url($base)) ?>"><?php if (!empty($brand['logo'])): ?><img class="site-logo" src="<?= site_escape(site_url($base, $brand['logo'])) ?>" alt=""> <?php endif; ?><?= site_escape($settings['name']) ?></a>
<nav class="site-menu desktop-menu" aria-label="Верхнее меню">
    <?php require site_template_file('navigation-links.php'); ?>
</nav>
