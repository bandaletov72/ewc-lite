<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

$type = $_GET['type'] ?? '';
$path = $_GET['page'] ?? '';
$types = ['css' => 'text/css', 'js' => 'application/javascript'];
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-cache');
header("Content-Security-Policy: default-src 'none'; sandbox");
if (!is_string($type) || !isset($types[$type]) || !is_string($path) || !empty($_SERVER['PATH_INFO'])) {
    http_response_code(404);
    exit;
}

try {
    if ($path === '') {
        $assets = site_global_assets();
    } else {
        $page = site_read_page($path);
        $assets = $page !== null && $page['fields']['Hidden'] === '0' ? $page['fields'] : [];
    }
    $code = site_asset_decode($assets[strtoupper($type)] ?? '');
} catch (RuntimeException $exception) {
    $code = null;
}
if ($code === null || $code === '') {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . $types[$type] . '; charset=UTF-8');
echo $code;
