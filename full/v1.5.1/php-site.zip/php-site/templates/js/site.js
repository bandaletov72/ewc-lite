(() => {
    window.siteFetchContent = async (path) => {
        const token = document.querySelector('meta[name="site-fragment-token"]');
        const url = new URL(path, window.location.href);
        if (!token || url.origin !== window.location.origin) {
            throw new Error('Фрагмент доступен в текущем сеансе сайта.');
        }
        url.searchParams.set('ajax', '1');
        const response = await fetch(url, {
            credentials: 'same-origin',
            headers: { Accept: 'text/html', 'X-Site-Fragment': token.content },
        });
        if (!response.ok) throw new Error('Не удалось загрузить страницу (' + response.status + ').');
        return response.text();
    };

    document.querySelectorAll('.mobile-header-menu').forEach((element, index) => {
        const toggle = element.querySelector('[data-mobile-toggle]');
        const menu = element.querySelector('[data-mobile-navigation]');
        if (!toggle || !menu) return;
        menu.id = 'mobile-site-menu-' + (index + 1);
        toggle.setAttribute('aria-controls', menu.id);
        const mobile = window.matchMedia('(max-width: 40rem)');
        const setOpen = (open) => {
            toggle.setAttribute('aria-expanded', String(open));
            menu.hidden = !open;
        };
        const update = () => {
            toggle.hidden = !mobile.matches;
            setOpen(!mobile.matches);
        };

        toggle.addEventListener('click', () => setOpen(menu.hidden));
        if (mobile.addEventListener) mobile.addEventListener('change', update);
        else mobile.addListener(update);
        update();
    });

    const formatPhone = (input) => {
        const raw = input.value;
        if (!/^ *\+?[0-9 ().-]*$/.test(raw)) return;

        const digits = raw.replace(/\D/g, '');
        const hasPlus = raw.trimStart().startsWith('+');
        const hasRussianPrefix = hasPlus ? digits[0] === '7' : /^[78]/.test(digits);
        let value = hasPlus ? '+' + digits : digits;
        if (digits && (!hasPlus || hasRussianPrefix)) {
            const local = hasRussianPrefix ? digits.slice(1) : digits;
            value = '+7';
            if (local.length) value += '(' + local.slice(0, 3);
            if (local.length > 3) value += ')' + local.slice(3, 6);
            if (local.length > 6) value += '-' + local.slice(6, 8);
            if (local.length > 8) value += '-' + local.slice(8);
        }
        if (value === raw) return;

        const caret = input.selectionStart;
        input.value = value;
        if (caret === null || caret === raw.length) return;
        let digitsBeforeCaret = raw.slice(0, caret).replace(/\D/g, '').length;
        if (digitsBeforeCaret > 0 && !hasPlus && !hasRussianPrefix) digitsBeforeCaret += 1;
        let position = 0;
        while (position < value.length && digitsBeforeCaret > 0) {
            if (/\d/.test(value[position])) digitsBeforeCaret -= 1;
            position += 1;
        }
        input.setSelectionRange(position, position);
    };

    const initialize = (root) => {
        const selector = '[data-gallery]:not([data-ready]), [data-contact-form]:not([data-ready])';
        const elements = [...(root.matches(selector) ? [root] : []), ...root.querySelectorAll(selector)];
        elements.forEach((element) => {
            element.dataset.ready = 'true';
            if (element.matches('[data-contact-form]')) {
                const formatTelephone = (event) => {
                    if (event.target.matches('input[type="tel"]')) formatPhone(event.target);
                };
                element.addEventListener('input', formatTelephone);
                element.addEventListener('change', formatTelephone);
                element.querySelectorAll('input[type="tel"]').forEach(formatPhone);
                element.querySelector('button[type="submit"]').disabled = false;
                return;
            }
            const controls = element.querySelector('.gallery-controls');
            const track = element.querySelector('[data-gallery-track]');
            const images = [...track.children];
            if (images.length < 2) return;
            const status = controls && controls.querySelector('[data-gallery-status]');
            const effect = element.dataset.galleryEffect;
            const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

            let current = -1;
            const select = (index) => {
                if (index === current) return;
                current = index;
                if (status) status.textContent = (current + 1) + ' / ' + images.length;
                images.forEach((image, position) => {
                    image.classList.toggle('is-active', position === current);
                    if (position === current) image.removeAttribute('aria-hidden');
                    else image.setAttribute('aria-hidden', 'true');
                });
            };
            const move = (direction) => {
                const next = (current + direction + images.length) % images.length;
                if (effect === 'fade') {
                    select(next);
                } else {
                    track.scrollTo({ left: images[next].offsetLeft,
                        behavior: effect === 'slide' && !reducedMotion.matches ? 'smooth' : 'auto' });
                }
            };

            if (controls) {
                controls.hidden = false;
                const previous = controls.querySelector('[data-gallery-prev]');
                const next = controls.querySelector('[data-gallery-next]');
                if (previous && next) {
                    previous.addEventListener('click', () => move(-1));
                    next.addEventListener('click', () => move(1));
                }
            }
            if (effect === 'fade') {
                let start;
                track.addEventListener('touchstart', (event) => {
                    start = event.touches.length === 1 ? event.touches[0] : null;
                }, { passive: true });
                track.addEventListener('touchend', (event) => {
                    if (!start) return;
                    const end = event.changedTouches[0];
                    const x = end.clientX - start.clientX;
                    const y = end.clientY - start.clientY;
                    start = null;
                    if (Math.abs(x) > Math.max(35, Math.abs(y))) move(x < 0 ? 1 : -1);
                }, { passive: true });
            } else {
                track.addEventListener('scroll', () => {
                    if (track.clientWidth > 0) {
                        select(Math.max(0, Math.min(images.length - 1, Math.round(track.scrollLeft / track.clientWidth))));
                    }
                }, { passive: true });
            }
            element.addEventListener('keydown', (event) => {
                if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
                event.preventDefault();
                move(event.key === 'ArrowRight' ? 1 : -1);
            });
            select(0);
        });
    };

    initialize(document.body);
    new MutationObserver((records) => {
        records.forEach((record) => record.addedNodes.forEach((node) => {
            if (node.nodeType === 1) initialize(node);
        }));
    }).observe(document.body, { childList: true, subtree: true });

    document.addEventListener('submit', async (event) => {
        const form = event.target;
        if (!form.matches('[data-contact-form]')) return;
        event.preventDefault();
        const button = form.querySelector('button[type="submit"]');
        if (button.disabled) return;

        const feedback = form.querySelector('[data-form-feedback]');
        const fields = [...form.querySelectorAll('[data-message-field]')];
        fields.forEach((field) => {
            field.querySelector('[data-field-error]').hidden = true;
            field.querySelectorAll('[aria-invalid]').forEach((input) => input.removeAttribute('aria-invalid'));
        });
        feedback.hidden = true;
        button.disabled = true;
        try {
            const response = await fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                headers: { Accept: 'application/json' },
            });
            const result = await response.json();
            feedback.textContent = result.message;
            feedback.classList.toggle('error', !result.ok);
            if (result.ok) {
                form.reset();
            } else {
                fields.forEach((field) => {
                    const name = field.dataset.messageField;
                    if (!Object.prototype.hasOwnProperty.call(result.fields || {}, name)) return;
                    const fieldError = field.querySelector('[data-field-error]');
                    fieldError.textContent = result.fields[name];
                    fieldError.hidden = false;
                    field.querySelectorAll('input, textarea, select').forEach((input) => input.setAttribute('aria-invalid', 'true'));
                });
            }
        } catch (error) {
            feedback.textContent = 'Не удалось отправить сообщение. Попробуйте ещё раз.';
            feedback.classList.add('error');
        } finally {
            feedback.hidden = false;
            button.disabled = false;
        }
    });
})();
