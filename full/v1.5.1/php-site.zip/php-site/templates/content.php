<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main" id="content">
    <h1><?= site_escape($heading) ?></h1>
    <div class="page-content">
        <?= $content ?>
    </div>
</main>
