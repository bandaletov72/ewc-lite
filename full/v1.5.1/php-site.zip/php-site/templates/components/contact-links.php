<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($code === 'contacts' && $settings['heading'] !== ''): ?>
    <span class="contact-links-heading"><?= site_escape($settings['heading']) ?></span>
<?php endif; ?>
<span class="contact-links<?= $code === 'soc-icons' ? ' soc-icons' : '' ?>">
    <?php foreach ($items as $item): ?>
        <a class="contact-link" href="<?= site_escape($item['href']) ?>" aria-label="<?= site_escape($item['text'] === $item['label'] ? $item['text'] : $item['text'] . ' — ' . $item['label']) ?>">
            <img src="<?= site_escape(site_url($base, 'templates/icons/contact/' . $item['icon'] . '.png')) ?>" width="24" height="24" alt="">
            <?php if ($code !== 'soc-icons'): ?><?= site_escape($item['text']) ?><?php endif; ?>
        </a>
    <?php endforeach; ?>
</span>
