<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<ul class="file-list" aria-label="Файлы">
    <?php foreach ($files as $file): ?>
        <li><a href="<?= site_escape($file['url']) ?>"<?= $options['download'] === 'on' ? ' download' : '' ?>>
            <?php if ($options['icons'] === 'on'): ?>
                <span class="file-icon file-icon-<?= $file['extension'] ?>" aria-hidden="true"><?= strtoupper($file['extension']) ?></span>
            <?php endif; ?>
            <span><?= site_escape($file['name']) ?></span>
            <?php if (is_int($file['size'] ?? null)): ?>
                <small class="file-size"><?= site_escape(site_file_size($file['size'])) ?></small>
            <?php endif; ?>
        </a></li>
    <?php endforeach; ?>
</ul>
