<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$description = site_expand_text($fields['Description'] !== '' ? $fields['Description'] : $settings['description'], $snippets);
$assetUrls = site_asset_urls($base, $page);
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if (isset($public['fragment'])): ?>
        <meta name="site-fragment-token" content="<?= site_escape($public['fragment']) ?>">
    <?php endif; ?>
    <title><?= site_escape($title . ' | ' . $settings['name']) ?></title>
    <?php if ($description !== ''): ?>
        <meta name="description" content="<?= site_escape($description) ?>">
    <?php endif; ?>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, $brand['favicon'] ?: 'templates/icons/site.png')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>">
    <?php foreach ($assetUrls['CSS'] as $url): ?>
        <link rel="stylesheet" href="<?= site_escape($url) ?>">
    <?php endforeach; ?>
    <script src="<?= site_escape(site_url($base, 'templates/js/site.js')) ?>" defer></script>
    <?php foreach ($assetUrls['JS'] as $url): ?>
        <script src="<?= site_escape($url) ?>" defer></script>
    <?php endforeach; ?>
</head>
<body>
    <a class="skip-link" href="#content">Перейти к содержимому</a>
    <header class="site-header">
        <div class="container header-row">
            <div class="desktop-header"><?= site_layout_block('header', $components) ?></div>
            <?= site_layout_block('mobile-menu', $components) ?>
        </div>
    </header>

    <?php $sidebar = site_layout_block('menu', $components); ?>
    <div class="container site-layout<?= trim($sidebar) !== '' ? ' has-sidebar' : '' ?>">
        <?php $embeddedContent = true; require site_template_file('content.php'); ?>
        <?php if (trim($sidebar) !== ''): ?>
            <aside class="site-sidebar"><?= $sidebar ?></aside>
        <?php endif; ?>
    </div>

    <?= site_layout_block('footer', $components) ?>
</body>
</html>
