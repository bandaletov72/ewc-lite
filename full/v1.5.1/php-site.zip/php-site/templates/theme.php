<?php
define('SITE_ROOT', dirname(__DIR__));
require SITE_ROOT . '/app/site.php';

header('Content-Type: text/css; charset=UTF-8');
header('Cache-Control: no-cache');
header('X-Content-Type-Options: nosniff');
$theme = site_theme_settings();
$scheme = $theme['mode'] === 'dark' ? 'dark' : 'light';
echo site_theme_css($scheme, $theme[$scheme]);
if ($theme['mode'] === 'auto') {
    echo "@media (prefers-color-scheme: dark) {\n", site_theme_css('dark', $theme['dark']), "}\n";
}
