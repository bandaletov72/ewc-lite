<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php if ($navigation): ?>
    <nav class="site-menu sidebar-menu" aria-label="Правое меню">
        <?php require site_template_file('navigation-links.php'); ?>
    </nav>
<?php endif; ?>
