<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

$phoneColumns = [];
$nameColumn = null;
foreach ($block['columns'] as $index => $column) {
    if ($column['type'] === 'tel') {
        $phoneColumns[] = $index;
    }
    if ($column['type'] === 'text' && ($nameColumn === null || $column['key'] === 'name')) {
        $nameColumn = $index;
    }
}
if (!$phoneColumns) {
    return;
}
?>
<ul class="phone-list">
    <?php foreach ($block['rows'] as $row): ?>
        <?php
        $numbers = [];
        foreach ($phoneColumns as $index) {
            if (($row[$index] ?? '') !== '') {
                $numbers[] = site_iblock_cell($row[$index], 'tel');
            }
        }
        if (!$numbers) { continue; }
        ?>
        <li>
            <?php if ($nameColumn !== null && ($row[$nameColumn] ?? '') !== ''): ?>
                <strong><?= site_escape($row[$nameColumn]) ?></strong>
            <?php endif; ?>
            <?= implode(' · ', $numbers) ?>
        </li>
    <?php endforeach; ?>
</ul>
