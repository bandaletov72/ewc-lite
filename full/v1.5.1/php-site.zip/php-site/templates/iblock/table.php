<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<div class="iblock-table-wrap">
    <table class="iblock-table">
        <thead><tr>
            <?php foreach ($block['columns'] as $column): ?>
                <th scope="col"><?= site_escape($column['label']) ?></th>
            <?php endforeach; ?>
        </tr></thead>
        <tbody>
            <?php foreach ($block['rows'] as $row): ?>
                <tr>
                    <?php foreach ($block['columns'] as $index => $column): ?>
                        <td><?= site_iblock_cell($row[$index] ?? '', $column['type']) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
