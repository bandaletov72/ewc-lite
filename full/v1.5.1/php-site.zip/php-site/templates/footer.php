<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$footerText = $settings['footer'];
if ($footerText === '') {
    $footerText = '© ' . ($snippets['year'] ?? date('Y')) . ' ' . $settings['name'];
} else {
    $footerText = site_expand_text($footerText, $snippets ?? site_date_snippets());
}
?>
<footer class="site-footer">
    <div class="container"><?= site_escape($footerText) ?></div>
</footer>
