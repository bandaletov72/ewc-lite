<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_SPAM_FILE = SITE_ROOT . '/admin/.spam.php';

function site_spam_rules(): array
{
    return array_replace(['words' => ['casino', 'poker', 'ставки'], 'ips' => []], site_read_record(SITE_SPAM_FILE));
}

function site_normalize_ip(string $ip): string
{
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return '';
    }
    $canonical = strtolower(inet_ntop(inet_pton($ip)));
    return strpos($canonical, '::ffff:') === 0 && filter_var(substr($canonical, 7), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
        ? substr($canonical, 7) : $canonical;
}

function site_has_url(string $value): bool
{
    $pattern = <<<'REGEX'
~
  [a-z][a-z0-9+.-]*://\S+
  | (?:www\.|mailto:)\S+
  | (?<![\p{L}\p{N}@_.-])
    (?:[\p{L}\p{N}](?:[\p{L}\p{N}-]{0,61}[\p{L}\p{N}])?\.)+
    (?:xn--[a-z0-9-]{2,59}|[\p{L}]{2,63})
    (?![\p{L}\p{N}_-])
  | (?:\b[0-9]{1,3}\.){3}[0-9]{1,3}(?::[0-9]+)?/
~iux
REGEX;
    return preg_match($pattern, $value) === 1;
}

function site_spam_errors(array $fields, array $words): array
{
    $errors = [];
    foreach ($fields as $name => $field) {
        if ($field['value'] === '') {
            continue;
        }
        if ($field['type'] !== 'email' && $field['type'] !== 'tel' && site_has_url($field['value'])) {
            $errors[$name] = 'Удалите ссылки из этого поля.';
            continue;
        }
        foreach ($words as $word) {
            if ($word !== '' && preg_match('~(?<![\p{L}\p{N}_])' . preg_quote($word, '~') . '(?![\p{L}\p{N}_])~iu', $field['value']) === 1) {
                $errors[$name] = 'Это поле содержит запрещённое слово или выражение.';
                break;
            }
        }
    }
    return $errors;
}
