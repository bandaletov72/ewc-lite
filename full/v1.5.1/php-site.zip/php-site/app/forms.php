<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

const SITE_FORMS_FILE = SITE_ROOT . '/admin/.forms.php';
const SITE_INBOX = SITE_ROOT . '/admin/inbox';

function site_form_types(): array
{
    return ['text' => 'Текстовое поле', 'textarea' => 'Многострочный текст',
        'radio' => 'Переключатели (radio)', 'select' => 'Выпадающий список',
        'tel' => 'Телефон', 'email' => 'Email'];
}

function site_valid_form_id(string $id): bool
{
    return preg_match('/\Aform[1-9][0-9]{0,8}\z/', $id) === 1;
}

function site_default_forms(): array
{
    return ['form1' => [
        'button' => 'Отправить',
        'recipient' => '',
        'fields' => [
            ['name' => 'name', 'label' => 'Имя', 'type' => 'text', 'required' => true, 'options' => []],
            ['name' => 'email', 'label' => 'Email', 'type' => 'email', 'required' => true, 'options' => []],
            ['name' => 'message', 'label' => 'Сообщение', 'type' => 'textarea', 'required' => true, 'options' => []],
        ],
    ]];
}

function site_forms(): array
{
    return array_replace(site_default_forms(), site_read_record(SITE_FORMS_FILE));
}

function site_public_session(string $base): bool
{
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('FILE_SITE_PUBLIC');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params(0, site_url($base), '', $secure, true);
    session_cache_limiter('');
    return @session_start();
}

function site_public_context(string $base, bool $fragment): array
{
    header('Cache-Control: private, no-store');
    $presented = $_SERVER['HTTP_X_SITE_FRAGMENT'] ?? '';
    $scheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    $requestOrigin = $scheme . '://' . strtolower($_SERVER['HTTP_HOST'] ?? '');
    $scope = $requestOrigin . site_url($base);
    if ($fragment) {
        $fetchSite = $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '';
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if (!in_array($_SERVER['REQUEST_METHOD'] ?? '', ['GET', 'HEAD'], true)
            || ($fetchSite !== '' && $fetchSite !== 'same-origin')
            || ($origin !== '' && strtolower($origin) !== $requestOrigin)
            || !isset($_COOKIE['FILE_SITE_PUBLIC'])
            || preg_match('/\A[0-9a-f]{64}\z/', $presented) !== 1) {
            return [];
        }
    }

    if (!site_public_session($base)) {
        return [];
    }
    if ($fragment && (($_SESSION['fragmentScope'] ?? '') !== $scope
            || !hash_equals($_SESSION['fragment'] ?? '', $presented))) {
        session_write_close();
        return [];
    }

    if (!isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    if (($_SESSION['fragmentScope'] ?? '') !== $scope || !isset($_SESSION['fragment'])) {
        $_SESSION['fragment'] = bin2hex(random_bytes(32));
        $_SESSION['fragmentScope'] = $scope;
    }
    $context = ['token' => $_SESSION['csrf'], 'fragment' => $_SESSION['fragment']];
    session_write_close();
    return $context;
}

function site_form_signature(string $token, string $id, string $page): string
{
    return hash_hmac('sha256', $id . "\0" . $page, $token);
}

function site_valid_phone(string $phone): bool
{
    return preg_match('/\A\+?[0-9 ().-]{7,32}\z/', $phone) === 1
        && preg_match('/\A[0-9]{7,15}\z/', preg_replace('/[^0-9]/', '', $phone)) === 1;
}

function site_normalize_form_phone(string $phone): string
{
    if (!site_valid_phone($phone)) {
        return '';
    }

    $digits = preg_replace('/[^0-9]/', '', $phone);
    if ($phone[0] === '+' && $digits[0] !== '7') {
        return $digits[0] === '0' ? '' : '+' . $digits;
    }

    if ($phone[0] !== '+') {
        if ($digits[0] === '8') {
            $digits = '7' . substr($digits, 1);
        } elseif ($digits[0] !== '7') {
            $digits = '7' . $digits;
        }
    }
    if (strlen($digits) !== 11) {
        return '';
    }

    return '+7(' . substr($digits, 1, 3) . ')' . substr($digits, 4, 3)
        . '-' . substr($digits, 7, 2) . '-' . substr($digits, 9, 2);
}

function site_validate_message(array $form, array $submitted): array
{
    $fields = [];
    $errors = [];
    $replyTo = '';
    foreach ($form['fields'] as $field) {
        $name = $field['name'];
        $input = $submitted[$name] ?? '';
        $value = is_string($input) ? trim($input) : '';
        $type = $field['type'];
        if ($value === '') {
            if ($field['required']) {
                $errors[$name] = 'Заполните это поле.';
            }
        } elseif (strlen($value) > ($type === 'textarea' ? 12000 : 1500)
            || preg_match('//u', $value) !== 1 || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)
            || ($type !== 'textarea' && preg_match('/[\r\n]/', $value))) {
            $errors[$name] = 'Проверьте длину и формат значения.';
        } elseif ($type === 'email' && (strlen($value) > 254 || !filter_var($value, FILTER_VALIDATE_EMAIL))) {
            $errors[$name] = 'Укажите действительный email.';
        } elseif ($type === 'tel') {
            $normalized = site_normalize_form_phone($value);
            if ($normalized === '') {
                $errors[$name] = 'Укажите полный номер телефона, включая код страны.';
            } else {
                $value = $normalized;
            }
        } elseif (in_array($type, ['radio', 'select'], true) && !in_array($value, $field['options'], true)) {
            $errors[$name] = 'Выберите один из предложенных вариантов.';
        }

        if ($type === 'email' && $replyTo === '' && $value !== '' && !isset($errors[$name])) {
            $replyTo = $value;
        }
        $fields[$name] = ['label' => $field['label'], 'value' => $value, 'type' => $type];
    }
    return ['fields' => $fields, 'errors' => $errors, 'replyTo' => $replyTo];
}

function site_save_message(array $message)
{
    $id = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
    admin_write_record(SITE_INBOX . '/' . $id . '.php', $message);
}

function site_notify_message(string $recipient, string $replyTo, array $message)
{
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL) || !function_exists('mail')) {
        return;
    }
    $subject = '=?UTF-8?B?' . base64_encode('Новое сообщение с сайта') . '?=';
    $headers = "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8";
    if ($replyTo !== '') {
        $headers .= "\r\nReply-To: " . $replyTo;
    }
    $lines = ['Форма: [' . $message['form'] . ']', 'Домен: ' . $message['host']];
    foreach ($message['fields'] as $field) {
        $lines[] = $field['label'] . ": " . $field['value'];
    }
    @mail($recipient, $subject, implode("\r\n", $lines), $headers);
}
