<?php
if (PHP_SAPI !== 'cli-server') {
    http_response_code(404);
    exit;
}

$request = explode('?', $_SERVER['REQUEST_URI'] ?? '/', 2)[0];
$path = str_replace('\\', '/', rawurldecode($request));
$segments = [];
foreach (explode('/', $path) as $part) {
    if (DIRECTORY_SEPARATOR === '\\') {
        $part = rtrim($part, ' ');
    }
    if ($part === '..') {
        array_pop($segments);
    } elseif ($part !== '' && $part !== '.') {
        $segments[] = DIRECTORY_SEPARATOR === '\\' ? rtrim($part, '.') : $part;
    }
}

if (strcasecmp($segments[0] ?? '', 'data') === 0 || strcasecmp($segments[0] ?? '', 'router.php') === 0) {
    http_response_code(404);
    exit;
}

return false;
