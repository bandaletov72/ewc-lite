<?php
define('SITE_ROOT', __DIR__);
require SITE_ROOT . '/app/site.php';
site_render(isset($pageFile) ? $pageFile : __FILE__);
__halt_compiler();
Title: Главная
Heading: Добро пожаловать
Description: Главная страница сайта.
Menu: Главная
Order: 10

<p>Здесь можно разместить краткое описание сайта, проекта или организации.</p>
<p>На странице «Контакты» можно указать, как с вами связаться.</p>
