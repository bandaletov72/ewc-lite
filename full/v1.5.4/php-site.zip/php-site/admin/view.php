<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Управление сайтом | <?= site_escape($siteSettings['name']) ?></title>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, site_brand_settings()['favicon'] ?: 'templates/icons/site.png')) ?>">
    <?php if ($loggedIn): ?>
        <link rel="stylesheet" href="<?= site_escape(site_font_awesome_stylesheet($base)) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>">
    <?php if ($loggedIn && in_array($section, ['pages', 'forms', 'iblocks', 'contacts', 'components', 'theme'], true)): ?>
        <script src="<?= site_escape(site_url($base, 'templates/js/admin.js') . '?v=' . site_update_version()) ?>" defer></script>
    <?php endif; ?>
</head>
<body>
    <header class="site-header">
        <div class="container header-row">
            <a class="brand" href="<?= site_escape($adminUrl) ?>">Управление сайтом</a>
            <div class="header-actions">
                <a class="button" href="<?= site_escape(site_url($base)) ?>">Открыть сайт</a>
                <?php if ($loggedIn): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>">
                        <input type="hidden" name="action" value="logout">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <button type="submit">Выйти</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main class="container admin-main">
        <?php if ($accessError !== ''): ?>
            <section class="panel login-panel">
                <h1>Настройка входа</h1>
                <p class="notice error" role="alert"><?= site_escape($accessError) ?></p>
            </section>
        <?php elseif (!$configured): ?>
            <section class="panel login-panel">
                <p class="hint">Шаг 1 из 2</p>
                <h1>Мастер установки</h1>
                <h2>Создать учётную запись</h2>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                <?php endif; ?>
                <?php if ($setupAvailable): ?>
                    <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                        <input type="hidden" name="action" value="setup">
                        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                        <?php if ($needsCode): ?>
                            <div class="field">
                                <label for="setup-code">Одноразовый код установки</label>
                                <input id="setup-code" name="setup_code" autocomplete="off" required>
                            </div>
                        <?php endif; ?>
                        <div class="field">
                            <label for="setup-username">Логин</label>
                            <input id="setup-username" name="username" value="<?= site_escape($username) ?>" placeholder="admin" autocomplete="username" maxlength="64" required>
                        </div>
                        <div class="field">
                            <label for="setup-password">Пароль</label>
                            <input id="setup-password" type="password" name="password" autocomplete="new-password" minlength="8" aria-describedby="password-hint" required>
                            <small class="hint" id="password-hint">От 8 символов, не более 72 байт.</small>
                        </div>
                        <div class="field">
                            <label for="setup-confirmation">Повторите пароль</label>
                            <input id="setup-confirmation" type="password" name="confirmation" autocomplete="new-password" required>
                        </div>
                        <div><button class="button-primary" type="submit">Создать учётную запись и продолжить</button></div>
                    </form>
                <?php else: ?>
                    <p>В каталоге сайта выполните <code>php admin/setup.php</code>, затем обновите страницу и введите полученный код.</p>
                <?php endif; ?>
            </section>
        <?php elseif (!$loggedIn): ?>
            <section class="panel login-panel">
                <h1>Вход в админку</h1>
                <?php if ($error !== ''): ?>
                    <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                <?php endif; ?>
                <form method="post" action="<?= site_escape($adminUrl) ?>" class="form-stack">
                    <input type="hidden" name="action" value="login">
                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                    <div class="field">
                        <label for="username">Логин</label>
                        <input id="username" name="username" value="<?= site_escape($username) ?>" autocomplete="username" required>
                    </div>
                    <div class="field">
                        <label for="password">Пароль</label>
                        <input id="password" type="password" name="password" autocomplete="current-password" required>
                    </div>
                    <div><button class="button-primary" type="submit">Войти</button></div>
                </form>
            </section>
        <?php elseif ($section === 'install'): ?>
            <?php require __DIR__ . '/installation-view.php'; ?>
        <?php else: ?>
            <?php if ($installationPending): ?>
                <p class="notice"><a href="<?= site_escape($installationUrl) ?>">Завершить первичную настройку сайта</a></p>
            <?php endif; ?>
            <nav class="site-menu admin-menu" aria-label="Разделы админки">
                <?php foreach (['pages' => ['Страницы', $adminUrl], 'settings' => ['Настройки', $settingsUrl], 'layout' => ['Шаблоны оформления', $layoutEditorUrl], 'assets' => ['CSS и JS', $assetsUrl], 'snippets' => ['Подшаблоны', $snippetsUrl], 'domains' => ['Домены', $domainsUrl], 'iblocks' => ['Инфоблоки', $iblocksUrl], 'forms' => ['Формы', $formsUrl], 'spam' => ['Антиспам', $spamUrl], 'messages' => ['Сообщения', $messagesUrl], 'callbacks' => ['Обратные звонки', $callbacksUrl], 'help' => ['Помощь', $helpUrl]] as $key => $item): ?>
                    <a href="<?= site_escape($item[1]) ?>"<?= $section === $key || ($key === 'layout' && $section === 'headers') || ($key === 'settings' && in_array($section, ['contacts', 'theme', 'components', 'updates', 'libraries'], true)) ? ' aria-current="page"' : '' ?>><?= site_escape($item[0]) ?></a>
                <?php endforeach; ?>
            </nav>
            <?php if ($section !== 'pages'): ?>
                <?php require __DIR__ . '/config-view.php'; ?>
            <?php else: ?>
            <div class="admin-heading">
                <h1>Страницы</h1>
                <a class="button button-primary" href="<?= site_escape($adminUrl . '?new=1') ?>">Новая страница</a>
            </div>
            <p data-page-feedback class="notice" role="status" hidden></p>
            <div class="editor-grid" data-page-admin data-admin-url="<?= site_escape($adminUrl) ?>" data-csrf="<?= site_escape($token) ?>">
                <nav class="panel" aria-label="Папки и страницы">
                    <form class="form-stack" data-folder-move-form hidden>
                        <strong data-folder-move-label></strong>
                        <input type="hidden" name="action" value="folder-move">
                        <input type="hidden" name="path">
                        <label class="field">
                            Папка назначения
                            <select name="folder" required></select>
                        </label>
                        <div class="header-actions">
                            <button type="submit">Переместить</button>
                            <button type="button" data-folder-move-cancel>Отмена</button>
                        </div>
                    </form>
                    <div data-page-tree>
                        <?= admin_page_tree_html($tree, $creating ? '' : ($page['path'] ?? ''), $base, $adminUrl) ?>
                    </div>
                </nav>
                <section class="panel">
                    <?php if ($error !== ''): ?>
                        <p class="notice error" role="alert"><?= site_escape($error) ?></p>
                    <?php elseif ($notice !== ''): ?>
                        <p class="notice" role="status"><?= site_escape($notice) ?></p>
                    <?php endif; ?>
                    <?php if ($page !== null && !$creating && in_array($pageOperation, ['hide', 'show', 'delete'], true)
                        && ($pageOperation !== 'delete' || $page['path'] !== 'index.php')): ?>
                        <?php
                        $address = site_page_url('', $page['path']);
                        $editUrl = $adminUrl . '?' . http_build_query(['page' => $address]);
                        $operationLabel = ['hide' => 'Скрыть страницу', 'show' => 'Опубликовать страницу', 'delete' => 'Удалить страницу'];
                        ?>
                        <h2><?= $operationLabel[$pageOperation] ?>?</h2>
                        <p><?= site_escape($page['fields']['Title'] . ' · ' . $address) ?></p>
                        <?php if ($pageOperation === 'delete'): ?>
                            <p class="hint">Файл страницы будет удалён. Остальные файлы в её папке останутся.</p>
                        <?php elseif ($pageOperation === 'hide'): ?>
                            <p class="hint">Страница исчезнет из меню и будет недоступна по прямой ссылке, пока вы её не опубликуете.</p>
                        <?php endif; ?>
                        <form class="header-actions" method="post" action="<?= site_escape($editUrl . '&confirm=' . $pageOperation) ?>">
                            <input type="hidden" name="action" value="change-page-status">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="path" value="<?= site_escape($address) ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <input type="hidden" name="operation" value="<?= $pageOperation ?>">
                            <button class="<?= $pageOperation === 'delete' ? 'button-danger' : 'button-primary' ?>" type="submit"><?= $operationLabel[$pageOperation] ?></button>
                            <a class="button" href="<?= site_escape($editUrl) ?>">Отмена</a>
                        </form>
                    <?php elseif ($page !== null): ?>
                        <div data-page-editor-wrapper>
                        <h2><?= $creating ? 'Новая страница' : 'Редактирование страницы' ?></h2>
                        <form method="post" action="<?= site_escape($adminUrl) ?>" data-page-editor
                            data-page-path="<?= site_escape($creating ? '' : $page['path']) ?>">
                            <input type="hidden" name="action" value="save">
                            <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                            <input type="hidden" name="new" value="<?= $creating ? '1' : '0' ?>">
                            <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                            <div class="fields">
                                <div class="field field-wide">
                                    <label for="path">Адрес страницы</label>
                                    <input id="path" name="path" value="<?= site_escape($creating ? $page['path'] : site_page_url('', $page['path'])) ?>" placeholder="/Services-1/" maxlength="240"
                                        <?php if ($creating): ?>
                                            required data-address-input aria-describedby="path-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*(/|\.php)?') ?>"
                                        <?php else: ?>readonly<?php endif; ?>>
                                    <?php if ($creating): ?>
                                        <small id="path-hint" class="hint">В именах файлов и папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Примеры: /Services-1/ и /Services-1/About_2.php.</small>
                                    <?php endif; ?>
                                </div>
                                <?php
                                $labels = [
                                    'Title' => 'Заголовок вкладки',
                                    'Heading' => 'Заголовок H1',
                                    'Description' => 'Метаописание',
                                    'Menu' => 'Название в меню',
                                    'Order' => 'Порядок в меню',
                                ];
                                ?>
                                <?php foreach ($labels as $name => $label): ?>
                                    <div class="field<?= $name === 'Description' ? ' field-wide' : '' ?>">
                                        <label for="<?= $name ?>"><?= $label ?></label>
                                        <input id="<?= $name ?>" name="<?= $name ?>" value="<?= site_escape($page['fields'][$name]) ?>"
                                            <?= $name === 'Order' ? 'type="number" min="0" max="99999" required' : 'maxlength="375"' ?>
                                            <?= $name === 'Title' ? 'required' : '' ?>
                                            <?= $name === 'Menu' ? 'aria-describedby="menu-hint"' : '' ?>>
                                        <?php if ($name === 'Menu'): ?>
                                            <small id="menu-hint" class="hint">Если поле пустое, в меню используется заголовок вкладки.</small>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                                <label class="choice field-wide">
                                    <input type="hidden" name="menu_visibility" value="1">
                                    <input type="checkbox" name="MenuVisible" value="1"<?= $creating ? '' : ' data-page-menu' ?><?= ($page['fields']['MenuVisible'] ?? '0') === '1' ? ' checked' : '' ?>>
                                    Показывать в меню
                                </label>
                                <div class="field field-wide">
                                    <label for="html">Содержимое HTML</label>
                                    <textarea id="html" name="html" spellcheck="false" rows="12"><?= "\n" . site_escape($page['html']) ?></textarea>
                                </div>
                                <details class="field-wide page-code">
                                    <summary>CSS и JavaScript страницы</summary>
                                    <div class="form-stack">
                                        <?php admin_asset_editors($pageAssets ?? [
                                            'CSS' => site_asset_decode($page['fields']['CSS'] ?? '') ?? '',
                                            'JS' => site_asset_decode($page['fields']['JS'] ?? '') ?? '',
                                        ]); ?>
                                    </div>
                                </details>
                            </div>
                            <div class="form-actions">
                                <button class="button-primary" type="submit">Сохранить</button>
                                <?php if (!$creating): ?>
                                    <a class="button" data-page-open href="<?= site_escape(site_page_url($base, $page['path'])) ?>"<?= ($page['fields']['Hidden'] ?? '0') === '1' ? ' hidden' : '' ?>>Открыть страницу</a>
                                <?php endif; ?>
                            </div>
                        </form>
                        <?php if (!$creating && $page['path'] !== 'index.php'): ?>
                            <details class="page-code" data-page-move>
                                <summary>Переместить страницу</summary>
                                <form class="form-stack" method="post" action="<?= site_escape(admin_page_edit_url($adminUrl, $page['path'])) ?>" data-page-move-form>
                                    <input type="hidden" name="action" value="page-move">
                                    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                                    <input type="hidden" name="path" value="<?= site_escape($page['path']) ?>">
                                    <input type="hidden" name="revision" value="<?= site_escape($page['revision']) ?>">
                                    <label class="field">
                                        Папка назначения
                                        <input name="folder" list="page-folders" placeholder="/Services-1/" maxlength="230" required
                                            data-address-input aria-describedby="page-folder-hint"
                                            pattern="<?= site_escape('/?' . SITE_IDENTIFIER_PATTERN . '(/' . SITE_IDENTIFIER_PATTERN . ')*/?') ?>">
                                    </label>
                                    <datalist id="page-folders">
                                        <?php $folders = array_keys($tree); sort($folders, SORT_STRING); ?>
                                        <?php foreach ($folders as $folder): ?>
                                            <?php if ($folder !== '.'): ?><option value="<?= site_escape('/' . $folder . '/') ?>"><?php endif; ?>
                                        <?php endforeach; ?>
                                    </datalist>
                                    <small class="hint" id="page-folder-hint">В именах папок разрешены A–Z, a–z, 0–9, дефис (-) и подчёркивание (_). Без пробелов. Можно указать новую папку. Подпапки страницы останутся по прежним адресам.</small>
                                    <div><button type="submit">Переместить</button></div>
                                </form>
                            </details>
                        <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</body>
</html>
