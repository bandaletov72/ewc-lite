<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$editText = static function (string $text) use ($editor): string {
    return site_escape(site_translation($text, $editor['language']));
};
$editAdmin = site_url($base, 'admin/');
$editPath = $searchMode ? '' : $page['path'];
$editUrl = $editAdmin . '?' . http_build_query(['page' => site_page_url('', $editPath)]);
$editParent = $editPath !== '' && dirname($originalPath) !== '.' ? dirname($originalPath) : '';
$editHidden = '<input type="hidden" name="csrf" value="' . site_escape($editor['csrf']) . '">'
    . '<input type="hidden" name="path" value="' . site_escape($editPath) . '">'
    . '<input type="hidden" name="revision" value="' . site_escape($page['revision'] ?? '') . '">';
$editIcon = static function (string $icon, string $label): string {
    return '<i class="fa-solid fa-' . $icon . '" aria-hidden="true"></i><span class="toolbar-label">' . $label . '</span>';
};
$editLink = static function (string $url, string $icon, string $name) use ($editIcon, $editText): string {
    $label = $editText($name);
    return '<a class="toolbar-item" href="' . site_escape($url) . '" data-nav-tooltip="' . $label . '">' . $editIcon($icon, $label) . '</a>';
};
?>
<nav class="editor-bar" aria-label="<?= $editText('Панель администратора') ?>">
    <div class="editor-bar-actions">
    <?= $editLink($editAdmin, 'gear', 'Админка') ?>
    <?php if ($editPath !== ''): ?>
        <?= $editLink($editUrl, 'pen-to-square', 'Править страницу') ?>
        <?= $editLink($editAdmin . '?new=1&parent=' . rawurlencode($editParent), 'folder-plus', 'Новый раздел') ?>
        <?= $editLink($editAdmin . '?components=1', 'puzzle-piece', 'Компоненты') ?>
        <?= $editLink($editAdmin . '?layout=1', 'palette', 'Шаблоны оформления') ?>
        <?= $editLink($editAdmin . '?snippets=1', 'tags', 'Подшаблоны') ?>
        <?php foreach (['CSS' => 'paintbrush', 'JS' => 'code'] as $asset => $icon): ?>
            <button class="toolbar-item" type="button" data-nav-tooltip="<?= $asset ?>" data-show-page-dialog="page-asset-<?= $asset ?>"><?= $editIcon($icon, $asset) ?></button>
        <?php endforeach; ?>
        <?php $inMenu = $page['fields']['MenuVisible'] === '1'; ?>
        <?php $menuLabel = $editText($inMenu ? 'Убрать из меню' : 'Показать в меню'); ?>
        <form method="post" action="<?= site_escape($editAdmin) ?>">
            <?= $editHidden ?>
            <input type="hidden" name="visible" value="<?= $inMenu ? '0' : '1' ?>">
            <button class="toolbar-item" name="action" value="live-page-menu" data-nav-tooltip="<?= $menuLabel ?>"><?= $editIcon('list', $menuLabel) ?></button>
        </form>
        <?= $editLink($editUrl . '&confirm=hide', 'eye-slash', 'Скрыть') ?>
        <?php if ($editPath !== 'index.php'): ?>
            <?= $editLink($editUrl . '&confirm=delete', 'trash', 'Удалить') ?>
        <?php endif; ?>
    <?php endif; ?>
    </div>
    <form class="editor-bar-toggle" method="post" action="<?= site_escape($editAdmin) ?>">
        <?= $editHidden ?>
        <input type="hidden" name="enabled" value="<?= $editor['edit'] ? '0' : '1' ?>">
        <button class="editor-switch" name="action" value="public-edit-mode" role="switch" aria-checked="<?= $editor['edit'] ? 'true' : 'false' ?>">
            <span><?= $editText('Режим правки') ?></span><span class="editor-switch-track" aria-hidden="true"></span>
        </button>
    </form>
</nav>
<?php if ($editPath !== ''): ?>
    <?php foreach (['CSS' => 'css', 'JS' => 'javascript'] as $asset => $syntax): ?>
        <dialog class="editor-dialog" id="page-asset-<?= $asset ?>" aria-labelledby="page-asset-title-<?= $asset ?>">
            <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>">
                <div class="header-actions editor-dialog-heading">
                    <h2 id="page-asset-title-<?= $asset ?>"><?= $asset ?> · <?= site_escape($heading) ?></h2>
                    <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
                </div>
                <?= $editHidden ?>
                <input type="hidden" name="asset" value="<?= $asset ?>">
                <textarea name="code" aria-label="<?= $asset ?>" class="short-editor" data-code-mode="<?= $syntax ?>" spellcheck="false" rows="16"><?= "\n" . site_escape(site_asset_decode($page['fields'][$asset] ?? '') ?? '') ?></textarea>
                <div><button class="button-primary" name="action" value="live-page-asset"><?= $editText('Сохранить') ?></button></div>
            </form>
        </dialog>
    <?php endforeach; ?>
<?php endif; ?>
<?php if ($inline): ?>
    <dialog class="editor-dialog component-data-dialog" id="page-banner-editor" aria-labelledby="page-banner-editor-label">
        <div class="header-actions editor-dialog-heading">
            <h2 id="page-banner-editor-label"><?= site_escape(site_banner_edit_slide_label($editor['language'])) ?></h2>
            <a class="button" href="<?= site_escape($editAdmin . '?components=1#banners') ?>" target="_blank" rel="noopener"><?= site_escape(site_banner_defaults_label($editor['language'])) ?></a>
            <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
        </div>
        <iframe data-component-data-iframe title="<?= site_escape(site_banner_edit_slide_label($editor['language'])) ?>"></iframe>
    </dialog>
    <?php $inlineComponents = site_inline_components($page['html'], $components['extensions'], $snippets); ?>
    <?php if ($inlineComponents): ?>
        <?php list($editDataText, $editWideText) = site_data_editor_labels($editor['language']); $hasDataTarget = false; ?>
        <dialog class="editor-dialog" id="page-inline-editor" aria-labelledby="page-inline-title">
            <div class="header-actions editor-dialog-heading">
                <h2 id="page-inline-title"><?= $editText('Компоненты страницы') ?></h2>
                <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
            </div>
            <?php $inlineSchema = site_component_schema(); ?>
            <?php foreach ($inlineComponents as $index => $item): ?>
                <?php $inlineCode = $item['code']; ?>
                <details id="inline-component-<?= $index ?>" class="inline-component-entry">
                    <summary><code><?= site_escape(site_search_clip($inlineCode, 145)) ?></code></summary>
                    <?php $dataTarget = site_inline_data_target($item, $base, $contentHost, $settings); ?>
                    <?php $mediaTarget = $dataTarget && in_array($item['kind'], ['gal', 'fotos', 'files'], true); ?>
                    <?php if ($dataTarget && !$mediaTarget): ?>
                        <?php $hasDataTarget = true; ?>
                        <div class="header-actions component-data-actions">
                            <button type="button" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>" data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>"><?= site_escape($editDataText) ?></button>
                            <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
                        </div>
                    <?php endif; ?>
                    <form class="form-stack" method="post" action="<?= site_escape($editAdmin) ?>" data-inline-editor="<?= site_escape($item['kind']) ?>">
                        <?= $editHidden ?>
                        <input type="hidden" name="index" value="<?= $index ?>">
                        <div class="fields">
                            <?php foreach (site_inline_editor_fields($item) as $field => list($label, $value)): ?>
                                <label class="field"><?= $editText($label) ?>
                                    <?php if ($item['kind'] === 'iblock' && $field === 'template'): ?>
                                        <?php $viewOptions = site_iblock_views(); ?>
                                        <select data-inline-field="template">
                                            <?php if (!isset($viewOptions[$value]) && $value !== ''): ?><option value="<?= site_escape($value) ?>" selected disabled><?= site_escape($value) ?></option><?php endif; ?>
                                            <?php foreach ($viewOptions as $name => $viewLabel): ?><option value="<?= site_escape($name) ?>"<?= $name === $value ? ' selected' : '' ?>><?= $editText($viewLabel) ?></option><?php endforeach; ?>
                                        </select>
                                    <?php elseif ($item['kind'] === 'iblock' && $field === 'type'): ?>
                                        <?php $chartLabels = site_iblock_chart_text($editor['language']); ?>
                                        <select data-inline-field="type">
                                            <?php foreach (site_iblock_chart_types() as $index => $type): ?>
                                                <option value="<?= site_escape($type) ?>"<?= $type === $value ? ' selected' : '' ?>><?= site_escape($chartLabels['types'][$index]) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php else: ?>
                                        <input data-inline-field="<?= site_escape($field) ?>" value="<?= site_escape($value) ?>" maxlength="500">
                                    <?php endif; ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <?php if (isset($inlineSchema[$item['kind']])): ?>
                            <?php $selectedOptions = site_shortcode_options($item['options']); ?>
                            <?php if (isset($selectedOptions['width'])) $selectedOptions['width'] = rtrim($selectedOptions['width'], '%'); ?>
                            <div class="fields">
                                <?php foreach ($inlineSchema[$item['kind']]['settings'] as $name => $option): ?>
                                    <label class="field"><?= $editText($option['label']) ?>
                                        <select data-inline-option="<?= site_escape($name) ?>">
                                            <option value=""><?= $editText('По умолчанию') ?></option>
                                            <?php foreach ($option['options'] as $value => $label): ?>
                                                <option value="<?= site_escape((string) $value) ?>"<?= (string) $value === ($selectedOptions[$name] ?? null) ? ' selected' : '' ?>><?= $editText($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <label class="field"><?= $editText('Код вставки') ?>
                            <textarea class="inline-component-code" name="code" rows="2" maxlength="4000" spellcheck="false"><?= "\n" . site_escape($inlineCode) ?></textarea>
                        </label>
                        <div class="header-actions">
                            <button class="button-primary" name="action" value="live-component"><?= $editText('Сохранить') ?></button>
                            <?php if ($mediaTarget): ?>
                                <?php $hasDataTarget = true; ?>
                                <a class="button" href="<?= site_escape($dataTarget['wide']) ?>" data-editor-data-url="<?= site_escape($dataTarget['modal']) ?>"
                                    data-editor-data-wide="<?= site_escape($dataTarget['wide']) ?>" aria-haspopup="dialog"><?= site_escape(site_file_manager_labels($editor['language'])[0]) ?></a>
                            <?php endif; ?>
                        </div>
                    </form>
                </details>
            <?php endforeach; ?>
        </dialog>
        <?php if ($hasDataTarget): ?>
            <dialog class="editor-dialog component-data-dialog" id="page-component-data" aria-labelledby="page-component-data-label">
                <div class="header-actions editor-dialog-heading">
                    <h2 id="page-component-data-label"><?= site_escape($editDataText) ?></h2>
                    <a class="button" data-component-data-wide target="_blank" rel="noopener"><?= site_escape($editWideText) ?></a>
                    <button type="button" data-close-page-dialog aria-label="<?= $editText('Закрыть') ?>">×</button>
                </div>
                <iframe data-component-data-iframe title="<?= site_escape($editDataText) ?>"></iframe>
            </dialog>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
