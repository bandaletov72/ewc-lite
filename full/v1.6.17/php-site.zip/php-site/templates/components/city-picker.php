<?php if (!defined('SITE_ROOT')) exit; ?>
<div class="city-picker" data-city-picker data-city-url="<?= site_escape(site_url($context['base'])) ?>">
    <label class="field">
        <span><?= site_escape($labels['choose']) ?></span>
        <select data-city-select>
            <?php if ($context['cityId'] === ''): ?><option value="" selected disabled><?= site_escape($labels['choose']) ?></option><?php endif; ?>
            <?php foreach ($context['cities'] as $id => $city): ?>
                <option value="<?= site_escape($id) ?>"<?= $context['cityId'] === $id ? ' selected' : '' ?>><?= site_escape($city['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <small class="notice error" data-city-error role="alert" hidden><?= site_escape($labels['error']) ?></small>
</div>
