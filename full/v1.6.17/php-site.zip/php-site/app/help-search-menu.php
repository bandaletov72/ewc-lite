<?php
if (!defined('SITE_ROOT')) exit;

$help = [
    'ru' => ['Поиск в меню', 'Шорткод [search] выводит поиск в одном ряду с пунктами [main-menu] на компьютере и внутри [mobile-menu] на телефоне. Режим поиска задаётся в основных настройках. Явный [search] в тексте страницы сохраняет приоритет.'],
    'en' => ['Search in navigation', '[search] places search beside the desktop [main-menu] links and inside [mobile-menu] on phones. Choose the search mode in general settings. An explicit [search] in page content takes priority.'],
    'uk' => ['Пошук у меню', '[search] виводить пошук поруч із пунктами [main-menu] на комп’ютері й усередині [mobile-menu] на телефоні. Режим задається в основних налаштуваннях. Явний [search] у тексті сторінки має пріоритет.'],
    'ja' => ['メニューの検索', '[search] はデスクトップの [main-menu] のリンク横と、モバイルの [mobile-menu] 内に表示されます。基本設定で検索形式を変更できます。ページ本文の [search] が優先されます。'],
    'vi' => ['Tìm kiếm trong menu', '[search] đặt ô tìm kiếm cạnh các mục [main-menu] trên máy tính và trong [mobile-menu] trên điện thoại. Chọn chế độ trong cài đặt chung. [search] trong nội dung trang được ưu tiên.'],
    'fr' => ['Recherche dans le menu', '[search] affiche la recherche à côté des liens [main-menu] sur ordinateur et dans [mobile-menu] sur téléphone. Le mode se choisit dans les réglages généraux. Un [search] dans la page est prioritaire.'],
    'de' => ['Suche im Menü', '[search] steht auf dem Desktop neben den Links von [main-menu] und auf dem Handy in [mobile-menu]. Den Suchmodus wählen Sie in den allgemeinen Einstellungen. [search] im Seiteninhalt hat Vorrang.'],
    'es' => ['Búsqueda en el menú', '[search] sitúa la búsqueda junto a los enlaces de [main-menu] en escritorio y dentro de [mobile-menu] en el móvil. El modo se elige en los ajustes generales. Un [search] en el contenido tiene prioridad.'],
    'pt' => ['Pesquisa no menu', '[search] apresenta a pesquisa junto às ligações de [main-menu] no computador e dentro de [mobile-menu] no telemóvel. Selecione o modo nas configurações gerais. [search] no conteúdo tem prioridade.'],
    'ko' => ['메뉴의 검색', '[search]는 데스크톱 [main-menu] 링크 옆과 모바일 [mobile-menu] 안에 표시됩니다. 기본 설정에서 검색 모드를 선택합니다. 본문에 있는 [search]가 우선합니다.'],
    'zh' => ['菜单中的搜索', '[search] 在桌面端与 [main-menu] 的链接并排显示，在手机端显示在 [mobile-menu] 内。搜索模式在常规设置中选择。页面正文中的 [search] 优先。'],
];
$mobile = [
    'ru' => 'В мобильном меню поле поиска открыто сразу. [lang] выводит переключатель языков в мобильном меню. В шапке переключатель виден на компьютере.',
    'en' => 'The search field is always visible inside the mobile menu. [lang] provides language links inside that menu and in the desktop header.',
    'uk' => 'У мобільному меню поле пошуку відразу відкрите. [lang] показує вибір мови в мобільному меню та в шапці на комп’ютері.',
    'ja' => 'モバイルメニューでは検索欄が最初から表示されます。[lang] はモバイルメニュー内とデスクトップのヘッダーに言語を表示します。',
    'vi' => 'Ô tìm kiếm luôn hiển thị khi mở menu di động. [lang] đặt bộ chọn ngôn ngữ trong menu di động và phần đầu trang trên máy tính.',
    'fr' => 'Le champ de recherche est visible dès l’ouverture du menu mobile. [lang] affiche les langues dans ce menu et dans l’en-tête sur ordinateur.',
    'de' => 'Im mobilen Menü ist das Suchfeld sofort sichtbar. [lang] zeigt die Sprachauswahl im mobilen Menü und im Desktop-Kopfbereich.',
    'es' => 'El campo de búsqueda aparece al abrir el menú móvil. [lang] muestra el selector de idioma dentro de ese menú y en el encabezado de escritorio.',
    'pt' => 'O campo de pesquisa aparece ao abrir o menu móvel. [lang] mostra a seleção de idioma nesse menu e no cabeçalho no computador.',
    'ko' => '모바일 메뉴를 열면 검색 입력란이 바로 표시됩니다. [lang]은 모바일 메뉴와 데스크톱 헤더에 언어 선택을 표시합니다.',
    'zh' => '打开手机端菜单后，搜索框直接显示。[lang] 在手机端菜单和桌面端页眉中显示语言切换。',
];
foreach ($mobile as $language => $details) $help[$language][1] .= ' ' . $details;
return $help;
