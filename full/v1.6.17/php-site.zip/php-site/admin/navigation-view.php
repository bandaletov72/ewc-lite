<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$appearanceSections = ['layout', 'headers', 'functions', 'assets'];
$settingsSections = ['settings', 'contacts', 'theme', 'components', 'updates', 'libraries', 'region', 'captcha'];
$groups = [
    'Содержимое' => [
        'snippets' => ['Подшаблоны', $snippetsUrl],
        'iblocks' => ['Инфоблоки', $iblocksUrl],
        'modules' => ['PHP-модули', $modulesUrl],
    ],
    'Формы и заявки' => [
        'forms' => ['Формы', $formsUrl],
        'messages' => ['Сообщения', $messagesUrl],
        'callbacks' => ['Обратные звонки', $callbacksUrl],
        'spam' => ['Антиспам', $spamUrl],
    ],
    'Сайт и сервисы' => [
        'domains' => ['Домены', $domainsUrl],
        'integrations' => ['Интеграции', $integrationsUrl],
        'maintenance' => ['Обслуживание', $maintenanceUrl],
    ],
];
$navigation = [
    ['Страницы', 'file-lines', $adminUrl, $section === 'pages'],
    [admin_page_template_labels($adminLanguage)[0], 'file-code', $pageTemplatesUrl, $section === 'page_templates'],
    [site_city_language($adminLanguage)['cities'], 'location-dot', $citiesUrl, $section === 'cities'],
    ['Настройки', 'gear', $settingsUrl, in_array($section, $settingsSections, true)],
    ['Шаблоны оформления', 'palette', $layoutEditorUrl, in_array($section, $appearanceSections, true)],
    ['Содержимое', 'layer-group', $snippetsUrl, isset($groups['Содержимое'][$section])],
    ['Формы и заявки', 'inbox', $formsUrl, isset($groups['Формы и заявки'][$section])],
    [site_sale_label($adminLanguage)['purchases'], 'bag-shopping', $purchasesUrl, $section === 'purchases'],
    ['Сайт и сервисы', 'screwdriver-wrench', $domainsUrl, isset($groups['Сайт и сервисы'][$section])],
    ['Помощь', 'circle-question', $helpUrl, $section === 'help'],
];
?>
<nav class="site-menu admin-menu" aria-label="<?= admin_l('Разделы админки') ?>">
    <?php foreach ($navigation as list($label, $icon, $url, $current)): ?>
        <a class="admin-nav-item" data-nav-tooltip="<?= admin_l($label) ?>" href="<?= site_escape($url) ?>"<?= $current ? ' aria-current="page"' : '' ?>>
            <i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l($label) ?></span>
        </a>
    <?php endforeach; ?>
</nav>
<?php foreach ($groups as $label => $links): ?>
    <?php if (isset($links[$section])): ?>
        <nav class="site-menu scope-menu" aria-label="<?= admin_l($label) ?>">
            <?php foreach ($links as $name => list($title, $url)): ?>
                <a href="<?= site_escape($url) ?>"<?= $section === $name ? ' aria-current="page"' : '' ?>><?= admin_l($title) ?></a>
            <?php endforeach; ?>
        </nav>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; ?>
