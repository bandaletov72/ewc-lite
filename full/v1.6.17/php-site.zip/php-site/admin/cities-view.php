<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$labels = site_city_language($adminLanguage);
try {
    $cities = site_cities();
    $availableDomains = admin_city_domains($currentHost);
} catch (RuntimeException $exception) {
    echo '<p class="notice error" role="alert">' . admin_l($exception->getMessage()) . '</p>';
    return;
}
$selected = $cityDraftId ?? admin_input($_GET, 'city');
if ($selected !== 'new' && !isset($cities[$selected])) $selected = key($cities) ?? 'new';
$city = $cityDraft ?? ($cities[$selected] ?? ['name' => '', 'domain' => '', 'phones' => site_city_rows()]);
$domains = array_diff($availableDomains, array_column(array_diff_key($cities, [$selected => true]), 'domain'));
if ($city['domain'] !== '' && !in_array($city['domain'], $domains, true)) $domains[] = $city['domain'];
?>
<h1><?= site_escape($labels['cities']) ?></h1>
<nav class="site-menu scope-menu" aria-label="<?= site_escape($labels['cities']) ?>">
    <?php foreach ($cities as $id => $item): ?>
        <a href="<?= site_escape($citiesUrl . '&city=' . $id) ?>"<?= $id === $selected ? ' aria-current="page"' : '' ?>><?= site_escape($item['name']) ?></a>
    <?php endforeach; ?>
    <a href="<?= site_escape($citiesUrl . '&city=new') ?>"<?= $selected === 'new' ? ' aria-current="page"' : '' ?>>+ <?= site_escape($labels['add']) ?></a>
</nav>
<form class="panel form-stack" method="post" action="<?= site_escape($citiesUrl . '&city=' . $selected) ?>">
    <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
    <input type="hidden" name="revision" value="<?= site_escape(admin_settings_revision($cities)) ?>">
    <input type="hidden" name="action" value="save-city">
    <input type="hidden" name="city" value="<?= site_escape($selected) ?>">
    <label class="field"><?= site_escape($labels['name']) ?>
        <input name="name" required maxlength="120" value="<?= site_escape($city['name']) ?>">
    </label>
    <label class="field"><?= site_escape($labels['domain']) ?>
        <select name="domain">
            <option value=""><?= site_escape($labels['unbound']) ?></option>
            <?php foreach ($domains as $domain): ?>
                <option value="<?= site_escape($domain) ?>"<?= $domain === $city['domain'] ? ' selected' : '' ?>><?= site_escape($domain) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <?php foreach ($city['phones'] as $index => $row): ?>
        <details class="field-config disclosure-panel"<?= $error !== '' ? ' open' : '' ?>>
            <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= site_escape($labels['phone']) ?> <?= $index + 1 ?>
                <?php if ($row['label'] !== ''): ?><span><?= site_escape($row['label']) ?></span><?php endif; ?>
                <code>[<?= site_escape(site_city_phone_tokens()[$index]) ?>]</code></summary>
            <div class="form-stack">
            <label class="field"><?= site_escape($labels['label']) ?>
                <input name="phones[<?= $index ?>][label]" maxlength="120" value="<?= site_escape($row['label']) ?>">
            </label>
            <label class="field"><?= site_escape($labels['phone']) ?>
                <input type="tel" name="phones[<?= $index ?>][phone]" maxlength="66" value="<?= site_escape($row['phone']) ?>" placeholder="+7XXXXXXXXXX">
            </label>
            </div>
        </details>
    <?php endforeach; ?>
    <p class="hint"><?= site_escape($labels['help']) ?></p>
    <div><button type="submit" class="button-primary"><?= admin_l('Сохранить') ?></button></div>
</form>
