<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<section class="panel form-stack theme-presets">
    <h2><?= $layoutHost === '' ? admin_t('Общие шаблоны') : admin_t('Шаблоны · ') . site_escape($layoutHost) ?></h2>
    <?php $layoutLabels = admin_maintenance_labels($adminLanguage); ?>
    <?php if ($layoutHost === ''): ?>
        <details class="field-config">
            <summary><?= site_escape($layoutLabels['new-template']) ?></summary>
            <form method="post" action="<?= site_escape($layoutUrl) ?>" class="form-stack">
                <input type="hidden" name="action" value="create-layout-template">
                <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
                <label class="field"><?= admin_l('Ключ') ?><input name="template_name" maxlength="64" pattern="[a-z][a-z0-9_\-]{0,63}" placeholder="notice-box" required></label>
                <label class="field"><?= admin_l('Название') ?><input name="template_label" maxlength="90" required></label>
                <div><button class="button-primary"><?= site_escape($layoutLabels['new-template']) ?></button></div>
            </form>
        </details>
    <?php endif; ?>
    <?php $disclosures = require SITE_ROOT . '/app/help-layout-list.php'; $labels = $disclosures[$adminLanguage] ?? $disclosures['ru']; ?>
    <form class="form-stack" method="post" action="<?= site_escape($layoutUrl) ?>" data-disclosure-list>
        <input type="hidden" name="action" value="save-domain-templates">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($layoutRevision) ?>">
        <div><button type="button" data-disclosure-toggle data-expand="<?= site_escape($labels[0]) ?>"
            data-collapse="<?= site_escape($labels[1]) ?>" aria-expanded="false" hidden><span aria-hidden="true" class="disclosure-arrow"></span>
            <span data-disclosure-text><?= site_escape($labels[0]) ?></span></button></div>
        <?php foreach (admin_domain_template_labels() as $name => $label): ?>
            <?php $block = $layoutDraft[$name]; $tag = ['privacy' => 'privacy-content', 'conf-policy' => 'privacy'][$name] ?? $name; $file = site_layout_blocks()[$name]; ?>
            <details class="field-config disclosure-panel" id="layout-<?= site_escape($name) ?>" data-disclosure-item>
                <summary><span class="disclosure-arrow" aria-hidden="true"></span><?= admin_l($label) ?> <code>[<?= site_escape($tag) ?>]</code></summary>
                <div class="form-stack">
                <?php if ($name === 'home'): ?>
                    <p class="hint"><?= admin_l('Код [page-content] вставляет содержимое главной страницы в шаблон.') ?></p>
                <?php elseif ($name === 'privacy'): ?>
                    <p class="hint"><a href="<?= site_escape(admin_page_edit_url($adminUrl, 'privacy/index.php')) ?>"><?= admin_l('Править страницу') ?> <code>/privacy/</code></a>
                        <?= admin_l('Доступны [site-name] и [site-url].') ?></p>
                <?php elseif ($name === 'cookies'): ?>
                    <p class="hint"><?= admin_l('Сохраните атрибуты data-cookie-preferences, data-cookie-option и data-cookie-choice в своём HTML, чтобы кнопки согласия работали.') ?></p>
                <?php endif; ?>
                <?php if ($file !== ''): ?><p class="hint"><?= admin_l('Исходный файл') ?> <code>templates/<?= site_escape($file) ?></code></p><?php endif; ?>
                <div class="header-actions">
                    <input type="hidden" name="blocks[<?= $name ?>][visibility]" value="1">
                    <label class="choice"><input type="checkbox" name="blocks[<?= $name ?>][mobile]" value="1"<?= ($block['visibility'] & 1) ? ' checked' : '' ?>><?= site_escape($layoutLabels['mobile']) ?></label>
                    <label class="choice"><input type="checkbox" name="blocks[<?= $name ?>][desktop]" value="1"<?= ($block['visibility'] & 2) ? ' checked' : '' ?>><?= site_escape($layoutLabels['desktop']) ?></label>
                </div>
                <div class="field">
                    <label for="<?= $name ?>-source"><?= admin_l('Источник шаблона') ?></label>
                    <select id="<?= $name ?>-source" name="blocks[<?= $name ?>][mode]">
                        <option value="inherit"<?= $block['mode'] === 'inherit' ? ' selected' : '' ?>><?= admin_l($layoutHost === '' ? admin_t('Штатный шаблон') : admin_t('Общий шаблон')) ?></option>
                        <option value="php"<?= $block['mode'] === 'php' ? ' selected' : '' ?>><?= admin_l('Свой PHP') ?></option>
                        <option value="custom"<?= $block['mode'] === 'custom' ? ' selected' : '' ?>><?= admin_l('Свой HTML') ?></option>
                        <option value="stock"<?= $block['mode'] === 'stock' ? ' selected' : '' ?>><?= admin_l('Исходный PHP-шаблон') ?></option>
                    </select>
                </div>
                <div class="header-actions">
                    <button type="submit" name="block_action" value="undo:<?= $name ?>" formnovalidate<?= empty($ownLayouts['_layoutHistory'][$name]) ? ' disabled' : '' ?>><?= admin_l('Отменить последнее изменение') ?></button>
                    <button type="submit" name="block_action" value="reset:<?= $name ?>" formnovalidate<?= $block['mode'] === 'stock' ? ' disabled' : '' ?>><?= admin_l('Вернуть исходный шаблон') ?></button>
                </div>
                <div class="field">
                    <label for="<?= $name ?>-code"><?= admin_l('Код шаблона (PHP и HTML)') ?></label>
                    <textarea id="<?= $name ?>-code" class="short-editor" data-layout-editor="<?= $name ?>-source" data-code-mode="<?= $block['mode'] === 'custom' ? 'html' : 'php-mixed' ?>" rows="10" spellcheck="false" name="blocks[<?= $name ?>][value]"><?= "\n" . site_escape($block['value']) ?></textarea>
                    <small class="hint"><?= admin_l('Редактируйте исходник прямо здесь. Режим «Свой PHP» сохраняет вашу версию после проверки синтаксиса. Для разметки с подшаблонами [city] и [tg] можно выбрать «Свой HTML».') ?></small>
                </div>
                </div>
            </details>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить шаблоны') ?></button></div>
    </form>
</section>
