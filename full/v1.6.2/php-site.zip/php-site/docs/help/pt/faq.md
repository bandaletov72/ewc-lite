# Perguntas frequentes sobre administração

## Instalação e login

### Como lançar um site e abrir o painel de administração?

Para iniciar localmente, execute o comando php -S 127.0.0.1:8000 router.php no diretório do projeto e abra http://127.0.0.1:8000/admin/.. Na hospedagem, primeiro execute php admin/setup.php, depois insira o código único recebido na primeira etapa do assistente em /admin/.

### O que você pode configurar ao iniciar?

Primeiro crie um nome de usuário e uma senha. Na segunda etapa, defina o nome do site, meta descrição padrão, texto do rodapé, paleta e modo de tema. Se você possui PHP GD, pode baixar imediatamente o logotipo e criar um favicon a partir dele. Você pode pular a segunda etapa ou continuar na próxima vez que fizer login.

## Páginas e menus

### Como criar uma página e qual endereço inserir?

Vá para Páginas → Nova página. Insira o endereço, por exemplo /Services-1/Repair/ ou /Services-1/Price_2.php, preencha o título e salve. Para o endereço da pasta, o próprio mecanismo criará os diretórios e index.php. A-Z, a-z, 0-9, hífen e sublinhado são permitidos em nomes. A página principal é reservada na raiz e a criação de páginas nos diretórios de serviço é encerrada.

### Qual é a diferença entre a caixa de seleção “No Menu” e o botão “Ocultar”?

Desmarcar a caixa “No menu” remove o link dos menus normais, mantendo o acesso ao endereço direto. Em uma página com endereço de pasta, a caixa de seleção também controla itens em subpáginas. O botão “Ocultar” remove o link e fecha o endereço público da página até que ela seja publicada novamente.

### Como posso alterar a ordem das páginas ou mover uma pasta inteira?

Arraste o ícone ⠿ para reorganizar as páginas no mesmo nível. Para mover uma página, abra “Mover Página” em seu editor. Para transferir uma pasta junto com suas páginas e arquivos anexados, clique em ↪ ao lado do nome da pasta. Após a transferência, verifique os links manuais e os códigos [include] que apontavam para os endereços antigos.

### Por que as alterações de página não são imediatamente visíveis?

Clique em "Salvar" no editor. Em seguida, use o link "Abrir página" ou "Ir". Se o link desapareceu, verifique se a página está publicada. Para alterações em um subdomínio, verifique o domínio na barra de endereço.

## Design e subdomínios

### Onde posso alterar o título, rodapé, logotipo e favicon?

Abra Configurações → Geral. O campo Texto do rodapé suporta [year] para o ano atual. No bloco “Logos e ícones de sites”, você pode fazer upload de imagens ou clicar em “Criar um favicon a partir de um logotipo”. O carregamento e a conversão requerem PHP GD.

### Como mudar o tema ou fonte e depois voltar ao antigo?

Em Configurações → Tema e Cores, selecione um modo e uma paleta. Salve a paleta atual na lista para poder usá-la mais tarde. O botão "Usar como padrão" lembra a paleta do comando "Retornar tema ao padrão". A fonte pode ser alterada na seção "Bibliotecas e Fontes". Os nomes e exemplos na lista são mostrados nas fontes apropriadas. O valor "Sistema" retorna a fonte normal.

### Onde alterar o cabeçalho e onde inserir um contador, CSS ou JavaScript?

O cabeçalho dos blocos comuns, menu móvel, menu e rodapé são editados na aba “Modelos de Design”. No mesmo local, “Service Headers” insere HTML no cabeçalho ou antes da tag de fechamento do corpo. Para CSS e JavaScript regulares, há uma guia “CSS e JS” separada. O código de uma página é adicionado ao seu editor.

### Como definir diferentes números de telefone e cabeçalhos para subdomínios?

Adicione um subdomínio na seção “Domínios”. Em seguida, defina um valor de submodelo separado na seção Submodelos selecionando o domínio desejado. Altere o cabeçalho e outros blocos usando o botão “Modelos” próximo ao domínio. A versão do domínio tem precedência sobre a versão geral. O DNS e o servidor web devem apontar o subdomínio para o diretório desse site.

### Onde posso alterar os links das redes sociais e as legendas próximas a elas?

Abra “Configurações → Contatos e redes sociais”. Preencha endereços, assinaturas e números de telefone. O código [soc-icons] exibe ícones de todas as redes configuradas. Para um link único, utilize por exemplo [tg] ou [vk].

## Formulários e aplicações

### Como adicionar um formulário a uma página?

Abra Formulários, configure campos, comprimento máximo, obrigatório e texto dos botões. Salve o formulário e cole seu código, por exemplo [form1], no HTML da página.

### Onde posso visualizar as inscrições se não tiver recebido uma notificação por e-mail?

Abra Mensagens. As inscrições são salvas lá após o envio bem-sucedido do formulário. Para notificações, verifique os endereços no campo “Para” do modelo de formulário de email e a funcionalidade da função mail() na hospedagem.

### Como montar uma carta e enviar cópias?

Abra o formulário desejado e encontre o bloco “Mail Template”. Insira os endereços nos campos “Para” e “Cópias (Cc)”, separados por vírgulas. No assunto e no corpo, use chaves de campo entre chaves, por exemplo Olá {name}! Os botões abaixo do texto inserem a variável selecionada. O assunto ou texto em branco usa a notificação padrão.

### Por que o formulário rejeitou a mensagem ou perguntou “Não sou um robô”?

Verifique os campos obrigatórios, comprimento, telefone e formato de e-mail. Os campos de entrada gratuitos usam texto simples, sem HTML ou endereços de sites. As listas de palavras e IPs proibidos estão localizadas na seção Antispam. A caixa de seleção “Usar CAPTCHA” requer uma chave de site e uma chave secreta Google reCAPTCHA v2 para o domínio desejado.

### Onde posso ver as solicitações de retorno de chamada?

Na seção "Retornos de chamada". O componente é adicionado à página com o código [callback] ou [callback=Вызвать мастера]. Com o provedor “Não”, os aplicativos são salvos no painel de administração. Quando a telefonia está configurada, a transmissão manual ou automática está disponível.

## Blocos e componentes de informação

### Como criar um bloco de informações e exibi-lo na página?

Na seção “Infoblocks”, clique em “Novo Infoblock”, configure as colunas e adicione linhas. No nome do infobloco e nas chaves de coluna, use A–Z, a–z, 0–9, hífen ou sublinhado sem espaços. Salve e copie o código incorporado do editor de infoblock. Para obter uma lista de telefones, use o modelo de telefones.

### Como copiar ou substituir todas as linhas de um infoblock?

Abra o bloco de informações e clique em “Editar como texto”. CSV usa o | delimitador. As três primeiras linhas contêm as chaves, nomes e tipos das colunas. Em seguida vêm os dados. Coloque um campo com um delimitador, aspas ou quebra de linha entre aspas duplas e aspas internas duplas.

### O que verificar se a galeria ou lista de arquivos está vazia?

Verifique o caminho no código do componente com a pasta no servidor. Por exemplo, [fotos]/images/myfotos/[/fotos] usa fotos em images/myfotos/ ou templates/images/myfotos/.. Para [files], verifique a extensão do arquivo. Uma lista de extensões e parâmetros suportados pode ser encontrada na ajuda do componente.

### Por que uma solicitação com ?ajax=1 retorna 403?

O fragmento de página requer uma sessão pública válida e um token no mesmo site. Para carregar dentro do site, utilize window.siteFetchContent(), que transfere o token. Para uma transição normal, abra o endereço da página sem o parâmetro ajax.

## Atualizações e backup

### Como atualizar o motor de um site instalado?

Em Configurações → Atualizações, compare a versão instalada com a versão mais recente do GitHub e clique em Mecanismo de atualização. Se o GitHub não estiver disponível, o painel de administração mostrará a última versão verificada. Para atualizar manualmente, passe o arquivo php-site-update.zip para o comando php update.php. O pacote de atualização substitui os arquivos do mecanismo e os modelos padrão. Armazene seus modelos PHP em templates/local/.

### O que devo copiar antes de atualizar ou migrar?

Faça uma cópia de todo o diretório do site junto com os arquivos ocultos. As páginas estão localizadas na raiz e seus diretórios, blocos de informações em data/, configurações e arquivos de conta em admin/.. Salve também seus modelos, imagens enviadas, mensagens e solicitações. A cópia inclui segredos de configuração, portanto mantenha-a fora de um diretório público.

### O que verificar se o painel de administração não consegue salvar as alterações?

Primeiro leia a mensagem ao lado do formulário. Se as alterações entrarem em conflito, copie suas edições e abra o editor novamente. Caso haja erro de gravação, peça à hospedagem para verificar as permissões de gravação do processo PHP na pasta e arquivo desejado admin/write-lock.php.. Caso a atualização falhe, verifique o acesso do servidor ao GitHub e a disponibilidade de PHP Zip e OpenSSL.

