<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<section class="panel form-stack theme-presets">
    <h2><?= $layoutHost === '' ? admin_t('Общие шаблоны') : admin_t('Шаблоны · ') . site_escape($layoutHost) ?></h2>
    <form class="form-stack" method="post" action="<?= site_escape($layoutUrl) ?>">
        <input type="hidden" name="action" value="save-domain-templates">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($layoutRevision) ?>">
        <?php foreach (admin_domain_template_labels() as $name => $label): ?>
            <?php $block = $layoutDraft[$name]; ?>
            <fieldset class="field-config form-stack">
                <legend><?= admin_l($label) ?> <code>[<?= site_escape($name) ?>]</code></legend>
                <?php if ($section === 'layout'): ?>
                    <?php
                    $file = SITE_ROOT . '/templates/' . site_layout_blocks()[$name];
                    $relative = substr($file, strlen(SITE_ROOT) + 1);
                    $source = @file_get_contents($file, false, null, 0, 65537);
                    ?>
                    <details class="template-guide">
                        <summary><?= admin_l('Исходный файл') ?> <code><?= site_escape($relative) ?></code></summary>
                        <?php if ($source === false || strlen($source) > 65536): ?>
                            <p class="hint"><?= admin_l('Исходный файл недоступен для просмотра.') ?></p>
                        <?php else: ?>
                            <pre><code><?= site_escape($source) ?></code></pre>
                        <?php endif; ?>
                    </details>
                    <p class="hint"><?= admin_l('Для правки из админки выберите «Свой HTML» и введите разметку ниже. Для правки исходного PHP скопируйте файл в') ?> <code>templates/local/<?= site_escape(site_layout_blocks()[$name]) ?></code> <?= admin_l('и выберите наследование.') ?></p>
                <?php endif; ?>
                <div class="field">
                    <label for="<?= $name ?>-source"><?= admin_l('Источник шаблона') ?></label>
                    <select id="<?= $name ?>-source" name="blocks[<?= $name ?>][mode]">
                        <option value="inherit"<?= $block['mode'] === 'inherit' ? ' selected' : '' ?>><?= admin_l($layoutHost === '' ? admin_t('Штатный шаблон') : admin_t('Общий шаблон')) ?></option>
                        <option value="custom"<?= $block['mode'] === 'custom' ? ' selected' : '' ?>><?= admin_l('Свой HTML') ?></option>
                        <option value="stock"<?= $block['mode'] === 'stock' ? ' selected' : '' ?>><?= admin_l('Исходный PHP-шаблон') ?></option>
                    </select>
                </div>
                <div class="header-actions">
                    <button type="submit" name="block_action" value="undo:<?= $name ?>" formnovalidate<?= empty($ownLayouts['_layoutHistory'][$name]) ? ' disabled' : '' ?>><?= admin_l('Отменить последнее изменение') ?></button>
                    <button type="submit" name="block_action" value="reset:<?= $name ?>" formnovalidate<?= $block['mode'] === 'stock' ? ' disabled' : '' ?>><?= admin_l('Вернуть исходный шаблон') ?></button>
                </div>
                <div class="field">
                    <label for="<?= $name ?>-code"><?= admin_l('HTML шаблона') ?></label>
                    <textarea id="<?= $name ?>-code" class="short-editor" data-code-mode="html" rows="6" spellcheck="false" name="blocks[<?= $name ?>][value]"><?= "\n" . site_escape($block['value']) ?></textarea>
                    <small class="hint"><?= admin_l('Этот HTML применяется при выборе «Свой HTML». Можно вставлять подшаблоны, например [city] или [tg].') ?></small>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить шаблоны') ?></button></div>
    </form>
</section>
