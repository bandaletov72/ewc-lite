<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function admin_find_settings(string $query, string $adminUrl, string $language, int $limit = 0): array
{
    $settingsTerms = [
        ['Вид поиска', 'settings=1#site-search-settings', 'поиск лупа подсказки search magnifier compact'],
        ['Основные', 'settings=1', 'название сайт футер подвал хлебные крошки breadcrumbs поиск лупа search'],
        ['Логотипы и иконки сайта', 'settings=1#branding', 'лого светлый тёмный favicon фавикон картинки icon'],
        ['Тема и цвета', 'theme=1', 'системная палитра тёмная светлая авто dark light color'],
        ['Библиотеки и шрифты', 'libraries=1', 'типографика шрифт codemirror css js jquery bootstrap font awesome mui'],
        ['Региональные настройки', 'region=1', 'валюта язык дата время часовой пояс gmt currency timezone language'],
        ['Шаблоны оформления', 'layout=1', 'шапка подвал меню header footer sidebar mobile-menu'],
        ['Служебные заголовки', 'headers=1', 'head body счётчик скрипт canonical meta html'],
        ['CSS и JS', 'assets=1', 'стили скрипты stylesheet javascript'],
        ['Домены', 'domains=1', 'домен поддомен dns регион domain host'],
        ['Подшаблоны', 'snippets=1', 'переменные сниппет city spb tel snippet token шаблон'],
        ['Компоненты', 'components=1', 'карусель галерея список файлов ширина gal fotos files width arrows'],
        ['Формы', 'forms=1', 'форма письмо email почта копии captcha поля телефон form'],
        ['Антиспам', 'spam=1', 'спам слова запрет ip блокировка spam block'],
        ['Общие настройки CAPTCHA', 'captcha=1', 'рекапча google капча я не робот ключи'],
        ['Обратные звонки', 'callbacks=1', 'телефон callback ip телефония zadarma'],
        ['Внешние сервисы', 'integrations=1#services', 'интеграции метрика аналитика пиксель telegram cloudflare webhook api'],
        ['Яндекс Карты и Google Maps', 'integrations=1#maps', 'карта точки кластер координаты масштаб map cluster'],
        ['Контакты и соцсети', 'contacts=1', 'телефон telegram vk whatsapp youtube instagram max иконки соцсети contact'],
        ['Обновления', 'updates=1', 'github версия движок расписание обновление update'],
        ['Обслуживание', 'maintenance=1', 'индекс поиск переиндексация кеш кэш расписание cache index'],
        ['PHP-модули', 'modules=1', 'код php дата расширение модули extension module'],
        ['Инфоблоки', 'iblocks=1', 'таблица данные csv цены база data price'],
    ];
    $words = preg_split('/[^\p{L}\p{N}]+/u', $query, -1, PREG_SPLIT_NO_EMPTY);
    if (!$words || count($words) > 8) {
        return [];
    }
    $matches = [];
    foreach ($settingsTerms as list($label, $link, $terms)) {
        $translated = site_translation($label, $language);
        $searchable = $translated . ' ' . $label . ' ' . $terms . ' ' . site_translation($terms, $language);
        foreach ($words as $word) {
            if (!preg_match('~' . preg_quote($word, '~') . '~iu', $searchable)) {
                continue 2;
            }
        }
        $matches[] = ['title' => $translated, 'url' => $adminUrl . '?' . $link];
        if ($limit > 0 && count($matches) >= $limit) {
            break;
        }
    }
    return $matches;
}
