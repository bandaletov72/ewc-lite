<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$guide = require SITE_ROOT . '/app/template-guide.php';
$faq = require SITE_ROOT . '/app/admin-faq.php';
list($localized, $releaseExamples) = require SITE_ROOT . '/app/help-release.php';
$releaseHelp = $localized[$adminLanguage] ?? $localized['ru'];
$currentHelp = require SITE_ROOT . '/app/help-current.php';
$i18nHelp = require SITE_ROOT . '/app/help-i18n.php';
?>
<h1><?= admin_l('Помощь') ?></h1>
<nav class="site-menu scope-menu" aria-label="<?= admin_l('Разделы справки') ?>">
    <a href="#help-i18n"><?= admin_l('Новое в версии 1.6.2') ?></a>
    <a href="#help-current"><?= admin_l('Новое в версии 1.6.1') ?></a>
    <a href="#help-release"><?= admin_l('Новое в версии 1.6.0') ?></a>
    <a href="#help-admin-faq"><?= admin_l('FAQ по админке') ?></a>
    <?php foreach ($guide as $anchor => $group): ?>
        <a href="#help-<?= site_escape($anchor) ?>"><?= admin_l($group['title']) ?></a>
    <?php endforeach; ?>
</nav>
<div class="form-stack template-guide">
    <section class="panel form-stack" id="help-i18n">
        <h2><?= admin_l('Новое в версии 1.6.2') ?></h2>
        <?php foreach ($i18nHelp as $topic => $instructions): ?>
            <div class="help-entry"><h3><?= admin_l($topic) ?></h3><p><?= admin_l($instructions) ?></p></div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack" id="help-current">
        <h2><?= admin_l('Новое в версии 1.6.1') ?></h2>
        <?php foreach (($currentHelp[$adminLanguage] ?? $currentHelp['ru']) as $topic => $instructions): ?>
            <div class="help-entry"><h3><?= site_escape($topic) ?></h3><p><?= site_escape($instructions) ?></p></div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack" id="help-release">
        <h2><?= admin_l('Новое в версии 1.6.0') ?></h2>
        <?php foreach ($releaseHelp as $index => list($topic, $instructions)): ?>
            <div class="help-entry">
                <h3><?= site_escape($topic) ?></h3>
                <p><?= site_escape($instructions) ?></p>
                <?php foreach (($releaseExamples[$index] ?? []) as $example): ?>
                    <pre><code><?= site_escape($example) ?></code></pre>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </section>
    <section class="panel form-stack admin-faq" id="help-admin-faq">
        <h2><?= admin_l('FAQ по админке') ?></h2>
        <?php foreach ($faq as $topic => $questions): ?>
            <section class="faq-topic">
                <h3><?= admin_l($topic) ?></h3>
                <?php foreach ($questions as $question => $answer): ?>
                    <details>
                        <summary><?= admin_l($question) ?></summary>
                        <p><?= admin_l($answer) ?></p>
                    </details>
                <?php endforeach; ?>
            </section>
        <?php endforeach; ?>
    </section>
    <h2><?= admin_l('Помощь по шаблонам и компонентам') ?></h2>
    <?php foreach ($guide as $anchor => $group): ?>
        <section class="panel form-stack" id="help-<?= site_escape($anchor) ?>">
            <h2><?= admin_l($group['title']) ?></h2>
            <?php foreach ($group['entries'] as list($title, $description, $examples)): ?>
                <div class="help-entry">
                    <h3><?= admin_l($title) ?></h3>
                    <p><?= admin_l($description) ?></p>
                    <?php foreach ($examples as $example): ?>
                        <pre><code><?= admin_l($example) ?></code></pre>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endforeach; ?>
</div>
