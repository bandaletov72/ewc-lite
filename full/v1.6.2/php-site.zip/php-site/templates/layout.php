<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$description = site_expand_text($fields['Description'] !== '' ? $fields['Description'] : $settings['description'], $snippets);
$assetUrls = site_asset_urls($base, $page);
$canonical = site_canonical_url($base, $page['path']);
try {
    $headerInserts = site_header_inserts();
} catch (RuntimeException $exception) {
    $headerInserts = ['head' => '', 'bodyEnd' => ''];
}
?>
<!doctype html>
<html lang="<?= site_escape($locale) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if (isset($public['fragment'])): ?>
        <meta name="site-fragment-token" content="<?= site_escape($public['fragment']) ?>">
    <?php endif; ?>
    <title><?= site_escape($title . ' | ' . $settings['name']) ?></title>
    <?php if ($searchMode): ?>
        <meta name="robots" content="noindex,follow">
    <?php elseif ($canonical !== ''): ?>
        <link rel="canonical" href="<?= site_escape($canonical) ?>">
    <?php endif; ?>
    <?php if ($description !== ''): ?>
        <meta name="description" content="<?= site_escape($description) ?>">
    <?php endif; ?>
    <link rel="icon" type="image/png" href="<?= site_escape(site_url($base, $brand['favicon'] ?: 'templates/icons/site.png')) ?>">
    <?php require site_template_file('library-assets.php'); ?>
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/css/site.css')) ?>">
    <link rel="stylesheet" href="<?= site_escape(site_url($base, 'templates/theme.php')) ?>">
    <?php foreach ($assetUrls['CSS'] as $url): ?>
        <link rel="stylesheet" href="<?= site_escape($url) ?>">
    <?php endforeach; ?>
    <script src="<?= site_escape(site_url($base, 'templates/js/site.js') . '?v=' . (require SITE_ROOT . '/app/version.php')) ?>" defer></script>
    <?php if ($settings['searchMode'] !== 'off'): ?>
        <script src="<?= site_escape(site_url($base, 'templates/search-browser.php') . '?v=' . (require SITE_ROOT . '/app/version.php')) ?>" defer></script>
    <?php endif; ?>
    <?php if ($editor && site_code_editor_on()): ?>
        <script src="<?= site_escape(site_code_editor_url($base)) ?>" defer></script>
    <?php endif; ?>
    <?php $analytics = site_public_analytics(); ?>
    <?php if ($analytics): ?>
        <meta name="site-analytics" content="<?= site_escape((string) json_encode($analytics)) ?>">
    <?php endif; ?>
    <?php foreach ($assetUrls['JS'] as $url): ?>
        <script src="<?= site_escape($url) ?>" defer></script>
    <?php endforeach; ?>
    <?= $headerInserts['head'] ?>
</head>
<body<?= $editor ? ' data-code-auto="' . site_escape(site_translation('Авто', $editor['language']))
    . '" data-code-syntax="' . site_escape(site_translation('Язык подсветки', $editor['language'])) . '"' : '' ?>>
    <a class="skip-link" href="#content"><?= site_escape(site_translation('Перейти к содержимому', $locale)) ?></a>
    <?php if ($editor): require site_template_file('editor-bar.php'); endif; ?>
    <header class="site-header">
        <div class="container header-row">
            <div class="desktop-header"><?= site_layout_block('header', $components) ?></div>
            <?= site_layout_block('mobile-menu', $components) ?>
            <?php if ($page['path'] !== '' && count(site_region_settings()['languages']) > 1): ?>
                <nav class="site-menu language-menu" aria-label="<?= site_escape(site_translation('Язык', $locale)) ?>">
                    <?php foreach (site_region_settings()['languages'] as $code): ?>
                        <a lang="<?= $code ?>" href="<?= site_escape(site_page_url($base, $originalPath) . '?lang=' . $code) ?>"<?= $locale === $code ? ' aria-current="true"' : '' ?>><?= site_escape(site_languages()[$code]) ?></a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </div>
    </header>

    <?php if ($settings['searchMode'] !== 'off'): ?>
    <?php $compactSearch = $settings['searchMode'] === 'compact'; ?>
    <div class="container site-search-bar">
        <?php if ($compactSearch): ?>
        <details class="site-search-compact"<?= $searchMode ? ' open' : '' ?>>
            <summary aria-label="<?= site_escape(site_translation('Поиск по сайту', $locale)) ?>" title="<?= site_escape(site_translation('Поиск по сайту', $locale)) ?>">
                <span class="site-search-icon" aria-hidden="true"></span>
            </summary>
        <?php endif; ?>
        <form class="site-search" role="search" data-site-search action="<?= site_escape(site_url($base)) ?>" method="get">
            <label class="site-search-label" for="site-search-input"><?= site_escape(site_translation('Поиск по сайту', $locale)) ?></label>
            <input id="site-search-input" type="search" name="search" maxlength="100" autocomplete="off"
                placeholder="<?= site_escape(site_translation('Поиск по сайту', $locale)) ?>"
                value="<?= site_escape($searchQuery) ?>" aria-controls="site-search-suggestions" required>
            <?php if ($compactSearch): ?>
                <button class="site-search-enter" type="submit" aria-label="<?= site_escape(site_translation('Найти', $locale)) ?>"><span aria-hidden="true">↵</span></button>
            <?php else: ?>
                <button type="submit"><?= site_escape(site_translation('Найти', $locale)) ?></button>
            <?php endif; ?>
            <ul class="site-search-suggestions" id="site-search-suggestions" hidden></ul>
        </form>
        <?php if ($compactSearch): ?></details><?php endif; ?>
    </div>
    <?php endif; ?>

    <?php require site_template_file('breadcrumbs.php'); ?>
    <?php $sidebar = site_layout_block('menu', $components); ?>
    <div class="container site-layout<?= trim($sidebar) !== '' ? ' has-sidebar' : '' ?>">
        <?php $embeddedContent = true; require site_template_file('content.php'); ?>
        <?php if (trim($sidebar) !== ''): ?>
            <aside class="site-sidebar"><?= $sidebar ?></aside>
        <?php endif; ?>
    </div>

    <?= site_layout_block('footer', $components) ?>
    <?= $headerInserts['bodyEnd'] ?>
</body>
</html>
