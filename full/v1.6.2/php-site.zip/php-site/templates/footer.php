<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$credit = $snippets['author'] ?? site_author_credit($locale ?? 'ru');
$footer = $settings['footer'];
$parts = preg_split('/\[author\]/i', $footer);
if ($footer === '') {
    $footerText = site_escape('© ' . ($snippets['year'] ?? date('Y')) . ' ' . $settings['name']);
} else {
    $footerText = implode($credit, array_map(static function (string $part) use ($snippets): string {
        return site_escape(site_expand_text($part, $snippets));
    }, $parts));
}
?>
<footer class="site-footer">
    <div class="container">
        <?= $footerText ?>
        <?php if (count($parts) === 1): ?>
            <small class="site-credit"><?= $credit ?></small>
        <?php endif; ?>
    </div>
</footer>
