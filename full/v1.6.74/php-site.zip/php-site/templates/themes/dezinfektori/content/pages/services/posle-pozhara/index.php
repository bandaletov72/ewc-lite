<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Санитарная обработка после пожара
Heading: Санитарная обработка после пожара
Description: Заявка на оценку обработки помещения и устранения запаха гари после пожара.
Menu: После пожара
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 64
AnnouncementIcon: [fa-icon=fire]

<p class="dz-lead">Когда доступ в помещение разрешён, укажите площадь, сколько времени прошло после пожара и в каких комнатах остался запах. По описанию уточним возможность санитарной обработки и объём работ.</p>
<section class="dz-section" id="price">
    <h2>Стоимость</h2>
    [iblock=table]/data/dez-price-posle-pozhara.txt[/iblock]
</section>
<section class="dz-section">
    <h2>Связанные услуги</h2>
    <ul class="dz-service-links">
    <li><a href="/services/dezinfekciya/dezodoraciya/">Дезодорация помещений</a></li>
    </ul>
</section>
<section class="dz-request" id="request"><div><h2>Обсудить объект</h2><p>Оставьте телефон и кратко опишите ситуацию. Уточним возможные работы и стоимость.</p></div><div>[form86]</div></section>
