<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Санитарная обработка после затопления
Heading: Санитарная обработка после затопления
Description: Заявка на оценку санитарной обработки, устранения запаха и последствий сырости после затопления.
Menu: После затопления
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 63
AnnouncementIcon: [fa-icon=droplet]

<p class="dz-lead">Когда источник воды устранён, опишите повреждённые помещения, площадь и материалы, которые намокли. Уточним возможность санитарной обработки после устранения протечки и просушки.</p>
<section class="dz-section" id="price">
    <h2>Стоимость</h2>
    [iblock=table]/data/dez-price-posle-zatopleniya.txt[/iblock]
</section>
<section class="dz-section">
    <h2>Связанные услуги</h2>
    <ul class="dz-service-links">
    <li><a href="/services/dezinfekciya/plesen-i-gribok/">Обработка от плесени</a></li>
    <li><a href="/services/dezinfekciya/dezodoraciya/">Устранение запаха</a></li>
    </ul>
</section>
<section class="dz-request" id="request"><div><h2>Обсудить объект</h2><p>Оставьте телефон и кратко опишите ситуацию. Уточним возможные работы и стоимость.</p></div><div>[form86]</div></section>
