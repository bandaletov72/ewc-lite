<?php
$pageFile = __FILE__;
require __DIR__ . '/../../index.php';
__halt_compiler();
Title: Санитарная обработка участка
Heading: Санитарная обработка участка
Description: Подбор обработки участка от клещей, комаров и других насекомых.
Menu: Уход за участком
MenuVisible: 1
MobileMenu: 1
Sitemap: 1
Order: 61
AnnouncementIcon: [fa-icon=seedling]

<p class="dz-lead">Расскажите, где на участке замечены насекомые, сколько соток нужно обработать и есть ли рядом водоём или места, где гуляют дети и животные. Это поможет подобрать услугу и согласовать границы обработки.</p>
<section class="dz-section" id="price">
    <h2>Стоимость</h2>
    [iblock=table]/data/dez-price-uhod-za-uchastkom.txt[/iblock]
</section>
<section class="dz-section">
    <h2>Связанные услуги</h2>
    <ul class="dz-service-links">
    <li><a href="/services/dezinsekciya/kleshchi/">Обработка от клещей</a></li>
    <li><a href="/services/dezinsekciya/komary/">Обработка от комаров</a></li>
    </ul>
</section>
<section class="dz-request" id="request"><div><h2>Обсудить объект</h2><p>Оставьте телефон и кратко опишите ситуацию. Уточним возможные работы и стоимость.</p></div><div>[form86]</div></section>
