# Deutsch · Eurowebcart CMS Light

- [Management](de/readme.md)
- [Admin-FAQ](de/faq.md)
- [Vorlagen und Komponenten](de/templates.md)

## Mobilmenü · 1.6.7

- Im Hauptmenü anzeigen
- Im Mobilmenü anzeigen
- Im Mobilmenü ausblenden


## Komponentendaten direkt bearbeiten · 1.6.6

Im Bearbeitungsmodus bieten Infoblöcke, Formulare [formX], Textbausteine [tel] und andere Komponenten mit Dateneditor die Optionen Daten und Vollbild. Die Ansichtsliste enthält registrierte Vorlagen. Wählen Sie Stammordner für die oberste Ebene. [list-pages] listet veröffentlichte Seiten im Bereich und seinen Unterordnern. Schließen Sie das Sprachmenü durch einen Klick außerhalb oder mit Escape.


## Konfigurationsdateien, Karten und Vorlagen · 1.6.5

Unter Wartung → Konfigurationsdateien bearbeiten Sie .htaccess, robots.txt und sitemap.xml. Die Sitemap enthält angekreuzte veröffentlichte Seiten. Die vorige .htaccess-Version ist wiederherstellbar.

Geben Sie Breiten- und Längengrad ein. [map] zeigt den Ort der Seite, [maps] sammelt die Orte veröffentlichter Seiten. center und zoom bestimmen den Ausschnitt. Der Kartenanbieter steht unter Integrationen.

[main-menu] ist das Menü unter dem Kopfbereich mit ausklappbaren Unterpunkten. Eigene Vorlagen und die Gerätesichtbarkeit werden unter Layoutvorlagen eingestellt. Beim Hinzufügen einer Domain in den Textbausteinen öffnet sich das Domainformular. Verwenden Sie [privacy] für den Datenschutzlink.

Unter Integrationen können Sie die IDs von JivoSite, Microsoft Clarity und Umami Cloud, den Botfaqtor-Code oder einen Slack-Webhook speichern. Anleitungen stehen neben den Feldern. In Zadarma prüfen Sie den Kontostand oder testen SMS und Anrufe. Tests können kostenpflichtig sein. Für [payment] hinterlegen Sie Links von YooMoney, PayPal und SBP. Den Zahlungsstatus sehen Sie beim Anbieter.

Im HTML- und visuellen Editor finden Sie Symbole für Formatierung, H1–H5 und Listen. Setzen Sie den Cursor und wählen Sie Vorlage, Komponente, Bild oder Symbol. Formulare und Komponentenoptionen stehen zur Auswahl. Font Awesome ist bei aktivierter Bibliothek verfügbar.

Klicken Sie auf einen Ordnernamen, um den Bereich rechts zu verwalten. Wählen Sie einen übergeordneten Bereich oder stellen Sie Desktopmenü, Mobilmenü und Weiterleitungs-URL ein. Eine leere Bereichsseite listet Unterbereiche auf. Unter Wartung bearbeiten Sie Regeln wie /contact.html => /contacts/ und Seiten in /error/. Sprache und Suche haben mobile Symbole.

```text
[map]
[map center="55.7558,37.6173" zoom=14]
[maps center="55.7558,37.6173" zoom=11]
[main-menu]
[lang]
[privacy]
[payment]
```

```php
$var = translit("Москва"); // Moskva
```


## Schaltflächen im Kopfbereich der Verwaltung · 1.6.4

Der Globus öffnet die Website, der Pfeil meldet Sie ab. Auf Mobilgeräten sind nur die Symbole zu sehen. Fahren Sie mit der Maus darüber oder fokussieren Sie die Schaltflächen per Tastatur, um die Beschriftung zu sehen.

Inhalte, Formulare und Anfragen sowie Website und Dienste öffnen sich direkt. Unter dem Hauptmenü erscheinen die Registerkarten des gewählten Bereichs.

Fügen Sie [bread-crumbs] oder [search] in das HTML der Startseite (index.php) oder einer Vorlage ein. Jeder Block erscheint einmal an der gewählten Stelle. Die Einstellungen für Brotkrümelnavigation und Suche gelten weiterhin. [privacy] verweist auf /privacy/. Bearbeiten Sie die Datenschutzerklärung unter Seiten.

```text
[bread-crumbs]
[search]
[privacy]
```


## Neu in Version 1.6.3

### Startseite und Datenschutzbestimmungen

Öffnen Sie „Designvorlagen“, um die Startseite und die Seite /privacy.php zu bearbeiten. Der Code [page-content] zeigt den Inhalt der Hauptseite an. In der Richtlinie [site-name] und [site-url] übernehmen Sie den Namen und die öffentliche Adresse aus „Einstellungen → Allgemein“. Vervollständigen Sie den Anfangstext mit Informationen zu Ihrer Website und der Datenverarbeitung.

### Cookie und zurück nach oben

In der Fußzeile stellt [conf-policy] einen Link zur Richtlinie bereit, [cookies] öffnet die Einstellungen und [top] scrollt zum Seitenanfang. Analysen und integrierte CMS-Karten warten auf Zustimmung. Manuell zu Vorlagen oder Service-Headern hinzugefügte Skripte erfordern eine eigene Konfiguration.

### Herausgeber functions.php

Öffnen Sie „Designvorlagen → Funktionen“ nach der Registerkarte „Service-Header“. Fügen Sie dem zurückgegebenen Array Abschlüsse hinzu. Rufen Sie in Ihrer PHP-Vorlage `translit("Москва")` oder `ew_call("translit", "München")` auf. Fügen Sie im HTML [func=translit value="Москва и München"] ein. Das Beispiel erzeugt `Moskva i Muenchen`.

### Bearbeiten von Standardvorlagen

Im Feld „Design-Vorlagen“ ist bereits der PHP- und HTML-Quellcode mit Hervorhebung enthalten. Wählen Sie beim Bearbeiten einer Standardvorlage „Benutzerdefiniertes PHP“ aus. Beim Speichern wird eine benutzerdefinierte Version erstellt. Mit den Schaltflächen neben der Vorlage können Sie die letzte Bearbeitung rückgängig machen oder das Original wiederherstellen.

### PHP-Prüfung vor dem Speichern

Designvorlagen-, Modul- und functions.php-Editoren überprüfen die Syntax mit dem Befehl `php -l`. Im Fehlerfall bleibt die vorherige Version bestehen. Um die PHP-CLI auf dem Server auszuwählen, verwenden Sie die Variable `SITE_PHP_LINT_BINARY`.

### Hintergrundbeleuchtung und kompakte Suche

CodeMirror ist bei Neuinstallationen standardmäßig aktiviert. Die Einstellung befindet sich unter „Bibliotheken und Schriftarten“. Bei der kompakten Suche wird das Feld nach links erweitert, das Kreuz löscht die Zeile und die Eingabetaste startet die Suche.

### Admin-Menü und Bearbeitungsfeld

Im Menü unter der Kopfzeile des Admin-Panels und im Bearbeitungsfeld auf der Website werden Symbole mit Beschriftungen angezeigt. Symbole bleiben auf dem schmalen Bildschirm. Tooltips öffnen sich beim Hover und Tastaturfokus auf einem schmalen Bildschirm. „Ausblenden“ befindet sich neben den restlichen Seitenaktionen. Der Bearbeitungsmodus-Schalter befindet sich auf der rechten Seite.

### Beschreibung und Code des PHP-Moduls

In „PHP-Modulen“ handelt es sich bei der Kurzbeschreibung um Klartext. Fügen Sie den Hauptteil der Funktion in ein separates Feld „Quellcode · PHP“ ein.

## Neu in Version 1.6.2

### Sprache der Administration und Hilfe

Aktivieren Sie in den regionalen Einstellungen die gewünschten Sprachen. Das Sprachauswahlmenü in der Kopfzeile ändert die Benutzeroberfläche und die Hilfe, während der aktuelle Abschnitt beibehalten wird. Seitentexte und die Werte Ihrer Einstellungen werden in ihrer ursprünglichen Form gespeichert.

### Kellerdekoration

Der Code [author] zeigt die Signatur Eurowebcart CMS Light, den Autorennamen Бандалетов Павел und einen Link zu GitHub an. Um auszuwählen, wo Ihre Signatur in Ihrer benutzerdefinierten HTML-Fußzeile platziert werden soll, fügen Sie [author] in die entsprechende Zeile ein.

### Hintergrundbeleuchtung im Bearbeitungsmodus

Bewegen Sie den Mauszeiger über den Link „Komponente bearbeiten“ oder legen Sie den Tastaturfokus darauf fest. Der Rahmen hebt die Ausgabe dieser bestimmten Einfügung hervor.

### Wo kann man die Suche ändern?

Wählen Sie unter „Einstellungen → Allgemein“ den Suchtyp aus. Unter „Wartung“ können Sie Seiten neu indizieren und das Feld im Admin-Header sucht nach Einstellungen.

### Ergebnisse und Vorschläge

Die Suche zeigt 20 nummerierte Ergebnisse je Seite. Die kompakte Suche öffnet sich links neben der Lupe. Das Eingabefeld enthält ein Enter-Symbol. Suchvorschläge in der Verwaltung verlinken direkt auf die Einstellungen.

## Neu in Version 1.6.1

### Suche

Wählen Sie in den Grundeinstellungen Aus, Kompakt mit Lupe oder Erweitert. Die Adminleiste durchsucht Einstellungen. Der Index aktualisiert sich nach Änderungen; für FTP gibt es eine geplante Aktualisierung. Eingebundene Seiten und Datenblöcke werden indexiert, PHP-Module nicht ausgeführt.

### PHP-Module

Klappen Sie ein Modul für Einstellungen und verwendende Seiten auf. Geben Sie Modul-ID, Dateiname und PHP-Funktionsrumpf ein. Beim Umbenennen bleibt [php]id[/php] unverändert. CodeMirror lässt sich für Syntaxhervorhebung aktivieren.

### Vorlagen und Übersetzungen

Pro Vorlage können Sie bis zu acht Änderungen rückgängig machen oder das ursprüngliche PHP wiederherstellen. Die Historie ist je Domain getrennt. Eigenes HTML ändern Sie in der Verwaltung, PHP liegt in templates/local/. Die Sprachwahl bleibt beim Anlegen verfügbar; Übersetzungen werden mit der Seite verschoben.

### Integrationen und Wartung

CAPTCHA, Karten, Telefonie und Analyse verlinken die Anbieter. URL und Token der Rückruf-API sind in der Verwaltung einstellbar. Beim Wechsel auf die Hauptdomain gelten die Platzhalter der registrierten Subdomain weiter. Planen Sie php update.php --scheduled alle 15 Minuten ein.

## Neu in Version 1.6.0

### Suche und Cache

Erstellen Sie den Textindex unter Wartung nach Änderungen im Adminbereich oder per FTP neu. Die Suchvorschläge erfassen öffentliche Seiten in der gewählten Sprache. Der Cache ist zunächst aus und kann dort aktiviert oder geleert werden. Formulare und dynamische Komponenten werden pro Anfrage verarbeitet.

### Bearbeitung auf der Website

Nach der Anmeldung erscheint die Werkzeugleiste. Der Schalter ganz rechts aktiviert die Bearbeitungslinks auf der gesamten Website. CSS und JS der Seite öffnen sich im Dialog. Die Verwaltung bietet HTML- und visuelle Bearbeitung, das Einfügen von Codes sowie AJAX-Sammeluploads und Sortierung.

### Komponenten und Navigation

Fehlende Parameter verwenden die globalen Einstellungen. width akzeptiert 100, 50, 33 oder 25, auch mit %. Auf Smartphones stehen die Blöcke untereinander. numbers=off blendet den Zähler aus. Wischen wechselt das Bild; das mobile Menü kommt von rechts. Die Brotkrumennavigation lässt sich in den Grundeinstellungen deaktivieren.

```text
[gal width=50 numbers=off arrows=on fit=cover]/images/myfotos/[/gal]
[fotos width=50% columns=3 captions=on]/images/myfotos/[/fotos]
[files width=33 icons=off size=on download=on]/files/myfiles/[/files]
```

### Sprachen, Darstellung und Preise

Wählen Sie Sprachen, Währung, Zahlen-, Datums- und Zeitformate sowie Zeitzone in den Regionaleinstellungen. Speichern Sie die Übersetzung als index_en.php neben index.php. Ohne Übersetzung erscheint der Originalinhalt. Preisfelder verwenden die gewählte Währung. Vorschau, getrennte helle und dunkle Logos und eigene Schriftbeispiele für Roboto Condensed sind verfügbar.

```text
/contacts/index.php → /contacts/index_en.php
```

### Formulare, Anfragen und Integrationen

Gemeinsame Google-reCAPTCHA-v2-Schlüssel und Aktivierung stehen in den CAPTCHA-Einstellungen; Formulare bieten eigene Optionen. Nachrichten und Rückrufe stehen ungelesen zuerst mit 20 je Seite. Integrationen umfassen Zadarma, Telegram, Analytik und Google- oder Yandex-Karten mit optionalen Clustern. Der Testdialog prüft die aktive Bibliothek und zeigt Einfügecode. CodeMirror unterstützt Auto, HTML, CSS, JS, PHP und RAW.

```text
[map lat=55.7558 lng=37.6173 title="Office" zoom=13 provider=yandex url="/contacts/" button="Open"]
```

```text
[callback button="Call me" title="Callback" submit="Send" placeholder="+7(900)123-45-67"]
```

### PHP-Module

Unter PHP-Module bearbeiten Sie Namen, Beschreibung und Verfügbarkeit der registrierten Module. server-date zeigt das Datum im regionalen Format. Ausführbare Dateien liegen in einem geschützten Verzeichnis und werden von Entwicklern installiert.

```text
[php]server-date[/php]
```

## Seiteneinstellungen · 1.6.8

Erstellen Sie Inhalte unter „Bearbeiten“. Adresse, Menü und Veröffentlichungszeit stehen in den Seiteneinstellungen. SEO enthält Titel, Beschreibung, Schlüsselwörter und die Aufnahme in die Sitemap. Unter „Karten“ stehen Koordinaten und Beispiele.

Leere Datumsfelder bedeuten keine Einschränkung. Es gilt die Zeitzone der Website. Verborgene Seiten müssen separat veröffentlicht werden.

- `[map]` — Karte mit dem Standort der aktuellen Seite.
- `[maps]` — Karte mit den Standorten aller veröffentlichten Seiten.

## Banner und Bildeditor · 1.6.8

Verwalten Sie Sets und Folien unter Komponenten. Verwenden Sie Fotos aus einem Ordner, legen Sie Texte und Schaltflächen für Links, Formulare oder Rückrufe an und planen Sie die Anzeige. Im Bearbeitungsmodus erscheinen Aktionen an der Folie. Die Bildauswahl unterstützt Ordner, Uploads, Löschen und gedrehte oder skalierte Kopien mit GD. Font-Awesome-Symbole sind nach Namen suchbar.

```text
[banners]
[banners set=summer arrows=on numbers=off]
[banners]/images/myfotos/[/banners]
```

## Sprachen · 1.6.9

Der Tab „Sprachen“ listet die Seitensprachen auf. „Öffnen“ führt zur gespeicherten Version. „Übersetzung erstellen“ öffnet einen leeren Editor.

Ein Unterbereich entsteht im aktuellen Bereich, ein gleichrangiger Bereich daneben und ein Hauptbereich auf der obersten Ebene der Website.

## PHP-Kompatibilität und Navigation · 1.6.10

Die Mindestversion ist PHP 7.2. Website und Administration unterstützen PHP 8.6. Verwenden Sie in eigenen Modulen und Vorlagen die Syntax der PHP-Version Ihres Servers.

Der aktuelle Eintrag in [bread-crumbs] zeigt veröffentlichte Bereiche derselben Ebene aus dem Hauptmenü. Die eingestellte Seiten-URL gilt für Menüs, Bereichslisten, Brotkrümelnavigation, Suchergebnisse und Vorschläge.

Der Papierkorb entfernt eine Zeile aus dem Infoblock-Editor. Beim Entfernen einer Spalte gehen alle ihre Werte verloren. Änderungen werden beim Speichern übernommen, auch automatisch nach dem Umsortieren.

### Sicherungen der Website

Das private ZIP enthält Seiten, Medien, Infoblöcke, Einstellungen, eigene Vorlagen und PHP-Module. Administratorkonto und Anfragen werden separat gespeichert. PHP Zip wird benötigt.

Inhalte und Einstellungen ersetzen. Zuerst wird der aktuelle Stand gesichert.

### Ungenutzte Dateien bereinigen

Der Scan sucht Medien ohne Verweise in gespeicherten Inhalten. Prüfen Sie die Liste und wählen Sie Dateien aus. Zuvor wird eine Sicherung erstellt. Beim Entfernen eines Komponentencodes bleiben Ordner und Dateien erhalten.

### Punkt auf der Karte wählen

Erstellen Sie in der Yandex-Konsole einen Schlüssel für „JavaScript API“ und begrenzen Sie ihn per HTTP-Referrer. Wählen Sie in der Karten-Registerkarte der Seite einen Punkt und übernehmen Sie seine Koordinaten.

Markieren Sie Text zum Ausrichten oder zum Entfernen seiner Formatierung. Klicken Sie auf ein Bild, um Eigenschaften zu ändern. Ziehen Sie es zum Verschieben oder ziehen Sie an seiner Ecke. Links unterstützen URL, E-Mail, Telefonnummer und Anker. Schaltflächen öffnen URLs, Formulare, Rückrufe oder Zahlungslinks des Anbieters.

HTML und visueller Editor wechseln den Modus per Tab. SUP, SUB und Absatz fügen die passenden Elemente ein. Komponenten zeigen ihren Einfügecode. Fehlende Medienordner werden beim Einfügen erstellt. Namen nutzen lateinische Buchstaben, Ziffern, Bindestriche und Unterstriche. Der Tab „Sprachen“ führt zu den Spracheinstellungen.

```text
[button action="url" label="Contacts" url="/contacts/"]
[button action="form" label="Write to us" form="form1"]
[button action="callback" label="Call me"]
[button action="payment" label="Pay" amount="1250.00" currency="RUB" yoomoney="410010000000000"]
[map]
[maps]
```
