<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$tokens = array_unique(array_merge(['header', 'menu', 'mobile-menu', 'footer', 'bread-crumbs', 'search', 'privacy', 'author', 'year', 'date', 'time', 'contacts', 'phones', 'soc-icons'],
    array_keys(site_snippet_values($currentHost)), array_keys($siteSettings['variables'])));
?>
<div class="field field-wide" data-content-editor>
    <label for="html"><?= admin_l('Содержимое страницы') ?></label>
    <div class="header-actions" data-editor-toolbar hidden>
        <button type="button" data-editor-mode="html" aria-pressed="true">HTML</button>
        <button type="button" data-editor-mode="visual" aria-pressed="false"><?= admin_l('Визуальный редактор') ?></button>
    </div>
    <div class="header-actions" data-editor-format hidden>
        <button type="button" data-editor-command="bold"><strong><?= admin_l('Жирный') ?></strong></button>
        <button type="button" data-editor-command="italic"><em><?= admin_l('Курсив') ?></em></button>
        <button type="button" data-editor-command="formatBlock" data-editor-value="h2"><?= admin_l('Заголовок H2') ?></button>
        <button type="button" data-editor-command="insertUnorderedList"><?= admin_l('Маркированный список') ?></button>
        <button type="button" data-editor-command="createLink"><?= admin_l('Ссылка') ?></button>
    </div>
    <textarea id="html" name="html" data-code-mode="html" spellcheck="false" rows="12"><?= "\n" . site_escape($page['html']) ?></textarea>
    <iframe data-editor-frame hidden sandbox="allow-same-origin"
        data-src="<?= site_escape(site_url($base, 'templates/editor-frame.php')) ?>" title="<?= admin_l('Визуальный редактор страницы') ?>"></iframe>
    <details data-editor-insert hidden>
        <summary><?= admin_l('Вставить шаблон или компонент') ?></summary>
        <div class="fields">
            <label class="field"><?= admin_l('Компонент') ?>
                <select data-editor-component>
                    <?php foreach (['snippet' => admin_t('Подшаблон'), 'gal' => admin_t('Карусель'), 'fotos' => admin_t('Фотогалерея'), 'files' => admin_t('Список файлов'),
                        'include' => admin_t('Другая страница'), 'form' => admin_t('Форма'), 'callback' => admin_t('Обратный звонок'),
                        'iblock' => admin_t('Инфоблок'), 'map' => admin_t('Точка на карте'), 'php' => admin_t('PHP-модули')] as $key => $label): ?>
                        <option value="<?= $key ?>"><?= admin_l($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="php"><?= site_escape(admin_l('PHP-модули')) ?>
                <select data-editor-param="module">
                    <?php foreach (site_extensions() as $name => $definition): ?>
                        <?php if (!site_php_module_enabled($name)) continue; ?>
                        <option value="<?= site_escape($name) ?>"><?= site_escape(site_php_module_settings()[$name]['label'] ?? admin_t($definition['label'] ?? $name)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="snippet"><?= admin_l('Подшаблон') ?>
                <select data-editor-param="token">
                    <?php foreach ($tokens as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                </select>
            </label>
            <?php foreach ([
                'path' => [admin_t('Путь'), 'gal fotos files include iblock', '/images/myfotos/'],
                'form' => [admin_t('Код формы'), 'form', 'form1'],
                'title' => [admin_t('Название точки или заголовок формы'), 'map callback', admin_t('Офис')],
                'lat' => [admin_t('Широта'), 'map', '55.7558'],
                'lng' => [admin_t('Долгота'), 'map', '37.6173'],
                'zoom' => [admin_t('Масштаб'), 'map', '13'],
                'url' => [admin_t('URL кнопки'), 'map', '/contacts/'],
                'button' => [admin_t('Текст кнопки'), 'map callback', admin_t('Подробнее')],
                'submit' => [admin_t('Текст кнопки отправки'), 'callback', admin_t('Отправить номер')],
                'placeholder' => [admin_t('Подсказка в поле телефона'), 'callback', '+7(900)123-45-67'],
            ] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <input data-editor-param="<?= $key ?>" placeholder="<?= site_escape($field[2]) ?>">
                </label>
            <?php endforeach; ?>
            <?php foreach (['layout' => [admin_t('Вид инфоблока'), 'iblock', ['table' => admin_t('Таблица'), 'phones' => admin_t('Телефоны')]],
                'provider' => [admin_t('Карты'), 'map', ['' => admin_t('По умолчанию'), 'yandex' => admin_t('Яндекс Карты'), 'google' => 'Google Maps']],
                'mode' => [admin_t('Режим'), 'map', ['' => admin_t('По умолчанию')] + site_map_modes()]] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <select data-editor-param="<?= $key ?>">
                        <?php foreach ($field[2] as $value => $label): ?><option value="<?= $value ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                    </select>
                </label>
            <?php endforeach; ?>
            <?php foreach (site_component_schema() as $kind => $definition): ?>
                <?php foreach ($definition['settings'] as $name => $field): ?>
                    <label class="field" data-editor-show="<?= site_escape($kind) ?>"><?= admin_l($field['label']) ?>
                        <select data-editor-option="<?= site_escape($name) ?>">
                            <option value=""><?= admin_l('По умолчанию') ?></option>
                            <?php foreach ($field['options'] as $option => $label): ?><option value="<?= site_escape($option) ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <p class="hint" data-editor-feedback role="status"></p>
        <button type="button" data-editor-insert-button><?= admin_l('Вставить в текст') ?></button>
    </details>
    <details data-editor-media hidden>
        <summary><?= admin_l('Фотографии и файлы компонентов') ?></summary>
        <label class="field"><?= admin_l('Папка компонента') ?> <select data-media-folder></select></label>
        <div class="header-actions">
            <input type="file" multiple data-media-upload aria-label="<?= admin_l('Выберите файлы для загрузки') ?>">
            <button type="button" data-media-upload-button><?= admin_l('Загрузить файлы') ?></button>
        </div>
        <p class="hint" role="status" data-media-feedback></p>
        <ol class="media-list" data-media-list></ol>
    </details>
</div>
