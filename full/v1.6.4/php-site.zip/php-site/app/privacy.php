<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_default_privacy_page(string $body): string
{
    $header = <<<'PAGE'
<?php
$pageFile = __FILE__;
require __DIR__ . '/../index.php';
__halt_compiler();
Title: Политика конфиденциальности
Heading: Политика конфиденциальности
MenuVisible: 0
Order: 900
PAGE;
    return $header . "\n\n" . $body . "\n";
}

function site_privacy_migration_body(): string
{
    try {
        foreach (site_read_record(SITE_DOMAINS_FILE) as $host) {
            if (is_string($host) && isset(site_read_snippets($host)['privacy'])) {
                return '[privacy-content]';
            }
        }
        $local = site_read_snippets()['privacy'] ?? [];
        if (($local['mode'] ?? '') === 'php' || is_file(SITE_ROOT . '/templates/local/privacy.php')) {
            return '[privacy-content]';
        }
        if (($local['mode'] ?? '') !== 'stock' && is_string($local['value'] ?? null)) {
            return $local['value'];
        }
    } catch (RuntimeException $exception) {
        return '[privacy-content]';
    }
    return <<<'HTML'
<p>Эта страница описывает обработку данных при использовании сайта [site-name] · [site-url].</p>
<h2>Сообщения и заявки</h2>
<p>Когда вы отправляете форму, сайт сохраняет введённые данные для обработки вашего обращения. Для связи по поводу данных используйте контакты на сайте.</p>
<h2>Файлы cookie</h2>
<p>Служебные файлы cookie нужны для сеанса, защиты форм и хранения выбранных настроек. Согласие на встроенные карты и аналитику можно изменить в подвале.</p>
HTML;
}

function site_install_privacy_page(): bool
{
    $installed = SITE_ROOT . '/app/.privacy-installed.php';
    if (is_file($installed)) {
        return true;
    }
    $directory = SITE_ROOT . '/privacy';
    $file = $directory . '/index.php';
    if (is_link($directory) || is_link($file) || (!is_dir($directory) && !@mkdir($directory, 0755) && !is_dir($directory))) {
        return false;
    }
    if (!is_file($file)) {
        $handle = @fopen($file, 'xb');
        if ($handle === false) {
            return false;
        }
        $source = site_default_privacy_page(site_privacy_migration_body());
        try {
            $written = @fwrite($handle, $source) === strlen($source);
        } finally {
            fclose($handle);
        }
        if (!$written) {
            @unlink($file);
            return false;
        }
    }
    $legacy = SITE_ROOT . '/privacy.php';
    $legacyStub = "<?php\ndefine('SITE_ROOT', __DIR__);\nrequire SITE_ROOT . '/app/site.php';\nsite_render(__FILE__);";
    if (is_file($legacy) && !is_link($legacy)) {
        $bytes = @file_get_contents($legacy, false, null, 0, 512);
        if (is_string($bytes) && rtrim(str_replace("\r\n", "\n", $bytes)) === $legacyStub && !@unlink($legacy)) {
            return false;
        }
    }
    return @file_put_contents($installed, "<?php http_response_code(404); exit;\n", LOCK_EX) !== false;
}

function site_cookie_permissions(): string
{
    $mode = $_COOKIE['FILE_SITE_CONSENT'] ?? null;
    return in_array($mode, ['essential', 'analytics', 'maps', 'all'], true) ? $mode : '';
}
