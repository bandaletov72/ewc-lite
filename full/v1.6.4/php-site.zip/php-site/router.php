<?php
if (PHP_SAPI !== 'cli-server') {
    http_response_code(404);
    exit;
}

$request = explode('?', $_SERVER['REQUEST_URI'] ?? '/', 2)[0];
$path = str_replace('\\', '/', rawurldecode($request));
$segments = [];
foreach (explode('/', $path) as $part) {
    if (DIRECTORY_SEPARATOR === '\\') {
        $part = rtrim($part, ' ');
    }
    if ($part === '..') {
        array_pop($segments);
    } elseif ($part !== '' && $part !== '.') {
        $segments[] = DIRECTORY_SEPARATOR === '\\' ? rtrim($part, '.') : $part;
    }
}

$root = strtolower($segments[0] ?? '');
$second = strtolower($segments[1] ?? '');
if (in_array($root, ['data', 'extensions', 'router.php', 'functions.php'], true)
    || ($root === 'app' && $second === 'extensions') || ($root === 'admin' && $second === 'languages')) {
    http_response_code(404);
    exit;
}
if (preg_match('~\A/privacy\.php(?:/|$)~i', $path)) {
    http_response_code(404);
    return true;
}
if (preg_match('~\A/(?:[A-Za-z0-9_-]+/)*index_[a-z]{2}\.php\z~', $path)
    && !is_file(__DIR__ . $path)) {
    $_SERVER['SCRIPT_NAME'] = '/app/page-language.php';
    require __DIR__ . '/app/page-language.php';
    return true;
}

return false;
