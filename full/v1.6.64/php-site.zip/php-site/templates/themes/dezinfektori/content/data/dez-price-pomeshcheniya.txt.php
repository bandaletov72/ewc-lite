<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Дезинфекция квартиры|3500
Дезинфекция частного дома|5500
Дезинфекция офиса|6000
