<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Осмотр заведения|3500
Обработка кухни и подсобки|6500
Комплексная обработка ресторана|10000
