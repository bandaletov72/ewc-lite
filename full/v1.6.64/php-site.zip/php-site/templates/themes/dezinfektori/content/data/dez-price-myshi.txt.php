<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Осмотр и план работ|2200
Обработка квартиры|3500
Обработка частного дома|5000
