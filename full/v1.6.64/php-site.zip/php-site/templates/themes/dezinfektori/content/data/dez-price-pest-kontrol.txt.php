<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Аудит объекта|4500
Разовый выезд и мониторинг|6500
Абонентское обслуживание за месяц|12000
