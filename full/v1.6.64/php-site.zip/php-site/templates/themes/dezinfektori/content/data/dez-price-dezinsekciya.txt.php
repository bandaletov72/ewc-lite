<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Дезинсекция квартиры|2500
Дезинсекция частного дома|4500
Дезинсекция офиса|5000
