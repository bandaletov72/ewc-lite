<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Осмотр участка|2500
Работы на участке до 6 соток|5500
Работы на участке до 12 соток|8500
