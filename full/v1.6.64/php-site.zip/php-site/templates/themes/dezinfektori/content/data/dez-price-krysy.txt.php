<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Осмотр следов и мест проникновения|2500
Обработка частного дома|5500
Обработка склада|8500
