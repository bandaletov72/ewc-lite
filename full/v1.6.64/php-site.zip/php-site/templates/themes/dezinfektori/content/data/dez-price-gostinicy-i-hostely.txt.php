<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Обработка отдельного номера|3000
Обработка общих зон|5500
Обработка группы номеров|9500
