<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Обработка одной зоны хранения|2400
Обработка нескольких шкафов|3600
Обработка квартиры|5000
