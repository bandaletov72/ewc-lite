<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Осмотр проблемной зоны|2300
Локальная обработка до 5 м²|3500
Обработка нескольких зон|6500
