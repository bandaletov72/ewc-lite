<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Обработка отдельной комнаты|2800
Обработка квартиры|4200
Обработка офисной зоны|6500
