<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Обработка одной комнаты|2300
Обработка квартиры|3400
Обработка дома|4800
