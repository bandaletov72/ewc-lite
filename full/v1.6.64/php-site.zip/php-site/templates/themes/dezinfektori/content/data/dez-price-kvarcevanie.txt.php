<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Оценка условий на объекте|2000
Обработка одной комнаты|3000
Обработка нескольких комнат|5000
