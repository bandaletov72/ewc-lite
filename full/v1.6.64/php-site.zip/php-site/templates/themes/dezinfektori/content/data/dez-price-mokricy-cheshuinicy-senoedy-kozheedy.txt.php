<?php http_response_code(404); exit; __halt_compiler();
service|price
Услуга|Ориентировочная цена
text|price
Обработка локальной зоны|2400
Обработка двух помещений|3600
Обработка квартиры|4900
