<?php if (!defined('SITE_ROOT')) { http_response_code(404); exit; } ?>
<?php
if (empty($searchMode) && $originalPath === 'services/dezinsekciya/klopy/index.php' && !empty($page['path'])) {
    $promotions = [
        ['form1641', 'Скидка 10%', 'на первый заказ через сайт',
            'Оставьте онлайн-заявку в течение суток после посещения сайта. Скидка действует на первый заказ.'],
        ['form1642', 'Скидка 15%', 'пенсионерам и людям с инвалидностью',
            'Скидка для льготных категорий Москвы действует на все услуги. Подтверждающий документ можно показать специалисту при выезде.'],
        ['form1643', 'Скидка до 15%', 'при заказе вместе с соседями',
            'Закажите обработку совместно. При заказе на два объекта скидка 10% для каждого, на три и более объекта — 15%.'],
    ];
    ob_start();
    ?>
    <section class="dz-section" id="offers" aria-labelledby="dz-offers-title">
        <h2 id="dz-offers-title">Акции и скидки</h2>
        <div class="dz-promotions">
            <?php foreach ($promotions as list($promotionForm, $discount, $shortTitle, $terms)): ?>
                <article class="dz-promotion">
                    <h3><span><?= site_escape($discount) ?></span> <?= site_escape($shortTitle) ?></h3>
                    <p><?= site_escape($terms) ?></p>
                    <div class="dz-promotion-action">
                        <?= site_component_action_button('action=form form=' . $promotionForm
                            . ' label="Участвовать" title="' . $discount . ' ' . $shortTitle . '"', $components) ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
    $promotionsHtml = (string) ob_get_clean();
    $content = preg_replace_callback('~<section\b[^>]*\s+id="offers"[^>]*>.*?</section>~s',
        static function () use ($promotionsHtml): string { return $promotionsHtml; }, $content, 1, $replacedOffers) ?? $content;
    if ($replacedOffers === 0 && strpos($content, 'id="offers"') === false) $content .= $promotionsHtml;
}
$dezHome = empty($searchMode) && $originalPath === 'index.php' && strpos($page['html'], 'id="dez-hero-title"') !== false;
$dezReviews = empty($searchMode) && strpos($originalPath, 'services/') === 0 && empty($components['reviewInstances'])
    ? site_component_reviews($components, true) : '';
?>
<main class="<?= empty($embeddedContent) ? 'container ' : '' ?>site-main dz-main<?= $dezHome ? ' dz-home' : '' ?>" id="content" lang="<?= site_escape($page['language'] ?? 'ru') ?>">
    <?php if (!$dezHome): ?><h1 class="dz-page-title"><?= site_escape($heading) ?></h1><?php endif; ?>
    <div class="page-content">
        <?php if ($dezReviews !== ''): ?>
            <p><a class="dz-button dz-button-soft" href="#dez-service-reviews"><?= site_escape(site_review_labels($locale)[9]) ?></a></p>
        <?php endif; ?>
        <?= $content ?>
        <?php if ($dezReviews !== ''): ?><div class="dz-section" id="dez-service-reviews"><?= $dezReviews ?></div><?php endif; ?>
    </div>
</main>
