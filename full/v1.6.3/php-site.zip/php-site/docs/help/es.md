# Español · Eurowebcart CMS Light

- [Gestión](es/readme.md)
- [Preguntas frecuentes del administrador](es/faq.md)
- [Plantillas y componentes](es/templates.md)

## Nuevo en la versión 1.6.3

### Inicio y política de privacidad

Abra "Plantillas de diseño" para editar la página de inicio y la página /privacy.php. El código [page-content] muestra el contenido de la página principal. En la política [site-name] y [site-url] toman el nombre y dirección pública de “Configuración → General”. Complete el texto inicial con información sobre su sitio y procesamiento de datos.

### Cookie y volver al principio

En el pie de página, [conf-policy] proporciona un enlace a la política, [cookies] abre la configuración y [top] se desplaza hasta la parte superior de la página. Los análisis y los mapas CMS integrados están a la espera de un acuerdo. Los scripts agregados manualmente a plantillas o encabezados de servicios requieren su propia configuración.

### Editor functions.php

Abra "Plantillas de diseño → Funciones" después de la pestaña "Encabezados de servicio". Agregue cierres a la matriz devuelta. En su plantilla PHP, llame a `translit("Москва")` o `ew_call("translit", "München")`. En HTML inserte [func=translit value="Москва и München"]. El ejemplo produce `Moskva i Muenchen`.

### Editar plantillas estándar

En el campo "Plantillas de diseño" ya contiene el código fuente PHP y HTML resaltado. Al editar una plantilla estándar, seleccione "PHP personalizado". Al guardar se crea una versión personalizada. Usando los botones al lado de la plantilla, puede deshacer la última edición o restaurar el original.

### Verificación de PHP antes de guardar

Los editores de plantillas de diseño, módulos y functions.php verifican la sintaxis con el comando `php -l`. Si hay un error, se mantiene la versión anterior. Para seleccionar la CLI de PHP en el servidor, utilice la variable `SITE_PHP_LINT_BINARY`.

### Retroiluminación y búsqueda compacta.

CodeMirror está habilitado de forma predeterminada en instalaciones nuevas. La configuración se encuentra en "Bibliotecas y fuentes". En la búsqueda compacta, el campo se expande hacia la izquierda, la cruz borra la línea y la tecla Intro inicia la búsqueda.

### Menú de administración y panel de edición

El menú debajo del encabezado del panel de administración y el panel de edición del sitio muestran íconos con subtítulos. Los iconos permanecen en la pantalla estrecha. La información sobre herramientas se abre al pasar el mouse y el teclado se enfoca en una pantalla estrecha. “Ocultar” se encuentra junto al resto de acciones de la página. El interruptor del modo de edición se encuentra a la derecha.

### Descripción y código del módulo PHP.

En "Módulos PHP", la breve descripción es para texto sin formato. Pegue el cuerpo de la función en un campo separado “Código fuente · PHP”.

## Nuevo en la versión 1.6.2

### Idioma de administrador y ayuda.

En la configuración regional, habilite los idiomas deseados. El menú de selección de idioma en el encabezado cambia la interfaz y la ayuda, manteniendo la sección actual. Los textos de las páginas y los valores de su configuración se almacenan en su forma original.

### Decoración del sótano

El código [author] muestra la firma Eurowebcart CMS Light, el nombre del autor Бандалетов Павел y un enlace a GitHub. Para elegir dónde colocar su firma en su pie de página HTML personalizado, pegue [author] en la línea correspondiente.

### Luz de fondo en modo de edición

Pase el cursor sobre el enlace Editar componente o establezca el foco del teclado en él. El marco resaltará el resultado de este inserto en particular.

### Dónde cambiar la búsqueda

En “Configuración → General” seleccione el tipo de búsqueda. En "Mantenimiento" puede volver a indexar páginas y el campo en el encabezado del administrador busca por configuración.

### Resultados y sugerencias

La búsqueda muestra 20 resultados numerados por página. El campo compacto se abre a la izquierda de la lupa con un icono Intro dentro. Las sugerencias de administración enlazan directamente a los ajustes.

## Novedades de la versión 1.6.1

### Búsqueda

En General puedes desactivar la búsqueda o elegir lupa o campo ampliado. La cabecera de administración busca ajustes. El índice se actualiza tras editar; para FTP se puede programar. Se indexan páginas incluidas y bloques de datos sin ejecutar módulos PHP.

### Módulos PHP

Despliega un módulo para ver ajustes y páginas que lo usan. Indica identificador, nombre del archivo y cuerpo de función. Al renombrar el archivo se mantiene [php]id[/php]. Activa CodeMirror para resaltar sintaxis.

### Plantillas y traducciones

Deshaz hasta ocho cambios por plantilla o restablece el PHP original. Cada dominio tiene su propio historial. Usa HTML personalizado en la administración y templates/local/ para PHP. Puedes cambiar de idioma al crear una traducción; las traducciones guardadas se trasladan con la página.

### Integraciones y mantenimiento

CAPTCHA, mapas, telefonía y analítica enlazan a la documentación de sus proveedores. Configura URL y token HTTP de la devolución de llamada. Los ajustes de un subdominio registrado se mantienen al pasar al dominio principal. Ejecuta php update.php --scheduled cada 15 minutos.

## Novedades de la versión 1.6.0

### Búsqueda y caché

Reconstruye el índice de texto en Mantenimiento después de publicar o editar páginas desde la administración o por FTP. Las sugerencias usan las páginas públicas en el idioma del visitante. La caché está desactivada de forma predeterminada y se administra allí. Los formularios y bloques dinámicos se procesan en cada solicitud.

### Edición en el sitio

Tras iniciar sesión, la barra superior tiene un interruptor a la derecha para editar componentes en todo el sitio. CSS y JS de la página se editan en un cuadro modal. La administración ofrece modos HTML y visual, inserción de códigos y carga masiva y ordenación de archivos mediante AJAX.

### Componentes y navegación

Sin parámetros se usan los ajustes globales. width admite 100, 50, 33 o 25, con o sin %. Los bloques se apilan en móviles. numbers=off oculta el contador. Desliza para cambiar de foto. El menú móvil sale de la derecha y las migas de pan pueden desactivarse en ajustes generales.

```text
[gal width=50 numbers=off arrows=on fit=cover]/images/myfotos/[/gal]
[fotos width=50% columns=3 captions=on]/images/myfotos/[/fotos]
[files width=33 icons=off size=on download=on]/files/myfiles/[/files]
```

### Idiomas, apariencia y precios

Elige idiomas, moneda, formatos y zona horaria en ajustes regionales. Guarda index_en.php junto a index.php para traducir una página; si falta, se muestra el texto original. El campo Precio usa la moneda seleccionada. Previsualiza las paletas y el modo, sube los logotipos claro y oscuro y prueba Roboto Condensed con tu propia frase.

```text
/contacts/index.php → /contacts/index_en.php
```

### Formularios, solicitudes e integraciones

Configura claves de Google reCAPTCHA v2 globales o por formulario. Mensajes y llamadas muestran 20 entradas y priorizan las no leídas. Integraciones incluye Zadarma, Telegram, analítica y mapas Google o Yandex con agrupación opcional. El cuadro de bibliotecas prueba la versión activa y muestra el código. CodeMirror ofrece Auto, HTML, CSS, JS, PHP y RAW.

```text
[map lat=55.7558 lng=37.6173 title="Office" zoom=13 provider=yandex url="/contacts/" button="Open"]
```

```text
[callback button="Call me" title="Callback" submit="Send" placeholder="+7(900)123-45-67"]
```

### Módulos PHP

En Módulos PHP, edita el nombre, la descripción y la disponibilidad. server-date muestra la fecha con el formato regional. Los desarrolladores instalan los archivos ejecutables en una carpeta protegida.

```text
[php]server-date[/php]
```

