<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$index = site_search_index();
?>
<h1><?= admin_l('Обслуживание') ?></h1>
<div class="form-stack">
    <form method="post" action="<?= site_escape($maintenanceUrl) ?>" class="panel form-stack" id="search-index-settings">
        <h2><?= admin_l('Индексация разделов и страниц') ?></h2>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <p><?= site_escape(admin_l('Страниц в индексе')) ?> — <?= count($index['pages'] ?? []) ?></p>
        <?php if (isset($index['built'])): ?>
            <p><time datetime="<?= date('c', $index['built']) ?>"><?= site_escape(date(site_region_settings()['date'] . ' ' . site_region_settings()['time'], $index['built'])) ?></time></p>
        <?php endif; ?>
        <p class="hint"><?= admin_l('После правок в админке индекс обновляется автоматически. Для файлов, изменённых по FTP, используйте расписание или кнопку ниже.') ?></p>
        <div><button class="button-primary" type="submit" name="action" value="index-pages"><?= site_escape(admin_l('Перестроить индекс')) ?></button></div>
    </form>
    <?php $jobs = admin_jobs_settings(); ?>
    <form method="post" action="<?= site_escape($maintenanceUrl) ?>" class="panel form-stack">
        <h2><?= admin_l('Обслуживание по расписанию') ?></h2>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="action" value="save-jobs">
        <label class="choice"><input type="checkbox" name="index" value="1"<?= $jobs['index'] ? ' checked' : '' ?>> <?= admin_l('Переиндексировать страницы каждые 15 минут') ?></label>
        <label class="field"><?= admin_l('Интервал обновления с GitHub') ?>
            <select name="updates">
                <option value="0"<?= !$jobs['updates'] ? ' selected' : '' ?>><?= admin_l('Выключен') ?></option>
                <?php foreach ([1, 6, 12, 24] as $hours): ?>
                    <option value="<?= $hours ?>"<?= $jobs['updates'] === $hours ? ' selected' : '' ?>><?= $hours ?> <?= admin_l('ч') ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <p class="hint"><?= admin_l('Добавьте команду в планировщик сервера с запуском каждые 15 минут.') ?> <code>php update.php --scheduled</code></p>
        <div><button class="button-primary"><?= admin_l('Сохранить') ?></button></div>
    </form>
    <form method="post" action="<?= site_escape($maintenanceUrl) ?>" class="panel form-stack">
        <h2><?= site_escape(admin_l('Кеш страниц')) ?></h2>
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <label class="choice"><input type="checkbox" name="cache" value="1"<?= site_performance_settings()['cache'] ? ' checked' : '' ?>>
            <?= site_escape(admin_l('Кешировать контент')) ?></label>
        <p class="hint"><?= site_escape(admin_l('Кеш хранит разобранные страницы. Формы и динамические компоненты обрабатываются при каждом запросе.')) ?></p>
        <div class="header-actions">
            <button class="button-primary" type="submit" name="action" value="save-cache"><?= site_escape(admin_l('Сохранить')) ?></button>
            <button type="submit" name="action" value="clear-cache"><?= site_escape(admin_l('Очистить кеш')) ?></button>
        </div>
    </form>
</div>
