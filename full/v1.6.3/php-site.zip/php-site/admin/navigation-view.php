<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$appearanceSections = ['layout', 'headers', 'functions', 'assets'];
$settingsSections = ['settings', 'contacts', 'theme', 'components', 'updates', 'libraries', 'region', 'captcha'];
$groups = [
    'Содержимое' => [
        'snippets' => ['Подшаблоны', $snippetsUrl],
        'iblocks' => ['Инфоблоки', $iblocksUrl],
        'modules' => ['PHP-модули', $modulesUrl],
    ],
    'Формы и заявки' => [
        'forms' => ['Формы', $formsUrl],
        'messages' => ['Сообщения', $messagesUrl],
        'callbacks' => ['Обратные звонки', $callbacksUrl],
        'spam' => ['Антиспам', $spamUrl],
    ],
    'Сайт и сервисы' => [
        'domains' => ['Домены', $domainsUrl],
        'integrations' => ['Интеграции', $integrationsUrl],
        'maintenance' => ['Обслуживание', $maintenanceUrl],
    ],
];
$groupIcons = ['Содержимое' => 'layer-group', 'Формы и заявки' => 'inbox', 'Сайт и сервисы' => 'screwdriver-wrench'];
$navigation = [
    ['Страницы', 'file-lines', $adminUrl, $section === 'pages'],
    ['Настройки', 'gear', $settingsUrl, in_array($section, $settingsSections, true)],
    ['Шаблоны оформления', 'palette', $layoutEditorUrl, in_array($section, $appearanceSections, true)],
];
?>
<nav class="site-menu admin-menu" aria-label="<?= admin_l('Разделы админки') ?>">
    <?php foreach ($navigation as list($label, $icon, $url, $current)): ?>
        <a class="admin-nav-item" data-nav-tooltip="<?= admin_l($label) ?>" href="<?= site_escape($url) ?>"<?= $current ? ' aria-current="page"' : '' ?>>
            <i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l($label) ?></span>
        </a>
    <?php endforeach; ?>
    <?php foreach ($groups as $label => $links): ?>
        <details class="admin-nav-group"<?= isset($links[$section]) ? ' data-current' : '' ?>>
            <summary class="admin-nav-item" data-nav-tooltip="<?= admin_l($label) ?>">
                <i class="fa-solid fa-<?= $groupIcons[$label] ?>" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l($label) ?></span>
            </summary>
            <div class="admin-nav-links">
                <?php foreach ($links as $name => list($title, $url)): ?>
                    <a href="<?= site_escape($url) ?>"<?= $section === $name ? ' aria-current="page"' : '' ?>><?= admin_l($title) ?></a>
                <?php endforeach; ?>
            </div>
        </details>
    <?php endforeach; ?>
    <a class="admin-nav-item" data-nav-tooltip="<?= admin_l('Помощь') ?>" href="<?= site_escape($helpUrl) ?>"<?= $section === 'help' ? ' aria-current="page"' : '' ?>>
        <i class="fa-solid fa-circle-question" aria-hidden="true"></i><span class="admin-nav-label"><?= admin_l('Помощь') ?></span>
    </a>
</nav>
