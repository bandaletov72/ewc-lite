<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<section class="panel form-stack theme-presets">
    <h2><?= $layoutHost === '' ? admin_t('Общие шаблоны') : admin_t('Шаблоны · ') . site_escape($layoutHost) ?></h2>
    <form class="form-stack" method="post" action="<?= site_escape($layoutUrl) ?>">
        <input type="hidden" name="action" value="save-domain-templates">
        <input type="hidden" name="csrf" value="<?= site_escape($token) ?>">
        <input type="hidden" name="revision" value="<?= site_escape($layoutRevision) ?>">
        <?php foreach (admin_domain_template_labels() as $name => $label): ?>
            <?php $block = $layoutDraft[$name]; ?>
            <fieldset class="field-config form-stack" id="layout-<?= site_escape($name) ?>">
                <legend><?= admin_l($label) ?> <code>[<?= site_escape($name) ?>]</code></legend>
                <?php if ($name === 'home'): ?>
                    <p class="hint"><?= admin_l('Код [page-content] вставляет содержимое главной страницы в шаблон.') ?></p>
                <?php elseif ($name === 'privacy'): ?>
                    <p class="hint"><a href="<?= site_escape(site_url($base, 'privacy.php')) ?>"><?= admin_l('Открыть страницу политики') ?></a>
                        <?= admin_l('Доступны [site-name] и [site-url].') ?></p>
                <?php elseif ($name === 'cookies'): ?>
                    <p class="hint"><?= admin_l('Сохраните атрибуты data-cookie-preferences, data-cookie-option и data-cookie-choice в своём HTML, чтобы кнопки согласия работали.') ?></p>
                <?php endif; ?>
                <p class="hint"><?= admin_l('Исходный файл') ?> <code>templates/<?= site_escape(site_layout_blocks()[$name]) ?></code></p>
                <div class="field">
                    <label for="<?= $name ?>-source"><?= admin_l('Источник шаблона') ?></label>
                    <select id="<?= $name ?>-source" name="blocks[<?= $name ?>][mode]">
                        <option value="inherit"<?= $block['mode'] === 'inherit' ? ' selected' : '' ?>><?= admin_l($layoutHost === '' ? admin_t('Штатный шаблон') : admin_t('Общий шаблон')) ?></option>
                        <option value="php"<?= $block['mode'] === 'php' ? ' selected' : '' ?>><?= admin_l('Свой PHP') ?></option>
                        <option value="custom"<?= $block['mode'] === 'custom' ? ' selected' : '' ?>><?= admin_l('Свой HTML') ?></option>
                        <option value="stock"<?= $block['mode'] === 'stock' ? ' selected' : '' ?>><?= admin_l('Исходный PHP-шаблон') ?></option>
                    </select>
                </div>
                <div class="header-actions">
                    <button type="submit" name="block_action" value="undo:<?= $name ?>" formnovalidate<?= empty($ownLayouts['_layoutHistory'][$name]) ? ' disabled' : '' ?>><?= admin_l('Отменить последнее изменение') ?></button>
                    <button type="submit" name="block_action" value="reset:<?= $name ?>" formnovalidate<?= $block['mode'] === 'stock' ? ' disabled' : '' ?>><?= admin_l('Вернуть исходный шаблон') ?></button>
                </div>
                <div class="field">
                    <label for="<?= $name ?>-code"><?= admin_l('Код шаблона (PHP и HTML)') ?></label>
                    <textarea id="<?= $name ?>-code" class="short-editor" data-layout-editor="<?= $name ?>-source" data-code-mode="<?= $block['mode'] === 'custom' ? 'html' : 'php-mixed' ?>" rows="10" spellcheck="false" name="blocks[<?= $name ?>][value]"><?= "\n" . site_escape($block['value']) ?></textarea>
                    <small class="hint"><?= admin_l('Редактируйте исходник прямо здесь. Режим «Свой PHP» сохраняет вашу версию после проверки синтаксиса. Для разметки с подшаблонами [city] и [tg] можно выбрать «Свой HTML».') ?></small>
                </div>
            </fieldset>
        <?php endforeach; ?>
        <div><button class="button-primary" type="submit"><?= admin_l('Сохранить шаблоны') ?></button></div>
    </form>
</section>
