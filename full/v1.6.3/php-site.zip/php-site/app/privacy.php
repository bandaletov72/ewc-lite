<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}

function site_privacy_bootstrap(): string
{
    return "<?php\ndefine('SITE_ROOT', __DIR__);\nrequire SITE_ROOT . '/app/site.php';\nsite_render(__FILE__);\n";
}

function site_install_privacy_page(): bool
{
    $file = SITE_ROOT . '/privacy.php';
    if (is_link($file)) {
        return false;
    }
    if (is_file($file)) {
        return true;
    }
    $handle = @fopen($file, 'xb');
    if ($handle === false) {
        return is_file($file) && !is_link($file);
    }
    $source = site_privacy_bootstrap();
    try {
        $written = @fwrite($handle, $source) === strlen($source);
    } finally {
        fclose($handle);
    }
    if (!$written) {
        @unlink($file);
    }
    return $written;
}

function site_cookie_permissions(): string
{
    $mode = $_COOKIE['FILE_SITE_CONSENT'] ?? null;
    return in_array($mode, ['essential', 'analytics', 'maps', 'all'], true) ? $mode : '';
}
