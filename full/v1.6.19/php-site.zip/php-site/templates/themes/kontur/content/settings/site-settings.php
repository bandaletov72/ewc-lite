<?php http_response_code(404); exit; __halt_compiler();
{
    "name": "КОНТУР",
    "subtitle": "Архитектурное бюро",
    "description": "Архитектура, интерьеры и предметы для дома.",
    "footer": "© [year] КОНТУР · Демонстрационная тема",
    "searchMode": "compact",
    "scrollAnimation": "fade"
}
