<?php
if (!defined('SITE_ROOT')) {
    http_response_code(404);
    exit;
}
$layouts = array_diff(array_keys(site_layout_blocks()), ['conf-policy']);
$layouts = array_merge($layouts, ['page-content', 'privacy-content']);
$tokens = array_values(array_diff(array_unique(array_merge(['payment', 'sections', 'author', 'site-name', 'site-url'], array_keys(site_date_snippets()), ['dmY'],
    array_keys(site_snippet_values($currentHost)), array_keys($siteSettings['variables']), array_keys(site_contact_tokens()))), $layouts, ['conf-policy']));
$iconTokens = array_keys(site_contact_tokens());
try { $editorForms = site_forms(); } catch (RuntimeException $exception) { $editorForms = site_default_forms(); }
try { $editorLibraries = site_library_settings(site_read_record(SITE_LIBRARIES_FILE)); } catch (RuntimeException $exception) { $editorLibraries = site_library_settings(); }
$canInsertFA = $editorLibraries['enabled']['fontawesome'];
$editorLabels = admin_editor_labels($adminLanguage);
?>
<div class="field field-wide" data-content-editor>
    <label for="html"><?= admin_l('Содержимое страницы') ?></label>
    <div class="header-actions" data-editor-toolbar hidden>
        <button type="button" data-editor-mode="html" aria-pressed="true">HTML</button>
        <button type="button" data-editor-mode="visual" aria-pressed="false"><?= admin_l('Визуальный редактор') ?></button>
    </div>
    <div class="header-actions" data-editor-format hidden>
        <?php foreach (['bold' => ['bold', admin_t('Жирный')], 'italic' => ['italic', admin_t('Курсив')],
            'underline' => ['underline', $editorLabels['underline']], 'strikeThrough' => ['strikethrough', $editorLabels['strike']],
            'insertUnorderedList' => ['list-ul', admin_t('Маркированный список')], 'insertOrderedList' => ['list-ol', $editorLabels['numbered']],
            'createLink' => ['link', admin_t('Ссылка')]] as $command => list($icon, $label)): ?>
            <button class="editor-tool" type="button" data-editor-command="<?= $command ?>" title="<?= site_escape($label) ?>" aria-label="<?= site_escape($label) ?>"><i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i></button>
        <?php endforeach; ?>
        <?php for ($level = 1; $level <= 5; $level++): ?>
            <?php $headingLabel = $editorLabels['heading'] . ' H' . $level; ?>
            <button class="editor-tool" type="button" data-editor-command="formatBlock" data-editor-value="h<?= $level ?>" title="<?= site_escape($headingLabel) ?>" aria-label="<?= site_escape($headingLabel) ?>">H<?= $level ?></button>
        <?php endfor; ?>
        <?php foreach (['template' => ['layer-group', $editorLabels['template']], 'component' => ['puzzle-piece', $editorLabels['component']],
            'image' => ['image', $editorLabels['image']], 'icon' => ['icons', $editorLabels['icon']]] as $picker => list($icon, $label)): ?>
            <button class="editor-tool" type="button" data-editor-open="<?= $picker ?>" title="<?= site_escape($label) ?>" aria-label="<?= site_escape($label) ?>" aria-controls="editor-picker-<?= $picker ?>" aria-expanded="false"><i class="fa-solid fa-<?= $icon ?>" aria-hidden="true"></i></button>
        <?php endforeach; ?>
    </div>
    <textarea id="html" name="html" data-code-mode="html" spellcheck="false" rows="12"><?= "\n" . site_escape($page['html']) ?></textarea>
    <iframe data-editor-frame hidden sandbox="allow-same-origin"
        data-src="<?= site_escape(site_url($base, 'templates/editor-frame.php')) ?>" title="<?= admin_l('Визуальный редактор страницы') ?>"></iframe>
    <div class="panel form-stack" id="editor-picker-template" data-editor-picker="template" hidden>
        <h3><?= site_escape($editorLabels['template']) ?></h3>
        <label class="field"><?= admin_l('Шаблоны') ?>
            <select data-editor-template>
                <?php foreach ([admin_t('Шаблоны') => $layouts, admin_t('Подшаблоны') => $tokens] as $label => $options): ?>
                    <optgroup label="<?= site_escape($label) ?>">
                        <?php foreach ($options as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                    </optgroup>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button type="button" data-editor-add-template><?= admin_l('Вставить в текст') ?></button></div>
    </div>
    <div class="panel form-stack" id="editor-picker-component" data-editor-picker="component" hidden>
        <h3><?= site_escape($editorLabels['component']) ?></h3>
        <div class="fields">
            <label class="field"><?= admin_l('Компонент') ?>
                <select data-editor-component>
                    <?php foreach (['gal' => admin_t('Карусель'), 'fotos' => admin_t('Фотогалерея'), 'files' => admin_t('Список файлов'),
                        'include' => admin_t('Другая страница'), 'form' => admin_t('Форма'), 'callback' => admin_t('Обратный звонок'),
                        'iblock' => admin_t('Инфоблок'), 'map' => admin_t('Точка на карте'), 'maps' => $discoveryLabels['all-maps'], 'php' => admin_t('PHP-модули')] as $key => $label): ?>
                        <option value="<?= $key ?>"><?= admin_l($label) ?></option>
                    <?php endforeach; ?>
                    <?php foreach (site_extensions() as $tag => $definition): ?>
                        <?php if (isset(site_php_module_settings()[$tag]) || site_php_module_source($tag)[1] !== '') continue; ?>
                        <option value="extension:<?= site_escape($tag) ?>" data-kind="<?= site_escape($definition['kind']) ?>"><?= site_escape($definition['label'] ?? $tag) ?> [<?= site_escape($tag) ?>]</option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="extension"><?= admin_l('Значение') ?><input data-editor-param="extension-value"></label>
            <label class="field" data-editor-show="php"><?= site_escape(admin_l('PHP-модули')) ?>
                <select data-editor-param="module">
                    <?php foreach (site_extensions() as $name => $definition): ?>
                        <?php if (!site_php_module_enabled($name)) continue; ?>
                        <option value="<?= site_escape($name) ?>"><?= site_escape(site_php_module_settings()[$name]['label'] ?? admin_t($definition['label'] ?? $name)) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field" data-editor-show="form"><?= admin_l('Форма') ?>
                <select data-editor-param="form">
                    <?php foreach ($editorForms as $id => $definition): ?>
                        <?php if (!site_valid_form_id($id)) continue; ?>
                        <option value="<?= site_escape($id) ?>">[<?= site_escape($id) ?>] · <?= site_escape($definition['title'] ?? $definition['button'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <?php foreach ([
                'path' => [admin_t('Путь'), 'gal fotos files include iblock', '/images/myfotos/'],
                'title' => [admin_t('Название точки или заголовок формы'), 'map callback', admin_t('Офис')],
                'lat' => [admin_t('Широта'), 'map', '55.7558'],
                'lng' => [admin_t('Долгота'), 'map', '37.6173'],
                'zoom' => [admin_t('Масштаб'), 'map maps', '13'],
                'center' => [$discoveryLabels['map-center'], 'map maps', '55.7558,37.6173'],
                'url' => [admin_t('URL кнопки'), 'map', '/contacts/'],
                'button' => [admin_t('Текст кнопки'), 'map callback', admin_t('Подробнее')],
                'submit' => [admin_t('Текст кнопки отправки'), 'callback', admin_t('Отправить номер')],
                'placeholder' => [admin_t('Подсказка в поле телефона'), 'callback', '+7(900)123-45-67'],
            ] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <input data-editor-param="<?= $key ?>" placeholder="<?= site_escape($field[2]) ?>">
                </label>
            <?php endforeach; ?>
            <?php foreach (['layout' => [admin_t('Вид инфоблока'), 'iblock', ['table' => admin_t('Таблица'), 'phones' => admin_t('Телефоны')]],
                'provider' => [admin_t('Карты'), 'map maps', ['' => admin_t('По умолчанию'), 'yandex' => admin_t('Яндекс Карты'), 'google' => 'Google Maps']],
                'mode' => [admin_t('Режим'), 'map maps', ['' => admin_t('По умолчанию')] + site_map_modes()]] as $key => $field): ?>
                <label class="field" data-editor-show="<?= $field[1] ?>"><?= site_escape($field[0]) ?>
                    <select data-editor-param="<?= $key ?>">
                        <?php foreach ($field[2] as $value => $label): ?><option value="<?= $value ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                    </select>
                </label>
            <?php endforeach; ?>
            <?php foreach (site_component_schema() as $kind => $definition): ?>
                <?php foreach ($definition['settings'] as $name => $field): ?>
                    <label class="field" data-editor-show="<?= site_escape($kind) ?>"><?= admin_l($field['label']) ?>
                        <select data-editor-option="<?= site_escape($name) ?>">
                            <option value=""><?= admin_l('По умолчанию') ?></option>
                            <?php foreach ($field['options'] as $option => $label): ?><option value="<?= site_escape($option) ?>"><?= admin_l($label) ?></option><?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
        <div><button type="button" data-editor-insert-button><?= admin_l('Вставить в текст') ?></button></div>
    </div>
    <div class="panel form-stack" id="editor-picker-image" data-editor-picker="image" hidden>
        <h3><?= site_escape($editorLabels['image']) ?></h3>
        <label class="field">URL <input data-editor-image-url placeholder="/images/photo.jpg"></label>
        <label class="field"><?= site_escape($editorLabels['alt']) ?><input data-editor-image-alt></label>
        <div><button type="button" data-editor-add-image><?= admin_l('Вставить в текст') ?></button></div>
    </div>
    <div class="panel form-stack" id="editor-picker-icon" data-editor-picker="icon" hidden>
        <h3><?= site_escape($editorLabels['icon']) ?></h3>
        <label class="field"><?= site_escape($editorLabels['system-icons']) ?>
            <select data-editor-system-icon>
                <?php foreach ($iconTokens as $key): ?><option value="<?= site_escape($key) ?>">[<?= site_escape($key) ?>]</option><?php endforeach; ?>
                <?php foreach (['site.png', 'contact/phone.png', 'contact/tg.png', 'contact/vk.png', 'contact/whatsapp.png', 'contact/youtube.png', 'contact/instagram.png', 'contact/max.png'] as $file): ?>
                    <option value="<?= site_escape(site_url($base, 'templates/icons/' . $file)) ?>"><?= site_escape($file) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <div><button type="button" data-editor-add-system-icon><?= admin_l('Вставить в текст') ?></button></div>
        <?php if ($canInsertFA): ?>
            <label class="field">Font Awesome
                <input list="editor-fa-icons" data-editor-fa-icon placeholder="solid:house" autocomplete="off">
                <datalist id="editor-fa-icons">
                    <?php foreach ((require SITE_ROOT . '/app/editor-icons.php') as $style => $names): ?>
                        <?php foreach ($names as $name): ?><option value="<?= $style ?>:<?= site_escape($name) ?>"></option><?php endforeach; ?>
                    <?php endforeach; ?>
                </datalist>
            </label>
            <div><button type="button" data-editor-add-fa><?= admin_l('Вставить в текст') ?> Font Awesome</button></div>
        <?php endif; ?>
    </div>
    <p class="hint" data-editor-feedback role="status" hidden></p>
    <details data-editor-media hidden>
        <summary><?= admin_l('Фотографии и файлы компонентов') ?></summary>
        <label class="field"><?= admin_l('Папка компонента') ?> <select data-media-folder></select></label>
        <div class="header-actions">
            <input type="file" multiple data-media-upload aria-label="<?= admin_l('Выберите файлы для загрузки') ?>">
            <button type="button" data-media-upload-button><?= admin_l('Загрузить файлы') ?></button>
        </div>
        <p class="hint" role="status" data-media-feedback></p>
        <ol class="media-list" data-media-list></ol>
    </details>
</div>
